<?php

namespace App\Console\Commands;

use App\Models\UserCustomField;
use App\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Doctrine\DBAL\Driver\PDOConnection;

/**
 * This is a AUFC-specific custom importer.
 *
 * Requires all CSV files to be supplied at the same time from the command
 * line, this then attempts to merge them all and remove any duplicate records
 * with the same email or mobile number.
 *
 * @see AbstractCSVImport
 */
class ImportAUFCUser extends AbstractCSVImport
{
    /**
     * The name and signature of the console command.
     *
     * Example usage:
     *
     * sudo -u AUFC-engage php7.3 artisan engage:import-user-aufc --file=../../ingest/user_data.csv --force-commit
     *
     * add -v, -vv, -vvv on the end for debug info
     *
     * @var string
     */
    protected $signature = "engage:import-user-aufc\n" .
        "  {--file= : CSV file to import (neverTransacted)}\n" .
        "  {--db-test-mode : Test mode (only inserts 1000 records)}\n" .
        "  {--force-commit : Skip DB commit confirmation}";

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'CSV file import tool for Engage user data (AUFC)';

    protected $columns = [];
    protected $users;
    protected $usersAddresses;
    protected $userCustomFields;
    protected $totalInsertedUsers;
    protected $insertedUsers = 0;
    protected $insertedUserAddresses = 0;
    protected $totalInsertedUserAddresses;
    protected $insertedUserCustomFields = 0;

    /**
     * Execute the console command.
     *
     * This is considerably more complex than normal as we are attempting to
     * load, merge & de-duplicate multiple CSV files in memory before any
     * import to the database takes place.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->users = [];
        $this->usersAddresses = [];
        $this->userCustomFields = [];
        $this->headerLine = 2;

        $this->handleUserDataCSV();

        $this->info(
            sprintf(
                'Starting database operations (Changes will %s)',
                $this->option('force-commit') === true
                    ? 'be automatically committed'
                    : 'require manual confirmation before being committed'
            )
        );

        $this->insertUser();
        $this->insertUserAddress();
        $this->insertUserCustomField();

        $this->stopProgressTracking();
    }

    protected function insertUser() {
        $this->info('Starting to insert users into the database and elasticsearch');
        $this->totalInsertedUsers = sizeof($this->users);
        $this->insertedUsers = 0;
        $this->startProgressTracking($this->totalInsertedUsers);

        foreach ($this->users as $user) {
            $clientCustomerId = $user['client_customer_id'];
            unset($user['client_customer_id']);
            DB::table("users")->updateOrInsert([
                'client_customer_id' => $clientCustomerId
            ], $user);
        }

        $this->info('Finished inserting users into the database');
    }

    protected function insertUserAddress() {
        $this->info('Starting to insert user address into the database');

        foreach ($this->usersAddresses as $usersAddress) {
            $userId = DB::table('users')
                ->where('client_customer_id', $usersAddress['client_customer_id'])
                ->pluck('user_id')
                ->first();
            unset($usersAddress['client_customer_id']);
            DB::table("user_addresses")->updateOrInsert([
                'user_id' => $userId
            ], $usersAddress);
        }

        $this->info('Finished inserting user addresses into the database');
    }

    protected function insertUserCustomField() {
        $this->info('Starting to insert user custom field into the database');

        foreach ($this->userCustomFields as $userCustomField) {
            $userId = DB::table('users')
                ->where('client_customer_id', $userCustomField['client_customer_id'])
                ->pluck('user_id')
                ->first();
            $custom_field_id = $userCustomField['custom_field_id'];
            unset($userCustomField['client_customer_id']);
            unset($userCustomField['custom_field_id']);

            if ($userCustomField['multiselect_value'] !== null) {
                $customField = DB::table("user_custom_field_data")
                    ->where("user_id", $userId)
                    ->where("custom_field_id", $custom_field_id)
                    ->first();
                $newMultiSelectValue = [$userCustomField['multiselect_value']];
                if ($customField !== null && $customField->multiselect_value !== null) {
                    $newMultiSelectValue = json_decode($customField->multiselect_value);
                    foreach (json_decode($customField->multiselect_value) as $value) {
                        if ($value !== $userCustomField['multiselect_value']) {
                            array_push($newMultiSelectValue, $userCustomField['multiselect_value']);
                        }
                    }
                }

                $userCustomField['multiselect_value'] = json_encode($newMultiSelectValue);
            }

            DB::table("user_custom_field_data")->updateOrInsert([
                'user_id' => $userId,
                'custom_field_id' => $custom_field_id,
            ], $userCustomField);
        }

        $this->info('Finished inserting user custom fields into the database');
    }

    /**
     * This handles records from the 'vend' CSV file.
     *
     * The data in this CSV is ordered by the 'Last Sale Date' with the most
     * recent sales at the top.
     *
     * The most recent records are the important ones so if there are
     * duplicates later on for email or phone the most recent one wins.
     */
    public function handleUserDataCSV()
    {
        $this->columns = [
            'OrderId' => [],
            'Price' => [],
            'PPFee Internal' => [],
            'GrossValue' => [],
            'PriceNet' => [],
            'OrderLineDate' => [],
            'PackageName' => [],
            'VenueName' => [],
            'Section' => [],
            'Row' => [],
            'Seat' => [],
            'ChannelName' => [],
            'Seller' => [],
            'PricecategoryName' => [],
            'PricetypeName' => [],
            'Payment Method' => [],
            'TicketCount' => [],
            'UserName' => [],
            'Salutation' => [],
            'Firstname' => [],
            'LastName' => [],
            'PrimaryPhone' => [],
            'Gender' => [],
            'DateofBirth' => [],
            'EmailAddress' => [],
            'Addressline1' => [],
            'Addressline2' => [],
            'City' => [],
            'State' => [],
            'PostCode' => [],
            'CountryName' => [],
            'CustomerCompanyname' => [],
            'Membernumber' => [],
            'Customer ID' => [],
            'Membersince' => [],
            'ExternalID' => [],
            'Membershiptype' => [],
            'Expiry Date' => [],
            'Financial Status' => [],
            'PAHCustomerID' => [],
            'PahMembernumber' => [],
            'OrderbyCustomerfirstname' => [],
            'OrderbyCustomerlastname' => [],
            'OrderbyMembernumber' => [],
            'Delivery Type' => [],
        ];

        $this->validateBaseOptions('file');

        $existing_client_customer_ids = User::select('client_customer_id')->where('client_customer_id', '!=', null)->get();
        $existing_client_customer_id_map = array();
        foreach ($existing_client_customer_ids as $row) {
            $existing_client_customer_id_map[$row['client_customer_id']] = null;
        }

        $user_custom_fields = UserCustomField::all();
        $user_custom_fields_map = array();
        foreach ($user_custom_fields as $row) {
            $user_custom_fields_map[$row['field_name']] = $row;
        }

        foreach ($this->getNormalisedRows($this->option('file')) as $lineNumber => $row) {
            $user_first_name = $row['Firstname'];
            $user_family_name = $row['LastName'];
            $address_replace =  $row['Addressline1'];
            $address2_replace =  $row['Addressline2'];
            $state_replace =  $this->normaliseState($row['State']);
            $postal_code_replace =  $row['PostCode'];
            $city_replace =  $row['City'];
            $email =  $row['EmailAddress'];
            $member_type = 'Member';
            $dob = $this->normaliseDate($row['DateofBirth']);
            $gender = $this->normaliseGender($row['Salutation']);
            $client_customer_id = trim($row['Membernumber']);
            $updated_at = $this->normaliseDate($row['OrderLineDate']);
            $country_replace = trim($row['CountryName']);
            $user_mobile =  $this->normaliseMobile($row['PrimaryPhone'], $row['CountryName']);

            $custom_fields = collect([]);
            $custom_fields['subscriptions'] = $row['PackageName'];
            $custom_fields['season_membership'] = '2020/2021';
            $custom_fields["membership_type"] = $row['PricecategoryName'];
            $custom_fields["customerid"] = $row['Customer ID'];
            $custom_fields["sign_up_date"] = $this->normaliseDate($row['OrderLineDate']) ? $this->normaliseDate($row['OrderLineDate'])->format('Y-m-d') : null;

            $user_data = [
                'user_first_name' => $user_first_name,
                'user_family_name' => $user_family_name,
                'address_replace' => $address_replace,
                'address2_replace' => $address2_replace,
                'state_replace' => $state_replace,
                'postal_code' => $postal_code_replace,
                'country_replace' => $country_replace,
                'email' => $email,
                'city_replace' => $city_replace,
                'groups' => collect([$member_type]),
                'user_mobile' => $user_mobile,
                'dob' => $dob,
                'gender' => $gender,
                'client_customer_id' => $client_customer_id,
                'custom_fields' => collect($custom_fields),
                'is_active' => 1,
                'activation_token' => rand(111111, 999999),
                'created_at' => Carbon::now(),
                'device_token' => uniqid(true),
                'updated_at' => $updated_at
            ];

            $address_data = [
                'address' => $address_replace,
                'country' => $country_replace,
                'state' => $state_replace,
                'latitude' => 0,
                'longitude' => 0,
                'is_default' => 1,
                'address2' => $address2_replace,
                'postal_code' => $postal_code_replace,
                'client_customer_id' => $client_customer_id,
            ];

            $custom_fields_arr = $custom_fields->toArray();
            $custom_fields_data = array();
            foreach ($user_custom_fields_map as $key => $value) {
                if (array_key_exists($key, $custom_fields_arr)) {
                    if ($value['field_type'] === 'multiselect') {
                        array_push($custom_fields_data, [
                                'custom_field_id' => $value['id'],
                                'multiselect_value' => is_array($custom_fields_arr[$key]) ? json_encode($custom_fields_arr[$key]) : $custom_fields_arr[$key],
                                'client_customer_id' => $client_customer_id,
                                'value' => null
                            ]
                        );
                    } else {
                        array_push($custom_fields_data, [
                                'custom_field_id' => $value['id'],
                                'value' => is_array($custom_fields_arr[$key]) ? json_encode($custom_fields_arr[$key]) : $custom_fields_arr[$key],
                                'client_customer_id' => $client_customer_id,
                                'multiselect_value' => null
                            ]
                        );
                    }
                }
            }

            array_push($this->users, $user_data);
            array_push($this->usersAddresses, $address_data);
            $this->userCustomFields = array_merge($this->userCustomFields, $custom_fields_data);
        }
    }

    private function normaliseDate($rawDate)
    {
        $rawDate = trim($rawDate);
        if ($rawDate === null || $rawDate === '') {
            return null;
        }

        return Carbon::createFromFormat('d-M-Y', $rawDate);
    }

    private function normaliseGender($salutation)
    {
        $gender = strtolower(trim($salutation));
        if (in_array($gender, ['mr', 'm'])) {
            return 'male';
        } elseif (in_array($gender, ['ms', 'mrs', 'miss', 'f'])) {
            return 'female';
        } else {
            return 'other';
        }
    }

    /**
     * Normalise mobile numbers to the standard international format.
     *
     * @param string $number
     */
    protected function normaliseMobile($number, $country)
    {
        $number = preg_replace('/[^0-9]/', '', $number);

        if (empty($number)) {
            return null;
        }

        if (strtolower($country) === 'australia') {
            $number = "+61{$number}";
        }

        return $number;
    }

    /**
     * Normalise AU/NZ States
     *
     * @param mixed $state
     */
    protected function normaliseState($state)
    {
        return $state === null
            ? $state
            : strtoupper(trim($state));
    }
}
