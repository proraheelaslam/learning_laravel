<?php

namespace App\Console\Commands;

use App\Services\Tenant;
use App\Repositories\CategoryTypeRepository;
use App\Helpers\CSVFileHelper;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class ExportWuhuUser extends BaseCommand
{
    protected $users = [];
    protected $totalExportedRecords = 0;

    const DEFAULT_BATCH_SIZE = 1000;

    # Define CSV File Helper formats
    #
    protected $csvFileHelper;
    protected $csvFileFormats = [
        'wuhu_users' => [
            'delimiter' => ",",
            'header_rows' => 1,
            'validate' => false,
            'fields' => [
                'user_id', 'company_id', 'soldi_id', 'user_first_name', 'user_family_name',
                'user_mobile', 'email', 'gender', 'dob', 'user_avatar', 'created_at', 'user_type',
                'old_user', 'address', 'street_number', 'street_name', 'country', 'city', 'state',
                'suburb', 'latitude', 'longitude', 'address2', 'postal_code', 'address_type', 'password'
            ],
        ],
    ];

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = "engage:export-wuhu-user\n" .
        "  {--dirPath=     : [Required] Directory path to store exported CSV file}\n" .
        "  {--fileName=    : [Required] Exported CSV file name}\n" .
        "  {--erase        : Delete all existing user records in CSV file before export}\n" .
        "  {--limit=       : Records limit}\n";

    protected $requiredOptions = ['dirPath'];

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Export Wuhu users into CSV files';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

        // Initialise CSV file helper and load file specifications
        $this->csvFileHelper = new CSVFileHelper();
        foreach($this->csvFileFormats as $name => $detail) {
            $this->csvFileHelper->addFileSpecification($name, $detail);
        }
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        parent::handle();

        $exportedCSVDirPath = $this->option('dirPath');
        # Check the CSV ingestion file exists
        #
        if (!file_exists($this->option('dirPath'))) {
            $this->die("Directory path ${exportedCSVDirPath} does not exist");
        }

        $exportedCSVFilePath = $this->buildCSVExportedFilePath($exportedCSVDirPath);
        if ($this->option('erase')) {
            $fh = fopen( $exportedCSVFilePath, 'w' );
            fclose($fh);
        }
        $this->log("INFO: Exporting Wuhu users into CSV file at ${exportedCSVFilePath}");

        # Apply limit
        #
        $numberOfRecordsNeedToExport = $this->countRecordsNeedToExport();
        $batchSize = self::DEFAULT_BATCH_SIZE;
        $limit = $numberOfRecordsNeedToExport;

        if ($this->option('limit')) {
            $limit = intval($this->option('limit'));

            if ($limit > $numberOfRecordsNeedToExport) {
                $limit = $numberOfRecordsNeedToExport;
            }

            if ($batchSize > $limit) {
                $batchSize = $limit;
            }
        }

        $this->csvFileHelper->writeFileHeader($exportedCSVFilePath, 'wuhu_users');

        while ($this->totalExportedRecords < $limit) {
            $offset = $this->totalExportedRecords > 0 ? $this->totalExportedRecords + 1: $this->totalExportedRecords;
            $numRecordsToExport = min($limit - $this->totalExportedRecords, $batchSize);

            $this->log(sprintf('Exporting %d Wuhu users records to CSV file', $numRecordsToExport));
            $dataToExport = $this->prepareDataToExport($numRecordsToExport, $offset);

            $this->csvFileHelper->writeFile(
                $exportedCSVFilePath,
                'wuhu_users',
                $dataToExport,
                $limit,
                true
            );

            $this->totalExportedRecords += $numRecordsToExport;
        }

        $this->log(sprintf('Exported Wuhu users operation completed with %d records', $this->totalExportedRecords));
    }

    protected function buildCSVExportedFilePath($exportedCSVDirPath): string
    {
        if ($this->option('fileName')) {
            $fileName = $this->option('fileName');
        } else {
            $todayString = Carbon::now()->format('Ymd');
            $fileName = "wuhu_users_${todayString}.csv";
        }

        if(substr($exportedCSVDirPath, -1) === '/') {
            $exportedCSVDirPath = substr($exportedCSVDirPath, 0, -1);
        }

        return "${exportedCSVDirPath}/${fileName}";
    }

    protected function countRecordsNeedToExport()
    {
        $query = "
            SELECT count(users.user_id) as total_records
            FROM `users`
            INNER JOIN `user_addresses` ON user_addresses.user_id=users.user_id
            ";

        return DB::select($query)[0]->total_records;
    }

    /**
     * @param $limit
     * @param $offset
     * @return array
     */
    protected function prepareDataToExport($limit = null, $offset = null): array
    {
        $query = "
            SELECT users.user_id,
                   users.company_id,
                   users.soldi_id,
                   users.user_first_name,
                   users.user_family_name,
                   users.user_mobile,
                   users.email,
                   users.gender,
                   users.dob,
                   users.user_avatar,
                   users.created_at,
                   users.user_type,
                   users.old_user,
                   user_addresses.address,
                   user_addresses.street_number,
                   user_addresses.street_name,
                   user_addresses.country,
                   user_addresses.city,
                   user_addresses.state,
                   user_addresses.suburb,
                   user_addresses.latitude,
                   user_addresses.longitude,
                   user_addresses.address2,
                   user_addresses.postal_code,
                   user_addresses.address_type,
                   users.password
            FROM `users`
            INNER JOIN `user_addresses` ON user_addresses.user_id=users.user_id
            ";

        if ($limit !== null) {
            $query = $query . " LIMIT ${limit}";
        }

        if ($offset !== null) {
            $query = $query . " OFFSET ${offset}";
        }

        return DB::select($query);
    }
}
