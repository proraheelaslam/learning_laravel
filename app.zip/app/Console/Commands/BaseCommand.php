<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

abstract class BaseCommand extends Command
{
    protected $requiredOptions = [];

    protected $jsonStatsFile;
    protected $statistics;
    // Logging
    protected $logChannel;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

        $this->startStatisticsRuntimeTracking();
    }

    /**
     * Verify that we are not running as the root user.
     *
     * We only allow running as root in the 'local' environment in a docker image
     * during development.
     *
     * In other deployments we will be running as a non-privileged user and will
     * need to ensure that permissions and ownership of any generated files match
     * the deployment user.
     */
    protected function verifyNonRootUser()
    {
        $appEnv = config('app.env');
        $unixUsername = posix_getpwuid(posix_geteuid())['name'];

        if ($appEnv !== 'local' && $unixUsername === 'root') {
            $this->die(sprintf('This command should not be run as the root user in %s environments', $appEnv));
        }
    }

    /**
     * Validate the required options common to all artisan commands.
     *
     * Unfortunately the way laravel constructs this object means that we can't
     * override the constructor so we are forced to run this manually in each
     * command.
     */
    protected function validateBaseOptions()
    {
        foreach ($this->requiredOptions as $option) {
            if (!isset($this->options()[$option])) {
                $this->info('Usage: ' . $this->signature);
                exit(1);
            }
        }
    }

    /**
     * Execute the console command.
     *
     */
    public function handle()
    {
        $this->verifyNonRootUser();
        $this->validateBaseOptions();
        $this->logChannel = $this->getLogChannel();
    }

    protected function getLogChannel()
    {
        $logChannel = $this->getClassName(get_called_class());

        if (array_key_exists($logChannel, config('logging.channels'))) {
            return $logChannel;
        }
        return config('logging.default');
    }

    protected function getClassName(string $class): string
    {
        if ($pos = strrpos($class, '\\')) {
            return substr($class, $pos + 1);
        }

        return $class;
    }

    /**
     * Error and bail out of the script immediately.
     *
     * @param string $text
     */
    protected function die($text)
    {
        $message = "ERROR: {$text}";
        $this->log($message, 'error');
        exit(1);
    }

    protected function log(string $message, string $level = 'info', string $verbosity = '')
    {
        // Write the message to the log channel
        // Validate level and fallback level as required
        $log_level = $level;
        if (!method_exists(Log::channel($this->logChannel), $level)) {
            $log_level = 'info';
        }

        if ($level == 'warn') {
            $this->collectStatisticsLogs('warnings', $message);
        }

        if ($level == 'error') {
            $this->collectStatisticsLogs('errors', $message);
        }

        Log::channel($this->logChannel)->$log_level($message);

        // Write the message to specified channel/verbosity
        // Validate level and fallback level as required
        if (!method_exists($this, $level)) {
            $level = 'info';
        }
        $this->$level($message, $verbosity);
    }

    /**
     * Collect statistics
     *
     * @param string $identifier
     * @param int $amount
     *
     * @return void
     */
    protected function incrementStatistics(string $identifier, int $amount)
    {
        if (!isset($this->statistics['summary'][$identifier])) {
            $this->statistics['summary'][$identifier] = 0;
        }
        $this->statistics['summary'][$identifier] += $amount;
    }

    /**
     * Tracking start time of statistics
     *
     * @param string $section
     *
     * @return void
     */
    protected function startStatisticsRuntimeTracking(string $section = 'main')
    {
        $this->statistics['time'][$section]['start'] = time();
        $this->statistics['runtime'][$section] = -1;
    }

    /**
     * Tracking end time of statistics
     *
     * @param string $section
     *
     * @return void
     */
    protected function stopStatisticsRuntimeTracking(string $section = 'main')
    {
        $endTime = time();
        $this->statistics['time'][$section]['stop'] = $endTime;

        if (isset($this->statistics['time'][$section]['start'])) {
            $this->statistics['runtime'][$section] = $endTime
                - $this->statistics['time'][$section]['start'];
        }
    }

    /**
     * Export statistics to Json file
     *
     * @return void
     */
    protected function exportStatisticsToJson()
    {
        if (array_key_exists('suppress-statistics', $this->options()) && $this->option('suppress-statistics')) {
            return;
        }

        // Convert the epoch values into timestamps
        foreach ($this->statistics['time'] as $section => &$times) {
            foreach ($times as &$time) {
                $time = strftime("%Y-%m-%d %H:%M:%S %z %Z", $time);
            }
        }

        $this->jsonStatsFile = sprintf(
            '%s-statistics-%s.json',
            preg_replace('/^petstock:/', '', $this->name),
            strftime("%Y%m%d-%H%M%S", time())
        );

        Storage::disk('ingestion_statistics')->put(
            $this->jsonStatsFile,
            json_encode($this->statistics, JSON_PRETTY_PRINT)
        );
    }

    /**
     * Collect statistics problems
     *
     * @param string $level
     * @param string $message
     *
     * @return void
     */
    protected function collectStatisticsLogs(string $level, string $message)
    {
        $this->statistics['logs'][$level][] = $message;
    }
}
