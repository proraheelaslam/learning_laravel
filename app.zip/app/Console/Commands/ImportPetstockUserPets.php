<?php

namespace App\Console\Commands;

use App\Helpers\EmailValidationHelper;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Services\Tenant;
use App\Repositories\CategoryTypeRepository;
use App\Helpers\CSVFileHelper;

class ImportPetstockUserPets extends BaseCommand
{
    protected $csv_records = [];
    protected $users_pets = [];
    protected $user_pet_db_id = [];
    protected $csv_hashed_records_map = [];
    protected $totalRecords = 0;

    const BATCH_SIZE = 1000;

    # Define CSV File Helper formats
    #
    protected $csvFileHelper;
    protected $csvFileFormats = [
        'petstock_user_pet' => [
            'delimiter' => ",",
            'header_rows' => 1,
            'validate' => false,
            'fields' => [
                'customer_id', 'Email', 'pets'
            ],
        ],
    ];

    protected $emailValidationHelper;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = "engage:import-user-pets-petstock\n" .
        "  {--file=        : [Required] User CSV (UTF-8) file to process}\n" .
        "  {--limit=       : record limit}\n" .
        "  {--replace      : Replace existing user records}\n" .
        "  {--force        : Replace without user prompt}";

    protected $requiredOptions = ['file'];

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import user pets from Petstock CSV file';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

        // Initialise CSV file helper and load file specifications
        $this->csvFileHelper = new CSVFileHelper();
        foreach($this->csvFileFormats as $name => $detail) {
            $this->csvFileHelper->addFileSpecification($name, $detail);
        }
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        parent::handle();
        $this->log('INFO: Petstock user pet data ingestion');

        # Check the CSV ingestion file exists
        #
        if (!file_exists($this->option('file'))) {
            $this->die(sprintf('File %s does not exist', $this->option('file')));
        }

        # Delete existing user records
        #
        if ($this->option('replace')) {
            $this->deleteUserPetsRecords($this->option('force'));
        }

        $batchSize = self::BATCH_SIZE;

        # Apply limit
        #
        $limit = null;
        if ($this->option('limit')) {
            $limit = intval($this->option('limit'));
            if ($batchSize > $limit) {
                $batchSize = $limit;
            }
        }

        # Read in batches of user records from CSV file
        #
        $eof = false;
        while (!$eof) {
            $this->csv_records = $this->csvFileHelper->readFile(
                $this->option('file'),
                'petstock_user_pet',
                $batchSize,
                $eof
            );

            $this->log(sprintf('CSV records read from file = %d', count($this->csv_records)));

            # Convert the CSV records to User Pet records
            #
            $this->prepareUserPetData($this->csv_records);
            $this->log(sprintf('Prepared user pet count = %d', count($this->users_pets)), 'info', 'vv');

            # Insert the records
            #
            $userPointCount = $this->createUserPetRecords($this->users_pets);
            $this->log(sprintf('Ingested %d user pet record(s)', $userPointCount));

            $this->totalRecords += $userPointCount;

            if ($limit && $this->totalRecords >= $limit) {
                break;
            }
        }

        $this->log(sprintf('Insert user pet operation completed with %d records', $this->totalRecords));
    }

    protected function deleteUserPetsRecords($force = false)
    {
        # Count existing records
        $count = DB::table('temp_pets')->count();

        if (!$force) {
            # Prompt user before deletion if records exist
            $response = $this->cliPrompt("Delete existing user pet records?", ['Y', 'N']);
            if ($response != 'Y') {
                $this->die('Operation aborted');
            }

            $response = $this->cliPrompt("Are you sure you want to delete all user pet records?", ['Y', 'N']);
            if ($response != 'Y') {
                $this->die('Operation aborted');
            }
        }

        if ($count > 0) {
            $this->log(sprintf('Deleting %d user pet records...', $count));

            /**
             * Delete all user pet records
             */
            DB::table('temp_pets')->delete();

            $this->log(sprintf('%d user pet records has been deleted!', $count));
        } else {
            $this->log(sprintf('There is not existing user pet records in the database!', $count));
        }
    }

    protected function prepareUserPetData($csv_records = [])
    {
        # Process the CSV records we have been provided and create an array of users point
        $this->users_pets = [];
        $this->user_pet_db_id = DB::table('temp_pets')
            ->select('id')
            ->pluck('id')
            ->toArray();

        foreach ($csv_records as $index => $record) {
            # Calculate CSV line number for error messages
            #
            $lineNumber = $index;
            if ($this->isDuplicatedWithCSVRecord($record, $lineNumber)) {
                continue;
            }

            $customer_id = trim($record['customer_id']);

            if (in_array($customer_id, $this->user_pet_db_id)) {
                $this->log(
                    sprintf("Line %d: User pet with id %s already exist, ignore this record", $lineNumber, $customer_id),
                    'warn',
                    'vv');

                continue;
            }

            if (trim($record['Email']) === '') {
                continue;
            }

            $user_pet = [
                'id' => $customer_id,
                'email' => $record['Email'],
                'pets' => $record['pets']
            ];

            array_push($this->users_pets, $user_pet);
        }
    }

    protected function createUserPetRecords($users_pets = [])
    {
        $userPetCount = 0;

        # Perform all operations within a transaction in case rollback is required
        #
        DB::beginTransaction();

        # Process user pet inserts
        #
        foreach ($users_pets as $user_pet) {
            try {
                $id = DB::table('temp_pets')->insertGetId([
                    'id' => $user_pet['id'],
                    'email' => $user_pet['email'],
                    'pets' => $user_pet['pets'],
                ]);

                $userPetCount++;
            } catch (\Exception $e) {
                $this->error(sprintf("ERROR: %s", print_r($e->getMessage(), true)));
                $this->error(sprintf("ERROR: user pet = %s", print_r($user_pet, true)));
                DB::rollBack();
                exit(1);
            }
        }

        $count['temp_pets'] = $userPetCount;

        # Reporting
        #
        foreach (['temp_pets'] as $table) {
            $this->log(sprintf('Inserted %d record(s) in %s table', $count[$table], $table));
        }

        # Commit the transactions
        #
        DB::commit();

        return $userPetCount;
    }

    protected function isDuplicatedWithCSVRecord($record, $lineNumber)
    {
        $hashed_record = $this->hashCSVRecord($record);
        foreach ($this->csv_hashed_records_map as $line => $hashed) {
            if ($hashed_record === $hashed) {
                $this->log(sprintf("Line %d: Duplicate CSV record defined on line %d", $lineNumber, $line), 'warn', 'vv');
                return true;
            }
        }

        $this->csv_hashed_records_map[$lineNumber] = $hashed_record;

        return false;
    }

    protected function hashCSVRecord($record) {
        $hashedValue = '';
        foreach ($record as $value) {
            $hashedValue = $hashedValue . trim($value);
        }

        return md5($hashedValue);
    }

    protected function cliPrompt($prompt = null, $permitted_responses = [], $default_response = '')
    {
        if (is_null($prompt)) {
            $prompt = sprintf("Proceed");
        }
        $prompt = rtrim($prompt, '?');

        if (count($permitted_responses) == 0) {
            $permitted_responses = ['Y', 'N'];
        }

        $response = '';
        while (!in_array($response, $permitted_responses)) {
            printf(
                '%s [%s]? %s',
                $prompt,
                implode(',', $permitted_responses),
                $default_response
            );
            $response = trim(strtoupper(fgets(STDIN)));
            if ($response == '') {
                $response = $default_response;
            }
        }
        return ($response);
    }
}
