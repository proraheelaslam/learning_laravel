<?php

namespace App\Console\Commands;

use App\Helpers\EmailValidationHelper;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Services\Tenant;
use App\Repositories\CategoryTypeRepository;
use App\Helpers\CSVFileHelper;

class ImportAUFCStudent extends BaseCommand
{
    protected $csv_records = [];
    protected $users = [];
    protected $csv_hashed_records_map = [];
    protected $user_db_emails = [];
    protected $totalRecords = 0;

    const BATCH_SIZE = 1000;

    # Define CSV File Helper formats
    #
    protected $csvFileHelper;
    protected $csvFileFormats = [
        'aufc_student' => [
            'delimiter' => ",",
            'header_rows' => 1,
            'validate' => false,
            'fields' => [
                'SCHOOL', 'EMAIL', 'CONTACT NAME', 'Num1', 'Num2', 'Num3', 'FirstName', 'LastName'
            ],
        ],
    ];

    protected $emailValidationHelper;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = "engage:import-student-aufc\n" .
        "  {--file=        : [Required] User CSV (UTF-8) file to process}\n" .
        "  {--limit=       : record limit}\n" .
        "  {--replace      : Replace existing user records}\n" .
        "  {--ignore-dup   : Ignored duplicated record by email}\n" .
        "  {--force        : Replace without user prompt}";

    protected $requiredOptions = ['file'];

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import student from AUFC CSV file';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

        // Initialise CSV file helper and load file specifications
        $this->csvFileHelper = new CSVFileHelper();
        foreach($this->csvFileFormats as $name => $detail) {
            $this->csvFileHelper->addFileSpecification($name, $detail);
        }

        $this->emailValidationHelper = new EmailValidationHelper();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        parent::handle();
        $this->log('INFO: AUFC student (user) and related data ingestion');

        # Check the CSV ingestion file exists
        #
        if (!file_exists($this->option('file'))) {
            $this->die(sprintf('File %s does not exist', $this->option('file')));
        }

        # Delete existing user records
        #
        if ($this->option('replace')) {
            $this->deleteUserRecords($this->option('force'));
        }

        $batchSize = self::BATCH_SIZE;

        # Apply limit
        #
        $limit = null;
        if ($this->option('limit')) {
            $limit = intval($this->option('limit'));
            if ($batchSize > $limit) {
                $batchSize = $limit;
            }
        }

        # Read in batches of user records from CSV file
        #
        $eof = false;
        while (!$eof) {
            $this->csv_records = $this->csvFileHelper->readFile(
                $this->option('file'),
                'aufc_student',
                $batchSize,
                $eof
            );

            $this->log(sprintf('CSV records read from file = %d', count($this->csv_records)));

            # Convert the CSV records to User records
            #
            $this->prepareStudentData($this->csv_records);
            $this->log(sprintf('Prepared user count = %d', count($this->users)), 'info', 'vv');

            # Insert the records
            #
            $userCount = $this->createUserRecords($this->users);
            $this->log(sprintf('Ingested %d user record(s)', $userCount));

            $this->totalRecords += $userCount;

            if ($limit && $this->totalRecords >= $limit) {
                break;
            }
        }

        $this->log(sprintf('Insert student operation completed with %d records', $this->totalRecords));
    }

    protected function deleteUserRecords($force = false)
    {
        # Count existing records
        $count = DB::table('users')->count();

        if (!$force) {
            # Prompt user before deletion if records exist
            $response = $this->cliPrompt("Delete existing user records?", ['Y', 'N']);
            if ($response != 'Y') {
                $this->die('Operation aborted');
            }

            $response = $this->cliPrompt("Are you sure you want to delete all user records?", ['Y', 'N']);
            if ($response != 'Y') {
                $this->die('Operation aborted');
            }
        }

        if ($count > 0) {
            $this->log(sprintf('Deleting %d user records...', $count));

            /**
             * Delete all user records
             */
            DB::table('users')->delete();

            $this->log(sprintf('%d user records has been deleted!', $count));
        } else {
            $this->log(sprintf('There is not existing user records in the database!', $count));
        }
    }

    protected function prepareStudentData($csv_records = [])
    {
        # Process the CSV records we have been provided and create an array of users
        $this->users = [];
        $this->user_db_emails = DB::table('users')
            ->select('user_id', 'email')
            ->whereNotNull('email')
            ->distinct()
            ->pluck('user_id', 'email')
            ->toArray();

        $companyId = $companyId = config('constant.COMPANY_ID');

        foreach ($csv_records as $index => $record) {
            # Calculate CSV line number for error messages
            #
            $lineNumber = $index;
            if ($this->isDuplicatedWithCSVRecord($record, $lineNumber)) {
                continue;
            }

            $email = $this->normalizeEmail($record['EMAIL']);

            $user = [
                'school' => $record['SCHOOL'],
                'user_first_name' => $record['FirstName'],
                'user_family_name' => $record['LastName'],
                'email' => $email,
                'created_at' => Carbon::now(),
                'latitude' => 0,
                'longitude' => 0,
                'company_id' => $companyId,
                'line' => $lineNumber
            ];

            if (!$this->option('ignore-dup') && $this->isDuplicatedWithDBRecord($user, $lineNumber)) {
                continue;
            }
            array_push($this->users, $user);
        }
    }

    protected function normalizeEmail($rawValue)
    {
        $rawValue = trim($rawValue);

        if ($rawValue === null || $rawValue === '') {
            return null;
        }

        $message = null;
        if (!$this->emailValidationHelper->validateEmailAddress($rawValue, $message)) {
            return null;
        }

        return $rawValue;
    }

    protected function normalizeGender($rawValue)
    {
        $rawValue = trim($rawValue);

        if ($rawValue === 'MALE') {
            return 'male';
        } elseif ($rawValue === 'FEMALE') {
            return 'female';
        } else {
            return 'other';
        }
    }

    protected function createUserRecords($users = [])
    {
        $customFields = DB::table('user_custom_field')
            ->select('id', 'field_name')
            ->pluck('id', 'field_name')
            ->toArray();
        $userAddresses = [];
        $userCustomFieldsData = [];
        $userCount = 0;

        # Perform all operations within a transaction in case rollback is required
        #
        DB::beginTransaction();

        # Process user inserts
        #
        foreach ($users as $user) {
            try {
                $userId = DB::table('users')->insertGetId([
                    'company_id' => $user['company_id'],
                    'user_first_name' => $user['user_first_name'],
                    'user_family_name' => $user['user_family_name'],
                    'country_code' => 'au',
                    'country_replace' => 'Australia',
                    'email' => $user['email'],
                    'activation_token' => rand(111111, 999999),
                    'created_at' => $user['created_at'],
                    'device_token' => uniqid(true),
                    'user_lat_replace' => $user['latitude'],
                    'user_long_replace' => $user['longitude'],
                    'soldi_id' => 0,
                    'groups' => collect(["School"])
                ]);

                $userCount++;
            } catch (\Exception $e) {
                $this->error(sprintf("ERROR: %s", print_r($e->getMessage(), true)));
                $this->error(sprintf("ERROR: user = %s", print_r($user, true)));
                DB::rollBack();
                exit(1);
            }

            $userAddress = [
                'latitude' => $user['latitude'],
                'longitude' => $user['longitude'],
                'country' => 'Australia',
                'created_at' => Carbon::now()
            ];
            if (!empty($userAddress)) {
                $userAddress['user_id'] = $userId;
                array_push($userAddresses, $userAddress);
            }

            $userCustomFieldData = [
                'custom_field_id' => $customFields['school'],
                'value' => $user['school'],
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ];
            if (!empty($userCustomFieldData)) {
                $userCustomFieldData['user_id'] = $userId;
                array_push($userCustomFieldsData, $userCustomFieldData);
            }
        }

        $count['users'] = $userCount;

        # Insert ALL user address records with batching
        #
        $count['user_addresses'] = $this->insertRecords('user_addresses', $userAddresses);

        # Insert ALL user custom field data records with batching
        #
        $count['user_custom_field_data'] = $this->insertRecords('user_custom_field_data', $userCustomFieldsData);

        # Reporting
        #
        foreach (['users', 'user_addresses', 'user_custom_field_data'] as $table) {
            $this->log(sprintf('Inserted %d record(s) in %s table', $count[$table], $table));
        }

        # Commit the transactions
        #
        DB::commit();

        return $userCount;
    }

    protected function insertRecords(string $table, array $db_records = [], int $batch_size = 250)
    {
        $insert_count = 0;

        foreach (array_chunk($db_records, $batch_size) as $batch) {
            $result = DB::table($table)->insert($batch);
            if ($result == 1) {
                $insert_count += count($batch);
            }
        }
        return $insert_count;
    }

    protected function isDuplicatedWithDBRecord($record, $lineNumber)
    {
        if (array_key_exists($record['email'], $this->user_db_emails)) {
            $this->log(
                sprintf("Line %d: Student with email '%s' already exist in the database", $lineNumber, $record['email']),
                'warn',
                'vv');

            return true;
        }

        if ($record['email']) {
            $this->user_db_emails[$record['email']] = null;
        }

        return false;
    }

    protected function isDuplicatedWithCSVRecord($record, $lineNumber)
    {
        $hashed_record = $this->hashCSVRecord($record);
        foreach ($this->csv_hashed_records_map as $line => $hashed) {
            if ($hashed_record === $hashed) {
                $this->log(sprintf("Line %d: Duplicate CSV record defined on line %d", $lineNumber, $line), 'warn', 'vv');
                return true;
            }
        }

        $this->csv_hashed_records_map[$lineNumber] = $hashed_record;

        return false;
    }

    protected function hashCSVRecord($record) {
        $hashedValue = '';
        foreach ($record as $value) {
            $hashedValue = $hashedValue . trim($value);
        }

        return md5($hashedValue);
    }

    protected function cliPrompt($prompt = null, $permitted_responses = [], $default_response = '')
    {
        if (is_null($prompt)) {
            $prompt = sprintf("Proceed");
        }
        $prompt = rtrim($prompt, '?');

        if (count($permitted_responses) == 0) {
            $permitted_responses = ['Y', 'N'];
        }

        $response = '';
        while (!in_array($response, $permitted_responses)) {
            printf(
                '%s [%s]? %s',
                $prompt,
                implode(',', $permitted_responses),
                $default_response
            );
            $response = trim(strtoupper(fgets(STDIN)));
            if ($response == '') {
                $response = $default_response;
            }
        }
        return ($response);
    }
}
