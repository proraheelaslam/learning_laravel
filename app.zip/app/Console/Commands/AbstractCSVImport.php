<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;

/**
 * This is a generic abstract class to be used as a base for all future CSV
 * importers which provides basic validation, normalisation and progress
 * tracking.
 *
 * Client-specific functionality must be implemented in child classes and not
 * added to this class.
 *
 * Example importer:
 *
 * class TestImport extends AbstractCSVImport
 * {
 *     protected $signature = 'engage:TestImport ' .
 *         '{--file= : CSV file to import}';
 *
 *     protected $description = 'CSV file test import tool';
 *
 *     protected $columns = [
 *         'Name' => ['string', 'required'],
 *         'Email' => ['email'],
 *         'City' => ['city', 'required'],
 *     ];
 *
 *     public function handle()
 *     {
 *         $this->validateBaseOptions();
 *
 *         DB::beginTransaction();
 *
 *         $data = $this->getNormalisedRows();
 *
 *         $this->startProgressTracking($data->count());
 *
 *         foreach ($data as $lineNumber => $row) {
 *             $this->recordAndDisplayProgress();
 *
 *             DB::table('users')
 *                 ->where('name', $row['Name'])
 *                 ->update(['email' => $row['Email'], 'city' => $row['City']]);
 *         }
 *
 *         $this->stopProgressTracking();
 *
 *         if ($this->confirm('Commit database changes?) {
 *             $this->info('Committing transaction');
 *             DB::commit();
 *         } else {
 *             $this->info('Rolling back transaction');
 *             DB::rollBack();
 *         }
 *     }
 *
 *     protected function normaliseCity($city)
 *     {
 *         return strtoupper($this->normaliseString($city));
 *     }
 * }
 *
 * Note that varying levels of logs are configured, use -v, -vv or -vvv
 * respectively on the command line get more verbose output.
 *
 * @see Command
 * @abstract
 */
abstract class AbstractCSVImport extends Command
{
    /**
     * Fields and associated normalization and validation criteria.
     *
     * The first array entry reflects the normalisation method to use, some
     * basic ones such as 'string' and 'email' are provided in this base class
     * and custom ones should be added to your class implementation.
     *
     * 'required' appearing anywhere in the criteria will enforce a check that
     * skips this row if this value is not defined.
     *
     * These normalisers and validators are applied automatically.
     *
     * Example
     *
     * protected $columns = [
     *     'id' => ['integer', 'required'],
     *     'email' => ['email', 'required'],
     *     'name' => ['string', 'required'],
     *     'alias' => ['string'],
     * ];
     *
     * @var array
     */
    protected $columns = [];
    protected $headers = [];
    protected $csvFileHandle = false;
    protected $prependTimestampToLog = false;
    protected $startTime;

    /**
     * By default we attempt to skip duplicate rows, what we define as
     * 'duplicate' can be partially controlled by the following variables or by
     * overriding the appropriate method in the child class.
     */
    protected $skipDuplicateRows = true;
    protected $duplicateRowHashMethod = 'md5';
    protected $duplicateRowHashMap = [];
    protected $duplicateRowIgnoreWhitespace = false;
    protected $duplicateRowIgnoreCase = false;

    /**
     * These track progress of the script and assist in completion estimates.
     */
    protected $progressCount = 0;
    protected $progressCurrent = 0;
    protected $progressTotalRecords = 0;
    protected $progressSectionTimes = [];
    protected $progressLastSectionTime;

    protected $headerLine = 0;

    /**
     * Validate the basic options common to all CSV file imports.
     *
     * Unfortunately the way laravel constructs this object means that we can't
     * override the constructor so we are forced to run this manually in each
     * command.
     */
    protected function validateBaseOptions($file)
    {
        $this->startTime = new \DateTime();

        if (!array_key_exists($file, $this->options())) {
            $this->info('Usage: ' . $this->signature);
            exit;
        }

        $this->validateHeaders($this->option($file));
    }

    /**
     * Ensure we clean up after ourselves.
     */
    public function __destruct()
    {
        if ($this->csvFileHandle) {
            fclose($this->csvFileHandle);
        }

        if (!empty($this->startTime)) {
            // Determine how long it took our import to run
            $interval = $this->startTime->diff((new \DateTime()));

            $this->question(sprintf('Runtime: %s', $interval->format('%h hours, %i minutes, %s seconds')));
        }
    }

    /**
     * Yields normalised rows as a generator and is intended to be called
     * directly from child classes as follow:
     *
     * foreach ($this->getNormalisedRows() as $lineNumber => $row) {
     *     // Do some work
     * }
     */
    protected function getNormalisedRows($file)
    {
        $lineNumber = 0;
        $successfullynormalisedLines = 0;

        $this->prependTimestampToLog = true;
        $this->info(sprintf("Starting CSV record parsing for '%s'", basename($file)));

        /**
         * We first iterate through to determine the max number of lines in
         * order to display progress tracking.
         */
        while (($line = fgets($this->getCsvFileHandle($file))) !== false) {
            $lineNumber++;
        }

        $this->startProgressTracking($lineNumber);
        rewind($this->getCsvFileHandle($file));
        $lineNumber = 0;

        $count = 0;
        while ($count < $this->headerLine) {
            fgetcsv($this->csvFileHandle);
            $count++;
        }

        while (($line = fgetcsv($this->getCsvFileHandle($file))) !== false) {
            $lineNumber++;

            $this->line('DEBUG: Processing line ' . + $lineNumber, null, 'vvv');

            // Skip the header row
            if ($lineNumber === 1) {
                $successfullynormalisedLines++;
                $this->recordAndDisplayProgress('question');
                continue;
            }

            $row = $this->normaliseRow($line, $lineNumber);

            // Skip rows that have failed normalization
            if (!$row) {
                continue;
            }

            $this->line(sprintf('DEBUG: line %s: %s', $lineNumber, json_encode($row)), null, 'vvv');

            if ($this->skipDuplicateRows && $this->isDuplicateRow($row, $lineNumber)) {
                continue;
            }

            $successfullynormalisedLines++;

            $this->recordAndDisplayProgress('question');

            yield $lineNumber => $row;
        }

        $this->stopProgressTracking('question');

        $this->info(sprintf("Finished CSV record parsing for '%s' with %s successfully normalised rows", basename($file), $successfullynormalisedLines));
    }

    /**
     * Tests to see if this row is a duplicate.
     *
     * By default this requires an exact match, child classes can override this
     * to perform other operations if necessary.
     *
     * We also support optionally ignoring whitespace and character case.
     *
     * Note that storing the hash as an md5sum will take far less
     * memory but with a corresponding increase in time taken to run.
     *
     * Storing the hash as an imploded array has the opposite effect -
     * both methods are included as it is dependent on the data
     * supplied as to what will be better.
     *
     * @param array $row
     */
    protected function isDuplicateRow(array $row, $lineNumber)
    {
        $hash = implode($row, '');

        if ($this->duplicateRowIgnoreWhitespace) {
            $hash = preg_replace('/\s+/', '', $hash);
        }

        if ($this->duplicateRowIgnoreCase) {
            $hash = strtolower($hash);
        }

        if ($this->duplicateRowHashMethod) {
            $hash = hash($this->duplicateRowHashMethod, $hash);
        }

        if (!in_array($hash, $this->duplicateRowHashMap)) {
            $this->duplicateRowHashMap[] = $hash;

            return false;
        }

        $this->warn(sprintf('WARNING: duplicate data found on line %s, skipping', $lineNumber));

        return true;
    }

    /**
     * Start tracking progess.
     *
     * Note that this resets a number of class variables back to their existing
     * defaults - we do this as we may be starting and stopping multiple
     * progress counters in a sequence depending on the specific importer in
     * use.
     *
     * @param integer $totalRecords
     * @param string $logLevel
     */
    protected function startProgressTracking($totalRecords, $logLevel = 'info')
    {
        $this->progressCount = 0;
        $this->progressCurrent = 0;
        $this->progressSectionTimes = [];
        $this->progressTotalRecords = $totalRecords;
        $this->progressInterval = round($totalRecords / 100);
        $this->progressLastSectionTime = new \DateTime();

        $this->$logLevel(sprintf("%s records to process", $this->progressTotalRecords));
    }

    /**
     * Records processing progress and provides an estimate of the completion
     * time based on the average time taken per section.
     *
     * @param string $logLevel What log level to record progress at.
     */
    protected function recordAndDisplayProgress($logLevel = 'info')
    {
        $this->progressCount++;
        $this->progressCurrent++;

        if ($this->progressCount >= $this->progressInterval) {
            $this->progressCount = 0;
            $percentageComplete = round(($this->progressCurrent / $this->progressTotalRecords) * 100);

            $sectionStartTime = new \DateTime();

            $this->progressSectionTimes[] = $sectionStartTime->getTimestamp() - $this->progressLastSectionTime->getTimestamp();
            $averageSecondsTaken = array_sum($this->progressSectionTimes) / count($this->progressSectionTimes);
            $secondsRemaining = round($averageSecondsTaken * (100 - $percentageComplete));
            $estimatedCompletion = (new \DateTime())->setTimestamp(time() + $secondsRemaining);

            $this->progressLastSectionTime = $sectionStartTime;

            $this->$logLevel(sprintf('Processed %s%%: %s records, %s remaining, estimated completion at %s', $percentageComplete, $this->progressCurrent, $this->progressTotalRecords - $this->progressCurrent, $estimatedCompletion->format(DATE_ISO8601)));
        }
    }

    protected function stopProgressTracking($logLevel = 'info')
    {
        $this->$logLevel(sprintf('Processed 100%%: %s out of %s records', $this->progressCurrent, $this->progressTotalRecords));
    }

    /**
     * Normalises and validates a row, returning an associative array using the
     * headers provided.
     *
     * @param array $row
     */
    protected function normaliseRow(array $row, $lineNumber)
    {
        $normalisedRow = [];

        if (count($row) !== count($this->headers)) {
            $this->error(sprintf("ERROR: Skipping line '%s' due to incorrect field count", $lineNumber)) ;

            return false;
        }

        foreach ($row as $key => $value) {
            $header = $this->headers[$key];

            if (in_array('skip', $this->columns[$header])) {
                $this->line(sprintf("DEBUG: Skipping unused column '%s'", $header), null, 'vvv');
                continue;
            }

            $field = $this->normaliseField($header, $value, $lineNumber);

            if (in_array('required', $this->columns[$header]) && empty($field)) {
                $this->warn(sprintf("WARNING: line %s: Value for required field '%s' was not found, skipping record", $lineNumber, $header));
                return false;
            }

            if ($field === false) {
                $this->warn(sprintf("WARNING: line %s: Failed to normalise field '%s' with value '%s', skipping record", $lineNumber, $header, $field));
                return false;
            }

            $normalisedRow[$header] = $field;
        }

        return $normalisedRow;
    }

    /**
     * Validate that we have the required headers present in the CSV file.
     */
    protected function validateHeaders($file)
    {
        $this->getCsvFileHandle($file);

        $count = 0;
        while ($count < $this->headerLine) {
            fgetcsv($this->csvFileHandle);
            $count++;
        }

        $this->headers = fgetcsv($this->csvFileHandle);
        $failed = false;

        foreach ($this->headers as $header) {
            if (!array_key_exists($header, $this->columns)) {
                $this->error(sprintf("ERROR: Unknown column '%s' found in file", $header));
                $failed = true;
            }
        }

        foreach ($this->columns as $name => $criteria) {
            if (in_array('required', $criteria) && !in_array($name, $this->headers)) {
                $this->error(sprintf('ERROR: Mandatory column \'%s\' is not present in file headers', $name));
                $failed = true;
            }
        }

        rewind($this->getCsvFileHandle($file));

        if ($failed) {
            $this->error(sprintf('ERROR: File headers present: \'%s\'', implode($this->headers, ', ')));
            $this->die(sprintf('File headers expected: \'%s\'', implode(array_keys($this->columns), ', ')));
        }
    }

    /**
     * Validates and normalises a field based on the settings in the columns
     * config.
     *
     * @param string $header
     * @param string $value
     * @param integer $lineNumber
     */
    protected function normaliseField($header, $value, $lineNumber)
    {
        foreach ($this->columns[$header] as $method) {
            /**
             * On columns which are required but have no normalisation defined, the
             * first array value may simply be the required option, in this case we
             * return immediately.
             */
            if ($method == 'required') {
                continue;
            }

            $normalizationMethod = 'normalise' . ucfirst($method);

            if (!method_exists($this, $normalizationMethod)) {
                $this->die(sprintf('No normalization method exists named \'%s\'', $normalizationMethod));
            }

            $value = $this->$normalizationMethod($value);
        }

        return $value;
    }

    protected function normaliseInteger($integer)
    {
        return filter_var($integer, FILTER_VALIDATE_INT);
    }

    protected function normaliseString($string, $characters = null)
    {
        $string = trim($string, $characters);

        return $string !== ''
            ? $string
            : null;
    }

    protected function normaliseEmail($email)
    {
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        $email = strtolower($email);

        return filter_var($email, FILTER_VALIDATE_EMAIL)
            ? $email
            : null;
    }

    /**
     * Open a CSV file and return the handle
     */
    protected function getCsvFileHandle($file)
    {
        if (!$this->csvFileHandle) {
            if (!file_exists($file)) {
                $this->die(sprintf('File does not exist: %s', $file));
            }

            $this->csvFileHandle = fopen($file, 'r');

            if (!$this->csvFileHandle) {
                $this->die(sprintf('Failed to open file: %s', $file));
            }
        }

        return $this->csvFileHandle;
    }

    /**
     * Extend the parent 'line' method for logging to optionally prepend a
     * timestamp to the log output if requested.
     *
     * @param string $string
     * @param mixed $style
     * @param mixed $verbosity
     */
    public function line($string, $style = null, $verbosity = null)
    {
        // Prepend a timestamp to the log entry if required
        if ($this->prependTimestampToLog) {
            $string = sprintf(
                '%s - %s',
                (new \DateTime())->format(DATE_ISO8601),
                $string
            );
        }

        return parent::line($string, $style, $verbosity);
    }

    /**
     * Error and bail out of the script immediately.
     *
     * @param string $text
     */
    protected function die($text)
    {
        $this->error('ERROR: ' . $text);
        exit(1);
    }
}
