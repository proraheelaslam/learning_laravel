<?php

namespace App\Console\Commands;

use App\Helpers\EmailValidationHelper;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Services\Tenant;
use App\Repositories\CategoryTypeRepository;
use App\Helpers\CSVFileHelper;

class ImportWuhuUserPoints extends BaseCommand
{
    protected $csv_records = [];
    protected $users_point = [];
    protected $user_db_external_id = [];
    protected $csv_hashed_records_map = [];
    protected $totalRecords = 0;

    const BATCH_SIZE = 1000;

    # Define CSV File Helper formats
    #
    protected $csvFileHelper;
    protected $csvFileFormats = [
        'wuhu_user_point' => [
            'delimiter' => "\t",
            'header_rows' => 1,
            'validate' => false,
            'fields' => [
                'EXTERNAL_ACCOUNT_ID', 'CURRENT_BALANCE'
            ],
        ],
    ];

    protected $emailValidationHelper;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = "engage:import-user-points-wuhu\n" .
        "  {--file=        : [Required] User CSV (UTF-8) file to process}\n" .
        "  {--limit=       : record limit}\n" .
        "  {--replace      : Replace existing user records}\n" .
        "  {--force        : Replace without user prompt}";

    protected $requiredOptions = ['file'];

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import user from Wuhu CSV file';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

        // Initialise CSV file helper and load file specifications
        $this->csvFileHelper = new CSVFileHelper();
        foreach($this->csvFileFormats as $name => $detail) {
            $this->csvFileHelper->addFileSpecification($name, $detail);
        }
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        parent::handle();
        $this->log('INFO: Wuhu user point data ingestion');

        # Check the CSV ingestion file exists
        #
        if (!file_exists($this->option('file'))) {
            $this->die(sprintf('File %s does not exist', $this->option('file')));
        }

        # Delete existing user records
        #
        if ($this->option('replace')) {
            $this->deleteUserPointRecords($this->option('force'));
        }

        $batchSize = self::BATCH_SIZE;

        # Apply limit
        #
        $limit = null;
        if ($this->option('limit')) {
            $limit = intval($this->option('limit'));
            if ($batchSize > $limit) {
                $batchSize = $limit;
            }
        }

        # Read in batches of user records from CSV file
        #
        $eof = false;
        while (!$eof) {
            $this->csv_records = $this->csvFileHelper->readFile(
                $this->option('file'),
                'wuhu_user_point',
                $batchSize,
                $eof
            );

            $this->log(sprintf('CSV records read from file = %d', count($this->csv_records)));

            # Convert the CSV records to User Point records
            #
            $this->prepareUserPointData($this->csv_records);
            $this->log(sprintf('Prepared user point count = %d', count($this->users_point)), 'info', 'vv');

            # Insert the records
            #
            $userPointCount = $this->createUserPointRecords($this->users_point);
            $this->log(sprintf('Ingested %d user record(s)', $userPointCount));

            $this->totalRecords += $userPointCount;

            if ($limit && $this->totalRecords >= $limit) {
                break;
            }
        }

        $this->log(sprintf('Insert user operation completed with %d records', $this->totalRecords));
    }

    protected function deleteUserPointRecords($force = false)
    {
        # Count existing records
        $count = DB::table('lt_transations')->count();

        if (!$force) {
            # Prompt user before deletion if records exist
            $response = $this->cliPrompt("Delete existing user point records?", ['Y', 'N']);
            if ($response != 'Y') {
                $this->die('Operation aborted');
            }

            $response = $this->cliPrompt("Are you sure you want to delete all user point records?", ['Y', 'N']);
            if ($response != 'Y') {
                $this->die('Operation aborted');
            }
        }

        if ($count > 0) {
            $this->log(sprintf('Deleting %d user point records...', $count));

            /**
             * Delete all user point records
             */
            DB::table('lt_transations')->delete();

            $this->log(sprintf('%d user point records has been deleted!', $count));
        } else {
            $this->log(sprintf('There is not existing user point records in the database!', $count));
        }
    }

    protected function prepareUserPointData($csv_records = [])
    {
        # Process the CSV records we have been provided and create an array of users point
        $this->users_point = [];
        $this->user_db_external_id = DB::table('users')
            ->select('user_id', 'client_customer_id')
            ->whereNotNull('client_customer_id')
            ->distinct()
            ->pluck('user_id', 'client_customer_id')
            ->toArray();

        foreach ($csv_records as $index => $record) {
            # Calculate CSV line number for error messages
            #
            $lineNumber = $index;
            if ($this->isDuplicatedWithCSVRecord($record, $lineNumber)) {
                continue;
            }

            $user_external_id = trim($record['EXTERNAL_ACCOUNT_ID']);
            if (!array_key_exists($user_external_id, $this->user_db_external_id)) {
                $this->log(
                    sprintf("Line %d: User with external id %s didn't exist, ignore this record", $lineNumber, $user_external_id),
                    'warn',
                    'vv');

                continue;
            }
            $point = $this->normalizeUserPoints($record['CURRENT_BALANCE']);
            $user_id = $this->user_db_external_id[$user_external_id];

            $user_point = [
                'value_points' => $point,
                'user_id' => $user_id,
                'expiry_date' => Carbon::now()->addMonth(12),
                "line" => $lineNumber
            ];

            array_push($this->users_point, $user_point);
        }
    }

    protected function createUserPointRecords($users_point = [])
    {
        $userPointCount = 0;
        $companyId = config('constant.COMPANY_ID');

        # Perform all operations within a transaction in case rollback is required
        #
        DB::beginTransaction();

        # Process user inserts
        #
        foreach ($users_point as $user_point) {
            try {
                $ltTransactionId = DB::table('lt_transations')->insertGetId([
                    'soldi_id' => 0,
                    'company_id' => $companyId,
                    'order_amount' => 0,
                    'lt_rule_id' => 1,
                    'status' => 1,
                    'customer_id' => 0,
                    'rule_for' => 'store',
                    'source' => 'manual',
                    'type' => 'credit',
                    'point_id' => 1,
                    'value_points' => $user_point['value_points'],
                    'created_at' => Carbon::now()->timestamp,
                    'updated_at' => Carbon::now()->timestamp,
                    'wi_code' => 1,
                    'user_id' => $user_point['user_id'],
                    'expiry_date' => $user_point['expiry_date'],
                ]);

                $userPointCount++;
            } catch (\Exception $e) {
                $this->error(sprintf("ERROR: %s", print_r($e->getMessage(), true)));
                $this->error(sprintf("ERROR: user point = %s", print_r($user_point, true)));
                DB::rollBack();
                exit(1);
            }
        }

        $count['lt_transations'] = $userPointCount;

        # Reporting
        #
        foreach (['lt_transations'] as $table) {
            $this->log(sprintf('Inserted %d record(s) in %s table', $count[$table], $table));
        }

        # Commit the transactions
        #
        DB::commit();

        return $userPointCount;
    }

    protected function insertRecords(string $table, array $db_records = [], int $batch_size = 250)
    {
        $insert_count = 0;

        foreach (array_chunk($db_records, $batch_size) as $batch) {
            $result = DB::table($table)->insert($batch);
            if ($result == 1) {
                $insert_count += count($batch);
            }
        }
        return $insert_count;
    }

    protected function isDuplicatedWithCSVRecord($record, $lineNumber)
    {
        $hashed_record = $this->hashCSVRecord($record);
        foreach ($this->csv_hashed_records_map as $line => $hashed) {
            if ($hashed_record === $hashed) {
                $this->log(sprintf("Line %d: Duplicate CSV record defined on line %d", $lineNumber, $line), 'warn', 'vv');
                return true;
            }
        }

        $this->csv_hashed_records_map[$lineNumber] = $hashed_record;

        return false;
    }

    protected function hashCSVRecord($record) {
        $hashedValue = '';
        foreach ($record as $value) {
            $hashedValue = $hashedValue . trim($value);
        }

        return md5($hashedValue);
    }

    protected function cliPrompt($prompt = null, $permitted_responses = [], $default_response = '')
    {
        if (is_null($prompt)) {
            $prompt = sprintf("Proceed");
        }
        $prompt = rtrim($prompt, '?');

        if (count($permitted_responses) == 0) {
            $permitted_responses = ['Y', 'N'];
        }

        $response = '';
        while (!in_array($response, $permitted_responses)) {
            printf(
                '%s [%s]? %s',
                $prompt,
                implode(',', $permitted_responses),
                $default_response
            );
            $response = trim(strtoupper(fgets(STDIN)));
            if ($response == '') {
                $response = $default_response;
            }
        }
        return ($response);
    }

    /**
     * @param $rawPoint
     * @return float|int
     */
    protected function normalizeUserPoints($rawPoint)
    {
        $point = trim($rawPoint) ?? 0;
        $point = $point * 10;
        $point = $point <= 1500 ? $point : 1500;
        return $point;
    }
}
