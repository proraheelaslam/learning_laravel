<?php

namespace App\Console\Commands;

use Illuminate\Support\Facades\DB;
use Doctrine\DBAL\Driver\PDOConnection;
use Illuminate\Support\Str;

/**
 * This is a swimart-specific custom importer.
 *
 * This imports users supplied via CSV on an ongoing basis and attempts to
 * de-duplicate and merge with existing records with the same email or mobile
 * number.
 *
 * @see AbstractCSVImport
 */
class ImportSwimartUserUpdate extends AbstractCSVImport
{
    /**
     * The name and signature of the console command.
     *
     * Example usage:
     *
     * sudo -u swimart-engage php7.3 artisan engage:import-user-swimart-update --file=../../ingest/20200423/byron\ bay.csv --store='byron bay' --force-commit
     *
     * add -v, -vv, -vvv on the end for debug info
     *
     * @var string
     */
    protected $signature = 'engage:import-user-swimart-update ' .
        '{--store= : Store name}' .
        '{--file= : CSV file to import}' .
        '{--force-commit : Skip DB commit confirmation}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'CSV file import tool for Engage user data updates for Swimart';

    protected $columns = [
        'First Name' => ['string'],
        'Last Name' => ['string'],
        'Address' => ['string'],
        'Primary Mobile Phone' => ['string', 'mobile'],
        'Primary Email' => ['string', 'email'],
        '' => [], // For some reason they have an extra empty column on the end which we ignore
    ];

    protected $store;
    protected $skipDuplicateRows = true;
    protected $duplicateRowIgnoreWhitespace = true;
    protected $duplicateRowIgnoreCase = true;
    protected $deletedUsers = 0;
    protected $updatedUsers = 0;
    protected $insertedUsers = 0;
    protected $activityCustomFieldID;

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->validateBaseOptions('file');
        $store = $this->getStoreDetails();

        DB::beginTransaction();

        $this->info(
            sprintf(
                'Starting database operations (Changes will %s)',
                $this->option('force-commit') === true
                    ? 'be automatically committed'
                    : 'require manual confirmation before being committed'
            )
        );

        foreach ($this->getNormalisedRows($this->option('file')) as $lineNumber => $row) {
            $data = [
                'sequence' => $lineNumber,
                'venue_id' => $store->id,
                'venue_name' => $store->venue_name,
                'user_first_name' => $row['First Name'],
                'user_family_name' => $row['Last Name'],
                'address' => null,
                'suburb' => null,
                'state' => null,
                'postal_code' => null,
                'country' => null,
                'city' => null,
                'email' => $row['Primary Email'],
                'user_mobile' => $this->transformMobile($row['Primary Mobile Phone'], $store->country),
                'file_source' => 'Poolware',
                'sms_subscription_status' => 1,
                'email_subscription_status' => 1,
                'activity' => 'Active',
            ];

            // Populate the address if we can successfully decode it
            $addressDetails = $this->extractAddressDetails($row['Address']);

            if ($addressDetails !== null) {
                $data['address'] = $addressDetails['street'];
                $data['suburb'] = $addressDetails['suburb'];
                $data['state'] = $addressDetails['state'];
                $data['postal_code'] = $addressDetails['postcode'];
                $data['country'] = $addressDetails['country'];
            }

            // Attempt to find existing users by email address or mobile number
            $dbUsers = $this->findUsers($lineNumber, $data);

            if ($dbUsers->count() === 0) {
                // No existing records - Add as a new user
                $this->insertUser($data);
            } elseif ($dbUsers->count() === 1) {
                // One existing user - we update this existing user with
                // missing data.
                $this->updateUser($lineNumber, $dbUsers[0], $data);
            } elseif ($dbUsers->count() === 2) {
                /**
                 * Matched two users - we assume that these existing records
                 * are the same person with the email on one record and mobile on the other.
                 *
                 * We delete the existing records and insert a new one.
                 */
                $this->replaceUsers($lineNumber, $dbUsers, $data);
            } elseif ($dbUsers->count() > 2) {
                throw new \Exception(sprintf('Matched more than two users for data from line "%s" - this should never happen!', $lineNumber));
            }
        }

        $this->info('Finished database operations');

        if ($this->option('force-commit') || $this->confirm(sprintf('Commit database changes? (%s updated users, %s inserted users', $this->updatedUsers, $this->insertedUsers))) {
            $this->info('Committing transaction');
            DB::commit();
        } else {
            $this->info('Rolling back transaction');
            DB::rollBack();
        }
    }

    protected function getStoreDetails()
    {
        $store = DB::table('venues')
            ->select(['id', 'venue_name', 'country'])
            ->where([
                ['venue_name', '=', $this->option('store')]
            ])
            ->first();

        if ($store !== null) {
            return $store;
        }

        throw new \Exception(sprintf('No venue found matching "%s", please supply a valid store via --store', $this->option('store')));
    }

    /**
     * Find all users matching either the email address or mobile number.
     *
     * @param integer $lineNumber
     * @param array $data
     */
    protected function findUsers($lineNumber, array $data)
    {
        $dbUsers = DB::table('users')
            ->select(['user_id', 'user_first_name', 'user_family_name', 'user_mobile', 'email', 'store_name', 'is_active'])
            ->where(function($query) use ($data) {
                $query->where('email', $data['email'])
                      ->whereNotNull('email');
            })
            ->orWhere(function($query) use ($data) {
                $query->where('user_mobile', $data['user_mobile'])
                      ->whereNotNull('user_mobile');
            })
            ->get();

        if ($dbUsers->count() !== 0) {
            foreach ($dbUsers as $key => $dbUser) {
                // Record what we based our match on
                if ($dbUser->email === $data['email'] && $data['email'] !== null) {
                    $dbUsers[$key]->matchSource = 'email';
                } else {
                    $dbUsers[$key]->matchSource = 'user_mobile';
                }

                $this->line(sprintf('Found existing user with id "%s" for line number "%s" by "%s"', $dbUser->user_id, $lineNumber, $dbUsers[$key]->matchSource), null, 'v');

                // Retrieve subscription status for each user
                $dbUsers[$key]->notifications = DB::table('user_notification')
                    ->select(['channel', 'notification_type', 'subscribed'])
                    ->where([
                        ['user_id', '=', $dbUser->user_id],
                        ['notification_type', '=', 'marketing'],
                    ])
                    ->whereIn('channel', ['sms', 'email'])
                    ->get();
            }
        }

        return $dbUsers;
    }

    protected function getActivityCustomFieldID()
    {
        if ($this->activityCustomFieldID === null) {
            $this->activityCustomFieldID = DB::table('user_custom_field')
                ->where([
                    ['field_name', '=', 'activity']
                ])
                ->value('id');
        }

        return $this->activityCustomFieldID;
    }

    /**
     * Update an existing user with new data.
     *
     * @param integer $lineNumber
     * @param mixed $dbUser
     * @param array $data
     */
    protected function updateUser($lineNumber, $dbUser, array $data)
    {
        $affected = 0;

        // Update either the email or mobile number depending on what we
        // originally matched on.
        if ($dbUser->matchSource === 'email') {
            $updateField = 'user_mobile';
        } else {
            $updateField = 'email';
        }

        if ($data[$updateField] !== null && $dbUser->$updateField === null) {
            $affected += DB::table('users')
                ->where('user_id', $dbUser->user_id)
                ->update([$updateField => $data[$updateField]]);

            $this->line(sprintf('Updated existing record "%s" to set %s to "%s" based on CSV line "%s"', $dbUser->user_id, $updateField, $data[$updateField], $lineNumber));
        }

        // All users from these CSV updates are required to be made active
        $activityAffected = DB::table('user_custom_field_data')
            ->where([
                ['user_id', '=', $dbUser->user_id],
                ['custom_field_id', '=', $this->getActivityCustomFieldID()],
                ['value', '!=', $data['activity']],
            ])
            ->update(['value' => $data['activity']]);

        if ($activityAffected > 0) {
            $affected += $activityAffected;
            $this->line(sprintf('Updated existing record "%s" to set activity custom field to "%s"', $dbUser->user_id, $data['activity']));
        }

        // As we are importing from an ongoing source we always assume the
        // address data is correct
        if ($data['address'] !== null) {
            $addressDetails = [
                'address' => $data['address'],
                'suburb' => $data['suburb'],
                'city' => $data['city'],
                'state' => $data['state'],
                'postal_code' => $data['postal_code'],
                'country' => $data['country'],
            ];

            $affected += DB::table('users')
                ->where('user_id', $dbUser->user_id)
                ->update($addressDetails);

            if ($affected) {
                $this->line(sprintf('Updated existing record "%s" to set address details to "%s" based on CSV line "%s"', $dbUser->user_id, json_encode($addressDetails), $lineNumber), null, 'v');
            }
        }

        if ($affected > 0) {
            $this->line(sprintf('Updated %s rows for existing user "%s"', $affected, $dbUser->user_id), null, 'v');
            $this->updatedUsers++;
        }
    }

    /**
     * Replace multiple existing users with one new combined user based on our
     * new data.
     *
     * @param integer $lineNumber
     * @param mixed $dbUsers
     * @param array $data
     */
    protected function replaceUsers($lineNumber, $dbUsers, array $data)
    {
        $this->warn(sprintf('Replacing existing users "%s" and "%s" with a single new record based on CSV line "%s"', $dbUsers[0]->user_id, $dbUsers[1]->user_id, $lineNumber));

        foreach ($dbUsers as $dbUser) {
            // Ensure any existing unsubscriptions are honoured
            foreach ($dbUser->notifications as $field) {
                if (!$field->subscribed) {
                    $identifier = $field->channel . '_subscription_status';

                    $data[$identifier] = 0;

                    $this->line(sprintf('Recording existing "%s" unsubscription from defunct DB user "%s" for replacement entry from line "%s"', $field->channel, $dbUser->user_id, $lineNumber), null, 'v');
                }
            }

            // Remove the old user
            $this->line(sprintf('Deleting existing user "%s"', $dbUsers[0]->user_id), null, 'v');

            DB::table('users')
                ->where('user_id', $dbUser->user_id)
                ->delete();
        }

        $this->insertUser($data);
    }

    /**
     * Insert a user and associated data into the database
     *
     * @param array $user
     */
    protected function insertUser(array $user)
    {
        $result = DB::select(
            'call import_swimart_user(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $user['sequence'],
                $user['venue_id'],
                $user['venue_name'],
                $user['address'],
                $user['suburb'],
                $user['city'],
                $user['state'],
                $user['postal_code'],
                $user['country'],
                $user['user_first_name'],
                $user['user_family_name'],
                $user['email'],
                $user['user_mobile'],
                $user['sms_subscription_status'],
                $user['email_subscription_status'],
                $user['file_source'],
                $user['activity']
            ]
        );

        $this->insertedUsers++;

        $this->line('Inserted user: ' . json_encode($user), null, 'v');
    }

    /**
     * The supplied files seem to commonly use a number of single-characters
     * for fields that don't exist - we fix that so they are actually empty.
     *
     * @param string $string
     */
    protected function normaliseString($string, $characters = null)
    {
        // Lots of the data in these files has trailing spaces so we just trim
        // them all by default
        $characters .= ' ';

        $string = parent::normaliseString($string, $characters);

        // Various strings have multiple whitespace entries for no apparent
        // reason
        $string = preg_replace('/\s+/', ' ', $string);

        if (in_array($string, ['-', '.', ',', '1', ''])) {
            $string = null;
        }

        return $string;
    }

    /**
     * Normalise mobile numbers to the standard international format.
     *
     * @param string $number
     */
    protected function normaliseMobile($number)
    {
        $number = preg_replace('/[^0-9]/', '', $number);

        if (empty($number)) {
            return null;
        }

        return $number;
    }

    /**
     * These CSV update files come with the address in a very strange format so
     * we refactor them to a normal format.
     *
     * CSV Format:
     * {Street Number} {Street Name} {State} {Postcode} {Suburb}
     *
     * @param string $address
     */
    protected function extractAddressDetails($address)
    {
        if ($address === null) {
            return null;
        }

        $australianStates = ['ACT', 'NT', 'SA', 'NSW', 'VIC', 'QLD', 'WA', 'TAS'];

        foreach ($australianStates as $state) {
            $country = 'Australia';

            if (strstr($address, $state)) {
                $pattern = sprintf('/(.*) (%s) (\d{4}) (.*)/', $state);

                if (preg_match($pattern, $address, $matches)) {
                    $street = $matches[1];
                    $state = $matches[2];
                    $postcode = $matches[3];
                    $suburb = $matches[4];

                    break;
                }
            }
        }

        // @todo Add support for NZ if required

        if (isset($street)) {
            $details = [
                'street' => $street,
                'state' => $state,
                'postcode' => $postcode,
                'suburb' => $suburb,
                'country' => $country,
            ];

            $this->line(sprintf('Translated address "%s" to "%s"', $address, json_encode($details)), null, 'vv');

            return $details;
        }

        // Any addresses we can't decode are dropped on the floor
        $this->warn(sprintf('Failed to normalise address "%s", Nulling out field.', $address));

        return null;
    }

    /**
     * Transform a mobile number into a standard format with country code
     *
     * @param mixed $number
     */
    protected function transformMobile($number, $country = null)
    {
        if (empty($number)) {
            return null;
        }

        // Match Australian mobile numbers
        if (($country === null || $country == 'Australia')) {
            if (preg_match('/^(61)?(0)?(4)\d{8}$/', $number)) {
                $newNumber = preg_replace('/^(\d{1,3})?(4)(\d{8})$/', '+614$3', $number);

                $this->line(sprintf('Matched mobile number as AU mobile: %s -> %s', $number, $newNumber), null, 'vvv');

                return $newNumber;
            }
        } elseif ($country == 'New Zealand' && preg_match('/^(64)?(0)?2(0|1|2|4|7|8|9)\d{6,7}$/', $number)) {
            $newNumber = preg_replace('/^(\d)?(2)(\d+)$/', '+64$3$4', $number);

            $this->line(sprintf('Matched mobile number as NZ mobile: %s -> %s', $number, $newNumber), null, 'vvv');

            return $newNumber;
        }

        // If we don't match on anything above we likely have a landline or
        // other malformed number - these get dropped on the floor.
        $this->line(sprintf("Failed to match '%s' mobile number, dropped: %s", $country ?? 'Unknown', $number), null, 'vv');

        return null;
    }
}
