<?php

namespace App\Console\Commands;

use Illuminate\Support\Facades\DB;
use Doctrine\DBAL\Driver\PDOConnection;
use Illuminate\Support\Str;

/**
 * This is a swimart-specific custom importer.
 *
 * Requires all CSV files to be supplied at the same time from the command
 * line, this then attempts to merge them all and remove any duplicate records
 * with the same email or mobile number.
 *
 * @see AbstractCSVImport
 */
class ImportSwimartUser extends AbstractCSVImport
{
    /**
     * The name and signature of the console command.
     *
     * Example usage:
     *
     * sudo -u swimart-engage php7.3 artisan engage:import-user-swimart --file=../../ingest/202004/NeverTransacted_v.csv --file-vend=../../ingest/202004/swimart_vend_AU_NZ_COMBINED_v2.csv --file-email=../../ingest/202004/Swimart-email-25-11-2019.csv --file-sms=../../ingest/202004/Swimart-sms-25-11-2019.csv --force-commit
     *
     * add -v, -vv, -vvv on the end for debug info
     *
     * @var string
     */
    protected $signature = 'engage:import-user-swimart ' .
        '{--file= : CSV file to import (neverTransacted)}' .
        '{--file-vend= : CSV file to import (vend)}' .
        '{--file-email= : CSV file to import (email)}' .
        '{--file-sms= : CSV file to import (email)}' .
        '{--db-test-mode : Test mode (only inserts 1000 records)}' .
        '{--force-commit : Skip DB commit confirmation}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'CSV file import tool for Engage user data (Swimart)';

    protected $columns = [];

    protected $fileFormat;
    protected $stores = [
        'Ascot' => [],
        'Aspley' => [],
        'Balwyn' => [],
        'Baukhamhills' => [],
        'Beenleigh' => [],
        'Belconnen' => [],
        'Blacktown' => [],
        'Brighton' => [],
        'Browns Plains' => [],
        'Bundall' => [],
        'Byron Bay' => [],
        'Cairns' => [],
        'Campbelltown' => [],
        'Camphill' => [],
        'Camphill' => [],
        'Capalaba' => [],
        'Carlingford' => [],
        'Cboolture' => [],
        'Charmhaven' => [],
        'Cheltenham' => [],
        'Clearview' => [],
        'Cleveland' => [],
        'Currimundi' => [],
        'Doncaster' => [],
        'Dural' => [],
        'Enoggera' => [],
        'Erindale' => [],
        'Frenchs Forest' => [],
        'Gladesville' => [],
        'Glen Waverley' => [],
        'Glenfield' => [],
        'Greenlane' => [],
        'Greenpoint' => [],
        'Greensborough' => [],
        'Harvey Bay' => [],
        'Headoffice' => [],
        'Henderson' => [],
        'Hope Island' => [],
        'Ipswich' => [],
        'Jindalee' => [],
        'Kirwan' => [],
        'Lawnton' => [],
        'Lindfield' => [],
        'Liverpool' => [],
        'Mackay' => [],
        'Malvern' => [],
        'Manukau' => [],
        'Maroochydore' => [],
        'Mermaid Waters' => [],
        'Minchinbury' => [],
        'Miranda' => [],
        'Mona Vale' => [],
        'Mornington' => [],
        'Mosman' => [],
        'Murrumba Downs' => [],
        'Nerang' => [],
        'New Lambton' => [],
        'Noosa' => [],
        'North Strathfield' => [],
        'Other' => [],
        'Oxenford' => [],
        'Padstow' => [],
        'Pakuranga' => [],
        'Palm Beach' => [],
        'Peel H2O Solutions' => [],
        'Penrith' => [],
        'Plutus Commerce' => [],
        'Pool and Spa 2' => [],
        'Redcliffe' => [],
        'Robina' => [],
        'Rockhampton' => [],
        'Rose Bay North' => [],
        'Rose Bay' => [],
        'Rousehill' => [],
        'Runaway Bay' => [],
        'Shellharbour' => [],
        'Somerton Park' => [],
        'Springwood' => [],
        'St Ives' => [],
        'St Marys' => [],
        'Sunnybank' => [],
        'Taringa' => [],
        'Tingalpa' => [],
        'Tweedheads' => [],
        'Warner Bay' => [],
        'Winston Hills' => [],
        'Woree' => [],
    ];
    protected $unknownStores = [];
    protected $skipDuplicateRows = false;
    protected $duplicateRowHashMethod = false;
    protected $duplicateRowIgnoreWhitespace = true;
    protected $duplicateRowIgnoreCase = true;
    protected $processUnsubscribes = false;
    protected $updatedUsers = 0;
    protected $insertedUsers = 0;
    protected $alteredUsersByStore = [];
    protected $users;
    protected $usersByEmail;
    protected $usersByMobile;
    protected $userSequence = 0;
    protected $emailUnsubscriptions = 0;
    protected $smsUnsubscriptions = 0;

    /**
     * Execute the console command.
     *
     * This is considerably more complex than normal as we are attempting to
     * load, merge & de-duplicate multiple CSV files in memory before any
     * import to the database takes place.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->users = collect([]);
        $this->usersByEmail = collect([]);
        $this->usersByMobile = collect([]);

        $this->handleNeverTransactedCSV();
        $this->handleVendCSV();
        $this->handleEmailCSV();
        $this->handleSMSCSV();

        DB::beginTransaction();

        $this->startProgressTracking($this->users->count(), 'question');

        $this->info(
            sprintf(
                'Starting database operations (Changes will %s)',
                $this->option('force-commit') === true
                    ? 'be automatically committed'
                    : 'require manual confirmation before being committed'
            )
        );

        $this->insertStores();

        $this->info('Starting to insert users into the database');

        foreach ($this->users as $key => $item) {
            if ($this->option('db-test-mode') && $this->insertedUsers >= 1000) {
                $this->warn('Database test mode limit reached, skipping remaining users');
                break;
            }

            $this->insertUser($item);
            $this->recordAndDisplayProgress('question');
        }

        $this->stopProgressTracking('question');

        $this->info('Finished inserting users into the database');

        foreach ($this->unknownStores as $unknownStore) {
            $this->question(sprintf("No store was found matching '%s'", $unknownStore));
        }

        foreach ($this->alteredUsersByStore as $store => $type) {
            if (!array_key_exists($store, $this->stores)) {
                $this->warn(sprintf('Unknown Store: %s, inserted: %s, updated: %s', $store, $type['inserted'], $type['updated']));
            } else {
                $this->question(sprintf('Store: %s, inserted: %s, updated: %s', $store, $type['inserted'], $type['updated']));
            }
        }

        $this->question('Email unsubscriptions: ' . $this->emailUnsubscriptions);
        $this->question('SMS unsubscriptions: ' . $this->smsUnsubscriptions);

        if ($this->option('force-commit') || $this->confirm(sprintf('Commit database changes? (%s updated users, %s inserted users', $this->updatedUsers, $this->insertedUsers))) {
            $this->info('Committing transaction');
            DB::commit();
        } else {
            $this->info('Rolling back transaction');
            DB::rollBack();
        }
    }

    /**
     * This handles records from the 'never transacted' CSV file.
     */
    public function handleNeverTransactedCSV()
    {
        /**
         * This spreadsheet forms the basis of our known store names so we skip
         * any 'unknown' stores at this stage.
         */
        $this->columns = [
            'id' => ['required'],
            'GHL_Longitude' => ['skip'],
            'GHL_Latitude' => ['skip'],
            'G_NAF_Street' => ['string', 'required'],
            'G_NAF_Locality' => ['string', 'required'],
            'state' => ['string', 'state', 'required'],
            'G_NAF_Postcode' => ['integer', 'required'],
            'Swimart_Store' => ['storeNoUnknowns', 'required'],
            'Swimart_Address' => ['string'],
            'Swiamrt_Suburb' => ['string'],
            'Swimart_State' => ['string'],
            'Swimart_Latitude' => ['string'],
            'Swimart_Longitude' => ['string'],
            'Swimart_Postcodes' => ['string']
        ];

        $this->validateBaseOptions('file');

        foreach ($this->getNormalisedRows($this->option('file')) as $lineNumber => $row) {
            $this->saveStore(
                $row['Swimart_Store'],
                $row['Swimart_Address'],
                $row['Swiamrt_Suburb'], // remove state/postcode if we can
                $row['Swimart_State'],
                $row['Swimart_Latitude'],
                $row['Swimart_Longitude'],
                $row['Swimart_Postcodes']
            );

            $data = [
                'user_first_name' => 'Gapmap',
                'user_family_name' => $row['id'],
                'venue_name' => $row['Swimart_Store'],
                'address' => $row['G_NAF_Street'],
                'suburb' => $row['G_NAF_Locality'],
                'state' => $row['state'],
                'country' => 'Australia',
                'postal_code' => $row['G_NAF_Postcode'],
                'file_source' => 'Gapmap',
                'activity' => 'No Transactions',
            ];

            $this->storeUser($data, 'never-transacted');
        }
    }

    /**
     * This handles records from the 'vend' CSV file.
     *
     * The data in this CSV is ordered by the 'Last Sale Date' with the most
     * recent sales at the top.
     *
     * The most recent records are the important ones so if there are
     * duplicates later on for email or phone the most recent one wins.
     */
    public function handleVendCSV()
    {
        $this->columns = [
            'storeName' => ['store', 'required'],
            'FullAddress' => ['string'],
            'Name' => ['string', 'name'],
            'Status' => ['string', 'required'],
            'email' => ['string', 'email'],
            'phone' => ['string', 'mobile'],
            'Address' => ['string'],
            'Suburb' => ['string'],
            'Locality' => ['string'],
            'Postcode' => ['string'],
            'State' => ['string', 'state'],
            'Country' => ['string'],
            'Last Sale Date' => ['string'],
            'First Name' => ['string', 'name'],
            'Last Name' => ['string', 'name'],
        ];

        $this->csvFileHandle = false;

        $this->validateBaseOptions('file-vend');

        foreach ($this->getNormalisedRows($this->option('file-vend')) as $lineNumber => $row) {
            $mobile = $this->transformMobile($row['phone'], $row['Country']);

            $data = [
                'venue_name' => $row['storeName'],
                'address' => $row['Address'],
                'suburb' => $row['Suburb'],
                'city' => $row['Locality'],
                'state' => $row['State'],
                'postal_code' => $row['Postcode'],
                'country' => $row['Country'],
                'user_first_name' => $row['First Name'],
                'user_family_name' => $row['Last Name'],
                'email' => $row['email'],
                'user_mobile' => $mobile,
                'file_source' => 'Vend',
                'activity' => $row['Status'],
            ];

            // At least one of address, email or mobile must be present
            if (($data['suburb'] ?? $data['email'] ?? $data['user_mobile']) === null) {
                $this->line(sprintf("DEBUG: Skipping row '%s', address, email & phone are all empty", $lineNumber), null, 'vv');
                continue;
            }

            $emailUser = $this->findUser('email', $data);

            if ($emailUser !== null) {
                $this->line(sprintf("DEBUG: email '%s' already exists on another user, removing from row '%s'", $data['email'], $lineNumber), null, 'vv');
                $data['email'] = null;
            }

            $mobileUser = $this->findUser('user_mobile', $data);

            if ($mobileUser !== null) {
                $this->line(sprintf("DEBUG: mobile '%s' already exists on another user, removing from row '%s'", $data['user_mobile'], $lineNumber), null, 'vv');
                $data['user_mobile'] = null;
            }

            if ($data['email'] === null && $data['user_mobile'] === null) {
                $this->line(sprintf("DEBUG: Skipping row '%s', both email and user_mobile are empty", $lineNumber), null, 'vv');
                continue;
            }

            $this->storeUser($data, 'vend');
        }
    }

    /**
     * This handles records from the 'email' CSV file.
     */
    public function handleEmailCSV()
    {
        $this->columns = [
            'FirstName' => ['string', 'name'],
            'LastName' => ['string', 'name'],
            'Email' => ['string', 'email'],
            'Status' => ['subscriptionStatus', 'required'],
            'Store' => ['store', 'required'],
        ];

        $this->csvFileHandle = false;

        $this->validateBaseOptions('file-email');

        foreach ($this->getNormalisedRows($this->option('file-email')) as $lineNumber => $row) {
            $data = [
                'venue_name' => $row['Store'],
                'user_first_name' => $row['FirstName'],
                'user_family_name' => $row['LastName'],
                'email' => $row['Email'],
                'file_source' => 'Scorch-Email',
                'email_subscription_status' => $this->isSubscribed($row['Status']),
                'activity' => 'No Transactions',
            ];

            $this->storeUser($data, 'email');
        }
    }

    /**
     * This handles records from the 'sms' CSV file.
     */
    public function handleSMSCSV()
    {
        $this->columns = [
            'FirstName' => ['string', 'name'],
            'LastName' => ['string', 'name'],
            'Mobile #' => ['string', 'mobile'],
            'Status' => ['subscriptionStatus', 'required'],
            'Store' => ['store', 'required'],
        ];

        $this->csvFileHandle = false;

        $this->validateBaseOptions('file-sms');

        foreach ($this->getNormalisedRows($this->option('file-sms')) as $lineNumber => $row) {
            $data = [
                'venue_name' => $row['Store'],
                'user_first_name' => $row['FirstName'],
                'user_family_name' => $row['LastName'],
                'user_mobile' => $this->transformMobile($row['Mobile #']),
                'file_source' => 'Scorch-SMS',
                'sms_subscription_status' => $this->isSubscribed($row['Status']),
                'activity' => 'No Transactions',
            ];

            $this->storeUser($data, 'sms');
        }
    }

    protected function findUser($identifier, array $data)
    {
        if (array_key_exists($identifier, $data) && $data[$identifier] !== null) {
            $method = $identifier === 'email'
                ? 'usersByEmail'
                : 'usersByMobile';

            $sequence = $this->$method->get($data[$identifier]);

            if ($sequence !== null) {
                $this->line(sprintf('Found existing user by %s: %s (Sequence %s)', $identifier, $data[$identifier], $sequence), null, 'vvv');

                return [
                    $sequence,
                    $this->users->get($sequence),
                ];
            }
        }

        return null;
    }

    /**
     * Store user data in a standard format.
     *
     * We do this as each file supplies slightly different data however we want
     * the database import to have all the same fields available.
     *
     * @param array $data
     */
    protected function storeUser(array $data, $source)
    {
        $user = null;

        /**
         * Attempt to find a matching user by email, unsubscribing them if
         * necessary.
         */
        $emailUser = $this->findUser('email', $data);

        if ($emailUser !== null) {
            list($sequence, $user) = $emailUser;

            if ($source === 'email' && $data['email_subscription_status'] === 0 && $user['email_subscription_status'] !== 0) {
                $user['email_subscription_status'] = 0;

                $this->line(sprintf("Unsubscribed '%s' from email marketing", $user['email']), null, 'v');
                $this->emailUnsubscriptions++;

                $this->users->put($sequence, $user);
            }
        }

        /**
         * Attempt to find a matching user by mobile number, unsubscribing them
         * if necessary.
         */
        $mobileUser = $this->findUser('user_mobile', $data);

        if ($mobileUser !== null) {
            list($sequence, $user) = $mobileUser;

            if ($source === 'sms' && $data['sms_subscription_status'] === 0 && $user['sms_subscription_status'] !== 0) {
                $user['sms_subscription_status'] = 0;

                $this->line(sprintf("Unsubscribed '%s' from SMS marketing", $user['user_mobile']), null, 'v');
                $this->smsUnsubscriptions++;

                $this->users->put($sequence, $user);
            }
        }

        /**
         * Save new users which match an existing store.
         */
        if ($user === null && array_key_exists($data['venue_name'], $this->stores)) {
            $sequence = $this->userSequence++;
            $user = $template = [
                'sequence' => $sequence,
                'venue_name' => null,
                'address' => null,
                'suburb' => null,
                'city' => null,
                'state' => null,
                'postal_code' => null,
                'country' => null,
                'user_first_name' => null,
                'user_family_name' => null,
                'email' => null,
                'user_mobile' => null,
                'sms_subscription_status' => 1,
                'email_subscription_status' => 1,
                'file_source' => null,
                'activity' => null,
            ];

            foreach ($data as $key => $value) {
                if ($user[$key] === null && $value !== null) {
                    $user[$key] = $value;
                }
            }

            $this->users->put($sequence, $user);

            // Update index arrays if we have a brand new user
            if ($user['email'] !== null && in_array($source, ['email', 'vend', 'never-transacted'])) {
                $this->usersByEmail->put($user['email'], $sequence);
            }

            if ($user['user_mobile'] !== null && in_array($source, ['sms', 'vend', 'never-transacted'])) {
                $this->usersByMobile->put($user['user_mobile'], $sequence);
            }
        } elseif ($user === null && !array_key_exists($data['venue_name'], $this->stores)) {
            $this->warn(sprintf("Skipping '%s' user %s %s - unknown store: %s", $source, $data['user_first_name'], $data['user_family_name'], $data['venue_name']));
        }
    }

    /**
     * Populates the database with store information and caches the resulting
     * automatically created id's locally for use when inserting users.
     */
    protected function insertStores()
    {
        $this->info(sprintf("Starting to insert store / venue data for '%s' stores", count($this->stores)));

        /**
         * We massage the store list first as some of them may not have been
         * used - in this case we just add the minimum of data so that they can
         * be populated later.
         */
        foreach ($this->stores as $name => $data) {
            if ($data === []) {
                $this->stores[$name] = [
                    'venue_name' => $name,
                    'address' => null,
                    'locality' => null,
                    'stateProvince' => null,
                    'venue_latitude' => null,
                    'venue_longitude' => null,
                    'postalCode' => null
                ];
            }
        }

        DB::table('venues')->insert($this->stores);

        $venues = DB::table('venues')->select('id', 'venue_name')->get();

        $this->info(sprintf("Finished inserting store / venue data '%s' inserted, '%s' total", count($this->stores), count($venues)));

        foreach ($venues as $venue) {
            $this->line(sprintf("Inserted venue '%s' with id '%s'", $venue->venue_name, $venue->id), null, 'v');

            if (array_key_exists($venue->venue_name, $this->stores)) {
                $this->stores[$venue->venue_name]['database_id'] = $venue->id;
            }
        }
    }

    /**
     * Insert a user and associated data into the database
     *
     * @param array $user
     */
    protected function insertUser(array $user)
    {

        $result = DB::select(
            'call import_swimart_user(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $user['sequence'],
                $this->stores[$user['venue_name']]['database_id'],
                $user['venue_name'],
                $user['address'],
                $user['suburb'],
                $user['city'],
                $user['state'],
                $user['postal_code'],
                $user['country'],
                $user['user_first_name'],
                $user['user_family_name'],
                $user['email'],
                $user['user_mobile'],
                $user['sms_subscription_status'],
                $user['email_subscription_status'],
                $user['file_source'],
                $user['activity']
            ]
        );

        $this->insertedUsers++;

        // Record some statistics to display on number of users changed by store
        $this->recordStoreStatistics($user['venue_name'], 'inserted');

        $this->line('Inserted user: ' . json_encode($user), null, 'v');
    }

    protected function saveStore($store, $address, $suburb, $state, $latitude, $longitude, $postcode)
    {
        if (!array_key_exists($store, $this->stores) || $this->stores[$store] == []) {
            $suburb = str_replace($postcode, '', $suburb);
            $suburb = str_replace($state, '', $suburb);
            $suburb = trim($suburb, ' ,');

            $this->stores[$store] = [
                'venue_name' => $store,
                'address' => $address,
                'locality' => $suburb,
                'stateProvince' => $state,
                'venue_latitude' => $latitude,
                'venue_longitude' => $longitude,
                'postalCode' => $postcode
            ];

            $this->line(sprintf("Inserted store '%s': %s", $store, json_encode($this->stores[$store])), null, 'v');
        }
    }

    protected function recordStoreStatistics($store, $type)
    {
        if (!array_key_exists($store, $this->alteredUsersByStore)) {
            $this->alteredUsersByStore[$store] = ['updated' => 0, 'inserted' => 0];
        }

        $this->alteredUsersByStore[$store][$type]++;
    }

    /**
     * The supplied files seem to commonly use a number of single-characters
     * for fields that don't exist - we fix that so they are actually empty.
     *
     * @param string $string
     */
    protected function normaliseString($string, $characters = null)
    {
        // Lots of the data in these files has trailing spaces so we just trim
        // them all by default
        $characters .= ' ';

        $string = parent::normaliseString($string, $characters);
        $string = preg_replace('/\s+/', ' ', $string);

        if (in_array($string, ['-', '.', ',', '1', ''])) {
            $string = null;
        }

        return $string;
    }

    protected function normaliseName($name)
    {
        // Some names in the CSV file are all upper-cased for no apparent
        // reason, we fix that here
        if (ctype_upper(preg_replace("/[^A-Z]+/", "", $name))) {
            $name = ucwords(strtolower($name));
        }

        return $name;
    }

    /**
     * The stores provided in the file seem to have been brought in from
     * multiple different sources and stored different cases.
     *
     * We normalise them here to hopefully get one set of stores.
     *
     * Stores in the database have had 'swimart' removed from the start of the
     * string so we do the same here.
     *
     * @param string $store
     */
    protected function normaliseStore($store, $detectUnknowns = True)
    {
        $storeSubstitutions = [
            'advantsservices' => 'Aspley',
            'ascot' => 'Ascot',
            'aspley' => 'Aspley',
            'balwyn' => 'Balwyn',
            'baulkhamhills' => 'Baulkham Hills',
            'bb' => 'Byron Bay',
            'beenleigh' => 'Beenleigh',
            'belconnen' => 'Belconnen',
            'bighton' => 'Brighton',
            'blacktown' => 'Blacktown',
            'brighton' => 'Brighton',
            'brownsplains' => 'Browns Plains',
            'bundall' => 'Bundall',
            'byronbay' => 'Byron Bay',
            'c' => 'Campbelltown',
            'caboolture' => 'Cboolture',
            'cairns' => 'Cairns',
            'campbelltown' => 'Campbelltown',
            'camphill' => 'Camphill',
            'camphills' => 'Camphill',
            'capalaba' => 'Capalaba',
            'carlingford' => 'Carlingford',
            'charmhaven' => 'Charmhaven',
            'cheltenham' => 'Cheltenham',
            'clearview' => 'Clearview',
            'cleveland' => 'Cleveland',
            'currimundi' => 'Currimundi',
            'doncaster' => 'Doncaster',
            'dural' => 'Dural',
            'enoggera' => 'Enoggera',
            'erindale' => 'Erindale',
            'erindale0506' => 'Erindale',
            'frenchsforest' => 'Frenchs Forest',
            'gf' => 'Glenfield',
            'gladesville' => 'Gladesville',
            'glenfield' => 'Glenfield',
            'glenwaverley' => 'Glen Waverley',
            'greenlane' => 'Greenlane',
            'greenpoint' => 'Greenpoint',
            'greensborough' => 'Greensborough',
            'headoffice' => 'Headoffice',
            'henderson' => 'Henderson',
            'herveybay' => 'Harvey Bay',
            'hopeisland' => 'Hope Island',
            'ipswich' => 'Ipswich',
            'jindalee' => 'Jindalee',
            'kirwan' => 'Kirwan',
            'lawnton' => 'Lawnton',
            'lindfield' => 'Lindfield',
            'liverpool' => 'Liverpool',
            'mackay' => 'Mackay',
            'malvern' => 'Malvern',
            'manukau' => 'Manukau',
            'maroochydore' => 'Maroochydore',
            'md' => 'Lawnton',
            'mermaidwaters' => 'Mermaid Waters',
            'minchinbury' => 'Minchinbury',
            'miranda' => 'Miranda',
            'monavale' => 'Mona Vale',
            'mornington' => 'Mornington',
            'mosman' => 'Mosman',
            'murrumbadowns' => 'Murrumba Downs',
            'mv' => 'Mona Vale',
            'nerang' => 'Nerang',
            'newlambton' => 'New Lambton',
            'noosa' => 'Noosa',
            'northstrathfield' => 'North Strathfield',
            'ns' => 'North Strathfield',
            'oxenford' => 'Oxenford',
            'padstow' => 'Padstow',
            'pakuranga' => 'Pakuranga',
            'palmbeach' => 'Palm Beach',
            'peelhosolutions' => 'Peel H2O Solutions',
            'penrith' => 'Penrith',
            'plutuscommerce' => 'Plutus Commerce',
            'poolandspa' => 'Pool and Spa 2',
            'redcliffe' => 'Redcliffe',
            'robina' => 'Robina',
            'rockhampton' => 'Rockhampton',
            'rocky' => 'Rockhampton',
            'rosebay' => 'Rose Bay',
            'rosebaynorth' => 'Rose Bay',
            'rousehill' => 'Rousehill',
            'runawaybay' => 'Runaway Bay',
            'shellharbour' => 'Shellharbour',
            'somerton' => 'Somerton Park',
            'somertonpark' => 'Somerton Park',
            'springwood' => 'Springwood',
            'stives' => 'St Ives',
            'stmarys' => 'St Marys',
            'storemonavalesdiy' => 'Mona Vale',
            'sunnybank' => 'Sunnybank',
            'taringa' => 'Taringa',
            'tarongpool' => 'Lawnton',
            'tingalpa' => 'Tingalpa',
            'tweedheads' => 'Tweedheads',
            'warnersbay' => 'Warner Bay',
            'wb' => 'Warner Bay',
            'winstonhills' => 'Winston Hills',
            'woree' => 'Woree',
        ];

        // Turn the existing store name into a slug as per the database
        $store = strtolower($this->normaliseString($store));
        $store = str_replace('swimart', '', $store);
        $store = preg_replace('/[^a-zA-Z_]+/', '', $store);

        // Substitute known stores
        if (array_key_exists($store, $storeSubstitutions)) {
            $store = $storeSubstitutions[$store];
        }

        // Various users in the spreadsheets have no store assigned, these are
        // all lumped together under 'other'
        if (empty($store)) {
            $store = 'Other';
        }

        if ($detectUnknowns && !array_key_exists($store, $this->stores)) {
            if (!in_array($store, $this->unknownStores)) {
                $this->unknownStores[] = $store;
            }
        }

        return $store;
    }

    protected function normaliseStoreNoUnknowns($store)
    {
        return $this->normaliseStore($store, False);
    }

    protected function isSubscribed($status)
    {
        return !in_array($status, ['HARDBOUNCE', 'UNSUBSCRIBED'])
            ? 1
            : 0;
    }

    protected function normaliseSubscriptionStatus($status)
    {
        $normalisedStatus = strtoupper($this->normaliseString($status));

        return in_array($normalisedStatus, ['SUBSCRIBE', 'HARDBOUNCE', 'UNSUBSCRIBED'])
            ? $normalisedStatus
            : false;
    }

    /**
     * Normalise mobile numbers to the standard international format.
     *
     * @param string $number
     */
    protected function normaliseMobile($number)
    {
        $number = preg_replace('/[^0-9]/', '', $number);

        if (empty($number)) {
            return null;
        }

        return $number;
    }

    /**
     * Transform a mobile number into a standard format with country code
     *
     * @param mixed $number
     */
    protected function transformMobile($number, $country = null)
    {
        if (empty($number)) {
            return null;
        }

        // Match Australian mobile numbers
        if (($country === null || $country == 'Australia')) {
            if (preg_match('/^(61)?(0)?(4)\d{8}$/', $number)) {
                $newNumber = preg_replace('/^(\d{1,3})?(4)(\d{8})$/', '+614$3', $number);

                $this->line(sprintf('Matched mobile number as AU mobile: %s -> %s', $number, $newNumber), null, 'vvv');

                return $newNumber;
            }
        } elseif ($country == 'New Zealand' && preg_match('/^(64)?(0)?2(0|1|2|4|7|8|9)\d{6,7}$/', $number)) {
            $newNumber = preg_replace('/^(\d)?(2)(\d+)$/', '+64$3$4', $number);

            $this->line(sprintf('Matched mobile number as NZ mobile: %s -> %s', $number, $newNumber), null, 'vvv');

            return $newNumber;
        }

        // If we don't match on anything above we likely have a landline or
        // other malformed number - these get dropped on the floor.
        $this->line(sprintf("Failed to match '%s' mobile number, dropped: %s", $country ?? 'Unknown', $number), null, 'vv');

        return null;
    }

    /**
     * Normalise AU/NZ States
     *
     * @param mixed $state
     */
    protected function normaliseState($state)
    {
        return $state === null
            ? $state
            : strtoupper($state);
    }
}
