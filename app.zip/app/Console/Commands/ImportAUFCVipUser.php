<?php

namespace App\Console\Commands;

use App\Helpers\EmailValidationHelper;
use App\Models\UserCustomFieldData;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Services\Tenant;
use App\Repositories\CategoryTypeRepository;
use App\Helpers\CSVFileHelper;

class ImportAUFCVipUser extends BaseCommand
{
    protected $csv_records = [];
    protected $csv_hashed_records_map = [];
    protected $totalRecords = 0;

    protected $users;
    protected $userDBEmails = [];

    const BATCH_SIZE = 1000;

    # Define CSV File Helper formats
    #
    protected $csvFileHelper;
    protected $csvFileFormats = [
        'aufc_vip_user' => [
            'delimiter' => ",",
            'header_rows' => 1,
            'validate' => false,
            'fields' => [
                'First name', 'Last name', 'Email', 'Member Type', 'External Campaign'
            ],
        ],
    ];

    protected $emailValidationHelper;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = "engage:import-vip-user-aufc\n" .
        "  {--file=        : [Required] User CSV (UTF-8) file to process}\n" .
        "  {--limit=       : record limit}\n" .
        "  {--erase        : Delete all existing user records before insert}\n" .
        "  {--force        : Replace without user prompt}";

    protected $requiredOptions = ['file'];

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import VIP users from AUFC CSV file';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();

        // Initialise CSV file helper and load file specifications
        $this->csvFileHelper = new CSVFileHelper();
        foreach($this->csvFileFormats as $name => $detail) {
            $this->csvFileHelper->addFileSpecification($name, $detail);
        }

        $this->emailValidationHelper = new EmailValidationHelper();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        parent::handle();
        $this->log('INFO: AUFC VIP users and related data ingestion');

        # Check the CSV ingestion file exists
        #
        if (!file_exists($this->option('file'))) {
            $this->die(sprintf('File %s does not exist', $this->option('file')));
        }

        # Apply limit
        #
        $batchSize = self::BATCH_SIZE;
        $limit = null;
        if ($this->option('limit')) {
            $limit = intval($this->option('limit'));
            if ($batchSize > $limit) {
                $batchSize = $limit;
            }
        }

        # Read in batches of user records from CSV file
        #
        $eof = false;
        while (!$eof) {
            $this->csv_records = $this->csvFileHelper->readFile(
                $this->option('file'),
                'aufc_vip_user',
                $batchSize,
                $eof
            );

            $this->log(sprintf('CSV records read from file = %d', count($this->csv_records)));

            # Convert the CSV records to User records
            #
            $this->prepareData($this->csv_records);
            $this->log(sprintf('Prepared user count = %d', count($this->users)), 'info', 'vv');

            # Insert the records
            #
            $userCount = $this->importUserRecords($this->users);
            $this->log(sprintf('Ingested %d user record(s)', $userCount));

            $this->totalRecords += $userCount;

            if ($limit && $this->totalRecords >= $limit) {
                break;
            }
        }

        $this->log(sprintf('Insert VIP users operation completed with %d records', $this->totalRecords));
    }

    protected function prepareData($csv_records = [])
    {
        # Process the CSV records we have been provided and create an array of users
        $this->users = [];
        $this->userDBEmails = DB::table('users')
            ->select('user_id', 'email')
            ->whereNotNull('email')
            ->distinct()
            ->pluck('user_id', 'email')
            ->toArray();

        $companyId = config('constant.COMPANY_ID');

        foreach ($csv_records as $index => $record) {
            # Calculate CSV line number for error messages
            #
            $lineNumber = $index;
            if ($this->isDuplicatedWithCSVRecord($record, $lineNumber)) {
                continue;
            }

            $email = $this->normalizeEmail($record['Email']);

            $user = [
                'user_first_name' => $record['First name'],
                'user_family_name' => $record['Last name'],
                'email' => $email,
                'company_id' => $companyId,
                'groups' => collect(['VIP']),
                'custom_fields' => [
                    'external_campaign' => collect([$record['External Campaign']]),
                ],
                'latitude' => 0,
                'longitude' => 0,
                'created_at' => Carbon::now(),
                'line' => $lineNumber
            ];

            if ($this->isDuplicatedWithDBRecord($user, $lineNumber)) {
                $user['import_action'] = 'UPDATE';
                $user['user_id'] = $this->userDBEmails[$email];
            } else {
                $user['import_action'] = 'INSERT';
            }

            array_push($this->users, $user);
        }
    }

    protected function normalizeEmail($rawValue)
    {
        $rawValue = trim($rawValue);

        if ($rawValue === null || $rawValue === '') {
            return null;
        }

        $message = null;
        if (!$this->emailValidationHelper->validateEmailAddress($rawValue, $message)) {
            return null;
        }

        return $rawValue;
    }

    protected function importUserRecords($users = [])
    {
        $userAddresses = [];
        $userCustomFieldsData = [];
        $userCount = 0;

        # Perform all operations within a transaction in case rollback is required
        #
        DB::beginTransaction();

        # Process user inserts
        #
        foreach ($users as $user) {
            try {
                if ($user['import_action'] === 'INSERT') {
                    $userId = DB::table('users')->insertGetId([
                        'email' => $user['email'],
                        'company_id' => $user['company_id'],
                        'user_first_name' => $user['user_first_name'],
                        'user_family_name' => $user['user_family_name'],
                        'groups' => $user['groups'],
                        'activation_token' => rand(111111, 999999),
                        'created_at' => $user['created_at'],
                        'device_token' => uniqid(true),
                        'user_lat_replace' => $user['latitude'],
                        'user_long_replace' => $user['longitude'],
                        'soldi_id' => 0,
                    ]);

                    $userCount++;

                    $userAddress = [
                        'user_id' => $userId,
                        'latitude' => $user['latitude'],
                        'longitude' => $user['longitude'],
                        'created_at' => $user['created_at'],
                    ];
                    array_push($userAddresses, $userAddress);

                    $userCustomFieldData = [
                        'custom_field_id'=> 14,
                        'user_id' => $userId,
                        'multiselect_value' => $user['custom_fields']['external_campaign'],
                        'value' => null,
                        'form_id'=> 0,
                        'form_index' => 0,
                        'created_at' => Carbon::now()
                    ];
                    array_push($userCustomFieldsData, $userCustomFieldData);
                } else {
                    DB::table('users')
                        ->where('user_id', $user['user_id'])
                        ->update([
                            'user_first_name' => $user['user_first_name'],
                            'user_family_name' => $user['user_family_name'],
                            'groups' => collect(["VIP"])
                        ]);

                    UserCustomFieldData::updateOrCreate([
                        'user_id' => $user['user_id'],
                        'custom_field_id'=> 14,
                    ],[
                        'multiselect_value' => $user['custom_fields']['external_campaign'],
                        'value' => null,
                        'form_id'=> 0,
                        'form_index' => 0,
                        'created_at' => Carbon::now()
                    ]);
                }
            } catch (\Exception $e) {
                $this->error(sprintf("ERROR: %s", print_r($e->getMessage(), true)));
                $this->error(sprintf("ERROR: user = %s", print_r($user, true)));
                DB::rollBack();
                exit(1);
            }
        }

        $count['users'] = $userCount;

        # Insert ALL user address records with batching
        #
        $count['user_addresses'] = $this->insertRecords('user_addresses', $userAddresses);

        # Insert ALL user custom field data records with batching
        #
        $count['user_custom_field_data'] = $this->insertRecords('user_custom_field_data', $userCustomFieldsData);

        # Reporting
        #
        foreach (['users', 'user_addresses', 'user_custom_field_data'] as $table) {
            $this->log(sprintf('Inserted %d record(s) in %s table', $count[$table], $table));
        }

        # Commit the transactions
        #
        DB::commit();

        return $userCount;
    }

    protected function insertRecords(string $table, array $db_records = [], int $batch_size = 250)
    {
        $insert_count = 0;

        foreach (array_chunk($db_records, $batch_size) as $batch) {
            $result = DB::table($table)->insert($batch);
            if ($result == 1) {
                $insert_count += count($batch);
            }
        }
        return $insert_count;
    }

    protected function isDuplicatedWithDBRecord($record, $lineNumber)
    {
        if (array_key_exists($record['email'], $this->userDBEmails)) {
            $this->log(
                sprintf("Line %d: User with email '%s' already exist in the database", $lineNumber, $record['email']),
                'warn',
                'vv');

            return true;
        }

        if ($record['email']) {
            $this->userDBEmails[$record['email']] = null;
        }

        return false;
    }

    protected function isDuplicatedWithCSVRecord($record, $lineNumber)
    {
        $hashed_record = $this->hashCSVRecord($record);
        foreach ($this->csv_hashed_records_map as $line => $hashed) {
            if ($hashed_record === $hashed) {
                $this->log(sprintf("Line %d: Duplicate CSV record defined on line %d", $lineNumber, $line), 'warn', 'vv');
                return true;
            }
        }

        $this->csv_hashed_records_map[$lineNumber] = $hashed_record;

        return false;
    }

    protected function hashCSVRecord($record) {
        $hashedValue = '';
        foreach ($record as $value) {
            $hashedValue = $hashedValue . trim($value);
        }

        return md5($hashedValue);
    }

    protected function cliPrompt($prompt = null, $permitted_responses = [], $default_response = '')
    {
        if (is_null($prompt)) {
            $prompt = sprintf("Proceed");
        }
        $prompt = rtrim($prompt, '?');

        if (count($permitted_responses) == 0) {
            $permitted_responses = ['Y', 'N'];
        }

        $response = '';
        while (!in_array($response, $permitted_responses)) {
            printf(
                '%s [%s]? %s',
                $prompt,
                implode(',', $permitted_responses),
                $default_response
            );
            $response = trim(strtoupper(fgets(STDIN)));
            if ($response == '') {
                $response = $default_response;
            }
        }
        return ($response);
    }
}
