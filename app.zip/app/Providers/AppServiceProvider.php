<?php

namespace App\Providers;


use App\Models\Games;
use App\Models\MemberTransaction;
use App\Models\SurveyFront;
use App\Models\SurveyQueue;
use App\Models\UserCustomFieldData;
use App\Models\UserStamp;
use App\Repository\Payment\WorldpayInterface;
use App\Repository\Payment\WorldpayRepository;
use App\User;
use App\Utility\TagReplacementUtility;
use Carbon\Carbon;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Log;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {

	    /*
				 * binding service (interface) to repo
				 * will optimize structure later
				 * */

//        dd(date('Y-m-d H:i:s'));
//        $d1 = "2021-02-08 05:24:25";
//        $d2 = "2021-02-09 05:24:25";
//
//        $sec = Carbon::parse($d1)->diffInSeconds(Carbon::parse($d2));
//        dd($sec);


//        $arr['test']['value'] = '';
//        if(isset($arr['test']['value']) && $arr['test']['value'] != ""  ) {
//            dd('not empty');
//        }
//        else {
//            dd('empty');
//        }
        //dd((isset($arr['test']['value']) && isset($arr['test']['value']) != "");

       // $sql = DB::select("SELECT COUNT(id) AS rec_count FROM user_receipts WHERE JSON_UNQUOTE(JSON_EXTRACT(detail,'$.receiptDate.value')) = '11/07/2020'");
//        $date = '';
//        $sql = DB::select("SELECT COUNT(id) AS rec_count FROM user_receipts WHERE  JSON_UNQUOTE(JSON_EXTRACT(detail,'$.receiptDate.value')) = '$date'");
//        dd($sql[0]->rec_count);

        if(config('constant.APP_DEBUG') == true) {
            Log::channel('user')->info(request()->getRequestUri(), ['input_request' => request()->all()]);
        }



        DB::listen(function ($query) {

            $log_info = sprintf("\n%-8s: %s\n\n", "sql", $query->sql);

            $bc = 0;
            foreach ($query->bindings as $binding) {
                $log_info .= sprintf("%-8s: ", "bind ".++$bc);
                if (is_object($binding)) {
                    $log_info .= print_r($binding, true);
                }
                else {
                    $log_info .= $binding . "\n";
                }
            }

            $log_info .= sprintf("%-8s: %s\n", "time", $query->time) .
                "-------------------------------------------------------------------------------";

            Log::channel('sql')->debug($log_info);
        });

        Collection::macro('paginate', function($perPage, $total = null, $page = null, $pageName = 'page') {
            $page = $page ?: LengthAwarePaginator::resolveCurrentPage($pageName);

            return new LengthAwarePaginator(
                $this->forPage($page, $perPage),
                $total ?: $this->count(),
                $perPage,
                $page,
                [
                    'path' => LengthAwarePaginator::resolveCurrentPath(),
                    'pageName' => $pageName,
                ]
            );
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
//        if(env('APP_DEBUG')){
//            $this->app->register(\Rap2hpoutre\LaravelLogViewer\LaravelLogViewerServiceProvider::class);
//        }
	    //$this->app->bind(WorldpayInterface::class,WorldpayRepository::class);

    }
}
