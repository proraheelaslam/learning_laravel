<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VenuesStorage extends Model
{
    //
    protected $table = "venue_storages";
}
