<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StoreConfig extends Model
{
    protected $table        =   'store_configurations';
    protected $guarded      =   ['id'];
    protected $primaryKey   =   "id";

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     * Social Links
     */
    public function socials()
    {
        return $this->hasMany(StoreSocialAccount::class,'store_id','id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     * Check storeImages
     */
    public function businessImages()
    {
        return $this->hasMany(BusinessImage::class,'store_id','id');
    }
}
