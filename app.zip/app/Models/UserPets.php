<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserPets extends Model
{
    protected $table        = 'user_pets';
    protected $primaryKey   = 'id';
    protected $guarded      = ['id'];
}
