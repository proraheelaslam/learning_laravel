<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VoucherCategory extends Model
{
    protected $table = 'voucher_categories';
    protected $guarded = ['id']; //
}
