<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VenueSubscription extends Model
{
    protected $table    = "venue_subscriptions";
    protected $guarded  = ['id'];
}
