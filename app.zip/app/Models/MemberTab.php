<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MemberTab extends Model
{

    protected $table = "member_tabs";
    protected $guarded = [];

    public function customForm() {
        return $this->belongsTo(UserCustomField::class,'custom_form_id','id');
    }

}
