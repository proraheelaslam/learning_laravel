<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserCharityCoins extends Model
{
    protected $table ='user_charity_coins';
    protected $guarded = ['id'];
}
