<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReceiptImages extends Model
{
   protected $table ='receipt_images';
    protected $guarded = ['id'];
}
