<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserReceipts extends Model
{
    protected $table        = 'user_receipts';
    protected $primaryKey   = 'id';
    protected $guarded      = ['id'];

    public function getImageAttribute($value){
        $receiptData = json_decode($this->attributes['detail'], true);

        //Check Logo For Retailer
        $logo ='';
        //mobeen code
        if (isset($receiptData['merchantName']) && isset($receiptData['merchantName']['value'])) {
            $merchant_name = trim(strtolower($receiptData['merchantName']['value']));
            $store = StoreConfig::where('name', $merchant_name)->first();
            if($store)
                $logo = (!empty($store->image))?url($store->image):'';
        }

//        if(isset($receiptData['retailerId'])){
//            $store = StoreConfig::where('external_id',$receiptData['retailerId'])->first();
//            if($store)
//                $logo = (!empty($store->image))?url($store->image):'';
//        }
         return "$logo";
    }

    public function receiptImages()
    {
        return $this->hasMany(ReceiptImages::class,'receipt_id','id');
    }
}
