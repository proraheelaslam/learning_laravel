<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VCampaign extends Model
{

    protected $table = "visual_campaigns";
    protected $fillable = ['company_id','tab_id'];

}
