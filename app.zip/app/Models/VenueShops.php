<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VenueShops extends Model
{
  protected $table ='venue_shops';
  protected $guarded =['id'];
}
