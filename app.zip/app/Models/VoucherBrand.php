<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VoucherBrand extends Model
{
    protected $table = 'voucher_brands';
    protected $guarded = ['id'];
}
