<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BusinessImage extends Model
{
    protected $table        = 'business_images';
    protected $primaryKey   = 'id';
    protected $guarded      = ['id'];
}
