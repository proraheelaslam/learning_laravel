<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserStore extends Model
{
    protected $table ='user_stores';
    protected $primaryKey   = 'id';
    protected $guarded      = ['id'];
}
