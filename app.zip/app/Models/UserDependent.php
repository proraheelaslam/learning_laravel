<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserDependent extends Model
{
    protected $table = "user_dependents";
    protected $guarded = ['id'];
}
