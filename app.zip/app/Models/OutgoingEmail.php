<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OutgoingEmail extends Model
{
    protected $table = 'outgoing_emails';
    protected $guarded = ['id'];
}
