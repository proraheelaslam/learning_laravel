<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AutoCheckout extends Model
{
    protected $table = "auto_checkout";
    protected $guarded = ['id'];
}
