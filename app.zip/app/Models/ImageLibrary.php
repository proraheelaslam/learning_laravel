<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ImageLibrary extends Model
{
    //
    protected $primaryKey = "id";
    protected $table = "file_repositories";
}


