<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserRewardSurvey extends Model
{
    protected $table        = 'user_reward_surveys';
    protected $primaryKey   = 'id';
    protected $guarded      = ['id'];
}
