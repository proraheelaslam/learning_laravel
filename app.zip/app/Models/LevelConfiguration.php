<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LevelConfiguration extends Model
{
    protected $table = 'level_configurations';
    protected $guarded = ['id'];
}
