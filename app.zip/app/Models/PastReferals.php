<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PastReferals extends Model
{
    protected $table    = 'past_referals';
    protected $guarded  = ['id'];
}
