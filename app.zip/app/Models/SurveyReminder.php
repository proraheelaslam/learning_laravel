<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class SurveyReminder extends Model
{

    protected $table = "survey_reminders";
    protected $guarded = [];



}
