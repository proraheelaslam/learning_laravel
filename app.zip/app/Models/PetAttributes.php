<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PetAttributes extends Model
{
    protected $table    = 'pet_attributes';
    protected $guarded  = ['id'];
}
