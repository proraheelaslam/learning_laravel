<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MailDrop extends Model
{
    protected $table = "mail_drops";
    protected $primaryKey = "id";
    protected $guarded = ["id"];
    public $timestamps = false;
}
