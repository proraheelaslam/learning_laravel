<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BadgeState extends Model
{
    protected $table        = "badge_states";
    protected $guarded      = [];
}
