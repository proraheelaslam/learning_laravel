<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VoucherChannel extends Model
{
    protected $table = 'voucher_channels';
    protected $guarded = ['id']; //
}
