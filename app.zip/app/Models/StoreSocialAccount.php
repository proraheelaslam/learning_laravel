<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StoreSocialAccount extends Model
{
    protected $table = "store_social_accounts";
    protected $primaryKey = "id";
    protected $guarded = ['id'];
}
