<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MissionUserEntry extends Model
{
    protected $table    = 'mission_users_entries';
    protected $guarded  = ['id'];
}
