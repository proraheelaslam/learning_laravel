<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StoreClasses extends Model
{
    protected $table        =   'store_classes';
    protected $guarded      =   ['id'];
    protected $primaryKey   =   "id";
}
