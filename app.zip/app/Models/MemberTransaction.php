<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MemberTransaction extends Model
{

    protected $table = "member_transactions";

    public function receipts()
    {
        return $this->belongsTo(UserReceipts::class,'reference_no','reference_no');
    }

}
