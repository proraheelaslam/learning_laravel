<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Badge extends Model
{
    protected $table        = "badges";
    protected $guarded      = [];

    public function states()
    {
        return $this->hasMany(BadgeState::class, 'badge_id', 'id');
    }//..... end of games() ......//
}
