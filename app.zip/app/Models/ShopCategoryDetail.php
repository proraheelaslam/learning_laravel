<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShopCategoryDetail extends Model
{
    protected $table ='venue_cat_details';
    protected $guarded = ['id'];
}
