<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SurveyQueue extends Model
{
    protected $table        = "survey_queue";
    protected $guarded      = [];


    public function user() {
        return $this->belongsTo(\App\User::class,'user_id','user_id');
    }

    public function survey() {
        return $this->belongsTo(SurveyFront::class,'survey_id','id');
    }
}
