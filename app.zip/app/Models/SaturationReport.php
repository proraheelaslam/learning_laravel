<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SaturationReport extends Model
{
    protected $table        = 'saturation_report';
    protected $primaryKey   = 'id';
    protected $guarded      = ['id'];
}
