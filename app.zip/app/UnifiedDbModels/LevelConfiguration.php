<?php

namespace App\UnifiedDbModels;

use Illuminate\Database\Eloquent\Model;

class LevelConfiguration extends Model
{
    protected $table = 'level_configurations';
    protected $guarded = ['id'];
}
