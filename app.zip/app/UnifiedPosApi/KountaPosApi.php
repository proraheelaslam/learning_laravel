<?php
/**
 * Created by PhpStorm.
 * User: elementary1
 * Date: 7/18/2017
 * Time: 10:51 AM
 */

namespace App\UnifiedPosApi;


use App\interfaces\PosApiInterface;

class KountaPosApi
{

    public function getStoreCategories($params = [])
    {
        // TODO: Implement getStoreCategories() method.
    }

    public function getStoreInfo($params = [])
    {
        // TODO: Implement getStoreInfo() method.
    }

    public function getAllProducts($params = [])
    {
        // TODO: Implement getAllProducts() method.
    }
}