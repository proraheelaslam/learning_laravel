<?php

namespace App\Exceptions;

use Exception;
use Throwable;

class PaymentConfigException extends Exception
{

}
