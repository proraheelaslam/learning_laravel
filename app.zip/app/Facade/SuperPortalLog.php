<?php

namespace App\Facade;

class SuperPortalLog extends \Illuminate\Support\Facades\Facade
{

    protected static function getFacadeAccessor()
    {
        return "SuperPortalLog";
    }
}