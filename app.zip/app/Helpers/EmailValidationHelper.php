<?php

namespace App\Helpers;

class EmailValidationHelper
{
    protected $domainResultCache = [];

    public function splitEmailAddress($email)
    {
        $pieces = explode('@', $email);
        $arr['user'] = $pieces[0];
        $arr['domain'] = $pieces[1];
        return $arr;
    }

    public function validateDomainForEmail($domainName, &$message)
    {
        // Return previously cached results if available
        if (isset($this->domainResultCache[$domainName])) {
            $message = $this->domainResultCache[$domainName]['message'] . ' (cached)';
            return $this->domainResultCache[$domainName]['result'];
        }

        $result = false;
        $message = '';

        // Check for NS records
        try {
            $nsResult = @dns_get_record($domainName, DNS_NS);
        } catch(Exception $e) {
            $message = sprintf("DNS resolution error: %s", $e->getMessage());
            print "ns error $message\n";
            return $result;
        }

        if (empty($nsResult)) {
            $message = sprintf("No NS records found for %s", $domainName);
            #print_r($nsResult);
        }
        else {
            // Check for MX records
            $mxResult = [];
            try {
                dns_get_mx($domainName, $mxResult);
            } catch(Exception $e) {
                $message = sprintf("DNS resolution error: %s", $e->getMessage());
                print "mx error $message\n";
                return $result;
            }

            if (empty($mxResult)) {
                $message = sprintf("No MX records found for %s", $domainName);
                #print_r($mxResult);
            }
            else {
                $result = true;
                $message = sprintf("Domain DNS valiation successful for %s", $domainName);
            }
        }

        // Cached the result
        $this->domainResultCache[$domainName] = [
            'result' => $result,
            'message' => $message,
        ];

        return $result;
    }

    function validateEmailAddress($email, &$message)
    {
        // Regex validation
        $regex = '/^((?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){255,})(?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){65,}@)(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22))(?:\.(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22)))*)@((?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-[a-z0-9]+)*\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-[a-z0-9]+)*)|(?:\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\])))$/iD';
        if (!preg_match($regex, $email, $matches)) {
            $message = 'Email address failed regex validation';
            return false;
        }

        #$emailParts = $this->splitEmailAddress($email);
        $emailParts['user'] = $matches[1];
        $emailParts['domain'] = $matches[2];

        $domainMessage = "";
        if (!$this->validateDomainForEmail($emailParts['domain'], $domainMessage)) {
            $message = $domainMessage;
            return false;
        }

        $message = "Email address validation passed";
        return true;
    }
}
