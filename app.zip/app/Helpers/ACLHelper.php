<?php

namespace App\Helpers;

use Illuminate\Contracts\Container\BindingResolutionException;
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Exception\SuspiciousOperationException;
use Symfony\Component\HttpFoundation\Exception\ConflictingHeadersException;

class ACLHelper
{
    public const ACL_INI_CONFIG_FILE_NAME = 'acl.ini';
    public const ACL_MODE_BLACKLIST = 'blacklist';
    public const ACL_MODE_WHITELIST = 'whitelist';
    public const ACL_MODES = [
        self::ACL_MODE_BLACKLIST,
        self::ACL_MODE_WHITELIST,
    ];
    protected $aclsConfig = [];

    /**
     * 
     * @param mixed|null $aclIniConfigFilePath 
     * @return void 
     * @throws BindingResolutionException 
     * @throws Exception 
     */
    public function __construct($aclIniConfigFilePath = null)
    {
        $this->aclsConfig = $this->loadACLsFromIniFile($aclIniConfigFilePath);
    }

    /**
     * Load ACLs config from INI file
     * 
     * @param mixed $aclIniConfigFilePath 
     * @return array 
     * @throws BindingResolutionException 
     * @throws Exception 
     */
    private function loadACLsFromIniFile($aclIniConfigFilePath)
    {        
        if (empty($aclIniConfigFilePath)) {
            $aclIniConfigFilePath = config_path(self::ACL_INI_CONFIG_FILE_NAME);
        }
    
        if (!file_exists($aclIniConfigFilePath)) {
            throw new \Exception('ACL INI file not found');
        }

        $config = parse_ini_file($aclIniConfigFilePath, true);
            
        if (!$config) {
            throw new \Exception('Failed to parse ACL INI file');
        }

        return $config;
    }

    /**
     * 
     * @param mixed $ip 
     * @param mixed $cidr_range 
     * @return bool 
     */
    public function isCIDRMatch($ip, $cidr_range): bool
    {
        # Apply default /32 mask if missing
        $pos = strpos($cidr_range, '/');

        if ($pos === false) {
            $cidr_range .= '/32';
        }

        list($subnet, $bits) = explode('/', $cidr_range);
        $ip = ip2long($ip);
        $subnet = ip2long($subnet);
        $mask = -1 << (32 - intval($bits));
        $subnet &= $mask;
        return ($ip & $mask) == $subnet;
    }

    /**
     * 
     * @param mixed $ipAddress 
     * @param array $acls 
     * @param string $aclMode 
     * @return bool 
     * @throws BindingResolutionException 
     * @throws SuspiciousOperationException 
     * @throws ConflictingHeadersException 
     */
    public function checkACL($ipAddress, $acls = [], $aclMode = self::ACL_MODE_WHITELIST): bool
    {
        $isWhitelist = strtolower($aclMode) == self::ACL_MODE_WHITELIST ? true : false;
        $result = false;
        $msg = "DENIED";

        // Handle single acl or array of acls
        if (!is_array($acls)) {
            $acls = [ $acls ];
        }

        $stop = false;
        
        foreach ($acls as $acl) {
            if (!array_key_exists($acl, $this->aclsConfig)) {
                $msg = "INVALID ACL $acl";
                continue;
            }

            $ranges = $this->aclsConfig[$acl];

            if (!is_array($ranges)) {
                $msg = "INVALID ACL $acl";
                continue;
            }

            foreach (array_keys($ranges) as $range) {
                if ($this->isCIDRMatch($ipAddress, $range)) {
                    $stop = true;
                    break;
                }
            }

            if ($stop) {
                break;
            }
        }

        if (($isWhitelist && $stop) || (!$isWhitelist && !$stop)) {
            $msg =  "ALLOWED";
            $result = true;
        }

        Log::channel('custom')->info('route_acls', ['message' => sprintf("INFO %s(%s, %s): %s", 
                                                        request()->path(),
                                                        request()->method(),
                                                        request()->ip(),
                                                        $msg)]);
        return $result;
    }
}
