<?php

namespace App\Helpers;

/*
 * A helper class for reading and writing CSV Files
 *
 * Usage:
 *
 * $csv_formats = [
 *     'customers' => [
 *         'delimiter' => "\t",
 *         'header_rows' => 1,
 *         'validate' => true,
 *         'fields' => [
 *             'ClientID', 'Last Name', 'First Name', 'Title', 'Email', 'Phone Number',
 *         ],
 *     ],
 *     'customers_invalid' => [
 *         'delimiter' => "\t",
 *         'header_rows' => 1,
 *         'validate' => true,
 *         'fields' => [
 *             'ClientID', 'Email', 'ValidationMessage',
 *         ],
 *     ],
 * ];
 *
 * // Add file specifications to CSV helper
 * foreach ($csv_formats as $name => $specification) {
 *     $CSVFileHelper->addFileSpecification($name, $specification);
 * }
 *
 * // Read all records in file
 * $records = $CSVFileHelper->readFile('customers.csv', 'customers');
 *
 * // Read records in batches
 * $batchSize = 100;
 * $eof = false;
 * while (!$eof) {
 *      $records = $CSVFileHelper->readFile('customers.csv', 'customers', $batchSize, $eof);
 *      print $CSVFileHelper->statusMessage . "\n";
 * }
 *
 * // Read in a batch of records from the beginnning of the file
 * $records = $CSVFileHelper->readFile('customers.csv', 'customers', 10, true);
 *
 * // Write the invalid records to file
 * $CSVFileHelper->writeFile('customers_invalid.csv', 'customers_invalid', $invalidRecords);
 *
 */

class CSVFileHelper
{
    public $specifications = [];
    public $statusMessage = '';
    protected $errors = [
        'error' => [],
        'warn' => [],
    ];
    protected $readFileHandle = null;
    protected $readFileHeaders = null;

    private function isAssociative(array $arr)
    {
        if (array() === $arr) {
            return false;
        }
        return array_keys($arr) !== range(0, count($arr) - 1);
    }

    public function addFileSpecification($name, $specification)
    {
        // Support backward compatibiliy for headers -> header_rows
        if (isset($specfication['headers'])) {
            $specfication['header_rows'] = intval($specfication['headers']);
            unset($specfication['headers']);
        }

        // Apply various defaults if not present in the specification
        $defaults = [
            'delimiter' => ',',     // default delimiter of comma
            'header_rows' => 1,     // The number of header rows
            'validate' => true,     // Validate the headers and column counts for each line of the file
        ];
        foreach ($defaults as $key => $val) {
            if (!isset($specification[$key])) {
                $specification[$key] = $val;
            }
        }

        $this->fileSpecifications[$name] = $specification;
    }

    public function getFileSpecification($name)
    {
        if (!isset($this->fileSpecifications[$name])) {
            $msg = sprintf("Unknown file specification '%s'", $name);
            $this->statusMessage = $msg;
            $this->logError($msg, null, 'error');
            return null;
        }

        return $this->fileSpecifications[$name];
    }

    public function getStatusMessage()
    {
        return $this->statusMessage;
    }

    public function logError($message, $level = 'info', $lineNumber = null)
    {
        $errorEvent = [
            'message' => $message,
            'level' => strtolower($level),
        ];
        if (!empty($lineNumber)) {
            $errorEvent['lineNumber'] = $lineNumber;
        }

        $this->errors[$level][] = $errorEvent;

        if ($level === 'error') {
            $this->statusMessage = $message;
        }

        return;
    }

    public function readFile(
        String $filename,
        String $specName,
        $lineLimit = null,
        &$eof = false,
        $reset = false
    ) {
        if (!file_exists($filename)) {
            $msg = sprintf("File does not exist '%s'", $filename);
            $this->statusMessage = $msg;
            $this->logError($msg, null, 'error');
            return null;
        }

        $specification = $this->getFileSpecification($specName);
        if (empty($specification)) {
            return null;
        }

        $lineCount = 0;
        $records = [];
        $continuing = false;

        #setlocale(LC_CTYPE, "en.UTF8");

        // Handle continuation reading of an existing open file
        if (!isset($this->readFileHandle[$filename])) {
            $fileHandle = fopen($filename, "r");
            $this->readFileHandle[$filename] = $fileHandle;
        } else {
            $fileHandle = $this->readFileHandle[$filename];
            $continuing = true;

            # Reset/rewind to the start of the file
            if ($reset) {
                rewind($fileHandle);
                $continuing = false;
            }

            foreach (['error', 'warn'] as $level) {
                $this->errors[$level] = [];
            }
        }

        // Handle the presence of a BOM (Byte Order Marker) at the top of CSV file
        // Progress file pointer and get first 3 characters to compare to the BOM string.
        if (!$continuing) {
            $bom = "\xef\xbb\xbf";
            if (fgets($fileHandle, 4) !== $bom) {
                # BOM not found - rewind pointer to start of file.
                rewind($fileHandle);
            }
        }

        while (!feof($fileHandle)) {
            $lineArray = fgetcsv($fileHandle, 1024, $specification['delimiter']);
            $lineCount++;

            if ($lineArray === false) {
                break;
            }

            // We always use the specification fields as record array keys
            $headers = $specification['fields'];

            // Handle header rows and validation according to specification
            if ($specification['header_rows'] > 0) {
                if (!$continuing && $lineCount <= $specification['header_rows']) {
                    if ($specification['validate']) {
                        $fileHeaders = $lineArray;
                        foreach ($headers as $field) {
                            if (!in_array($field, $fileHeaders)) {
                                $this->logError(
                                    sprintf("Field '%s' is not present in file header", $field),
                                    'error',
                                    $lineCount
                                );
                                return(null);
                            }
                        }
                    }
                    continue;
                }
            }

            if ($specification['validate'] && count($lineArray) != count($headers)) {
                $this->logError(
                    sprintf('Skipping line %d due to incorrect field count', $lineCount),
                    'warn',
                    $lineCount
                );
            } else {
                // Create an associative array using the column headers provided
                $record = array();
                for ($k = 0; $k < count($headers); $k++) {
                    if (isset($lineArray[$k])) {
                        $record[$headers[$k]] = trim($lineArray[$k]);
                    } else {
                        $record[$headers[$k]] = '';
                    }
                }

                $records[] = $record;
            }

            if (!empty($lineLimit) && count($records) >= $lineLimit) {
                break;
            }
        }

        $eof = feof($fileHandle);

        $this->statusMessage = sprintf(
            "success: %d records read, %d errors, %d warnings",
            count($records),
            count($this->errors['error']),
            count($this->errors['warn'])
        );

        return $records;
    }

    public function writeFileHeader(
        String $filename,
        String $specName
    ) {
        $specification = $this->getFileSpecification($specName);
        if (empty($specification)) {
            return null;
        }

        $lineCount = 0;

        #setlocale(LC_CTYPE, "en.UTF8");

        $fileHandle = fopen($filename, "a");

        // Output column headers
        if ($specification['header_rows'] > 0) {
            for ($x = 0; $x < $specification['header_rows']; $x++) {
                $length = fputcsv($fileHandle, $specification['fields'], $specification['delimiter']);
            }
        }
    }

    public function writeFile(
        String $filename,
        String $specName,
        Array $records = [],
        $recordLimit = null,
        $withoutHeader = false
    ) {
        $specification = $this->getFileSpecification($specName);
        if (empty($specification)) {
            return null;
        }

        $lineCount = 0;

        #setlocale(LC_CTYPE, "en.UTF8");

        $fileHandle = fopen($filename, "a");

        $recordCount = 0;
        foreach ($records as $record) {
            if (is_object($record)) {
                $record = (array) $record;
            }

            $recordCount++;

            // Output column headers
            if (!$withoutHeader && $specification['header_rows'] > 0 && $recordCount === 1) {
                for ($x = 0; $x < $specification['header_rows']; $x++) {
                    $length = fputcsv($fileHandle, $specification['fields'], $specification['delimiter']);
                }
            }

            // If record data is an associative array convert to sequential in the
            // correct order for the specification.  Array keys must match column headers.
            if ($this->isAssociative($record)) {
                $sequentialRecord = [];
                foreach ($specification['fields'] as $field) {
                    if (array_key_exists($field, $record)) {
                        $sequentialRecord[] = $record[$field];
                    } else {
                        $sequentialRecord[] = '';
                        $this->logError(
                            sprintf("Missing array key '%s' for record %d", $field, $recordCount),
                            'warn',
                            $recordCount
                        );
                    }
                }
            } else {
                $sequentialRecord = $record;
            }

            // Output the record
            $length = fputcsv($fileHandle, $sequentialRecord, $specification['delimiter']);

            if (!empty($recordLimit) && $recordCount >= $recordLimit) {
                break;
            }
        }

        $this->statusMessage = sprintf(
            "success: %d records written, %d errors, %d warnings",
            count($records),
            count($this->errors['error']),
            count($this->errors['warn'])
        );

        return $recordCount;
    }
}
