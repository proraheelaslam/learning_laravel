<?php

namespace App\OpenApi\Responses;

use GoldSpecDigital\ObjectOrientedOAS\Objects\Schema;
use Vyuldashev\LaravelOpenApi\Factories\ResponseFactory;
use Vyuldashev\LaravelOpenApi\Contracts\Reusable;
use App\OpenApi\Schemas\ListPaymentResponseSchema;
use GoldSpecDigital\ObjectOrientedOAS\Objects\MediaType;
use GoldSpecDigital\ObjectOrientedOAS\Objects\Response;


class ListPaymentResponse extends ResponseFactory
{
    public function build(): Response
    {
        return Response::create('ListPaymentResponse')
            ->description('Response body of Addcard Request')
            ->content(
                MediaType::json()->schema(ListPaymentResponseSchema::ref())
            );
//        return Response::ok()->description('Successful response')->content(
//            MediaType::json()->schema(ListPaymentResponseSchema::ref())
//        );
    }
}
