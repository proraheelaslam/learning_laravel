<?php

namespace App\OpenApi\Responses;

use GoldSpecDigital\ObjectOrientedOAS\Objects\MediaType;
use GoldSpecDigital\ObjectOrientedOAS\Objects\Response;
use GoldSpecDigital\ObjectOrientedOAS\Objects\Schema;
use Vyuldashev\LaravelOpenApi\Contracts\Reusable;
use Vyuldashev\LaravelOpenApi\Factories\ResponseFactory;

class AddCardResponse extends ResponseFactory implements Reusable
{
    public function build(): Response
    {
        $response = Schema::object()->properties(
            Schema::string('message')->example('Add new card success!'),
            Schema::number('status')->example('201'),
            Schema::array('data')->items(Schema::string())
        );

        return Response::create('AddCardResponse')
            ->description('Response body of Addcard Request')
            ->content(
                MediaType::json()->schema($response)
            );
    }
}
