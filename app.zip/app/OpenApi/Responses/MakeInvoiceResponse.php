<?php

namespace App\OpenApi\Responses;


use App\OpenApi\Schemas\MakeInvoiceResponseSchema;
use App\OpenApi\Schemas\PaymentAuthorizedResponseSchema;
use GoldSpecDigital\ObjectOrientedOAS\Objects\MediaType;
use GoldSpecDigital\ObjectOrientedOAS\Objects\Response;
use Vyuldashev\LaravelOpenApi\Contracts\Reusable;
use Vyuldashev\LaravelOpenApi\Factories\ResponseFactory;

class MakeInvoiceResponse extends ResponseFactory implements Reusable
{
    public function build(): Response
    {

        return Response::create('MakeInvoiceResponse')
            ->description('Response body of Addcard Request')
            ->content(
                MediaType::json()->schema(MakeInvoiceResponseSchema::ref())
            );
    }
}
