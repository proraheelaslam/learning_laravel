<?php

namespace App\OpenApi\Schemas;

use GoldSpecDigital\ObjectOrientedOAS\Contracts\SchemaContract;
use GoldSpecDigital\ObjectOrientedOAS\Objects\AllOf;
use GoldSpecDigital\ObjectOrientedOAS\Objects\AnyOf;
use GoldSpecDigital\ObjectOrientedOAS\Objects\Not;
use GoldSpecDigital\ObjectOrientedOAS\Objects\OneOf;
use GoldSpecDigital\ObjectOrientedOAS\Objects\Schema;
use Vyuldashev\LaravelOpenApi\Contracts\Reusable;
use Vyuldashev\LaravelOpenApi\Factories\SchemaFactory;

class MakeInvoiceResponseSchema extends SchemaFactory implements Reusable
{
    /**
     * @return AllOf|OneOf|AnyOf|Not|Schema
     */
    public function build(): SchemaContract
    {
        return Schema::object('MakeInvoiceResponse')
            ->properties(
                Schema::object('data')
                ->properties(
                    Schema::object('invoice')->properties(
                        Schema::string("invoiceItemId"),
                        Schema::string("invoiceId"),
                        Schema::string("linkedInvoiceItemId"),
                        Schema::string("accountId"),
                        Schema::string("childAccountId"),
                        Schema::string("bundleId"),
                        Schema::string("subscriptionId"),
                        Schema::string("productName"),
                        Schema::string("planName"),
                        Schema::string("phaseName"),
                        Schema::string("usageName"),
                        Schema::string("prettyProductName"),
                        Schema::string("prettyPlanName"),
                        Schema::string("prettyPhaseName"),
                        Schema::string("prettyUsageName"),
                        Schema::string("itemType"),
                        Schema::string("description"),
                        Schema::string("startDate"),
                        Schema::string("endDate"),
                        Schema::number("amount"),
                        Schema::string("rate"),
                        Schema::string("currency"),
                        Schema::string("quantity"),
                        Schema::string("itemDetails"),
                        Schema::string("childItems")
                    ),
                    Schema::object('challengeData')
                    ->properties(
                        Schema::string("outcome"),
                        Schema::string("transactionReference"),
                        Schema::string("childItems"),
                        Schema::object('authentication')
                            ->properties(
                                Schema::string('version')
                            ),
                        Schema::object('challenge')
                            ->properties(
                                Schema::string("reference"),
                                Schema::string("url"),
                                Schema::string("jwt"),
                                Schema::string('payload')
                            )
                    )
                ),
                Schema::number('status'),
                Schema::string('paymentMethodId'),
                Schema::string('isRequireChallenge')
            );
    }
}
