<?php

namespace App\OpenApi\Schemas;

use GoldSpecDigital\ObjectOrientedOAS\Contracts\SchemaContract;
use GoldSpecDigital\ObjectOrientedOAS\Objects\AllOf;
use GoldSpecDigital\ObjectOrientedOAS\Objects\AnyOf;
use GoldSpecDigital\ObjectOrientedOAS\Objects\Not;
use GoldSpecDigital\ObjectOrientedOAS\Objects\OneOf;
use GoldSpecDigital\ObjectOrientedOAS\Objects\Schema;
use Vyuldashev\LaravelOpenApi\Contracts\Reusable;
use Vyuldashev\LaravelOpenApi\Factories\SchemaFactory;

class PaymentAuthorizedRequestSchema extends SchemaFactory implements Reusable
{
    /**
     * @return AllOf|OneOf|AnyOf|Not|Schema
     */
    public function build(): SchemaContract
    {
        return Schema::object('PaymentAuthorizedRequest')
            ->properties(
                Schema::string('paymentMethodId'),
                Schema::string('transactionReference'),
                Schema::string('challengeReference'),
                Schema::object('invoice')->properties(
                    Schema::string("invoiceId"),
                    Schema::string("accountId"),
                    Schema::string("description"),
                    Schema::number("amount"),
                    Schema::string("currency")
                )
            );
    }
}
