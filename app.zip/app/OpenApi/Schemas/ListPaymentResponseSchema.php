<?php

namespace App\OpenApi\Schemas;

use GoldSpecDigital\ObjectOrientedOAS\Contracts\SchemaContract;
use GoldSpecDigital\ObjectOrientedOAS\Objects\AllOf;
use GoldSpecDigital\ObjectOrientedOAS\Objects\AnyOf;
use GoldSpecDigital\ObjectOrientedOAS\Objects\Not;
use GoldSpecDigital\ObjectOrientedOAS\Objects\OneOf;
use GoldSpecDigital\ObjectOrientedOAS\Objects\Schema;
use Vyuldashev\LaravelOpenApi\Factories\SchemaFactory;
use Vyuldashev\LaravelOpenApi\Contracts\Reusable;
class ListPaymentResponseSchema extends SchemaFactory implements Reusable
{
    /**
     * @return AllOf|OneOf|AnyOf|Not|Schema
     */
    public function build(): SchemaContract
    {
        return Schema::object('ListPayment')
            ->properties(
                Schema::number('status')->example(200),
                Schema::object('data')->properties(
                    Schema::string('paymentMethodId'),
                    Schema::string('accountId'),
                    Schema::string('pluginName'),
                    Schema::object('pluginInfo')
                        ->properties(
                            Schema::object('properties')
                            ->properties(Schema::object('value')
                            ->properties(Schema::object('_embedded')
                            ->properties(
                                Schema::object('verification')
                                    ->properties(Schema::object('paymentInstrument')
                                        ->properties(Schema::string('type'),
                                            Schema::object('card')->properties(Schema::string('brand'))
                                        )
                                    ),
                                Schema::object('token')
                                ->properties(
                                    Schema::object('tokenPaymentInstrument')
                                    ->properties(
                                        Schema::string('type'),
                                        Schema::string('href')
                                    ),
                                    Schema::object('paymentInstrument')
                                    ->properties(
                                        Schema::string('cardNumber'),
                                        Schema::string('cardHolderName'),
                                        Schema::string('cardExpiryDate')
                                    )
                                )
                            )))
                        )
                )
            );
    }
}
