<?php

namespace App\OpenApi\RequestBodies;

use App\OpenApi\Schemas\AddNewCardSchema;
use GoldSpecDigital\ObjectOrientedOAS\Objects\MediaType;
use GoldSpecDigital\ObjectOrientedOAS\Objects\RequestBody;
use Vyuldashev\LaravelOpenApi\Factories\RequestBodyFactory;

class AddNewCardRequestBody extends RequestBodyFactory
{
    public function build(): RequestBody
    {
        return RequestBody::create('AddNewCardRequest')
            ->description('User data')
            ->content(
                MediaType::json()->schema(AddNewCardSchema::ref())
            );
    }
}
