<?php

namespace App\OpenApi\RequestBodies;

use App\OpenApi\Schemas\MakeInvoiceRequestSchema;
use App\OpenApi\Schemas\PaymentAuthorizedRequestSchema;
use GoldSpecDigital\ObjectOrientedOAS\Objects\MediaType;
use GoldSpecDigital\ObjectOrientedOAS\Objects\RequestBody;
use Vyuldashev\LaravelOpenApi\Contracts\Reusable;
use Vyuldashev\LaravelOpenApi\Factories\RequestBodyFactory;

class PaymentAuthorizedRequestBody extends RequestBodyFactory implements Reusable
{
    public function build(): RequestBody
    {
        return RequestBody::create('PaymentAuthorizedRequest')
            ->description('Payment Authorized Request Body')
            ->content(
                MediaType::json()->schema(PaymentAuthorizedRequestSchema::ref())
            );
    }
}
