<?php

namespace App\OpenApi\RequestBodies;

use App\OpenApi\Schemas\MakeInvoiceRequestSchema;
use GoldSpecDigital\ObjectOrientedOAS\Objects\MediaType;
use GoldSpecDigital\ObjectOrientedOAS\Objects\RequestBody;
use Vyuldashev\LaravelOpenApi\Contracts\Reusable;
use Vyuldashev\LaravelOpenApi\Factories\RequestBodyFactory;

class MakeInvoiceRequestBody extends RequestBodyFactory implements Reusable
{
    public function build(): RequestBody
    {
        return RequestBody::create('MakeInvoiceBody')
        ->description('Make Invoice Body')
        ->content(
            MediaType::json()->schema(MakeInvoiceRequestSchema::ref())
        );
    }
}
