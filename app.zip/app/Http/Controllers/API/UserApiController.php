<?php /** @noinspection PhpLanguageLevelInspection */

namespace App\Http\Controllers\API;

use App\Exports\SurveyReport;
use App\Exports\UsersExport;
use App\Http\Controllers\API\ElasticSearchController;
use App\Http\Controllers\API\PaymentController;
use App\Http\Controllers\API\StripePaymentController;
use App\Http\Controllers\API\VisualCampaignController;
use App\Jobs\ElasticSearchEntry;
use App\Models\AppSetting;
use App\Models\AutoCheckout;
use App\Models\AutoOrderPlacement;
use App\Models\Badge;
use App\Models\BadgeState;
use App\Models\Campaign;
use App\Models\Charity;
use App\Models\EmailTemplate;
use App\Models\FaqFeedBack;
use App\Models\FeedBack;
use App\Models\Groups;
use App\Models\Lt_Transaction;
use App\Models\MemberTransaction;
use App\Models\MerchantStore;
use App\Models\Mission;
use App\Models\MissionUserEntry;
use App\Models\PastReferals;
use App\Models\PunchCard;
use App\Models\ReceiptImages;
use App\Models\RecipeOffer;
use App\Models\Segment;
use App\Models\ShopCategory;
use App\Models\Store;
use App\Models\Survey;
use App\Models\SurveyFront;
use App\Models\SurveyQuestion;
use App\Models\UserAddresses;
use App\Models\UserCharityCoins;
use App\Models\UserCustomField;
use App\Models\UserCustomFieldData;
use App\Models\UserNotification;
use App\Models\UserPets;
use App\Models\UserReceipts;
use App\Models\UserStamp;
use App\Models\UserSurveyAnswer;
use App\Models\UserVenueRelation;
use App\Models\VenueSubscription;
use App\Models\Voucher;
use App\Models\VoucherLog;
use App\Models\VoucherUser;
use App\Utility\ElasticsearchUtility;
use App\Utility\PushNotificationCustom;
use App\Utility\Utility;
use App\Utility\VCTrigger;
use Carbon\Carbon;
use Edujugon\PushNotification\Facades\PushNotification;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;
use http\Env;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\API\RecipeController;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use Matthewbdaly\SMS\Exceptions\DriverNotConfiguredException;
use mysql_xdevapi\Exception;
use phpDocumentor\Reflection\Types\Self_;
use Psr\Http\Message\ResponseInterface;
use Schema;
use Image;
use App\Models\User_Card;
use App\classes\CommonLibrary;
use App\Models\Setting;
use App\Models\FavouriteNews;
use App\Models\News;
use App\Models\VenueSubscription as VenueSubscrition;
use App\UnifiedDbModels\Venue;
use App\Facade\SoldiLog;
use App\Models\VenueImage;
use App\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\URL;
use Matthewbdaly\SMS\Client as awsClient;
use Matthewbdaly\SMS\Drivers\Aws;

use App\Http\Controllers\API\GamificationController;
use Matthewbdaly\SMS\Drivers\Twilio;
use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Psr7\Response;
use App\Http\Controllers\API\VenueController;
use function foo\func;
use App\Http\Controllers\API\VoucherController;
use App\Http\Controllers\API\FilesController;
use App\Http\Controllers\API\FixesController;
use App\Http\Controllers\API\PetController;


class UserApiController extends Controller
{

    const IS_ACTIVE = 'is_active';
    const OLD_USER = 'old_user';
    const USER_MOBILE = 'user_mobile';
    const COMPANY_ID = 'company_id';
    const COUNTRY = 'Country';
    const COUNTRY_INDEX = 'country';
    const DEVICE_TOKEN = 'device_token';
    const GENDER = 'gender';
    const IS_EMAIL = 'is_email';
    const MEMBER = 'Member';
    const CUSTOM = 'custom';
    const FORGET_EMAIL = 'forget_email';
    const REQUIRED = 'required';
    const PASS = 'password';
    const UPDATED_AT = 'updated_at';
    const PHONE = 'phone';
    const FIRST_NAME = 'first_name';
    const LAST_NAME = 'last_name';
    const IMAGE = 'image';
    const SUBRUB = 'subrub';
    const USERNAME = 'userName';
    const TITLE = 'title';
    const ROUTE = 'route';
    const DEFAULT = 'default';
    const CARD_NO = '4444333322221111';
    const CREATED_AT = 'created_at';
    const DATE_FORMAT = 'g:i a';
    const F_COLOR = 'FFFFFF';
    const C_COLOR = '5c5c5c';
    const DATA_FOUND = 'Data Found';
    const NO_DATA_FOUND = 'No data found';
    const ERROR = 'error';
    const CUSTOMER_ID = 'customer_id';
    const BUSINESS_ID = 'business_id';
    const ACCOUNT_ID = 'account_id';
    const REF_CODE = 'referral_code';
    const USER_ID_MISSING = 'user_id is missing';
    const IS_DELETED = 'is_deleted';
    const EMAIL = 'email';
    const USER_IMAGE = 'user_image';
    const USER_PATH = '/public/users/';
    const USER_PATH_THUMB = '/public/users/thumbs/thumb_';
    const USER_FIRST_NAME = 'user_first_name';
    const YMD = 'Y-m-d';
    const ACTIVATION_TOKEN = 'activation_token';
    const DEVICE_TYPE = 'device_type';
    const STATE = 'state';
    const STORE_DATA = 'store_data';
    const DEFAULT_VENUE = 'default_venue';
    const USER_ID = 'user_id';
    const VENUE_ID = 'venue_id';
    const API_TOKEN = 'api_token';
    const INVALID_INFO = 'Invalid information is added';
    const MAKE_PAYMENT = 'make_payment';
    const CUSTOM_DOC_TYPE = 'custom_doc_type';
    const REFERRAL = 'referral';
    const NOTES = 'notes';
    const COINS = 'coins';
    const EARNED = ' You Earned ';
    const ADDED_COINS = ' coins which has been added to your account.';
    const WELCOME = 'Welcome to ';
    const LOG_PUNCH = 'punchCardStamp()';
    const FAV = 'favourite';
    const SOURCE = '_source';
    const REDEEMED_POINTS = 'redeemed_points';
    const MEMBER_GROUP = 'member_group';
    const VOUCHER_NAME = 'voucher_name';
    const PRODUCT_ID = 'product_id';
    const SORT_DATE = 'sortDate';
    const MATCH = 'match';
    const PAYMENT_TYPE = 'payment_type';
    const STATUS = 'status';
    const PASS_ERROR_MSG = 'Password must be at least 6 characters and must contain at least one lower case letter, one upper case letter and one digit';
    const CONTENT = 'content';
    const USER_AVATAR = 'user_avatar';
    const SOLDI_ID = 'soldi_id';
    const EXPIRY_TIME = 'expiry_time';
    const DEBUG_MOD = 'debug_mod';
    const POSTAL_CODE = 'postal_code';
    const ADDRESS = 'address';
    const STREET_NUMBER = 'street_number';
    const STREET_NAME = 'street_name';
    const MESSAGE = 'message';
    const PERSONA_ID = 'persona_id';
    const USER_FAMILY_NAME = 'user_family_name';

    public $_common_library;


    public $KB_HEADERS = [];
    public $KB_CLIENT;
    public $register_unique_col = 'email';
    public $payment_method = 'barclay';
    public $app_name = '';
    public $timeout = '';
    public $send_email_vp = false;
    public $enable_gigya = false;
    public $password_check = false;

    public function __construct()
    {
        set_time_limit(0);
        ini_set('max_execution_time', '60000');
        ini_set('max_input_time', '1000');
        ini_set('allow_url_fopen', 'on');


        //Check Email Send Through VP
        $send_email_vp = Setting::where('type', 'send_email_vp')->first();
        if ($send_email_vp) {
            if ($send_email_vp->field1 == 1)
                $this->send_email_vp = true;
            else if ($send_email_vp->field1 == 0)
                $this->send_email_vp = false;
        }

        // Check Payment Timeout
        $timeout = Setting::where('type', 'payment_timeout')->first();
        $this->timeout = ($timeout) ? $timeout->field1 : 45;

        //Check Uniquer Field
        $setting = Setting::where('type', 'unique_setting')->first();
        if ($setting) {
            if ($setting->field1 == 'email' || $setting->field1 == 'phone')
                $this->register_unique_col = $setting->field1;
            else
                $this->register_unique_col = 'email';
        } else {
            $this->register_unique_col = 'email';
        }


        // Enable Gigya Check
        $enable_gigya = Setting::where('type', 'enable_gigya')->first();
        if ($enable_gigya)
            $this->enable_gigya = ($enable_gigya->field1 == 1) ? true : false;

        //Payment Type Check
        $payment_setting = Setting::where('type', 'payment_method')->first();
        if ($payment_setting)
            $this->payment_method = $payment_setting->field1;

        //Engage App Name
        $appName = config('constant.APP_NAME');
        $this->app_name = str_replace('engage-', '', $appName);

        $strict_password = Setting::where('type', 'strict_password')->first();
        if ($strict_password)
            $this->password_check = ($strict_password->field1 == 1) ? true : false;

    }

    /**
     * @param Request $request
     * @return array
     * @throws \Matthewbdaly\SMS\Exceptions\DriverNotConfiguredException
     * Register new user.
     */
    public function register(Request $request)
    {

        try {


            Log::channel('user')->info('register_req', ['register_req' => $request->headers, 'inputRequest' => $request->all()]);

            if ($request->has('isEmail')) {
                $request->merge([
                    'is_email' => ($request->isEmail == 'true') ? true : false
                ]);

            }


            //unique field check
            if ($this->register_unique_col == 'email') {
                $check_deleted_user = User::where([self::EMAIL => $request->email])->onlyTrashed()->get();
            } else {
                $check_deleted_user = User::where(['user_mobile' => $request->phone])->onlyTrashed()->get();
            }
            if ($check_deleted_user->isNotEmpty()) {
                foreach ($check_deleted_user as $user) {

                    Log::channel('user')->info('register_req', ['Removing already deleted user' => $user]);

                    $user->forceDelete();
                }
            }


            //unique field check
            if ($this->register_unique_col == 'email') {
                $userExsist = User::where([self::EMAIL => $request->email, self::IS_ACTIVE => 0, self::OLD_USER => 0])->first();
            } else {
                $userExsist = User::where(['user_mobile' => $request->phone, self::IS_ACTIVE => 0])->first();
            }
            if ($userExsist) {
                Log::channel('user')->info('register_req', ['Removing already existing active users' => $userExsist]);
                $userExsist->forceDelete();
            };


            // Unique email field check
            if ($this->register_unique_col == 'email') {
                if (!$request->email) {
                    return [self::STATUS => false, self::MESSAGE => 'Please enter email address'];
                }
            }

            // Unique phone field check
            if (!$request->phone and !\request()->has('business_id')) {
                return [self::STATUS => false, self::MESSAGE => 'Please enter your phone number'];
            }


            $request->request->add([self::USER_MOBILE => $request->phone]);


            // Check old user
            $id = 0;
            if ($this->register_unique_col == 'email' || $this->register_unique_col == 'phone') {
                $coulmn = ($this->register_unique_col == 'email') ? 'email' : 'user_mobile';
                $columnValue = ($this->register_unique_col == 'email') ? $request->email : $request->phone ?? $request->user_mobile;

                $old_user = User::where([$coulmn => $columnValue, self::OLD_USER => 1])->first();

                $id = ($old_user) ? $old_user->user_id : 0;
            }
            Log::channel('user')->info('register_req', ['Old user?' => $id]);


            // Unique email field check
            if ($this->register_unique_col == 'email') {
                if (!$id) {

                    $validator = Validator::make($request->all(), [
                        self::EMAIL => 'unique:users',
                    ]);

                    if ($validator->fails()) {
                        return [self::STATUS => false, self::MESSAGE => 'A user with this email already exits. Please try another email address.'];
                    }

                    $phone = rtrim($request->phone);
                    /*  $userUniquePhone = User::where([self::IS_ACTIVE => 1, self::OLD_USER => 0])->where(self::USER_MOBILE, 'like', "%$phone")->first();
                      $userOld = User::where([self::IS_ACTIVE => 1, self::OLD_USER => 1])->where(self::USER_MOBILE, 'like', "%$phone")->first();

                      if ($userUniquePhone) {
                          return [self::STATUS => false, self::MESSAGE => 'User with same phone number already exists'];
                      }

                      if ($userOld) {
                          return [self::STATUS => false, self::MESSAGE => 'User with same phone number already exists'];
                      }*/
                }

                // Unique phone number field check
            } else {

                $prev_user_with_same_phone = User::where('user_mobile', 'like', "%$request->phone")->first();
                if ($prev_user_with_same_phone) {
                    return [self::STATUS => false, 'message' => 'A user with this cell phone number is already registered, please login or use forgot password and recover password'];
                }
                if (\request()->has('email') and !empty(\request()->email)) {
                    $userWithExistingEmail = User::where(['email' => \request()->email, 'is_active' => 1])->first();
                    if ($userWithExistingEmail) {
                        return [self::STATUS => false, 'message' => 'A user with this email  is already registered, please login or use forgot password and recover password'];
                    }
                }

            }

            // Uploading Profile Image
            if ($request->hasFile(self::USER_IMAGE)) {
                $user_image = time() . '_' . $request->file(self::USER_IMAGE)->getClientOriginalName();
                $path = base_path() . self::USER_PATH;
                $request->file(self::USER_IMAGE)->move($path, $user_image);
                Image::make($path . $user_image, array(
                    'width' => 200,
                    'height' => 200,
                    'grayscale' => false
                ))->save(base_path() . self::USER_PATH_THUMB . $user_image);
            } else {

                $user_image = '';
            }//..... end if-else() .....//

            if (\request()->has('pos_image') and !empty(request()->pos_image)) {
                $file_name = basename(request()->pos_image);
                $path = base_path() . self::USER_PATH . '/' . $file_name;
                file_put_contents($path, $this->curl_get_file_contents(request()->pos_image));
                $thumbs = base_path() . self::USER_PATH_THUMB . $file_name;
                file_put_contents($thumbs, $this->curl_get_file_contents(request()->pos_image));
                $user_image = $file_name;
            }


            // Inserting final data in Engage
            $dataInsert = $this->createUserData($user_image);

            Log::channel('user')->info('register_req', ['Inserting data in Engage' => $dataInsert, 'Registration_start' => microtime(true) . " seconds."]);

            if ($request->has('is_email')) {
                $dataInsert[self::IS_EMAIL] = ($request->is_email == 'true' || $request->is_email == true || $request->is_email == 1) ? 1 : 0;
                $dataInsert['groups'] = json_encode([self::MEMBER]);
            }
            if ($request->has('password')) {
                $dataInsert['password'] = Hash::make($request->password);
            }

            $user = null;

            if ($request->has('country_code'))
                $dataInsert['country_code'] = $request->country_code;

            if (\request()->has('member_type')) {
                $groups = Groups::where('group_name', 'like', '%' . ucfirst(request()->member_type) . '%')->exists();
                if ($groups and ucfirst(request()->member_type) != 'Member') {
                    $dataInsert['groups'] = json_encode([self::MEMBER, ucfirst(\request()->member_type)]);
                } else {
                    $dataInsert['groups'] = json_encode([self::MEMBER]);
                }
            }

            if ($request->has('health_number'))
                $dataInsert['health_number'] = $request->health_number;

            if ($request->has('driver_license_number'))
                $dataInsert['driver_license_number'] = $request->driver_license_number;

            if ($request->has('driver_license_state'))
                $dataInsert['driver_license_state'] = $request->driver_license_state;

            // New User?
            if ($id == 0) {

                $user = User::Create($dataInsert);


                // Old User?
            } else {
                $dataInsert['groups'] = $old_user->groups;
                $dataInsert[self::OLD_USER] = true;
                $old_user->update($dataInsert);
                $user = $old_user;
            }


            UserAddresses::create([
                "address" => $request->address ?? '',
                "address2" => $request->address2 ?? '',
                "street_name" => $request->street_name ?? '',
                "street_number" => $request->street_number ?? '',
                "city" => $request->city ?? '',
                "state" => $request->state ?? '',
                "country" => $request->country ?? '',
                "suburb" => $request->suburb ?? '',
                "latitude" => $request->lat ?? '',
                "longitude" => $request->long ?? '',
                "postal_code" => $request->postal_code ?? '',
                "is_default" => 1,
                'user_id' => $user->user_id,
                'address_type' => 'Residential'
            ]);


            Log::channel('user')->info('register_req', ['Created User' => $user]);

            if ($user) {

                Log::channel('user')->info('register_req', ['User successfully created' => ""]);


                // Register from POS and automatically activate
                if ($request->has('pos_registration') && $request->pos_registration) {
                    $user->update([
                        self::IS_ACTIVE => 1,
                        self::ACTIVATION_TOKEN => '',
                    ]);
                    return [
                        self::STATUS => true,
                        self::MESSAGE => "Woohoo! Your account is up and running. Let's get started.", self::USER_ID => $user->user_id,

                        'data' => $user->only([self::USER_FIRST_NAME, self::USER_FAMILY_NAME, self::EMAIL, self::USER_MOBILE]),
                    ];


                } else {
                    //ByPass Activation
                    if (\request()->has('bypass_activation')) {
                        \request()->merge(['user_id' => $user->user_id, 'code' => $user->activation_token, 'is_existing_user' => 0]);
                        $checkStatus = $this->activateUser();
                        if (isset($checkStatus['status']) and !$checkStatus['status']) {

                            return $checkStatus;
                        }

                    } else {
                        // Disable Verification
                        DB::table('user_verifications')->insert([
                            'user_id' => $user->user_id,
                            'created_at' => Carbon::now()

                        ]);
                        $this->sendVerificationSms($request->phone, $user->activation_token, $user->user_first_name);
                    }

                    if (\request()->has('venue_id')) {
                        $this->assignUserAgainstVenue($user->user_id, $request->venue_id);
                    }
                    $message = '';
                    if ($request->has('referal_code')) {
                        $response = $this->checkValidReferralCode('', $request->referal_code);

                        $message = (!$response[self::STATUS]) ? '' : $response[self::MESSAGE];
                        $user->referal_by = \request()->referal_code;
                        $user->save();


                    }

                    $emailSettings = Setting::where('type', 'verification_email')->first();
                    $sendEmail = ($emailSettings) ? $emailSettings->field1 : 0;
                    if ($sendEmail) {
                        $json = ['user_id' => $user->user_id];
                        $value = urlencode(base64_encode(json_encode($json)));
                        $link = \url("/api/verify-email/$value");
                        //get short link
                        $link = (new Utility())->getShortLink($link);
                        $this->send_email($user->email, $user->user_first_name, 'email verification', $user->user_id, $link, 'email_verification', $user->region_type);
                    }

//                    //save user notifications in RDS
//                    $this->saveChannels($user);
                    $userData = User::where('user_id', $user->user_id)->first();
                    $user->be_customer_id = $userData->booking_engine_id ?? 0;

                    if ($request->has('refree_id') and \request()->has('reference_id') and !empty(request()->reference_id)) {
                        try {
                            DB::table('past_referals')->where('id', request()->reference_id)->update(['referred_id' => $user->user_id, 'is_signup' => 1, 'updated_at' => Carbon::now()]);
                        } catch (\Exception $e) {
                            Log::channel(self::CUSTOM)->error('is_sign_up_error', ['is_sign_up_error' => $e->getMessage(), 'line' => $e->getLine()]);
                        }
                        //call event trigger
                        $data = [
                            'user_id' => [$user->user_id],
                            'referred_by' => [
                                'user_id' => request()->refree_id,
                                'email' => ''
                            ],
                            'trigger_type' => 'referral',
                        ];
                        $trigger_type = "$.referral_trigger";
                        (new VCTrigger())->callVCTrigger($data, $trigger_type);
                    }


                    $dataSend = [
                        self::STATUS => true,
                        self::MESSAGE => "Woohoo! Your account is up and running. Let's get started.", self::USER_ID => $user->user_id,

                        'data' => $user->only([self::USER_FIRST_NAME, self::USER_FAMILY_NAME, self::EMAIL, self::USER_MOBILE, self::USER_ID]),
                        'member_type' => (\request()->has('member_type')) ? \request()->member_type : '',
                        'referal_message' => $message
                    ];
                    $dataSend['data']['email'] = ($dataSend['data']['email']) ? $dataSend['data']['email'] : '';


                    if ($this->send_email_vp) {
                        //call event trigger
                        $trigger_type = "$.pre_register_trigger";
                        $data = [
                            'user_id' => $user->user_id,
                            'trigger_type' => 'pre_signup'
                        ];
                        (new VCTrigger())->callVCTrigger($data, $trigger_type);
                    }

                    Log::channel('user')->info('register_req', ['Registration_end' => microtime(true) . " seconds."]);

                    return $dataSend;
                }
            } else {
                return [self::STATUS => false, self::MESSAGE => "Couldn't register at this moment, please try again!"];
            }//..... end of if-else() .....//
        } catch (\Exception $e) {
            Log::channel(self::CUSTOM)->info('User INSERT Profile: ', ['data' => $e->getMessage(), 'line' => $e->getLine()]);
            return [self::STATUS => false, self::MESSAGE => 'Due to some error user not registered.'];
        }
    }//..... end of register() .....//


    /**
     * @param $user_id
     * @param $eway
     * @return bool|string
     *  Add Default Card for User
     */
    function addDefaultCard($user_id, $eway)
    {
        $req = new \Illuminate\Http\Request();
        $req->replace([
            'card_name' => "Test Card " . rand(105, 999),
            'card_no' => "5105105105105100",
            self::COMPANY_ID => request()->company_id,

            'cvv' => rand(101, 999),
            'expiry_month' => rand(10, 12),
            'expiry_year' => rand(19, 25),
            'is_default' => 1,
            self::USER_ID => $user_id
        ]);

        if ($eway) {
            $userCards = new User_Card();
            $userCards->user_id = $user_id;
            $userCards->card_no = "eCrypted:UJ7LA338ghDzsnIWl28ZijNI1bakRhxDvh7incSpj+M2J1oPPRwEfInDL0bz57VFVoePw4e46AB0ev2MvTD0ioq+uFebjrqkAn+x0I92LwuCSTaYygZ+MtczEH5ajM3PigdPo7tOQ8/4efdkwQotrK8r2FJY5gMIF1rlD+PszClPJnhz+LhX70Eo/9sTK8fzk1T1xB492+4cgg8edigTKhiQCfM6rClnHJMFJpUVEs0a4JzRx4yTisu269/l66HJQDGmwzdruXylXfYbYTpzT2a+L6Fe2TzQRZHFBXXf6rUsn4EfxnMnZB+3DXhtbvfAVWBY1ykvTKf44KwehMhhYg==";
            $userCards->last_digit = 1111;
            $userCards->card_name = 'John';
            $userCards->expiry_month = rand(10, 12);
            $userCards->expiry_year = rand(19, 25);
            $userCards->cvv = 'eCrypted:V6jztFkWLdfNfP4KS5J46X8jUGJk/vls2DHSpBwsgTCvhzJGIKK9z/NHkdWrGDd9KGVxpZ4BQhunVrwF8oTVtSELhDYi5MN/Sxuxtlz29bkz1v2dV0Ih2ZF/60l0tsCg0iRfVsN/XAqj4zUaddMMxvV8L1//3Qfi7pU+YN1srlCH2Da4Iz7yrA3rR4dDs8Gl3Wt41ROnVYDzUJf8cTYOlJJCcNjrP0VUlkWYeC15HbatjRoRKaj5qDdiKSNsHFEZVUImCRtECaoCJtEvZpadRzns56mpghqUzeLPVbHr+jz4sacR6YJWlrf38txk50L5KrT9bg7rianU0XLvNQ8QAA==';
            $userCards->card_type = 'VISA';
            $userCards->timestamps = false;
            $userCards->is_default = 1;
            $userCards->save();
            return true;
        } else {
            $res = (new StoresApiController())->addCard($req);
            return $res[self::STATUS] ? "Default Card Added successfully." : "Error occurred while adding card";
        }//..... end if-else() .....//
    }//..... end of addDefaultCard() .....//

    /**
     * @return \Psr\Http\Message\StreamInterface|string
     * @throws \GuzzleHttp\Exception\GuzzleException
     *  Get Access Token to Authorize the user
     */
    public function getAccessToken()
    {
        $client = new Client;
        $base_url = URL::to('/');
        $client_ids = DB::table("oauth_clients")->select("id", "secret")->where("password_client", "1")->first();
        if ($client_ids) {
            try {
                $res = $client->request('POST', $base_url . '/oauth/token', [
                    'form_params' => [
                        '
                        ' => 'client_credentials',
                        'client_id' => $client_ids->id,
                        'client_secret' => $client_ids->secret
                    ]
                ]);
                return $res->getBody();
            } catch (RequestException $e) {
                $arr[self::STATUS] = false;
                $arr[self::MESSAGE] = 'Request faild.';
                return json_encode($arr);
            }
        } else {
            $arr[self::STATUS] = false;
            $arr[self::MESSAGE] = 'Create client for this application.';
            return json_encode($arr);
        }

    }//--- End of getAccessToken() ---//

    /**
     * @param Request $request
     * @return array|string
     *  Forgot Password for User
     */
    public function forget_password(Request $request)
    {
        $this->getUserInfo('forget_password');
        if ($this->register_unique_col == 'phone') {
            $message = '';
            if (\request()->has('email')) {
                $message = 'This email address you entered not registered with us';
                $user = User::where(['email' => $request->email, 'is_active' => 1])->first();
            } else {
                $message = 'The cell phone number you entered is not registered with us';
                $user = User::where('user_mobile', $request->user_mobile)->first();
            }

            if (!$user)
                return [self::STATUS => false, self::MESSAGE => $message];
            $pin = rand(1111, 9999);
            $user->update([self::ACTIVATION_TOKEN => $pin, self::EXPIRY_TIME => Carbon::now()->addMinute(5)]);
            $name = $user->user_first_name . ' ' . $user->user_family_name;

            $string = sprintf("Hi %s, it seems you forgot your password, please use this pin %s to change your password",
                $name, $pin);

            if (\config('constant.APP_NAME') == 'engage-wuhu') {
                $string = "Hey " . $user->user_first_name . ". You requested a password reset for Wuhu. Please use this pin :" . $pin . " to change your password";
            }
            $sendData = 'phone';
            if (\request()->has('email') and !empty(request()->email)) {
                $sendData = 'email';
                Log::channel('custom')->info('$this->send_email_vp', ['$this->send_email_vp' => $this->send_email_vp, 'user' => $user]);
                $pin = rand(1111, 9999);
                $user->update([self::ACTIVATION_TOKEN => $pin, self::EXPIRY_TIME => Carbon::now()->addMinute(5)]);
                $email_subject = 'Forgot password';
                $user_name = $user->user_first_name . ' ' . $user->user_family_name;
                if ($this->send_email_vp) {
                    //call event trigger
                    $trigger_type = "$.forgot_pass_trigger";
                    $data = [
                        'user_id' => $user->user_id,
                        'trigger_type' => 'forgot_pass'
                    ];
                    (new VCTrigger())->callVCTrigger($data, $trigger_type);
                } else {
                    $this->send_email($request->email, $user_name, $email_subject, $user->user_id, $pin, self::FORGET_EMAIL, $request->region_type);
                }
            } else {
                $this->sendSms(
                    $request->user_mobile,
                    $string
                );
            }

            return [self::STATUS => true, self::MESSAGE => 'Please check ' . $sendData . ' to reset password.'];
        }


        if ($request->has(self::EMAIL) && $request->email !== "") {
            $user = User::whereEmail($request->email)->whereUserType('app')->first();
            if ($user) {

                if ($user->region_type == null) {
                    $user->region_type = $request->region_type;
                    $user->save();
                }
                if (request()->header(Self::COUNTRY) == 'aus' || request()->header(Self::COUNTRY) == null || request()->header(Self::COUNTRY) == '' || request()->header(self::COUNTRY) == 'nz') {

                } else {
                    if ($user->region_type != $request->region_type) {
                        return [self::STATUS => false, self::MESSAGE => 'Email not exists.'];
                    }
                }

                $pin = rand(1111, 9999);
                $user->update([self::ACTIVATION_TOKEN => $pin, self::EXPIRY_TIME => Carbon::now()->addMinute(5)]);
                $email_subject = 'Forgot password';
                $user_name = $user->user_first_name . ' ' . $user->user_family_name;

                //test log
                Log::channel('custom')->info('$this->send_email_vp', ['$this->send_email_vp' => $this->send_email_vp]);

                if ($this->send_email_vp) {
                    //call event trigger
                    $trigger_type = "$.forgot_pass_trigger";
                    $data = [
                        'user_id' => $user->user_id,
                        'trigger_type' => 'forgot_pass'
                    ];
                    (new VCTrigger())->callVCTrigger($data, $trigger_type);
                } else {
                    $this->send_email($request->email, $user_name, $email_subject, $user->user_id, $pin, self::FORGET_EMAIL, $request->region_type);
                }

                return [self::STATUS => true, self::MESSAGE => 'Please check email to reset password.'];


            } else {
                return [self::STATUS => false, self::MESSAGE => "Hmmm... that email address doesn't seem right. Give it another shot"];
            }//..... end of inner-if-else() .....//
        } else {
            return [self::STATUS => false, self::MESSAGE => 'Please enter email address'];
        }//..... end if-else() .....//
    }//..... end of forget_password() .....//

    /**
     * @param Request $request
     * @return array|\Illuminate\Contracts\Routing\ResponseFactory|string|\Symfony\Component\HttpFoundation\Response
     * @throws \Matthewbdaly\SMS\Exceptions\DriverNotConfiguredException
     *  Reset Password for Users
     */
    public function reset_password(Request $request)
    {
        try {
            $this->getUserInfo('reset_password');
            //unique field check
            if ($this->register_unique_col == 'email') {
                $validator = Validator::make($request->all(), [
                    self::EMAIL => self::REQUIRED,
                    self::PASS => 'required|regex:/^.*(?=.{6,})(?=.*[0-9])(?=.*[a-z]).*$/',
                    'pin' => self::REQUIRED
                ]);
            } else {
                $validator = Validator::make($request->all(), [
                    self::PASS => 'required|regex:/^.*(?=.{6,})(?=.*[0-9])(?=.*[a-z]).*$/',
                    'pin' => self::REQUIRED
                ]);
            }


            if ($validator->fails()) {
                return response($validator->errors(), 400);
            }

            if (preg_match("/^.*(?=.{6,})(?=.*[0-9])(?=.*[a-z]).*$/", $request->password) === 0) {
                return [self::STATUS => false, self::MESSAGE => self::PASS_ERROR_MSG];
            }
            if ($this->app_name == 'wuhu') {
                if (preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*(_|[^\w])).+$/", $request->password) === 0) {
                    return [self::STATUS => false, self::MESSAGE => self::PASS_ERROR_MSG];
                }
            }


//unique field check
            if ($this->register_unique_col == 'email') {
                $user = User::whereEmail($request->email)->whereActivationToken($request->pin)->first();
            } else {
                if (\request()->has('email') and !empty(\request()->email)) {
                    $user = User::where('email', request()->email)->whereActivationToken($request->pin)->first();
                } else {
                    $user = User::where('user_mobile', $request->user_mobile)->whereActivationToken($request->pin)->first();
                }

            }

            if ($user) {
                if ($user->is_active == 1) {
                    if (!$user->old_user) {
                        $user->update([self::PASS => Hash::make($request->password), self::ACTIVATION_TOKEN => '']);
                    }
                    if (\request()->header(self::COUNTRY) == 'aus' || \request()->header(self::COUNTRY) == 'nz') {

                    } else {
                        if ($this->register_unique_col == 'email')
                            $this->send_email($user->email, $user->user_first_name . ' ' . $user->user_family_name, '', $user->user_id, '', 'update_password');
                    }

                    return [self::STATUS => true, self::MESSAGE => 'Your password has been updated.'];
                } else {
                    if (!$user->old_user) {
                        $user->update([self::ACTIVATION_TOKEN => rand(1111, 9999), self::PASS => Hash::make($request->password),
                            self::UPDATED_AT => date('Y-m-d h:i:s'), self::EXPIRY_TIME => Carbon::now()->addMinute(5)]);
                    }
                    $this->updateTimerForNotifications($user);

                    $this->sendVerificationSms($user->user_mobile, $user->activation_token, $user->user_first_name);
                    return [
                        self::STATUS => true,
                        "user_status" => "inactive",
                        self::PHONE => $user->user_mobile,
                        self::USER_ID => $user->user_id,
                        "referral_by" => $user->referral_by,
                        self::FIRST_NAME => $user->user_first_name,
                        self::LAST_NAME => $user->user_family_name,
                        "is_existing_user" => 0,
                        self::IMAGE => url("/") . 'public/users/thumbs/' . $user->user_avatar,
                        "image_thumb" => url("/") . 'public/users/thumbs/thumb_' . $user->user_avatar,
                        self::MESSAGE => "Your password has been updated. All that's left to do now is sign into your account."];
                }//..... end inner-if-else() .....//
            } else {
                //unique field check
                if ($this->register_unique_col == 'phone') {
                    return [self::STATUS => false, self::MESSAGE => "The pin you entered is wrong, Please enter the pin code which you received"];
                }
                return [self::STATUS => false, self::MESSAGE => "Oops… Your pin code doesn't look right. Please check the code we sent you and give it another shot."];
            }//..... end if-else() ......//
        } catch (\Exception $e) {
            Log::channel('custom')->info('reset_password_error', [
                'reset_password_error' => $e->getMessage(),
                'reset_password_error_line' => $e->getLine()
            ]);
        }

    }//..... end of reset_password() .....//

    /**
     * @param Request $request
     * @return array
     * Change user password.
     */
    public function changePassword(Request $request)
    {
        if ($request->email != '' && $request->old_password != '' && $request->new_password != '') {
            if ($this->password_check) {
                $request->request->add(['password' => $request->new_password]);
                if ($this->checkValidPassword()) {
                    return [self::STATUS => false, self::MESSAGE => "How'd you like to add some character to your password? At least one upper case, lower case,numeric and special character, please."];
                }
            } else {
                if (preg_match("/^.*(?=.{6,})(?=.*[0-9])(?=.*[a-z]).*$/", $request->new_password) === 0) {
                    return [self::STATUS => false, self::MESSAGE => self::PASS_ERROR_MSG];
                }
            }


            $user = $request->user();

            if ($user->email == $request->email) {
                if (Hash::check($request->old_password, $user->password)) {
                    $user->update([self::PASS => bcrypt($request->new_password)]);
                    return [self::STATUS => true, self::MESSAGE => 'Your password has been updated successfully.'];
                } else {
                    return [self::STATUS => false, self::MESSAGE => 'Old password is incorrect.'];
                }
            } else {
                return [self::STATUS => false, self::MESSAGE => 'Email does not match.'];
            }
        } else {
            return [self::STATUS => false, self::MESSAGE => 'Some parameters are missing.'];
        }
    }//..... end of changePassword() ......//

    /**
     * @param Request $request
     * @return array|string
     * @throws \Matthewbdaly\SMS\Exceptions\DriverNotConfiguredException
     *  Update Profile of user
     */
    public function updateProfile(Request $request)
    {
        try {
            Log::channel('custom')->info('update', ['updateProfile' => \request()->all()]);
            $user = $request->user();
            if (!$user) {
                return [self::STATUS => false, self::MESSAGE => 'User does not exist.'];
            }


            if ($user && $request->has('old_password') && $request->has(self::PASS) && $request->old_password && $request->password and $this->register_unique_col == 'email') {
                if (!Hash::check($request->old_password, $user->password)) {
                    return [self::STATUS => false, self::MESSAGE => "Incorrect user password."];
                } else {
                    if (preg_match("/^.*(?=.{6,})(?=.*[0-9])(?=.*[a-z]).*$/", $request->password) === 0) {
                        return [self::STATUS => false, self::MESSAGE => self::PASS_ERROR_MSG];
                    } else {
                        $user->password = Hash::make($request->password);
                    }//..... end if-else() .....//
                }//.... end if() .....//
            } else {
                if (\request()->has('password') and !empty(\request()->password)) {
                    if (preg_match("/^.*(?=.{6,})(?=.*[0-9])(?=.*[a-z]).*$/", $request->password) === 0) {
                        return [self::STATUS => false, self::MESSAGE => self::PASS_ERROR_MSG];
                    } else {
                        $user->password = Hash::make($request->password);
                    }//..... end if-else() .....//
                }
            }


            if ($request->hasFile(self::USER_IMAGE)) {
                if ($user->user_avatar != '') {
                    @unlink(base_path() . self::USER_PATH . $user->user_avatar);
                    @unlink(base_path() . self::USER_PATH_THUMB . $user->user_avatar);
                }//..... end if() .....//

                $user->user_avatar = rand(111, 999) * time() . '.' . $request->file(self::USER_IMAGE)->getClientOriginalExtension();
                $path = base_path() . self::USER_PATH;
                $request->file(self::USER_IMAGE)->move($path, $user->user_avatar);
                Image::make($path . $user->user_avatar, array(
                    'width' => 200,
                    'height' => 200,
                    'grayscale' => false
                ))->save(base_path() . self::USER_PATH_THUMB . $user->user_avatar);
            }//..... end if() .....//


            if (\request()->has('pos_image') and !empty(request()->pos_image)) {

                if ($user->user_avatar != '') {
                    @unlink(base_path() . self::USER_PATH . $user->user_avatar);
                    @unlink(base_path() . self::USER_PATH_THUMB . $user->user_avatar);
                }//..... end if() .....//


                $file_name = basename(request()->pos_image);
                $path = base_path() . self::USER_PATH . '/' . $file_name;
                file_put_contents($path, $this->curl_get_file_contents(request()->pos_image));
                $thumbs = base_path() . self::USER_PATH_THUMB . $file_name;
                file_put_contents($thumbs, $this->curl_get_file_contents(request()->pos_image));
                $user->user_avatar = $file_name;
            }

            if ((!$user->dob && $request->dob) && (!$user->gender && $request->gender) && (!$user->postal_code && $request->postal_code)) {
                $request->request->add([self::VENUE_ID => $user->default_venue]);
                (new GamificationController())->userOptionalFields($request, $user);
            }


            if ($request->has(self::FIRST_NAME) && $request->first_name) {
                $user->user_first_name = $request->first_name;
            }
            if ($request->has('country_code') && $request->country_code) {
                $user->country_code = $request->country_code;
            }

            if ($request->has(self::LAST_NAME) && $request->last_name) {
                $user->user_family_name = $request->last_name;
            }

            if ($request->has('dob') && $request->dob) {
                $user->dob = date(self::YMD, strtotime($request->dob));
            }

            if ($request->has(self::POSTAL_CODE) && $request->postal_code) {
                $this->updateUserProfileAddress('postal_code', $request->postal_code, $user->user_id);
            }

            if ($request->has(self::GENDER) && $request->gender) {
                $user->gender = $request->gender;
            }


            if ($request->has('city') && $request->city) {
                $this->updateUserProfileAddress('city', $request->city, $user->user_id);
            }

            if ($request->has('country') && $request->country) {
                // $user->country = $request->country;
                $this->updateUserProfileAddress('country', $request->country, $user->user_id);
            }

            if ($request->has('state') && $request->state) {
                $this->updateUserProfileAddress('state', $request->state, $user->user_id);
            }

            if ($request->has(self::SUBRUB) && $request->subrub) {
                $this->updateUserProfileAddress('suburb', $request->subrub, $user->user_id);
            }
            if ($request->has('suburb') and !empty($request->suburb)) {
                $this->updateUserProfileAddress('suburb', $request->suburb, $user->user_id);
            }

            if ($request->has(self::IS_EMAIL)) {

                $is_email = ($request->is_email == 'true') ? 1 : 0;
                $user->is_email = $is_email;
            }

            if ($request->has('address') and $request->address and request()->header(self::COUNTRY) == 'aus' || request()->header(self::COUNTRY) == 'nz' and !\request()->has('is_envoirnement')) {

                if ($request->has('address') and $request->address) {
                    $this->insertUserAddresses(json_decode($request->address, true));
                    //$user->address = json_encode(json_decode($request->address, true));
                }
            } else {
                if ($request->has('address') and $request->address) {
                    $this->updateUserProfileAddress('address', $request->address, $user->user_id);
                }
            }


            if (\request()->has('about_me') and !empty($request->about_me)) {
                $user->about_me = $request->about_me;
            }

            //unique field check
            if ($this->register_unique_col == 'phone') {
                if ($request->has('email') && !empty($request->email)) {
                    $users = User::where(['email' => $request->email, 'is_active' => 1])->where('user_id', '!=', $user->user_id)->first();

                    if ($users) {
                        return ['status' => false, 'message' => 'Email Exists for another user'];
                    } else {
                        $user->email = $request->email;
                    }

                }

                if (\request()->has('phone') and !empty(\request()->phone)) {
                    $duplicatePhoneNumber = User::where(['user_mobile' => $request->phone, 'is_active' => 1])->where('user_id', '!=', $user->user_id)->first();
                    if ($duplicatePhoneNumber) {
                        return ['status' => false, 'message' => 'User with phone number already exists'];
                    }
                }
            }

            $phone_input = str_replace(' ', '', $request->phone);

            // pos_update is for user update from pos
            if (!\request()->has('pos_update') and $request->has(self::PHONE) && $request->phone && $user->user_mobile != $phone_input) {
                $user->fill([self::ACTIVATION_TOKEN => rand(1111, 9999), self::EXPIRY_TIME => Carbon::now()->addMinute(5)]);
                $user->save();

                if (empty($user->gender)) {
                    $user->gender = 'U';
                }

                (new ElasticSearchController())->insertUserToES($user->user_id);
                $this->updateTimerForNotifications($user);
                $this->sendVerificationSms($phone_input, $user->activation_token, $user->user_first_name);
                return [self::STATUS => true, self::USER_ID => $user->user_id, self::PHONE => $phone_input, "data" => $user->only([self::USER_ID, self::USER_FIRST_NAME, self::USER_FAMILY_NAME, self::EMAIL, self::USER_MOBILE, self::USER_AVATAR, self::SUBRUB, "city", self::GENDER, "dob", self::IS_EMAIL, self::STORE_DATA]),
                    self::MESSAGE => "Please activate your account."];

            } else {
                if (\request()->has('phone') && $this->register_unique_col != 'phone') {
                    $user->user_mobile = str_replace(' ', '', $request->phone);
                }
            }


            $user->save();
            $userAddress = UserAddresses::where(['user_id' => $user->user_id, 'is_default' => 1])->first();

            if ($userAddress) {
                $user->address = $userAddress->address;
                $user->address2 = $userAddress->address2;
                $user->city = $userAddress->city;
                $user->state = $userAddress->state;
                $user->country = $userAddress->country;
                $user->postal_code = $userAddress->postal_code;
                $user->suburb = $userAddress->suburb;
            } else {
                $user->address = '';
                $user->city = '';
                $user->state = '';
                $user->country = '';
                $user->postal_code = '';
                $user->suburb = '';
                $user->address2 = '';
            }


            if (request()->header(self::COUNTRY) == 'aus' || request()->header(self::COUNTRY) == 'nz' and !\request()->has('is_envoirnement')) {
                $user->address = [];
                $Addresses = json_decode($this->getUserAddresses($user->user_id, 'api'));
                if (count($Addresses) > 0) {
                    $user->address = $Addresses;
                } else {
                    $user->address = [];
                }

            }


            if (empty($user->gender)) {
                $user->gender = 'U';
            }

            (new ElasticSearchController())->insertUserToES($user->user_id);
            sleep(4);
            $this->updateUserOnSoldi($user);
            if (isset($user->country_code)) {
                $user->country_code = $user->country_code;
            } else {
                $user->country_code = '';
            }
            $user->profile_percentage = $this->userProfilePercentage($user->user_id);
            $pointsRecieve = 0;
            $percentage = $user->profile_percentage;
            Log::channel('user')->info('update', ['update Profile Percentage' => $user->profile_percentage]);

            if ($percentage === 100) {
                Log::channel('user')->info('update', ['update Profile Percentage' => $user->profile_percentage]);
                $getData = (new GamificationController())->completedProfileUser($user->user_id, $user->profile_percentage);
                if (count($getData) > 0) {
                    foreach ($getData as $value) {
                        if (isset($value['points'])) {
                            $pointsRecieve = ($pointsRecieve + $value['points']);
                        }
                    }
                }
            }

            //call event trigger
            $req_data = $request->all();
            $req_data['profile_percentage'] = $user->profile_percentage;
            $data = [
                'user_id' => $request->user_id,
                'profile_data' => $req_data,
                'channel_type' => 'm_commerce',
                'trigger_type' => 'profile'
            ];
            $trigger_type = "$.profile_trigger";


            (new VCTrigger())->callVCTrigger($data, $trigger_type);


            return [self::STATUS => true, self::MESSAGE => 'Profile has been updated successfully', self::USER_ID => $user->user_id,
                'data' => $user->only([self::USER_ID,
                    self::USER_FIRST_NAME,
                    self::USER_FAMILY_NAME,
                    self::EMAIL,
                    self::USER_MOBILE,
                    self::USER_AVATAR,
                    "city",
                    "state",
                    "country",
                    "postal_code",
                    self::GENDER,
                    self::SUBRUB,
                    "dob",
                    self::IS_EMAIL,
                    self::STORE_DATA,
                    self::ADDRESS,
                    self::SOLDI_ID,
                    self::COMPANY_ID,
                    'country_code',
                    'profile_percentage'
                ]), 'points' => $pointsRecieve];
        } catch (\Exception $e) {
            Log::channel('custom')->info('update_profile_error', [
                'update_profile_error' => $e->getMessage(),
                'update_profile_error_line' => $e->getLine(),
                'filenName' => $e->getPrevious(),
            ]);
        }


    }//..... end of updateProfile() .....//

    public function getUserProfile(Request $request)
    {
        $user = $request->user();
        $user = collect($user)->except('password', 'kill_bill_id', 'kilbill_ire_id', 'custom_fields', 'user_notifications', 'created_at', 'updated_at', 'expiry_time');
        return ['status' => true, 'message' => '', 'data' => $user];
    }

    /**
     * @param $user_email
     * @param $user_name
     * @param $email_subject
     * @param $email_from
     * @param $link
     * @param $view_name
     * @param string $region_type
     * @return bool|string
     */
    public function send_email($user_email, $user_name, $email_subject, $user_id, $link, $view_name, $region_type = 'uk')
    {

        $appName = ucfirst($this->app_name);
        Log::channel(self::CUSTOM)->info('$appName', ['$appName' => $appName]);

        $html = '';
        $fbLink = (\request()->header(self::COUNTRY) == 'uk') ? \config('constant.URL_FACEBOOK') : config('constant.URL_FACEBOOK_IRELAND');
        $instaLink = (\request()->header(self::COUNTRY) == 'uk') ? \config('constant.URL_INSTAGRAM') : config('constant.URL_INSTAGRAM_IRE');
        if ($view_name == self::FORGET_EMAIL) {
            $email_subject = "$appName Password Reset";
            $res[self::USERNAME] = $user_name;
            $res['activationLink'] = $link;

            $html = EmailTemplate::select('html')->where(self::TITLE, 'ForgotPassword')->first();
            $vars = ['|ActivationCode|' => $link, '|FirstName|' => $user_name, '$fb' => "$fbLink", '$insta' => "$instaLink", '$pincode' => $link];
            $html = strtr($html->html, $vars);
            $res['text'] = $html;
        } else if ($view_name == 'activate_user') {
            $email_subject = 'Activation code';
            $res[self::USERNAME] = $user_name;
            $res['activationLink'] = $link;
        } else if ($view_name == 'welcome_user') {
            $email_subject = "$appName Team Welcome";
            $res[self::USERNAME] = $user_name;
            $html = EmailTemplate::select('html')->where(self::TITLE, 'WelcomeEmail')->first();
            $vars = ['|FirstName|' => $user_name, '$fb' => "$fbLink", '$insta' => "$instaLink"];
            $html = strtr($html->html, $vars);
            $res['text'] = $html;
        } else if ($view_name == 'update_password') {
            $html = EmailTemplate::select('html')->where(self::TITLE, 'UpdatedPassword')->first();
            $email_subject = ucfirst($this->app_name) . ' Team Password Updated';
            $res[self::USERNAME] = $user_name;
            $vars = ['|FirstName|' => $user_name, '$fb' => "$fbLink", '$insta' => "$instaLink"];
            $html = strtr($html->html, $vars);
            $res['text'] = $html;
        } else if ($view_name == 'forget_email_old') {
            $html = EmailTemplate::select('html')->where(self::TITLE, 'ForgotPasswordOld')->first();
            $email_subject = ucfirst($this->app_name) . ' Team Password Updated';
            $res[self::USERNAME] = $user_name;
            $vars = ['|ActivationCode|' => $link, '|FirstName|' => $user_name, '$fb' => "$fbLink", '$insta' => "$instaLink"];
            $html = strtr($html->html, $vars);
            $res['text'] = $html;
        } else if ($view_name == 'reset_email_password') {
            $html = EmailTemplate::select('html')->where(self::TITLE, 'RESETBYEMAIL')->first();
            $vars = ['|LINK|' => $link, '|FirstName|' => $user_name];
            $html = strtr($html->html, $vars);
        } else if ($view_name == 'email_verification') {
            $html = EmailTemplate::select('html')->where(self::TITLE, 'VERIFICATIONEMAIL')->first();
            if ($html) {
                $vars = ['|LINK|' => $link, '|FirstName|' => $user_name];
                $html = strtr($html->html, $vars);
            } else {
                $html = "<a href='$link' target='_blank'>Click Here To Verify</a>";

            }
        } else if ($view_name == 'code_verification') {
            $html = EmailTemplate::select('html')->where(self::TITLE, 'VERIFICATIONCODE')->first();
            if ($html) {
                $vars = ['|ActivationCode|' => $link, '|FirstName|' => $user_name, '|LastName|' => $user_id];
                $html = strtr($html->html, $vars);
            } else {
                $html = "<a href='$link' target='_blank'>Click Here To Verify</a>";

            }
        }
        return $this->sendEmailToVerification($user_email, $email_subject, $html, $user_id);


    }//..... end of send_email() .....//

    public function sendEmailToVerification($user_email, $email_subject, $html, $file_urls = [])
    {
        try {

            $http = new \GuzzleHttp\Client();
            Log::channel('custom')->info('input_email_data', ['from' => '', "to" => $user_email, 'subject' => $email_subject, self::ROUTE => self::DEFAULT, 'attachmentsURL' => $file_urls]);
            $response = $http->post(config('constant.JAVA_URL') . 'sendEmail', [
                'headers' => array(),
                'json' => ['from' => '', "to" => $user_email, 'subject' => $email_subject, 'payload' => $html, self::ROUTE => self::DEFAULT, 'attachmentsURL' => $file_urls]
            ]);
            Log::channel(self::CUSTOM)->info('sendEmailToVerification() ', ['sendEmailToVerification' => json_decode($response->getBody())]);
            return true;
        } catch (\Exception $e) {
            Log::channel(self::CUSTOM)->info('sendEmailToVerification() ', ['sendEmailToVerification' => $e->getMessage()]);
            return $e->getMessage();
        }
    }

    /**
     * @param $id
     * @return string
     */
    public function saveCardInfo($id)
    {
        $url = self::config('constant.eway_encrypt_url');
        $credentials = self::config('constant.eway_apiencrypt');
        $data = '{
                        "Method": "eCrypt",
                        "Items": [
                            {
                                "Name": "card",
                                "Value": "' . self::CARD_NO . '"
                            },
                            {
                                "Name": "CVN",
                                "Value": "' . 123 . '"
                            }
                        ]
                    }';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, Array("Content-Type: application/json"));
        curl_setopt($ch, CURLOPT_USERPWD, $credentials);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        $response = curl_exec($ch);
        curl_close($ch);
        $data = json_decode($response);
        if (isset($data->Errors) && $data->Errors != '') {
            return "ERROR";
        } else {
            $detail = $data->Items;
            $card_num = $detail[0]->Value;
            $card_cvv = $detail[1]->Value;
        }
        $card_type = $this->creditCardType(self::CARD_NO);
        $last_digit = substr(self::CARD_NO, -4);
        $cards = new User_Card();
        $cards->user_id = $id;
        $cards->card_no = $card_num;
        $cards->card_name = "John";
        $cards->expiry_month = 12;
        $cards->expiry_year = 18;
        $cards->cvv = $card_cvv;
        $cards->card_type = $card_type;
        $cards->last_digit = $last_digit;
        $cards->is_default = 1;
        $cards->timestamps = false;
        $cards->save();
    }//--- End of saveCardInfo() ---//

    /**
     * @param Request $request
     * @return string
     */
    public function app_skinning(Request $request)
    {
        $venue_id = $request->venue_id;
        $company_id = $request->company_id;
        $user_id = $request->user_id;
        if (isset($request->venue_id) && $venue_id != '' && isset($request->company_id) && $company_id != '') {
            $base_path_img = config('constant.base_path_img') . '/public/venues/';
            $venue = Venue::where([self::COMPANY_ID => $company_id, "id" => $venue_id])->select(["id as venue_id", "venue_name", "venue_description", "address as venue_location", "venue_latitude", "venue_longitude", "venue_url", self::COMPANY_ID, self::CREATED_AT, self::USER_ID, "mobile", self::ADDRESS, "website", "additional_information", "locality"])->first();

            if ($venue) {

                if (empty($venue->venue_description)) {
                    $venue->venue_description = "";
                }
                if (empty($venue->mobile)) {
                    $venue->mobile = "";
                }
                if (empty($venue->address)) {
                    $venue->address = "";
                }
                if (empty($venue->website)) {
                    $venue->website = "";
                }
                if (empty($venue->additional_information)) {
                    $venue->additional_information = "";
                }
                if (empty($venue->locality)) {
                    $venue->locality = "";
                }
                if (empty($venue->venue_url)) {
                    $venue->venue_url = "";
                }

                $vi = VenueImage::select([self::IMAGE, "pay_with_points"])->where([self::VENUE_ID => $venue->venue_id, self::COMPANY_ID => $company_id])->first();
                $venue->image = ($vi) ? $base_path_img . $vi->image : "";
                $venue->pay_with_points = ($vi) ? $vi->pay_with_points : 0;
                $sub = VenueSubscrition::where([self::USER_ID => $user_id, self::VENUE_ID => $venue->venue_id, self::COMPANY_ID => $company_id])->first();
                $venue->subscrition = ($sub) ? 1 : 0;
                $venue->venue_description = ($venue->venue_description) ? $venue->venue_description : "";
                $venue->venue_location = ($venue->venue_location) ? $venue->venue_location : "";
                $venue->venue_url = ($venue->venue_url) ? $venue->venue_url : "";
                $venue->user_id = $user_id;
                $operating_hours = DB::table('venue_operating_hours')->where(self::VENUE_ID, $venue_id)->get();
                $final_array = array();
                if ($operating_hours) {
                    $hours = array();
                    foreach ($operating_hours as $ope_hours) {
                        $hours['day'] = $ope_hours->days;
                        $hours['is_open'] = $ope_hours->is_open;
                        $hours['start_hours'] = date(self::DATE_FORMAT, strtotime($ope_hours->start_time));
                        $hours['end_hours'] = date(self::DATE_FORMAT, strtotime($ope_hours->end_time));
                        array_push($final_array, $hours);
                    }
                }
                $venue->operating_hours = $final_array;
                $venue_details_flag = DB::table('venue_details_flag')->where(self::VENUE_ID, $venue_id)->get();
                $venue->venue_details_flag = $venue_details_flag;
                $app_skinning = DB::table('app_skinning')->where(self::VENUE_ID, $venue_id)->first();
                if (!empty($app_skinning)) {
                    $skin = (object)[];
                    $venue_skinArr = json_decode($app_skinning->json);

                    $bg_color_exp = explode('#', $venue_skinArr->bg_color);
                    $txt_color_exp = explode('#', $venue_skinArr->txt_color);
                    $btn_color_exp = explode('#', $venue_skinArr->btn_color);
                    $hl_color_exp = explode('#', $venue_skinArr->hl_color);
                    $low_color_exp = explode('#', $venue_skinArr->low_color);
                    $line_color_exp = explode('#', $venue_skinArr->line_color);

                    $skin->venue_logo = $venue_skinArr->venue_logo;
                    $skin->bg_color = $bg_color_exp[1];
                    $skin->txt_color = $txt_color_exp[1];
                    $skin->btn_color = $btn_color_exp[1];
                    $skin->hl_color = $hl_color_exp[1];
                    $skin->low_color = $low_color_exp[1];
                    $skin->line_color = $line_color_exp[1];
                    $venue->venue_skin = $skin;
                } else {
                    $venue->venue_skin = array('venue_logo' => $venue->image, 'bg_color' => '000000', 'txt_color' => self::F_COLOR, 'btn_color' => self::C_COLOR, 'hl_color' => self::C_COLOR, 'low_color' => self::F_COLOR, 'line_color' => self::F_COLOR);
                }
                if ($venue) {
                    return [self::STATUS => true, self::MESSAGE => self::DATA_FOUND, "data" => $venue];
                } else {
                    return [self::STATUS => false, self::MESSAGE => self::NO_DATA_FOUND];
                }
            } else {
                return [self::STATUS => false, self::MESSAGE => self::NO_DATA_FOUND];
            }
        } else {
            return [self::STATUS => false, self::MESSAGE => "Requested parameaters are missing."];
        }
    }//---- End of app_skinning() ----//

    /**
     * @param $ccnum
     * @return string
     *  Check Credit card Type
     */
    function creditCardType($ccnum)
    {
        if (preg_match("/^4\d{3}-?\d{4}-?\d{4}-?\d{4}$/", $ccnum)) {
            // Visa: length 16, prefix 4, dashes optional.
            return "VISA";
        } else if (preg_match("/^5[1-5]\d{2}-?\d{4}-?\d{4}-?\d{4}$/", $ccnum)) {
            // Mastercard: length 16, prefix 51-55, dashes optional.
            return "MASTERCARD";
        } else if (preg_match("/^6011-?\d{4}-?\d{4}-?\d{4}$/", $ccnum)) {
            // Discover: length 16, prefix 6011, dashes optional.
            return "DISCOVER";
        } else if (preg_match("/^3[4,7]\d{13}$/", $ccnum)) {
            // American Express: length 15, prefix 34 or 37.
            return "American-Express";
        } else if (preg_match("/^3[0,6,8]\d{12}$/", $ccnum)) {
            // Diners: length 14, prefix 30, 36, or 38.
            return "Diners";
        } else {
            return "Other-Card";
        }
    }

    /**
     * @param $company_id
     * @param $user_id
     * @return mixed
     */
    public function dashboardSlider($company_id, $user_id)
    {
        if (!empty($company_id) && !empty($user_id)) {
            $news = News::where(self::COMPANY_ID, $company_id)->select('id as news_id', 'news_subject', 'news_desc', 'news_image', 'news_image_gif', 'news_tag', 'news_web_detail', 'news_url', self::CREATED_AT, 'is_public', self::VENUE_ID)->limit(4)->get();
            $res = [];
            foreach ($news as $n) {
                $news_arr = [];
                $news_arr[self::TITLE] = $n->news_subject;
                $clear = strip_tags($n->news_desc);
                $clear = html_entity_decode($clear);
                // Strip out any url-encoded stuff
                $clear = urldecode($clear);
                // Replace non-AlNum characters with space
                $clear = preg_replace('/[^A-Za-z0-9]/', ' ', $clear);
                // Replace Multiple spaces with single space
                $clear = preg_replace('/ +/', ' ', $clear);
                // Trim the string of leading/trailing space
                $clear = trim($clear);
                $trimstring = substr($clear, 0, 100);
                $news_arr['description'] = $trimstring;
                if ($company_id == 2) {
                    $news_arr[self::IMAGE] = url("public/skin_images/slider/$n->news_image_gif");
                } else {
                    $news_arr[self::IMAGE] = url("public/news/gif_images/$n->news_image_gif");
                }
                $news_arr['type'] = 'news';
                $news_arr[self::CONTENT]['news_id'] = $n->news_id;
                $news_arr[self::CONTENT]['news_subject'] = $n->news_subject;
                $news_arr[self::CONTENT]['news_desc'] = $trimstring;
                $news_arr[self::CONTENT]['news_image'] = $n->news_image;
                $news_arr[self::CONTENT]['news_tag'] = $n->news_tag;
                $news_arr[self::CONTENT]['news_web_detail'] = $n->news_web_detail;
                $news_arr[self::CONTENT]['news_url'] = $n->news_url;
                $news_arr[self::CONTENT][self::CREATED_AT] = date($n->created_at);
                $news_arr[self::CONTENT]['is_public'] = $n->is_public;
                $news_arr[self::CONTENT][self::VENUE_ID] = $n->venue_id;
                $news_arr[self::CONTENT]['news_date'] = date("d F Y", strtotime($n->created_at));
                $news_is_favourite = 0;
                $favourite_news = FavouriteNews::where('news_id', '=', $n->news_id)->where(self::USER_ID, '=', $user_id)->where(self::COMPANY_ID, $company_id)->first();
                if (!empty($favourite_news)) {
                    $news_is_favourite = $favourite_news->status;
                }
                $news_arr[self::CONTENT]['news_is_favourite'] = $news_is_favourite;
                $res[] = $news_arr;
            }//..... end foreach() .....//

            if (!empty($res)) {
                return [self::STATUS => true, self::MESSAGE => self::DATA_FOUND, 'data' => $res];
            } else {
                return ['data' => $res, self::STATUS => true, self::MESSAGE => self::NO_DATA_FOUND];
            }
        } else {
            return [self::STATUS => false, self::MESSAGE => self::NO_DATA_FOUND];
        }//..... end if-else() .....//
    }//...... end of dashboardSlider() .....//

    /**
     * @param $user_id
     * @param $company_id
     * @return mixed
     */
    public function usersVenue($user_id, $company_id)
    {
        $sub_res = VenueSubscription::whereUserId($user_id)->whereCompanyId($company_id)->get();
        $venue_array = [];
        if ($sub_res->isNotEmpty()) {
            foreach ($sub_res as $sub) {
                $venue_data = Venue::find($sub->venue_id);
                $base_path_img = url('/') . '/venues/';
                $venues_img = DB::table('venue_image')->where(self::VENUE_ID, '=', $sub->venue_id)->where(self::COMPANY_ID, '=', $company_id)->first();

                if ($venues_img) {
                    $venue_data->image = $base_path_img . $venues_img->image;
                    $venue_data->pay_with_points = $venues_img->pay_with_points;
                } else {
                    $venue_data->image = '';
                    $venue_data->pay_with_points = 0;
                }//..... end if-else() .....//

                $venue_data->subscrition = 1;
                $venue_data->persona_id = $sub->persona_id ?? 0;

                $app_skinning = DB::table('app_skinning')->where(self::VENUE_ID, $sub->venue_id)->first();
                if ($app_skinning) {
                    $skin = (object)[];
                    $venue_skinArr = json_decode($app_skinning->json);
                    $bg_color_exp = explode('#', $venue_skinArr->bg_color);
                    $txt_color_exp = explode('#', $venue_skinArr->txt_color);
                    $btn_color_exp = explode('#', $venue_skinArr->btn_color);
                    $hl_color_exp = explode('#', $venue_skinArr->hl_color);
                    $low_color_exp = explode('#', $venue_skinArr->low_color);
                    $line_color_exp = explode('#', $venue_skinArr->line_color);
                    $skin->venue_logo = $venue_skinArr->venue_logo;
                    $skin->bg_color = $bg_color_exp[1];
                    $skin->txt_color = $txt_color_exp[1];
                    $skin->btn_color = $btn_color_exp[1];
                    $skin->hl_color = $hl_color_exp[1];
                    $skin->low_color = $low_color_exp[1];
                    $skin->line_color = $line_color_exp[1];
                    $venue_data->venue_skin = $skin;
                } else {
                    $venue_data->venue_skin = array('venue_logo' => $venue_data->image, 'bg_color' => '000000', 'txt_color' => self::F_COLOR, 'btn_color' => self::C_COLOR, 'hl_color' => self::C_COLOR, 'low_color' => self::F_COLOR, 'line_color' => self::F_COLOR);
                }//..... end if-else() .....//

                $operating_hours = DB::table('venue_operating_hours')->where(self::VENUE_ID, $sub->venue_id)->get();
                $final_array = array();
                if ($operating_hours->isNotEmpty()) {
                    $hours = array();
                    foreach ($operating_hours as $ope_hours) {
                        $hours['day'] = $ope_hours->days;
                        $hours['is_open'] = $ope_hours->is_open;
                        $hours['start_hours'] = date(self::DATE_FORMAT, strtotime($ope_hours->start_time));
                        $hours['end_hours'] = date(self::DATE_FORMAT, strtotime($ope_hours->end_time));
                        array_push($final_array, $hours);
                    }//..... end foreach() .....//
                }//..... end if() .....//

                $venue_data->operating_hours = $final_array;
                $venue_data->venue_details_flag = DB::table('venue_details_flag')->where(self::VENUE_ID, $sub->venue_id)->get();
                $venue_array[] = $venue_data;
            }//..... end foreach() .....//

            return [self::STATUS => true, self::MESSAGE => 'Venues are found', 'data' => $venue_array];
        } else {
            return [self::STATUS => false, self::MESSAGE => 'You do not subscribed any venue.', 'data' => []];
        }//..... end if-else() .....//
    }//..... end of userVenue() .....//

    /**
     * @param $id
     * @param $company_id
     * @return mixed
     */
    public function getVenueInformation($id, $company_id)
    {
        $venue = Venue::find($id);
        if ($venue) {
            return [self::STATUS => true, 'venue' => $venue];
        } else {
            return [self::STATUS => false, self::ERROR => 'Server error!'];
        }

    }//---- End of getVenueInformation() ----//

    /**
     * @return mixed
     */
    public function getClientId()
    {
        if (Schema::hasTable('oauth_clients')) {
            $client_ids = DB::table("oauth_clients")->select("id", "secret")->where("name", "Laravel Password Grant Client")->get();
            if ($client_ids) {
                return [self::STATUS => true, 'cleint_data' => $client_ids];
            } else {
                return [self::STATUS => true, self::ERROR => "No Record Found"];
            }
        } else {
            return [self::STATUS => true, self::ERROR => "Table Not Found"];
        }
    }

    /**
     * @param string $phoneNumber
     * @param string $code
     * @return bool
     * @throws \Matthewbdaly\SMS\Exceptions\DriverNotConfiguredException
     *  Send Verification code to user for activation
     */
    public function sendSms($phoneNumber, $message, $route = null)
    {

        try {
            if (empty($route)) {
                $route = self::DEFAULT;
            }


            Log::channel(self::CUSTOM)->info('sendSms()', [
                'mobile' => $phoneNumber,
            ]);
//                if (request()->has('country_code') and Config::get('constant.APP_NAME') !='engage-wuhu') {
////                    $country_code = request()->country_code;
////                    if ($phoneNumber[0] == 0) {
////                        $phoneNumber = substr($phoneNumber, 1);
////                    }
////                    $phoneNumber = request()->country_code . $phoneNumber;
//                }
            if (Config::get('constant.APP_NAME') == 'engage-wuhu') {
                $str1 = ltrim($phoneNumber, '0');
                $phoneNumber = '+' . $str1;
            }


            Log::channel(self::CUSTOM)->info('sendSms()', [
                'phoneNumber' => $phoneNumber,
                self::MESSAGE => $message,
                self::ROUTE => $route
            ]);

            $http = new \GuzzleHttp\Client();
            $response = $http->post(config('constant.JAVA_URL') . 'sendSMS', [
                'headers' => array(),
                'json' => [
                    'mobile' => $phoneNumber,
                    self::ROUTE => $route,
                    'message_txt' => $message,
                ]
            ]);

            $smsResponse = json_decode($response->getBody(), true);

            Log::channel(self::CUSTOM)->info('SMS Response', [
                'smsStatus' => $smsResponse[self::STATUS],
                'smsMessage' => $smsResponse[self::MESSAGE],
            ]);

            if ($smsResponse[self::STATUS]) {
                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }//--- End of sendSms() ---//

    /**
     * @param string $phoneNumber
     * @param string $code
     * @return bool
     * @throws \Matthewbdaly\SMS\Exceptions\DriverNotConfiguredException
     *  Send Verification code to user for activation
     */
    public function sendVerificationSms($phoneNumber, $code, $name, $route = self::DEFAULT, $appName = null)
    {
        try {
            Log::channel(self::CUSTOM)->info('sendVerificationSms()', [
                'phoneNumber' => $phoneNumber,
                'code' => $code,
                self::ROUTE => $route
            ]);
            $string = sprintf("Hi %s, your activation code is %s for the %s app." .
                " Simply enter this code and let's get started! The %s Team.",
                $name, $code, ucfirst($this->app_name), ucfirst($this->app_name));
            if (empty($appName)) {
                if (Config::get('constant.APP_SMS_NAME') != '') {
                    $appName = Config::get('constant.APP_SMS_NAME');
                } else if (Config::get('constant.APP_NAME') != '') {
                    $appName = Config::get('constant.APP_NAME');
                    $appName = str_replace($appName, 'engage-', '');
                } else {
                    $appName = self::DEFAULT;
                }
            }

            if (\config('constant.APP_NAME') == 'engage-wuhu') {
                $string = "Wuhu :) Thanks for signing up to Wuhu. Here’s your OTP code: " . $code . ". If you didn’t request this code, please ignore this and don’t share it with anyone.";
            }

            $result = $this->sendSms(
                $phoneNumber,
                $string,
                $route
            );

            Log::channel(self::CUSTOM)->info('sendVertificationSms()', [
                'result' => $result
            ]);

            return $result;
        } catch (\Exception $e) {
            return ['statue' => false];
        }
    }//--- End of sendVerificationSms() ---//


    /**
     * @param Request $request
     * @return array
     * @throws DriverNotConfiguredException
     * @throws GuzzleException
     */
    public function activateUser()
    {
        Log::channel('user')->info('activateUser_req', ['activateUser_req' => \request()->all(), 'activation_start_time' => microtime(true) . " seconds."]);
        $validator = Validator::make(\request()->all(), [
            'code' => self::REQUIRED,
            self::USER_ID => self::REQUIRED
        ]);
        if (request()->has('password') and !empty(\request()->password)) {
            if ($this->password_check) {
                if ($this->checkValidPassword()) {
                    return [self::STATUS => false, self::MESSAGE => "How'd you like to add some character to your password? At least one upper case, lower case,numeric and special character, please."];
                }
            } else {
                if (preg_match("/^.*(?=.{6,})(?=.*[0-9])(?=.*[a-z]).*$/", request()->password) === 0) {
                    return [self::STATUS => false, self::MESSAGE => "How'd you like to add some character to your password? At least one upper case, lower case and numeric, please."];
                }
            }

        }

        if ($validator->fails()) {
            $errors = $validator->errors();
            foreach ($errors->get('code') as $message) {
                $mess['message'] = $message;
            }

            foreach ($errors->get(self::USER_ID) as $message) {
                $mess['message'] = $message;
            }

            return $mess;
        }//..... end if() .....//
        $foundUser = User::where([self::USER_ID => request()->user_id])->first();
        if ($foundUser->code_tries >= 3) {
            return ['status' => false, 'message' => "You have reached your maximum limit of tries, please try again later!"];
        }
        $user = User::where([self::USER_ID => request()->user_id, self::ACTIVATION_TOKEN => request()->code])->first();
        if ($user) {
            if (request()->code === $user->activation_token && strtotime(Carbon::now()) > strtotime($user->expiry_time)) {
                return [self::STATUS => false, self::MESSAGE => "Looks like your verification code has expired. Don't panic. Simply send a new code to yourself."];
            }
            if ($user->is_active and request()->is_existing_user !== "1") {
                return [self::STATUS => false, self::MESSAGE => "Your account is already active. Please login."];
            }


            $updateData = [self::IS_ACTIVE => 1, self::ACTIVATION_TOKEN => ''];
            if (request()->has(self::PHONE) && request()->phone != '') {
                //remove spaces from phone
                $phone = str_replace(' ', '', request()->phone);
                if ($this->register_unique_col == 'phone') {
                    $userExsist = User::where(['user_mobile' => request()->phone, self::IS_ACTIVE => 1])->first();
                    if ($userExsist) {
                        return ['status' => false, 'message' => 'User with same phone number already exists'];
                    }
                }
                $updateData[self::USER_MOBILE] = $phone;
            }


            //=================  create user on soldi  ==============//
            if (request()->is_existing_user == 0) {


                if ($this->payment_method != 'none') {
                    //Register Cutomer to killBill
                    if (config('constant.KILL_BILL_USER_NAME') and \config('constant.KILL_BILL_PASSWORD')) {
                        if (config('constant.APP_NAME') == 'engage-gawler' || config('constant.APP_NAME') == 'engage-ballers') {
                            if (!$user->kill_bill_id) {
                                $status = (new StripePaymentController())->registerUserToKB($user);
                                if (!$status['status']) {
                                    Log::channel('user')->error('Kill bill register error', ['Kill bill message' => $status['message']]);
                                    return ['status' => false, 'message' => 'Please try again'];
                                }
                            }
                        } else {
                            if (\request()->has('disable_killbill') and request()->disable_killbill) {

                            } else {
                                Log::channel('user')->info('register_req', ['Killbill_start_registration' => microtime(true) . " seconds."]);
                                $status = (new PaymentController())->registerUserToKB($user);
                                Log::channel('user')->info('register_req', ['Killbill_end_registration' => microtime(true) . " seconds."]);
                                if (!$status[self::STATUS]) {
                                    Log::channel('user')->error('Kill bill error', ['Kill bill message' => $status[self::MESSAGE]]);
                                    return [self::STATUS => false, self::MESSAGE => 'Please try again'];
                                }
                            }
                        }
                    }
                }

                if (config('constant.BOOKING_ENGINE_URL') and \config('constant.BOOKING_ENGINE_KEY')) {
                    Log::channel('user')->info('register_req', ['bookingengine_start_registration' => microtime(true) . " seconds."]);

                    // Register Cutomer to Booking Engine
                    if (\request()->has('disable_booking_engine') and request()->disable_booking_engine) {

                    } else {

                        $bookingEngineID = $this->registerUserToBookingEngine($user);
                        Log::channel('user')->info('register_req', ['bookingengine_end_registration' => microtime(true) . " seconds."]);
                        if (isset($bookingEngineID->status) and $bookingEngineID->status) {
                            $updateData['booking_engine_id'] = $bookingEngineID->user_id;
                            $user->booking_engine_id = $bookingEngineID->user_id;
                            \request()->merge(['booking_id' => $bookingEngineID->user_id]);
                        } else {
                            return ['status' => false, 'message' => 'Error In booking engine'];
                        }
                    }
                }
                // Register Customer on Soldi Pos
                if (config('constant.SOLDI_DEFAULT_PATH') != '') {

                    Log::channel('user')->info('register_req', ['soldi_start_registration' => microtime(true) . " seconds."]);
                    if (\request()->has('member_type') and ucfirst(\request()->member_type) == 'Admin') {

                    } else {
                        $soldiResponse = $this->createUserSoldi($user, request()->header(self::COUNTRY));
                        Log::channel('user')->info('register_req', ['soldi_end_registration' => microtime(true) . " seconds."]);
                        $updateData[self::SOLDI_ID] = $soldiResponse[self::CUSTOMER_ID] ?? 0;

                        if (isset($soldiResponse['icustomer_id_uk']) and !empty($soldiResponse['icustomer_id_uk'])) {
                            $updateData['client_customer_id'] = $soldiResponse['icustomer_id_uk'];
                        }
                    }

                    $soldiBusiness = [];
                    if (\request()->has('member_type') and ucfirst(\request()->member_type) == 'Admin') {
                        $updateData['user_type'] = 'web';
                        $updateData['is_merchant'] = 1;
                        $knoxRseponse = $this->addUserOnKnox($user);
                        if (!$knoxRseponse['status']) {
                            return ['status' => false, 'message' => $knoxRseponse['Message'] ?? $knoxRseponse['message'] ?? 'Cannot create vendor on knox'];
                        }
                        $soldiBusiness = $this->addSoldiBusiness($user, $knoxRseponse, true);
                        $updateData['knox_user_id'] = $knoxRseponse['user'];
                        $updateData['amp_user_id'] = $knoxRseponse['business_id'];

                    } else {
                        if ($updateData[self::SOLDI_ID] === 0) {
                            User::where([self::EMAIL => request()->email, self::IS_ACTIVE => 0])->delete();
                            return [self::STATUS => false, self::MESSAGE => 'User with this Email already exists, Please use different email.'];
                        }//..... end if() .....///
                    }
                    if (\request()->has('member_type') and !empty(\request()->member_type)) {
                        $updateData['groups'] = json_encode(['Member', request()->member_type]);
                    }


                }
                // Update User To Booking Engine
                if (config('constant.BOOKING_ENGINE_URL') and \config('constant.BOOKING_ENGINE_KEY') and isset($updateData['booking_engine_id'])) {
                    if (\request()->has('disable_booking_engine') and request()->disable_booking_engine) {

                    } else {

                        $data = $user;
                        $data['booking_engine_id'] = $updateData['booking_engine_id'];
                        $data['soldi_id'] = $updateData[self::SOLDI_ID] ?? $soldiBusiness['data']['user_id'] ?? 0;
                        $soldiID = $updateData[self::SOLDI_ID] ?? $soldiBusiness['data']['user_id'] ?? 0;
                        Log::channel('user')->info('register_req', ['bookingengineupdate_start' => microtime(true) . " seconds."]);

                        $bookingEngineID = $this->updateUserOnBookingEngine((object)$data, $soldiID, $soldiBusiness);
                        Log::channel('user')->info('register_req', ['bookingengineupdate_end' => microtime(true) . " seconds."]);
                    }

                }


                $updateData[self::REF_CODE] = $this->getReferralCode($user->user_id);
                $updateData[self::DEVICE_TOKEN] = request()->device_token;
                $updateData[self::DEVICE_TYPE] = request()->device_type;
                $updateData[self::DEBUG_MOD] = $this->getAppEnvoirnment();

                //------ Booking Engine User Registration --------//


            }//..... end if() .....//
            if (request()->has('password') and !empty(\request()->password)) {
                $user->password = Hash::make(request()->password);
            }
            if ($user->update($updateData)) {

                //gawler wuhu check

                if ($this->register_unique_col == 'email') {
                    if (request()->is_existing_user == 0 and (config('constant.APP_NAME') == 'engage-gawler')) {
                        $this->send_email($user->email, $user->user_first_name . ' ' . $user->user_family_name, '', $user->user_id, '', 'welcome_user');
                    }
                    if ((request()->is_existing_user == 0) && ($user->is_email)) {
                        $this->send_email($user->email, $user->user_first_name . ' ' . $user->user_family_name, '', $user->user_id, '', 'welcome_user');
                    }
                }
                // Register user on gigaya
                if ($this->enable_gigya)
                    $this->registerUserOnGigya($user);

                request()->merge(["region_type" => $user->region_type]);

                (new ElasticSearchController())->insertUserToES($user->user_id);
                sleep(3);
                (new GamificationController())->assignStampCardOldNewUser($user);
                (new GamificationController())->changeMemberShip($user->user_id);

                //save user notifications in RDS
                $this->saveChannels($user);


                //call event trigger
                $trigger_type = "$.register_trigger";
                $data = [
                    'user_id' => request()->user_id,
                    'trigger_type' => 'signup'
                ];
                (new VCTrigger())->callVCTrigger($data, $trigger_type);
                Log::channel('user')->info('register_req', ['activation_end_time' => microtime(true) . " seconds."]);
                $accessToken = $this->getAccessTokens($user);

                return [self::STATUS => true, self::MESSAGE => 'User is activated', 'access_token' => $accessToken];
            } else {
                return [self::STATUS => false, self::MESSAGE => 'Error occurred while activating user'];
            }
        } else {

            if ($foundUser) {
                $foundUser->code_tries = ($foundUser->code_tries + 1);
                $foundUser->save();
            }
            return [self::STATUS => false, self::MESSAGE => "Oops… Your verification code doesn't match up. Please check the code we sent you and try again."];
        }
    }

    public
    function saveChannels($user)
    {
        $channels = ['sms', 'email', 'push', 'letterbox', 'post'];
        if (request()->has('marketing') and request()->marketing) {
            $i = 0;

            $value = true;
            $channels[] = 'News';
            while ($i < count($channels)) {
                $data = [
                    'user_id' => $user->user_id,
                    'channel' => $channels[$i],
                    'notification_type' => 'marketing',
                    'subscribed' => true,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ];
                UserNotification::updateOrCreate([
                    'user_id' => $user->user_id,
                    'channel' => $channels[$i],
                    'notification_type' => 'marketing',
                ], $data);
                $i++;
            }
        }
        if (request()->has('system') and request()->system) {

            $i = 0;
            $value = true;
            $channels[] = 'Promotions';
            while ($i < count($channels)) {
                $data = [
                    'user_id' => $user->user_id,
                    'channel' => $channels[$i],
                    'notification_type' => 'system',
                    'subscribed' => $value,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ];
                UserNotification::updateOrCreate([
                    'user_id' => $user->user_id,
                    'channel' => $channels[$i],
                    'notification_type' => 'system',
                ], $data);
                $i++;
            }
        } else {
            $i = 0;
            while ($i < 5) {
                $data = [
                    'user_id' => $user->user_id,
                    'channel' => $channels[$i],
                    'notification_type' => 'system',
                    'subscribed' => true,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ];
                UserNotification::updateOrCreate([
                    'user_id' => $user->user_id,
                    'channel' => $channels[$i],
                    'notification_type' => 'system',
                ], $data);
                $i++;
            }
        }

    }

    /**
     * @param Request $request
     * @return array
     * @throws \Matthewbdaly\SMS\Exceptions\DriverNotConfiguredException
     *  If Code Recieved Failed Then User Request for another Verification Code
     */
    public
    function codeResendUser(Request $request)
    {

        $validate = Validator::make($request->all(), [
            self::USER_ID => self::REQUIRED,
            self::PHONE => self::REQUIRED
        ]);
        if ($validate->fails()) {
            $errors = $validate->errors();
            foreach ($errors->get(self::USER_ID) as $message) {
                $mess[self::USER_ID] = $message;
            }
            return $mess;
        }//..... end if() .....//

        //Check Timer
        $checkTimer = DB::table('user_verifications')->where('user_id', $request->user_id)->first();
        if ($checkTimer) {
            $datetime1 = new \DateTime(Carbon::parse($checkTimer->created_at)->format('Y-m-d h:i:s'));//start time
            $datetime2 = new \DateTime(Carbon::now()->format('Y-m-d h:i:s'));//en
            $interval = $datetime1->diff($datetime2);

            if ($interval->format("%i") === '59' || $interval->format("%i") === '0') {
                return [self::STATUS => true, self::MESSAGE => 'Message sent successfully.'];
            }
        }

        $code = rand(1111, 9999);
        $user = User::find($request->user_id);
        $user->activation_token = $code;
        $user->expiry_time = Carbon::now()->addMinute(5);
        $user->code_tries = 0;
        $this->updateTimerForNotifications($user);
        $user->save();

        $this->sendVerificationSms($request->phone, $code, $user->user_first_name);

        return [self::STATUS => true, self::MESSAGE => 'Message sent successfully.'];

    }//..... end of codeResendUser() .....//

    /**
     * @param Request $request
     * @return array
     * @throws DriverNotConfiguredException
     */
    public
    function loginUser(Request $request)
    {
        //Log::channel('user')->info('loginUser_req', ['loginUser_req' => $request->all()]);
        //unique field check
        $user = null;
        $message_uniq_key = 'email';
        if ($this->register_unique_col == 'phone') {
            $message_uniq_key = 'user_mobile';
        }
        if ($request->has('is_auth')) {
            $user = request()->user();
        } else {
            $validate = Validator::make($request->all(), [
                $this->register_unique_col == 'email' ? self::EMAIL : 'user_mobile' => self::REQUIRED,
                self::PASS => self::REQUIRED,
            ]);
            if ($validate->fails()) {
                if ($this->register_unique_col == 'email') {
                    if ($validate->errors()->has(self::EMAIL)) {
                        $mess[self::EMAIL] = $validate->errors()->get(self::EMAIL);
                    }
                } else {
                    if ($validate->errors()->has('user_mobile')) {
                        $mess['user_mobile'] = $validate->errors()->get('user_mobile');
                    }
                }

                if ($validate->errors()->has(self::PASS)) {
                    $mess[self::PASS] = $validate->errors()->get(self::PASS);
                }

                return $mess;
            }

            # Select matching user record(s) but ensure any active user record has priority
            #
            //unique field check

            $user = User::where([
                "$message_uniq_key" => $request->$message_uniq_key,
                //'user_type' => 'app',
            ])->orderBy(self::IS_ACTIVE, 'DESC')->first();

        }
        try {
            if (!$user) {
                //unique field check
                $this->getUserInfo('loginUserFailure');
                if ($message_uniq_key == 'user_mobile') {
                    return [
                        self::STATUS => false,
                        self::MESSAGE => "The cellphone number you are using doesn't exist"
                    ];
                }
                return [
                    self::STATUS => false,
                    self::MESSAGE => "Incorrect $message_uniq_key or password. Please try again."
                ];
            }

            # Handle legacy first generation users which have column old_user = 1
            # The is_active and empty password check ensures that legacy activation
            # can only occur once per user record
            #
            if (intval($user->old_user) > 0 && intval($user->is_active) == 0
                && empty($user->password)) {

                # The mobile app is unable to handle a null
                # DOB so we coalese to empty string if needed.
                #
                if (empty($user->dob)) {
                    $user->dob = '';
                }

                return [
                    'data' => $user,
                    'access_token_info' => (object)[],
                    self::STATUS => true,
                    self::MESSAGE => '',
                ];
            }

            # Send verfication SMS
            #
            /*       if ($user->is_active != 1) {
                       $code = rand(1111, 9999);
                       $this->sendVerificationSms(
                           $user->user_mobile,
                           $code,
                           $user->user_first_name . ' ' . $user->user_family_name
                       );
                       User::where([
                           self::USER_ID => $user->user_id
                       ])->update([
                           self::ACTIVATION_TOKEN => $code,
                           self::EXPIRY_TIME => Carbon::now()->addMinute(5)
                       ]);
                       return [
                           self::STATUS => false,
                           'data' => $user,
                           self::MESSAGE => 'Your account is not activated, please register again'
                       ];
                   }*/

            # Active users reach here
            #

            $this->getUserInfo('loginUserSuccess');

            if (!$request->has('is_auth') and !Hash::check($request->password, $user->password)) {
                $this->getUserInfo('loginUserFailure');
                //unique field check
                if ($message_uniq_key == 'user_mobile') {
                    return [
                        self::STATUS => false,
                        self::MESSAGE => "Please login using correct password, or use Forgot My Password to recover your password"
                    ];
                }

                return [
                    'status' => false,
                    'message' => "Incorrect $message_uniq_key or password. Please try again."
                ];
            }

            /**
             *  Check if old User and in active Activate and register on POS
             */
            if (intval($user->old_user) > 0 && intval($user->is_active) == 0 and !empty($user->password)) {
                $code = rand(1111, 9999);
                $user->activation_token = $code;
                $user->save();
                \request()->merge(['user_id' => $user->user_id, 'code' => $user->activation_token, 'is_existing_user' => 0]);
                $this->activateUser();
                $user = User::whereUserId($user->user_id)->first();
            }


            $userCode = ($user->referral_code != '') ?
                $user->referral_code : $this->getReferralCode($user->user_id);


            $user_type = ($user->user_type == 'app') ? 'app' : 'web';
            if ($user->user_type == 'app') {

            } else {
                if ($request->has('user_type')) {
                    $user_type = 'web';
                } else {
                    $user_type = ($user->user_type == 'app') ? 'app' : 'web';
                }
            }

            if (($request->has('device_token') and !empty($request->device_token)) and ($request->has('device_type') and !empty($request->device_type))) {
                $user->update([
                    self::DEBUG_MOD => $this->getAppEnvoirnment(),
                    self::DEVICE_TOKEN => $request->device_token,
                    self::DEVICE_TYPE => $request->device_type,
                    self::REF_CODE => $userCode,
                    'last_login' => date('Y-m-d H:i:s'),
                    'user_type' => $user_type
                ]);
            }

            $accessToken = $this->getAccessTokens($user);
            if (!isset($accessToken['access_token'])) {
                return [
                    self::STATUS => false,
                    self::MESSAGE => 'Error occurred while getting token.'
                ];
            }

            /**
             * Check if user demographic data exists then
             *  add demographic data and  update device data other wise update devices data
             */

            // Add device_id in user object
            if ($request->has('device_id') and !empty($request->device_id)) {
                $user->device_id = $request->device_id;
            }
            (new ElasticSearchController())->checkUserExists($user);

            // Add user to Killbill
            /*if (!$user->kill_bill_id || !$user->kilbill_ire_id) {
                (new PaymentController())->registerUserToKB($user);
            }*/

            $app_mode = Setting::where(self::COMPANY_ID, '=', $user->company_id)->first();
            $user->app_mod = $app_mode ? $app_mode->app_mode : 0;
            $user->dob = ($user->dob) ? $user->dob : '';
            $user->gender = ($user->gender) ? $user->gender : '';
            $user->postal_code = ($user->postal_code) ? $user->postal_code : '';
            $user->venue_name = $this->getVenueName($user->default_venue, false);
            if ($request->has('venue_details') and \request()->venue_details) {
                $user->venue_details = $this->getVenueName($user->default_venue, true);
            }
            $user->card_data = [];

            $user->completed_profile = 100;

            if (!$user->gender && !$user->dob) {
                $user->completed_profile = 35;
            }

            if ($user->food_preference) {
                $foodPreferences = json_decode($user->food_preference, true);
                $foodPreferences = collect($foodPreferences);
                $user->food = array_values(
                    $foodPreferences->where('type', '=', 'food')->toArray()
                );
                $user->allergy = array_values(
                    $foodPreferences->where('type', '=', 'allergy')->toArray()
                );
            } else {
                $user->food = [];
                $user->allergy = [];
            }
            if ($user->user_favourites) {
                $user->user_favourites = json_decode($user->user_favourites, true);
            } else {
                $user->user_favourites = [];
            }
            $oldData = ($user->old_user == 1) ? 0 : $user->old_user;
            $user->old_user = $oldData;
            if (empty($user->gender)) {
                $user->gender = 'U';
            }
            $giftCard = Setting::where('type', 'gift_card')->first();
            if ($giftCard) {
                $user->is_giftcard_enable = ($giftCard) ? (($giftCard->field1 == '1') ? true : false) : false;
            } else {
                $user->is_giftcard_enable = false;
            }

            $userData = [
                'access_token_info' => $accessToken,
                self::STATUS => true,
                self::MESSAGE => 'Login Successful',
            ];
            if (request()->header(self::COUNTRY) == 'aus' || request()->header(self::COUNTRY) == 'nz') {
                $userData['virtual_store_obj'] = $this->getVirtualStore();
                $userData['virtual_store'] = 117;

                $user->address = [];
                $user->address = $this->getUserAddresses($user->user_id, 'api');
                $user->address = json_decode($user->address, true);
            } elseif (\request()->has('all_address')) {
                $user->address = [];
                $user->address = $this->getUserAddresses($user->user_id, 'api');
                $user->address = json_decode($user->address, true);
            } else {
                $userAddress = UserAddresses::where(['user_id' => $user->user_id, 'is_default' => 1])->first();

                if ($userAddress) {
                    $user->address = $userAddress->address;
                    $user->city = $userAddress->city;
                    $user->state = $userAddress->state;
                    $user->country = $userAddress->country;
                    $user->postal_code = $userAddress->postal_code;
                } else {
                    $user->address = '';
                    $user->city = '';
                    $user->state = '';
                    $user->country = '';
                    $user->postal_code = '';
                }
            }

            if (isset($user->country_code)) {
                $user->country_code = $user->country_code;
            } else {
                $user->country_code = '';
            }
            $user->payment_timeout = $this->timeout;
            $user->profile_percentage = $this->userProfilePercentage($user->user_id);


            $customConfiguration = DB::table('custom_configurations')->get(['name', 'value']);
            $timeOut = 10;
            $settingsData = Setting::where('type', 'take_away')->first();
            if ($settingsData) {
                $timeOut = $settingsData->field1 ?? $settingsData['field1'];
            }

            $userData['data'] = $user;
            $userData['data']['custom_configuration'] = $customConfiguration;
            $userData['data']['takeaway_time'] = $timeOut;

            //check if user completed walthrough
            if (\request()->has('walkthrough_completed')) {
                $userData['data']['walkthrough_completed'] = \request()->walkthrough_completed;
                if (\request()->walkthrough_completed || request()->walkthrough_completed === 'true') {
                    Log::channel('custom')->info('walkthrough_completed', ['walkthrough_completed' => \request()->walkthrough_completed]);
                    (new GamificationController())->completedWalkThrougMission($user->user_id);
                    //call vp trigger if walkthrough completed
                    //call event trigger
                    $data = [
                        'user_id' => $user->user_id,
                        'trigger_type' => 'walkthrough',
                    ];
                    $trigger_type = "$.walkthrough_trigger";
                    (new VCTrigger())->callVCTrigger($data, $trigger_type);
                }
            } else {
                $userData['data']['walkthrough_completed'] = false;
            }
            $userData['data']['total_points'] = (new VoucherController())->calculateUserPoints($user->user_id);
            $userData['data']['email'] = ($userData['data']['email']) ? $userData['data']['email'] : '';
            $userData['data']['weak_password'] = $this->checkValidPassword();
            return $userData;
        } catch (\Exception $e) {
            Log::channel('user')->error('Error Occurred: -------------------- ', [
                'ErrorMessage' => $e->getMessage()
            ]);
        }
    }//--- End of loginUser() ---//


    private
    function userProfilePercentage($user_id)
    {
        $user = User::where(self::USER_ID, $user_id)->first();
        $userAddress = UserAddresses::where(['user_id' => $user_id, 'is_default' => 1])->first();

        if ($userAddress) {
            $user->address = $userAddress->address;
            $user->city = $userAddress->city;
            $user->state = $userAddress->state;
            $user->country = $userAddress->country;
            $user->postal_code = $userAddress->postal_code;
        } else {
            $user->address = '';
            $user->city = '';
            $user->state = '';
            $user->country = '';
            $user->postal_code = '';
        }

        $percentage = 40;
        if (!empty($user->user_avatar) || \request()->has('user_image')) {
            $percentage = $percentage + 10;
        }
        if (!empty($user->gender)) {
            $percentage = $percentage + 10;
        }
        if (!empty($user->dob)) {
            $percentage = $percentage + 10;
        }

        if (!empty($user->city)) {
            $percentage = $percentage + 5;
        }
        if (!empty($user->state)) {
            $percentage = $percentage + 5;
        }
        if (!empty($user->address)) {
            $percentage = $percentage + 5;
        }
        if (!empty($user->postal_code)) {
            $percentage = $percentage + 5;
        }
        if (!empty($user->country)) {
            $percentage = $percentage + 10;
        }
        if ($percentage > 100) {
            $percentage = 100;
        }
        try {
            //save user percentage in DB
            $user->profile_percentage;
            User::where('user_id', $user_id)->update(['profile_percentage' => $percentage]);
        } catch (\Exception $e) {
            Log::channel('custom')->info('profile_percentage_error', ['profile_percentage_error' => $e->getMessage()]);
        }

        return $percentage;

    }

    /**
     * @param $request
     * @return int|string
     * @throws \GuzzleHttp\Exception\GuzzleException
     * User Creation on Soldi
     */
    public
    function createUserSoldi($request, $region)
    {
        try {

            $userAddress = $this->getUserAddresses($request->user_id, '');


            $userAddress = collect(json_decode($userAddress));
            $userAddress = $userAddress[0];
            $business_details = $this->getVenuesInformation();
            if(!$business_details['status']){
                return ['status' => false,'message' =>'User cannot register on pos'];
            }
            $buss_id = $business_details['data']['company_id'];
            $appName = $this->app_name;

            //$appName = ($this->app_name =='sessions')?'session':$this->app_name ;
            $userType = 'Member';
            if (\request()->has('member_type') and !empty(\request()->member_type)) {
                $userType = \request()->member_type;
            }


            $parm = [self::BUSINESS_ID => $buss_id, self::FIRST_NAME => $request->user_first_name, self::LAST_NAME => $request->user_family_name,
                'email_address' => $request->email, self::GENDER => ($request->gender == 'Male' || $request->gender == 'male') ? '1' : (($request->gender == 'Female' || $request->gender == 'female' || $request->gender == 'F') ? '0' : '2'),
                'mobile_number' => $request->user_mobile, 'company_name' => \request()->company_name ?? '', 'land_line' => '', 'street_1' => $userAddress->address ?? '',
                'street_2' => $userAddress->address2 ?? '', 'suburb' => $userAddress->suburb ?? "", self::COUNTRY_INDEX => $userAddress->country ?? '', 'province' => $userAddress->state ?? '', 'city' => $userAddress->city ?? '', 'code' => $userAddress->postal_code ?? '',
                'app_name' => $appName, 'region' => $region, 'membership_id' => $request->client_customer_id,
                'compulsory' => $this->register_unique_col, 'image' => ($request->user_avatar) ? \url('/users/') . '/' . $request->user_avatar : '', 'user_type' => $userType, 'engage_user_id' => $request->user_id

            ];
            if (\request()->has('auth_code') and (\request()->auth_code || \request()->auth_code == 'true')) {
                $accessToken = $this->getAccessTokens($request);
                $parm['auth_code'] = $accessToken['access_token'] ?? $accessToken->access_token;
                $parm['app_name'] = $appName;
            }
            if (\request()->has('booking_id')) {
                $parm['be_customer_id'] = \request()->booking_id;
            }

            $client1 = new Client([
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-API-KEY' =>  $business_details['data']['api_key'],
                    'SECRET' =>  $business_details['data']['secret_key']

                ]
            ]);

            $response = $client1->request('POST', config('constant.SOLDI_DEFAULT_PATH') . '/customer/create', [
                'json' => $parm
            ]);
            $soldi_res = $response->getBody()->getContents();
            $soldi_arr = json_decode($soldi_res);
            Log::channel('user')->info('response on creation soldi', ['soldiResponse' => $soldi_arr, 'inputToSoldi' => $parm]);
            return [self::CUSTOMER_ID => $soldi_arr->data->customer_id ?? $soldi_arr->customer_id, 'icustomer_id_uk' => $soldi_arr->data->icustomer_id_uk ?? ''];

        } catch (\Exception $e) {
            Log::channel('user')->error('Exception from user on creation soldi', ['SOLDICREATEUSER_exception' => $e->getMessage()]);
            return $e->getMessage();
        }//..... end of try-catch() .....//
    }//..... end of createUserSoldi() .....//


    /**
     * @param Request $request
     * @return mixed
     * @throws \Matthewbdaly\SMS\Exceptions\DriverNotConfiguredException
     */
    function testSms(Request $request)
    {


        $reagion = ["us-west-2"];
        shuffle($reagion);
        $reg = $reagion[0];

        $config = [
            'api_key' => config('constant.AWS_SNS_API_KEY'),
            'api_secret' => config('constant.AWS_SNS_API_SECRET'),
            'api_region' => Config::get('constant.SES-REGION'),
        ];
        $driver = new Aws($config);
        $client = new awsClient($driver);
        $msg = [
            'to' => $request->phone,

            'from' => '',
            self::CONTENT => "This is test message to testing sms. Region is " . $reg,];


        try {
            $guzzle = new GuzzleClient();
            $resp = new Response();
            $driver = new Twilio($guzzle, $resp, [
                self::ACCOUNT_ID => 'AC90fee406d29396464cf5301f663a5943',
                self::API_TOKEN => 'e51ba8374750bdcd6d320cfa193a862d',
            ]);
            $client = new awsClient($driver);
            $msg = [
                'to' => '+923322497339',
                'from' => Config::get('constant.TWILLIONUMBER'),
                self::CONTENT => 'Just testing',
            ];
            dd($client->send($msg));
        } catch (\Exception $e) {
            return $e->getMessage();
        }
        return true;
    }//---- End of testSms() ----//

    /**
     * @param $user
     * @return array
     * Get User AccessToken.
     */
    private
    function getAccessTokens(User $user): array
    {
        return ['access_token' => $user->createToken($user->email)->accessToken];
    }//..... end of getAccessTokens() ......//

    /**
     * @param Request $request
     * @return array
     * @throws GuzzleException
     * Auto Checkout Feature For App
     */
    public
    function autoCheckoutCart(Request $request)
    {
        $data = json_decode($request->product_array, true);
        $valiadtor = Validator::make($request->all(), [
            self::VENUE_ID => self::REQUIRED,
            self::USER_ID => self::REQUIRED,
        ]);

        if ($valiadtor->fails()) {
            $errors = $valiadtor->errors();
            $mess[self::STATUS] = false;

            foreach ($errors->get(self::VENUE_ID) as $message) {
                $mess[self::MESSAGE] = 'venue_id is missing';
                return $mess;
            }
            foreach ($errors->get(self::USER_ID) as $message) {
                $mess[self::MESSAGE] = self::USER_ID_MISSING;
                return $mess;
            }
        }
        Log::channel(self::CUSTOM)->info('autoCheckoutCart() Auto Checkout process started: *****************************************###********************************');

        if ($request->last_synchronise_id) {// Update
            $infoData = AutoOrderPlacement::find($request->last_synchronise_id);
            if ($infoData->operation_performed == 'auto_payment_failed' || $infoData->operation_performed == 'auto_payment_done' || $infoData->operation_performed == 'checkout' || $infoData->operation_performed == 'order_inprocess' || $infoData->operation_performed == self::IS_DELETED || $infoData->operation_performed == 'cancel') {
                return [self::STATUS => false, self::MESSAGE => self::NO_DATA_FOUND];
            } else {
                AutoCheckout::where(self::USER_ID, $request->user_id)->delete();
                AutoCheckout::insert($data);
                $updateArray = [self::USER_ID => $request->user_id, self::BUSINESS_ID => $request->business_id, 'order_detail' => $request->payment_parameters, self::VENUE_ID => $request->venue_id];
                $autoOrder = new AutoOrderPlacement();
                if (!$request->server_schedular_update) {
                    $autoOrder->whereId($request->last_synchronise_id)->update($updateArray);
                    Log::channel(self::CUSTOM)->info('autoCheckoutCart() Auto Checkout Order updated with last synchronized id: ' . $request->last_synchronise_id . ' and ', ['data' => $updateArray]);
                } else {
                    $autoOrder->timestamps = false;
                    $autoOrder->whereId($request->last_synchronise_id)->update($updateArray);
                    Log::channel(self::CUSTOM)->info('autoCheckoutCart() Auto Checkout Order updated with last synchronized id: ' . $request->last_synchronise_id . ' and ', ['data' => $updateArray]);
                }
                $statusArray = [self::STATUS => true, self::MESSAGE => "Information updated", 'last_synchronise_id' => $request->last_synchronise_id];
                $this->allBusinessOrder($request->business_id);
                return $statusArray;

            }
        } else { // Insert and delete
            if (!$data) {
                AutoCheckout::where(self::USER_ID, $request->user_id)->delete();
                $orderPlacement = AutoOrderPlacement::where(self::USER_ID, $request->user_id);
                $orderPlacement->update(['operation_performed' => self::IS_DELETED]);
                $statusArray = [self::STATUS => false, self::MESSAGE => "Cart is empty"];
                $this->allBusinessOrder($request->business_id);
                return $statusArray;
            }
            $data = json_decode($request->product_array, true);
            AutoCheckout::where(self::USER_ID, $request->user_id)->delete();
            AutoOrderPlacement::where(self::USER_ID, $request->user_id)->update(['operation_performed' => self::IS_DELETED]);
            $ordePlace = new AutoOrderPlacement();
            $ordePlace->user_id = $request->user_id;
            $ordePlace->order_detail = $request->payment_parameters;
            $ordePlace->venue_id = $request->venue_id;
            $ordePlace->business_id = $request->business_id;
            $ordePlace->updated_at = Carbon::now('UTC');
            $ordePlace->operation_performed = self::DEFAULT;
            $ordePlace->save();
            $dataInsert = AutoCheckout::insert($data);

            $dataRecieve['date'] = Carbon::now();
            $dataRecieve['id'] = $ordePlace->id;
            if ($dataInsert) {
                $statusArray = [self::STATUS => true, self::MESSAGE => "Information added successfully. There are " . AutoCheckout::where(self::USER_ID, $request->user_id)->count() . " item in the cart", 'last_synchronise_id' => $ordePlace->id];
            } else {
                $statusArray = [self::STATUS => false, self::MESSAGE => "Error while adding information"];
            }
            $this->allBusinessOrder($request->business_id);
            return $statusArray;
        }
    }//--- End of autoCheckoutCart() ---//

    /**
     * @param Request $request
     * @return array
     * Save User data to Elastic Search
     */
    public
    function userDataES(Request $request)
    {
        try {
            $body = [self::USER_ID => $request->user_id, self::VENUE_ID => $request->venue_id, self::DEVICE_TOKEN => $request->device_token, self::DEVICE_TYPE => $request->device_type, self::DEBUG_MOD => $this->getAppEnvoirnment()];
            $http = new \GuzzleHttp\Client();
            $response = $http->post(config('contant.JAVA_URL') . 'registerUserES', [
                'headers' => array(),
                'json' => $body,
            ]);

            $d = json_decode($response->getBody());
            if ($d->status) {
                return [self::STATUS => true, self::MESSAGE => "User device added successfully"];
            } else {
                return [self::STATUS => false, self::MESSAGE => self::INVALID_INFO];
            }
        } catch (Exception $e) {
            return [self::STATUS => false, self::MESSAGE => "Email or password doesn't match any user to get access token."];
        }

    }//--- End of userDataES() ---//

    public
    function testTime()
    {
        echo Carbon::now('UTC');
    }

    /**
     * @param Request $request
     * @return array|\Psr\Http\Message\StreamInterface
     * @throws GuzzleException
     */
    public
    function user_badges(Request $request)
    {
        if ($request->has(self::USER_ID) && $request->user_id && $request->has(self::USER_ID) && $request->company_id) {
            try {
                $res = (new Client())->request('POST', config('constant.loyalty_api_path') . 'user/badges', [
                    'form_params' => [
                        self::USER_ID => $request->user_id,
                        self::COMPANY_ID => $request->company_id
                    ]
                ]);
                return $res->getBody();
            } catch (\Exception $e) {
                return [self::STATUS => false, self::MESSAGE => 'Server error'];
            }//..... end of try-catch() .....//
        } else {
            return [self::STATUS => false, self::MESSAGE => 'Requested Parameters are missing'];
        }
    }//..... end of user_badges() .....//

    /**
     * @param Request $request
     * @return \Psr\Http\Message\StreamInterface|string
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public
    function user_tier(Request $request)
    {
        $company_id = $request->company_id;
        if ($request->has(self::USER_ID) && $request->user_id != '' && $request->has(self::USER_ID) && $company_id != '') {
            $client = new Client();
            try {
                $res = $client->request('POST', config('constant.loyalty_api_path') . 'user/tier', [
                    'form_params' => [
                        self::USER_ID => $request->user_id,
                        self::COMPANY_ID => $company_id
                    ]
                ]);
                return $res->getBody();
            } catch (RequestException $e) {
                $arr[self::STATUS] = false;
                $arr[self::MESSAGE] = 'Server error';
                return json_encode($arr);
            }

        } else {
            $arr[self::STATUS] = false;

            $arr[self::MESSAGE] = 'Requested Parameaters are missing.';
            return json_encode($arr);
        }


    }//--- End of user_tier() ---//

    /**
     * @param Request $request
     * @return array
     */
    public
    function beaconTriggerData(Request $request)
    {
        try {
            $valiadtor = Validator::make($request->all(), [
                self::MAKE_PAYMENT => self::REQUIRED,
                self::PAYMENT_TYPE => self::REQUIRED,
                self::USER_ID => self::REQUIRED,
            ]);
            if ($valiadtor->fails()) {
                $errors = $valiadtor->errors();
                $mess[self::STATUS] = false;
                foreach ($errors->get(self::MAKE_PAYMENT) as $message) {
                    $mess[self::MESSAGE] = 'make_payment is missing';
                    return $mess;
                }
                foreach ($errors->get(self::USER_ID) as $message) {
                    $mess[self::MESSAGE] = self::USER_ID_MISSING;
                    return $mess;
                }
                foreach ($errors->get(self::PAYMENT_TYPE) as $message) {
                    $mess[self::MESSAGE] = 'payment_type is missing';
                    return $mess;
                }

            }
            $body = [self::USER_ID => $request->user_id, self::MAKE_PAYMENT => $request->make_payment, 'time' => date('h:i:s'), self::PAYMENT_TYPE => $request->payment_type];
            $http = new \GuzzleHttp\Client();
            $response = $http->post(config('contant.JAVA_URL') . 'make_auto_payment', [
                'headers' => array(),
                'json' => $body,
            ]);

            $d = json_decode($response->getBody());
            if ($d->status) {
                return [self::STATUS => true, self::MESSAGE => $d->message];
            } else {
                return [self::STATUS => false, self::MESSAGE => $d->message];
            }
        } catch (Exception $e) {
            return [self::STATUS => false, self::MESSAGE => self::ERROR . $e->getMessage()];
        }

    }//--- End of beaconTriggerData() ---//

    /**
     * @param Request $request
     * @return array
     * @throws GuzzleException
     */
    public
    function userActivityVouchers(Request $request)
    {

        if (config('constant.APP_NAME') == 'engage-gawler') {
            return $this->userActivityVouchersGawler($request);
        }
        if (\request()->has('filter') and \request()->filter) {
            return $this->filterActivityListing();
        }

        $user = User::where(self::USER_ID, $request->user_id)->first();

        $start_date = $request->start_date ?? "";
        $end_date = $request->end_date ?? "";
        $start_date = $start_date ? gmdate(self::YMD, $start_date) : "";
        $end_date = $end_date ? gmdate(self::YMD, $end_date) : "";

        try {
            $user = $request->user();
            if (!$user) {
                return ['status' => false, 'message' => 'User Not authenticated'];
            }

            $vouchers = VoucherLog::where('user_id', $user->user_id)->get();
            $new_array = [];
            /**
             *  Filtering Voucher data on redemption, campaign deletion
             *  and Punchcard deletion status
             */
            foreach ($vouchers as $voucher) {
                $voucherData = Voucher::where('id', $voucher['voucher_id'])->first();
                if ($voucherData) {
                    $voucher['date'] = date('l, j F, Y h:i a', strtotime($voucher['created_at']));
                    $voucher[self::SORT_DATE] = strtotime($voucher['created_at']);
                    $new_array[] = ['date' => date('l, j F, Y h:i a', strtotime($voucher['created_at'])),
                        self::SORT_DATE => strtotime($voucher['created_at']),
                        'type' => 'voucher',
                        "voucher_avial_data" => [],
                        "promotion_text" => $voucherData->promotion_text ?? '',
                        'voucher_name' => $voucherData->name ?? '',
                        "attachment_url" => url("/") . '/' . $voucherData->image ?? '',
                    ];
                }
            }

            /**
             *  Getting User Transaction data from SOLDI POS
             */
            $req = new \Illuminate\Http\Request();
            $req->replace([self::BUSINESS_ID => $request->business_id, self::CUSTOMER_ID => $user->soldi_id, self::COMPANY_ID => $user->company_id, 'amplify_id' => $user->amplify_id, 'page' => $request->page, 'start_date' => $request->start_date, 'end_date' => $request->end_date]);
            $data = (new StoresApiController())->customer_orders($req);

            if (isset($data['data'])) {
                $data['data'] = json_encode($data['data']);
                $data['data'] = json_decode($data['data'], true);
                foreach ($data['data'] as $transaction) {
                    $transaction['date'] = $transaction['ord_date'];
                    $transaction[self::SORT_DATE] = strtotime(str_replace(',', '', $transaction['ord_date']));
                    $transaction['type'] = 'transaction';
                    $new_array[] = $transaction;
                }
            }
            return [self::STATUS => true, self::MESSAGE => self::DATA_FOUND, 'data' => array_values(collect($new_array)->sortByDesc(self::SORT_DATE)->toArray()) ?? []];
        } catch (Exception $e) {
            return [self::STATUS => false, self::MESSAGE => self::ERROR . $e->getMessage()];
        }
    }


    public
    function userActivityVouchersGawler($request)
    {

        try {
            $user = $request->user();

            $vouchers_arr = [];
            $curr_time = date('Y-m-d');
            $vouchers = VoucherUser::with('voucher')->where('user_id', $user->user_id)->whereDate('voucher_start_date', '<=', $curr_time)->whereDate('voucher_end_date', '>=', $curr_time)->orderBy('created_at', 'DESC')->get();
            foreach ($vouchers as $voucher) {
                $camp = Campaign::find($voucher->campaign_id);
                if ($camp) {
                    $temp = [];
                    $temp['voucher_name'] = $voucher->voucher->name;
                    $temp['promotion_text'] = $voucher->voucher->promotion_text;
                    $temp['voucher_type'] = $voucher->voucher->discount_type;
                    $temp['voucher_amount'] = $voucher->voucher->amount;
                    $temp['voucher_avial_data'] = json_decode($voucher->voucher->voucher_avial_data);
                    $temp['attachment_url'] = url("/") . '/' . $voucher->voucher->image ?? '';
                    $temp['voucher_code'] = $voucher->voucher_code;

                    $temp['date'] = strtotime($voucher['created_at']);
                    $temp['dateadded'] = strtotime($voucher['created_at']);
                    $temp['voucher_start_date'] = $voucher['voucher_start_date'];
                    $temp['voucher_end_date'] = $voucher['voucher_end_date'];
                    $temp['type'] = 'voucher';
                    //$voucher['voucher_code'] = $voucher['pos_ibs'].$voucher['voucher_code'];
                    $temp['voucher_e_date'] = strtotime($voucher['voucher_end_date']);


                    // Log::channel(self::CUSTOM)->info('voucher_type', ['voucher_type' => $voucher_type]);

                    if ($voucher->voucher->discount_type == 'Free') {
                        $temp['voucher_amount'] = 100;
                    }

                    //Log::channel(self::CUSTOM)->info('temp', ['temp' => $voucher_type]);
                    if ($request->has('business_id') and $request->business_id) {
                        $vc = Voucher::where('id', $voucher->voucher_id)->first();
                        $business = json_decode($vc->business);
                        if ($request->business_id == $business->business_id) {
                            $vouchers_arr[] = $temp;
                        }
                    } else {
                        $vouchers_arr[] = $temp;
                    }
                }
            }


            //get customer orders
            $orders_arr = [];
            if (!empty($user->soldi_id)) {

                $req = new \Illuminate\Http\Request();
                $req->replace(['business_id' => $request->business_id, 'customer_id' => $user->soldi_id, 'company_id' => $user->company_id, 'amplify_id' => $user->amplify_id, 'page' => $request->page, 'start_date' => $request->start_date, 'end_date' => $request->end_date]);
                $data = (new StoresApiController())->customer_orders($req);


                if (isset($data['data'])) {
                    $data['data'] = json_encode($data['data']);
                    $data['data'] = json_decode($data['data'], true);
                    foreach ($data['data'] as $transaction) {
                        $transaction['date'] = str_replace(',', '', $transaction['ord_date']);
                        $transaction['type'] = 'transaction';
                        $transaction['card_type'] = isset($transaction['card_name']) ? $transaction['card_name'] : "";
                        $orders_arr[] = $transaction;
                    }
                }
            }

            //get stamps
            $punch_arr = [];
            $punch_cards = PunchCard::all()->sortByDesc('created_at');
            foreach ($punch_cards as $punch_card) {
                $temp = [];
                $user_punch = UserStamp::where('user_id', $user->user_id ?? $user['user_id'])->first();
                if ($user_punch) {
                    $res = (new RecipeController())->getUserStamps($punch_card->id);
                    $temp['quantity'] = $res[0]['quantity'];
                    $temp['punch_card_rule']['name'] = $punch_card->name;
                    $temp['punch_card_rule']['description'] = $punch_card->description;
                    $temp['punch_card_rule']['image'] = url('/') . '/' . $punch_card->image;
                    $temp['punch_card_rule']['no_of_use'] = $punch_card->no_of_use;
                } else {
                    $temp['quantity'] = 0;
                    $temp['punch_card_rule']['name'] = $punch_card->name;
                    $temp['punch_card_rule']['description'] = $punch_card->description;
                    $temp['punch_card_rule']['image'] = url('/') . '/' . $punch_card->image;
                    $temp['punch_card_rule']['no_of_use'] = $punch_card->no_of_use;
                }
                //business id filter
                if ($request->has('business_id') and $request->business_id) {
                    if ($request->business_id == $punch_card->business_id) {
                        $punch_arr[] = $temp;
                    }
                } else {
                    $punch_arr[] = $temp;
                }
            }

            return ['status' => true, 'message' => 'Data Found', 'vouchers_array' => $vouchers_arr, 'purchases_array' => $orders_arr, 'stamp_cards' => $punch_arr];
        } catch (\Exception $e) {
            Log::channel(self::CUSTOM)->error('userActivityVouchersGawler_error', ['userActivityVouchersGawler_error' => $e->getMessage(), 'linenumber' => $e->getLine()]);
            return ['status' => true, 'message' => $e->getMessage(), 'vouchers_array' => [], 'purchases_array' => [], 'stamp_cards' => []];
        }

    }


    public
    function userLogout(Request $request)
    {
        if (!$request->device_id) {
            return [self::STATUS => false, self::MESSAGE => "Please provide device id"];
        }
        if ($request->user()) {
            Log::channel(self::CUSTOM)->info('userLogout() print device id : ', ['print device id' => $request->device_id]);
            $company_id = (new ElasticSearchController())->companyIdFromHeader(request()->header(self::COUNTRY));
//            $company_id = request()->header(self::COUNTRY) == 'uk' ? config('constant.COMPANY_ID') : config('constant.COMPANY_IRE_ID');

            $query = [
                'bool' => [
                    'must' => [
                        [self::MATCH => ['device_name' => $request->device_id]],
                        [self::MATCH => [self::CUSTOM_DOC_TYPE => config('constant.persona_devices')]],
                        [self::MATCH => [self::PERSONA_ID => $request->user()->user_id]],
                        [self::MATCH => [self::COMPANY_ID => $company_id]]


                    ]
                ]
            ];
            ElasticsearchUtility::deleteByQuery(config('constant.ES_INDEX_BASENAME'), '', '', $query);
            $request->user()->token()->revoke();
            return [self::STATUS => true, self::MESSAGE => 'successfully logout'];
        } else {
            return [self::STATUS => false, self::MESSAGE => 'Please provide user identity'];
        }
    }

    /**
     * @param $business_id
     * @return array|bool
     * @throws GuzzleException
     * Notify Soldi POS about auto checkout cart.
     */
    private
    function allBusinessOrder($business_id)
    {
        try {
            $store = Store::where("pos_store_id", $business_id)->first();
            (new Client())->request('get', config('constant.SOLDI_DEFAULT_PATH') . '/notification/allbusinessorders?business_id=' . $business_id, [
                'headers' => [
                    'X-API-KEY' => $store->soldi_api_key ?? null,
                    'SECRET' => $store->soldi_secret ?? null
                ]
            ]);

            return true;
        } catch (\Exception $e) {
            return [self::STATUS => true, self::MESSAGE => $e->getMessage()];
        }//..... end of try-catch() .....//
    }//.....end of allBusinessOrder() .....//


    /**
     * @param $user_id
     * @return array|void
     */
    private
    function registerToJava($user_id)
    {
        try {
            $body = [self::USER_ID => $user_id];

            $http = new \GuzzleHttp\Client();
            $http->post(config('contant.JAVA_URL') . 'registerUserElasticSearchVenues', [
                'headers' => array(),
                'json' => $body,
            ]);
            return;
        } catch (Exception $e) {
            return [self::STATUS => false, self::MESSAGE => self::ERROR . $e->getMessage()];
        }
    }//--- End of registerToJava() ---//

    /**
     * @param Request $request
     * @return array
     */
    public
    function listPunchCard(Request $request)
    {
        try {
            $valiadtor = Validator::make($request->all(), [
                self::VENUE_ID => self::REQUIRED,
                self::USER_ID => self::REQUIRED,
                self::COMPANY_ID => self::REQUIRED
            ]);

            if ($valiadtor->fails()) {
                $errors = $valiadtor->errors();
                $mess[self::STATUS] = false;
                foreach ($errors->get(self::VENUE_ID) as $message) {
                    $mess[self::MESSAGE] = 'venue information is missing';
                    return $mess;
                }
                foreach ($errors->get(self::USER_ID) as $message) {
                    $mess[self::MESSAGE] = 'user information is missing';
                    return $mess;
                }
                foreach ($errors->get(self::COMPANY_ID) as $message) {
                    $mess[self::MESSAGE] = 'company information  is missing';
                    return $mess;
                }
            }//.... end if() .....//

            $dataArray = [self::USER_ID => $request->user_id, self::VENUE_ID => $request->venue_id, self::COMPANY_ID => $request->company_id];

            if ($request->has(self::BUSINESS_ID)) {
                $dataArray = [self::USER_ID => $request->user_id, self::VENUE_ID => $request->venue_id, self::COMPANY_ID => $request->company_id, self::BUSINESS_ID => $request->business_id];
            }

            $response = (new Client())->post(config('constant.JAVA_URL') . 'punchCardListing', [
                'headers' => array(),
                'json' => $dataArray,
            ]);

            $dd = json_decode($response->getBody());

            if ($dd->status) {
                return [self::STATUS => true, self::MESSAGE => "Successfully get punch card", "body" => $dd->body ?? []];
            } else {
                return [self::STATUS => false, self::MESSAGE => self::INVALID_INFO, 'body' => []];
            }
        } catch (\Exception $e) {
            return [self::STATUS => true, self::MESSAGE => $e->getMessage()];
        }//.... end of try-catch() .....//
    }//--- End of listPunchCard() ---//

    /**
     * @param Request $request
     * @return array
     */
    function updateUserAddress(Request $request)
    {
        $this->insertUserAddresses(json_decode($request->address, true));
        return [self::STATUS => true, self::MESSAGE => "User info updated successfully", 'data' => json_decode($this->getUserAddresses((\request()->has('user_id')) ? \request()->user_id : $request->user()->user_id, 'api'), true)];
    }


    public
    function check_env()
    {

        echo '<pre>';
        $data = file_get_contents(base_path('/.env'));
        print_r($data);
        echo "=================================================================";
        echo "SOLDI_DEFAULT_PATH        =" . config('constant.SOLDI_DEFAULT_PATH') . "<br>";
        echo "LOYALTY_DEFAULT_PATH      =" . config('constant.LOYALTY_DEFAULT_PATH') . "<br>";
        echo "JAVA_URL                  =" . config('contant.JAVA_URL') . "<br>";
        echo "LOYALTY                   =" . config('constant.LOYALTY') . "<br>";
        echo "SOLDI_API_KEY             =" . config('constant.SOLDI_API_KEY') . "<br>";
        echo "SOLDI_SECRET              =" . config('constant.SOLDI_SECRET') . "<br>";
        echo "CLIENT_ID                 =" . config('constant.CLIENT_ID') . "<br>";
        echo "CLIENT_SECRET             =" . config('constant.CLIENT_SECRET') . "<br>";
        echo "JAVA_ACTIVEMQ_URL         =" . config('constant.JAVA_ACTIVEMQ_URL') . "<br>";
        echo "JAVA_CAMPAIGN_TEST_URL    =" . config('constant.JAVA_CAMPAIGN_TEST_URL') . "<br>";
        echo "ES_URL                    =" . config('constant. ES_URL') . "<br>";
        echo "SOLDI_IRE_APIKEY          =" . config('constant.SOLDI_IRE_API_KEY') . "<br>";
        echo "SOLDI_IRE_SECRET          =" . config('constant.SOLDI_IRE_SECRET') . "<br>";
        echo "Knox_X_API_KEY            =" . config('constant.Knox_X_API_KEY') . "<br>";
        echo "Knox_Secret               =" . config('constant.Knox_Secret') . "<br>";
        echo "ES_INDEX_BASENAME               =" . config('constant.ES_INDEX_BASENAME') . "<br>";
        echo "Access_key               =" . config('constant.ACCESS_KEY') . "<br>";
    }


    /**
     * @param $user
     * @param $index
     * @param string $token
     * @return mixed
     * Update user token
     */
    private
    function updateUserTokenInEs($user, $index, $token = '')
    {
        (new ElasticSearchController())->registerUserDevice($index, [
            self::DEBUG_MOD => $user->debug_mod ?? "",
            'persona_device_token' => $user->device_token ?? "",
            'persona_device_type' => $user->device_type ?? "",
            self::CUSTOM_DOC_TYPE => config('constant.persona_devices'),
            self::PERSONA_ID => $user->user_id,
            'id' => $user->user_id . "_" . config('constant.persona_devices')
        ]);

        return true;
    }//..... end of updateUserToken() .....//

    /**
     * @param int $user_id
     * @return string
     */

    public
    function getReferralCode($user_id = 0)
    {
        $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $res = "";
        if (strlen($user_id) > 6) {
            for ($i = 0; $i < 4; $i++) {
                $res .= $chars[mt_rand(0, strlen($chars) - 1)];
            }
            $user_id = $res;
            $res = '';
        }

        for ($i = 0; $i < 6 - strlen($user_id); $i++) {
            $res .= $chars[mt_rand(0, strlen($chars) - 1)];
        }

        $code = str_split($res, 3);
        $first = $code[0] ?? '';
        $second = $code[1] ?? '';
        return $first . $user_id . $second;
    }//---- end of function getReferralCode() ----//

    /**
     * @param Request $request
     * @return array
     * @throws DriverNotConfiguredException
     */
    public
    function refferalFriend(Request $request)
    {
        try {
            $valiadtor = Validator::make($request->all(), [
                self::REF_CODE => self::REQUIRED
            ]);

            if ($valiadtor->fails()) {
                $errors = $valiadtor->errors();
                $mess[self::STATUS] = false;
                foreach ($errors->get(self::REF_CODE) as $message) {
                    $mess[self::MESSAGE] = 'Reffer code is missing';
                    return $mess;
                }
            }//.... end if() .....//
            /*if()*/
            $user = request()->user();
            $refferee = User::where(self::REF_CODE, $request->referral_code)->first();

            if ($refferee && $user->referral_code != $request->referral_code && empty($user->referal_by)) {
                if ($user->referal_by == $request->referral_code) {
                    return [self::STATUS => false, self::MESSAGE => "You've already used the code."];
                }

                $user->referal_by = $request->referral_code;
                $user->updated_at = Carbon::now();
                $user->save();
                $refferee->referalType = 'refree';
                $refferee->referdEmail = $user->email;
                $refferee->referdId = $user->client_customer_id;
                $refferee->regionType = $refferee->region_type;
                $refferee->region_type = $refferee->region_type;
                $refferee->referenceId = $user->user_id;
                $user->referalType = 'refered';
                $user->referByEmail = $refferee->email;
                $user->referByID = $refferee->client_customer_id;
                $user->regionType = $user->region_type;
                $user->region_type = $user->region_type;
                (new GamificationController())->userRefferalAssignReward($refferee);
                (new GamificationController())->userRefferalAssignReward($user);


                //call event trigger
                $data = [
                    'user_id' => [$user->user_id],
                    'referred_by' => [
                        'user_id' => $refferee->user_id,
                        'email' => $refferee->email
                    ],
                    'trigger_type' => 'referral',
                ];
                $trigger_type = "$.referral_trigger";
                (new VCTrigger())->callVCTrigger($data, $trigger_type);


                return [self::STATUS => true, self::MESSAGE => 'user data updated succesfully'];
            }

            return [self::STATUS => false, self::MESSAGE => ($user->referral_code == $request->referral_code) ? "You can't refer yourself" : ((!empty($user->referal_by)) ? 'You already been referred by other user' : 'Referral code is not valid')];

        } catch (\Exception $e) {
            return [self::STATUS => false, self::MESSAGE => 'Error Occurred while saving data'];

        }

    }//--- End of refferalFriend() ----//

    /**
     * @param $user_email
     * @param $user_name
     * @param $email_subject
     * @param $email_from
     * @param $link
     * @param $view_name
     *  Send Email to user for Referral Friend
     */
    public
    function sendRefferalEmail($request, $type = self::REFERRAL, $user)
    {
        $text = '';
        $html = '';
        if ($type == self::REFERRAL) {
            $request[self::FIRST_NAME] = $user->user_first_name;
            $request['refferee_name'] = $user->user_first_name . ' ' . $user->user_family_name;
            $html = EmailTemplate::select('html')->where(self::TITLE, 'ReferralFriend')->first();
            $vars = ['|ReferredUser|' => $request['reffered_name'], '|RefreeName|' => $user->user_first_name . ' ' . $user->user_family_name, '|FirstName|' => $user->user_first_name, '|ReferralCode|' => $request[self::REF_CODE], '$imageUrl' => URL::to('/uploads/logo.png')];
            $html = strtr($html->html, $vars);
            $request['text'] = $html;
        } else if ($type == 'welcome') {

        } else {
            if (\request()->header('Country') == 'uk') {
                $user_email = \config('constant.EMAIL_FEEDBACK');
            } else {
                $user_email = \config('constant.EMAIL_FEEDBACK_IRELAND');
            }

            $email_subject = 'Enquiry from '
                . $user->user_first_name . ' ' . $user->user_family_name
                . ' about ' . $request['type'];

            $request = $request->toArray();

            $text = 'Email: ' . $user->email . "\n" .
                'Mobile: ' . $user->user_mobile . "\n" .
                "Message:\n\n" . $request['notes'] . "\n";

            $html = '<p>Email: ' . $user->email . '</p>' .
                '<p>Mobile: ' . $user->user_mobile . '</p>' .
                '<p>Message:<br /><br />' . $request['notes'] . '</p>';
        }

        return $this->sendEmailToVerification($user_email, $email_subject, $html);
    }//..... end of sendRefferalEmail() .....//

    /**
     * @param string $phoneNumber
     * @param string $code
     * @param string $name
     * @return bool
     * @throws \Matthewbdaly\SMS\Exceptions\DriverNotConfiguredException
     */
    public
    function sendReferalSms($request, $user)
    {
        try {
            $phoneNumber = substr_replace($request['reffered_phone'], '+', 0, 2);
            $name = $user->user_first_name . ' ' . $user->user_family_name;
            $guzzle = new GuzzleClient();
            $resp = new Response();
            $driver = new Twilio($guzzle, $resp, [
                self::ACCOUNT_ID => Config::get('constant.TWILIOID'),
                self::API_TOKEN => Config::get('constant.TWILIOAPI'),
            ]);

            $client = new awsClient($driver);
            $msg = [
                'to' => $phoneNumber,
                'from' => Config::get('constant.TWILLIONUMBER'),
                self::CONTENT => $name . ' wants you to check out this App that supports local Community Groups when you shop.Use ' . $request[self::REF_CODE] . '  at sign up. localbyispt.com.au/shoppers',
            ];

            return $client->send($msg);
        } catch (\Exception $e) {
            return $e->getMessage();
        }


    }

    /**
     * @param $referal_code
     * @param $userID
     * @param $company_id
     * @throws GuzzleException
     */
    public
    function userReferedFriendSingup($referal_code, $userID, $company_id)
    {

        $user = User::where(self::REF_CODE, $referal_code)->first();

        Log::channel(self::CUSTOM)->info('userReferedFriendSingup() : ', ['data' => $referal_code]);
        if ($user) {
            User::whereUserId($userID)->update(['referal_by' => $referal_code]);
            $this->addReferralUserCoins($user, $company_id);
            $this->addReferredUserCoins($userID, $company_id);
            $response = $this->sendReferralVouchers([(string)$user[self::USER_ID]]);
            Log::channel(self::CUSTOM)->info('userReferedFriendSingup() Response from JAVA : ', ['data' => $response]);


            return $response;
        }
    }//---- End of userReferedFriendSingup() ----//

    /**
     * @param string $device_token
     * @return mixed
     */
    public
    function sendPushNotificationIos($device_token, $coins = 5, $msg)
    {
        $app_setting = AppSetting::where(self::COMPANY_ID, config('constant.COMPANY_ID')->where('key', 'refer_friend_title'))->first();
        Log::channel(self::CUSTOM)->info('sendPushNotificationIos() Push ios : ', ['data' => $msg, self::DEVICE_TOKEN => $device_token, self::COINS => $coins]);
        $push = new \Edujugon\PushNotification\PushNotification('apn');
        $data = $push->setMessage([
            'aps' => [
                'alert' => [
                    self::TITLE => $app_setting != null ? $app_setting->value : 'Refer Friend',
                    'body' => $msg . self::EARNED . $coins . self::ADDED_COINS
                ],
                'sound' => self::DEFAULT,
                'badge' => 1
            ]
        ])->setDevicesToken([(string)$device_token])
            ->send()
            ->getFeedback();
        Log::channel(self::CUSTOM)->info('sendPushNotificationIos() Logs  : ', ['data' => $data]);
        return $data;

    }//---- End of sendPushNotificationIos() ----//

    /**
     * @param string $deviceToken
     * @return mixed
     */
    private
    function sendPushNotificationAndroid($deviceToken = '', $coins = 5, $msg = '')
    {
        Log::channel(self::CUSTOM)->info('sendPushNotificationAndroid() Push Android : ', ['data' => $msg, self::DEVICE_TOKEN => $deviceToken, self::COINS => $coins]);
        $push = new \Edujugon\PushNotification\PushNotification();
        $data = $push->setMessage([
            'notification' => [
                self::TITLE => 'Referral Friend',
                'sound' => self::DEFAULT
            ],
            'data' => [
                self::MESSAGE => $msg . self::EARNED . $coins . self::ADDED_COINS,
                self::CONTENT => [self::MESSAGE => $msg . self::EARNED . $coins . self::ADDED_COINS, 'notification_type' => 'referral_friend']
            ]


        ])->setDevicesToken([(string)$deviceToken])
            ->send()
            ->getFeedback();
        Log::channel(self::CUSTOM)->info('sendPushNotificationAndroid()   : ', ['data' => $data]);
        return $data;
    }//---- End of sendPushNotificationAndroid() ----//

    /**
     * @param Request $request
     */
    public
    function sendTestPush(Request $request)
    {
        if ($request->device_type == 'ios') {
            dd($this->sendPushNotificationIos($request->device_token, '', ''));
        } else {
            dd($this->sendPushNotificationAndroid($request->device_token, '', ''));
        }
    }

    private
    function addReferredUserCoins($userId, $companyID)
    {

        $user = User::where(self::USER_ID, $userId)->first();
        $data = Setting::where(['field1' => $user[self::DEFAULT_VENUE], 'type' => self::REFERRAL])->first();
        if ($data) {
            $count = json_decode($data['remarks']);
            $count = $count->referral_points;
            if ($user[self::DEVICE_TYPE] == 'ios') {
                $this->sendPushNotificationIos($user[self::DEVICE_TOKEN], $count, self::WELCOME . ucfirst($this->app_name));
            } else {
                $this->sendPushNotificationAndroid($user[self::DEVICE_TOKEN], $count, self::WELCOME . ucfirst($this->app_name));
            }

            $count = 10;
            if ($user[self::DEVICE_TYPE] == 'ios') {
                $response = $this->sendPushNotificationIos($user[self::DEVICE_TOKEN], $count, self::WELCOME . ucfirst($this->app_name));
            } else {
                $response = $this->sendPushNotificationAndroid($user[self::DEVICE_TOKEN], $count, self::WELCOME . ucfirst($this->app_name));
            }

            Log::channel('user')->info('Push Notification Referred Friend : ', ['data' => $response]);
            for ($i = 0; $i < $count; $i++) {
                UserCharityCoins::create([self::USER_ID => $userId, self::COINS => 1, self::COMPANY_ID => $companyID, self::VENUE_ID => $user[self::DEFAULT_VENUE] ?? '']);

            }


            return $response;
        }//---- End of addUserCoins() ----//
    }

    /**
     * @param $user
     * @param $companyID
     * @throws GuzzleException
     */
    private
    function addReferralUserCoins($user, $companyID)
    {

        $count = 10;
        if ($user[self::DEVICE_TYPE] == 'ios') {
            $response = $this->sendPushNotificationIos($user[self::DEVICE_TOKEN], $count, config('constant.REFER_FRIEND_BODY'));
        } else {
            $response = $this->sendPushNotificationAndroid($user[self::DEVICE_TOKEN], $count, config('constant.REFER_FRIEND_BODY'));
        }

        Log::channel('user')->info('Push Notification Referral Friend : ', ['data' => $response]);
        for ($i = 0; $i < $count; $i++) {
            UserCharityCoins::create([self::USER_ID => $user[self::USER_ID], self::COINS => 1, self::COMPANY_ID => $companyID, self::VENUE_ID => $user[self::DEFAULT_VENUE] ?? '']);


        }

        return $response;
    }//--- End of addReferralUserCoins() ----//

    /**
     * @param Request $request
     * @return array|\Psr\Http\Message\StreamInterface
     * @throws GuzzleException
     */
    public
    function punchCardStamp(Request $request)
    {

        try {

            Log::channel(self::CUSTOM)->info('punchCardStamp() Request for Assign Punch Card', ['PunchCardRequest' => $request->all()]);
            $response = (new Client(['headers' => []]))
                ->request('POST', config('constant.JAVA_URL') . 'assignPunchCardStamp', [
                    'json' => $request->all()
                ])->getBody();
            Log::channel(self::CUSTOM)->info(self::LOG_PUNCH, [self::LOG_PUNCH => $response]);
            return $response;
        } catch (Exception $e) {
            Log::channel(self::CUSTOM)->error(self::LOG_PUNCH, [self::LOG_PUNCH => $e->getMessage()]);
            return [self::STATUS => false, self::MESSAGE => self::ERROR . $e->getMessage()];
        }
    }

    /**
     * @param array $data
     * @return array|\Psr\Http\Message\StreamInterface
     * @throws GuzzleException
     */
    private
    function sendReferralVouchers($data = [])
    {
        try {
            return (new Client(['headers' => []]))
                ->request('POST', config('contant.JAVA_URL') . 'assignReferral', [
                    'json' => ['users_ids' => $data]
                ])->getBody();
        } catch (Exception $e) {
            return [self::STATUS => false, self::MESSAGE => self::ERROR . $e->getMessage()];
        }
    }//---- End of sendReferralVouchers() ----//

    /**
     * @param $default_venue
     * @param $referal_code
     * @return array
     */
    private
    function checkValidReferralCode($default_venue, $referal_code)
    {
        if (!$referal_code) {
            return [self::STATUS => false];
        }

        $user = User::where(self::REF_CODE, $referal_code)->first();
        if (!$user) {
            return [self::STATUS => false];
        }

        $tokens = Setting::where('field1', $default_venue)->first();
        if ($tokens) {
            $tokens = json_decode($tokens['remarks']);
            return [self::STATUS => true, self::MESSAGE => 'You have earned yourself ' . $tokens->referred_points . ' Tokens to donate to a charity of your choice'];
        }
    }//--- End of checkValidReferralCode() ---//

    /**
     * @param Request $request
     * @return array
     */
    public
    function userFeedBack(Request $request)
    {

        if (empty($request->all())) {
            parse_str(file_get_contents("php://input"), $data);
// Cast it to an object
            $data = (object)$data;
            if (!empty($data)) {
                $request->request->add([self::VENUE_ID => $data->venue_id, self::NOTES => $data->notes, 'type' => $data->type]);
            }
        }

        $user = request()->user();
        Log::channel(self::CUSTOM)->info('userFeedBack()', ['userFeedBack()' => $request->all()]);
        $this->sendRefferalEmail($request, $type = 'feedback', $user);
        FeedBack::create([
            self::VENUE_ID => $request->venue_id ?? '',
            self::NOTES => $request->notes ?? '',
            self::USER_ID => $user->user_id ?? '',
            'type' => $request->type ?? '',

            'resturant' => $request->resturant ?? '',
            'ratings' => $request->resturant ?? 0,

        ]);
        return [self::STATUS => true, self::MESSAGE => "Thanks for reaching out to us, we love feedback! Don't worry you'll hear from us soon."];
    }

    /**
     * @param $charity_id
     * @return mixed
     */
    private
    function getCharityName($charity_id)
    {
        $charityName = Charity::whereId($charity_id)->get(['charity_name']);
        return ($charityName->isNotEmpty()) ? $charityName[0]->charity_name : '';
    }

    /**
     * @param Request $request
     * @return array
     */
    public
    function updateMenuFilters(Request $request)
    {
        $user = $request->user();

        $filterMenues = json_decode($user->menue_filters);
        $filterMenues->Gluten_Free = $request->gluten_free ?? $filterMenues->Gluten_Free;
        $filterMenues->Lactose_Free = $request->lactose_free ?? $filterMenues->Lactose_Free;
        $filterMenues->Soya_Free = $request->soya_free ?? $filterMenues->Soya_Free;
        $filterMenues->Egg_Free = $request->egg_free ?? $filterMenues->Egg_Free;

        $user->menue_filters = json_encode($filterMenues);
        $user->save();

        return [self::STATUS => true, self::MESSAGE => 'Filters updated successfully', 'data' => $user->only(["menue_filters"])];
    }//---- End of updateMenuFilters() ----//

//
    private
    function getVenueName($venue_id, $details = false)
    {
        if ($venue_id == 0 || $venue_id == "") {
            return "";
        }
        $venue = Venue::whereVenueId($venue_id)->first();
        return $venue ? ((!$details) ? $venue->venue_name : $venue) : "";
    }

    /**
     * @param $user_id
     * @return array|void
     */
    public
    function beaconProximity(Request $request)
    {
        try {
            Log::channel('proximity')->info('Proximity Input : ', ['data' => $request->all()]);
            $data = ['beacons_data' => json_decode($request->beacons_data, true), self::COMPANY_ID => $request->company_id, self::USER_ID => $request->user_id];
            Log::channel('proximity')->info('Forwarding data to java : ', $data);
            $http = new \GuzzleHttp\Client();
            $response = $http->post(config('constant.JAVA_ACTIVEMQ_URL'), [
                'headers' => ['campaign_type' => 'PROXIMITY_CAMPAIGN'],
                'json' => $data,
            ]);
            return $response->getBody()->getContents();
        } catch (Exception $e) {
            return [self::STATUS => false, self::MESSAGE => self::ERROR . $e->getMessage()];
        }
    }//--- End of beaconProximity() ---//

    public
    function tetCheck()
    {
        dd($this->getReferralCode(12));
    }

    /**
     * @param Request $request
     * @return array
     */


    public
    function updateNotifications(Request $request)
    {
        $user = $request->user();

        switch ($request->notification_type) {
            case 'app_notification':
                return $this->appNotifications($user, $request->all());
                break;
            case 'marketing_notification':
                return $this->marketingNotifications($user, $request->all());
                break;
            case 'rewards_notification':
                return $this->rewardNotifications($user, $request->all());
                break;
            default:
                return [self::STATUS => false, self::MESSAGE => 'Enter valid type for update'];
        }
    }//---- End of updateNotifications() ----//

    /**
     * @param $user
     * @param $request
     * @return array
     */
    private
    function appNotifications($user, $request)
    {
        $appNotifications = json_decode($user->wimpy_app_notification);
        $appNotifications->Sms = $request['sms'] ?? $appNotifications->Sms;
        $appNotifications->Email = $request[self::EMAIL] ?? $appNotifications->Email;
        $appNotifications->Push = $request['push'] ?? $appNotifications->Push;
        $user->wimpy_app_notification = json_encode($appNotifications);
        $user->save();

        $this->registerUserToElasticSearch($user);// Update data to elasticsearch ......
        return [self::STATUS => true, self::MESSAGE => 'App Notifications Updated Successfully', 'data' => $user->only(["wimpy_app_notification"])];
    }//----- End of appNotifications() ----//

    /**
     * @param $user
     * @param array $all
     * @return array
     */
    private
    function marketingNotifications($user, array $all)
    {
        $marketingNotifications = json_decode($user->wimpy_marketing_notification);
        $marketingNotifications->Sms = $all['sms'] ?? $marketingNotifications->Sms;
        $marketingNotifications->Email = $all[self::EMAIL] ?? $marketingNotifications->Email;
        $marketingNotifications->Push = $all['push'] ?? $marketingNotifications->Push;
        $user->wimpy_marketing_notification = json_encode($marketingNotifications);

        $user->save();

        try {
            $this->registerUserToElasticSearch($user);// Update data to elasticsearch ......
        } catch (Exception $e) {
            return [self::MESSAGE => $e->getMessage()];
        }
        return [self::STATUS => true, self::MESSAGE => 'Marketing Notifications Updated Successfully', 'data' => $user->only(["wimpy_marketing_notification"])];
    }//---- End of marketingNotifications() ----//

    /**
     * @param $user
     * @param array $all
     * @return array
     */
    private
    function rewardNotifications($user, array $all)
    {
        $rewardNotifications = json_decode($user->wimpy_rewards_notification);
        $rewardNotifications->Sms = $all['sms'] ?? $rewardNotifications->Sms;
        $rewardNotifications->Email = $all[self::EMAIL] ?? $rewardNotifications->Email;
        $rewardNotifications->Push = $all['push'] ?? $rewardNotifications->Push;
        $user->wimpy_rewards_notification = json_encode($rewardNotifications);

        $user->save();

        $this->registerUserToElasticSearch($user);// Update data to elasticsearch ......
        return [self::STATUS => true, self::MESSAGE => 'Reward Notifications Updated Successfully', 'data' => $user->only(["wimpy_rewards_notification"])];
    }//---- End of rewardNotifications() ----//

    /**
     * @param Request $request
     * @return array
     */
    public
    function dashBoardListing(Request $request)
    {
        try {
            $valiadtor = Validator::make($request->all(), [
                self::USER_ID => self::REQUIRED,
            ]);

            if ($valiadtor->fails()) {
                $errors = $valiadtor->errors();
                $mess[self::STATUS] = false;
                foreach ($errors->get(self::USER_ID) as $message) {
                    $mess[self::MESSAGE] = self::USER_ID_MISSING;
                    return $mess;
                }
            }
            $company_id = $request->company_id;
            $venue = Venue::where(self::COMPANY_ID, $company_id)->first();

            $body = [self::USER_ID => $request->user_id, self::VENUE_ID => $venue->venue_id ?? $venue[self::VENUE_ID], self::COMPANY_ID => $request->company_id, 'voucher_type' => 'integrated'];
            $http = new \GuzzleHttp\Client();
            $response = $http->post(config('contant.JAVA_URL') . 'userVoucherListing', [
                'headers' => array(),
                'json' => $body,
            ]);

            $dd = json_decode($response->getBody());
            if ($dd->status) {
                $listingNotifications = $dd->body;
            }
            $user = $request->user();

            $loyalty = $this->getLoyaltyPoints($user);

            $newsData = (new NewsApiController())->getNews($request);

            if ($dd->status) {
                return [self::STATUS => true, self::MESSAGE => self::DATA_FOUND, "vouchers_array" => $listingNotifications, 'loyalty' => $loyalty['data'] ?? (object)[], 'news' => $newsData['data'] ?? []];
            } else {
                return [self::STATUS => false, self::MESSAGE => self::INVALID_INFO];
            }
        } catch (Exception $e) {
            return [self::STATUS => false, self::MESSAGE => self::ERROR . $e->getMessage()];
        }
    }//---- End of dashBoardListing() ----//

    /**
     * @param Request $request
     * @return array
     */
    public
    function addUserFavourite(Request $request)
    {


        $valiadtor = Validator::make($request->all(), [
            self::FAV => self::REQUIRED,
            self::PRODUCT_ID => self::REQUIRED
        ]);

        if ($valiadtor->fails()) {
            $errors = $valiadtor->errors();
            $mess[self::STATUS] = false;
            foreach ($errors->get(self::FAV) as $message) {
                $mess[self::MESSAGE] = 'favourite is missing';
                return $mess;
            }
            foreach ($errors->get(self::PRODUCT_ID) as $message) {
                $mess[self::MESSAGE] = 'product_id is missing';
                return $mess;
            }

        }
        $dataNewArray = [];
        $user = $request->user();
        $dataArray = json_decode($user->user_favourites, true);
        if ($user->user_favourites && !empty($dataArray)) {

            if (!$this->find_key_value($dataArray, self::PRODUCT_ID, $request->product_id)) { // search value in the array
                array_push($dataArray, [self::PRODUCT_ID => $request->product_id, self::FAV => $request->favourite]);
            }

            if ($request->favourite == 'false') {
                $dataArray = $this->removeElementWithValue($dataArray, self::PRODUCT_ID, $request->product_id);
            }
            $newArray = [];
            foreach ($dataArray as $data) {
                array_push($newArray, $data);
            }

            $user->user_favourites = json_encode($newArray);
            $user->save();
            return [self::STATUS => true, self::MESSAGE => 'Favourites updated successfully', 'favourites' => json_decode($user->user_favourites, true)];
        } else {
            array_push($dataNewArray, [self::PRODUCT_ID => $request->product_id, self::FAV => $request->favourite]);
            $user->user_favourites = json_encode($dataNewArray);
            $user->save();
            return [self::STATUS => true, self::MESSAGE => 'Favourites updated successfully', 'favourites' => json_decode($user->user_favourites, true)];
        }
    }//---- End of addUserFavourite() ----//

    /**
     * @param $array
     * @param $key
     * @param $value
     * @return mixed
     */
    function removeElementWithValue($array, $key, $value)
    {
        foreach ($array as $subKey => $subArray) {
            if ($subArray[$key] == $value) {
                unset($array[$subKey]);
            }
        }
        return $array;
    }//---- End of removeElementWithValue() ----//

    /**
     * @param $array
     * @param $key
     * @param $val
     * @return bool
     */
    function find_key_value($array, $key, $val)
    {
        foreach ($array as $item) {
            if (is_array($item) && $this->find_key_value($item, $key, $val)) {
                return true;
            }

            if (isset($item[$key]) && $item[$key] == $val) {
                return true;
            }
        }

        return false;
    }//---- End of find_key_value

    public
    function getUserPunchAndStamp(Request $request)
    {
        $user = User::whereUserId($request->user_id)->first();
        switch ($request->type) {
            case 'voucher':
                return $this->getUserVouchers($user, $request->id, $request->venue_id);
                break;
            case 'cards':
                return $this->getUserPunchCard($user, $request->id, $request->venue_id);
                break;
            default:
                return [self::STATUS => false, self::MESSAGE => 'Please provide valid type'];
        }
    }//---- End of getUserPunchAndStamp() ----//

    /**
     * @param $user
     * @param $voucher_id
     * @param $venue_id
     * @return array
     */
    private
    function getUserVouchers($type, $startDate, $endDate)
    {
        $user = \request()->user();
        $voucher = VoucherUser::where('user_id', $user->user_id)->whereDate('created_at', '<=', $startDate)->whereDate('created_at', '>=', $endDate)->get(['voucher_id', 'user_id', 'created_at', 'assign_through']);
        foreach ($voucher as $value) {
            $points = Lt_Transaction::where(['user_id' => request()->user_id, 'point_id' => $value->voucher_id, 'source_value' => 'voucher'])->first();
            $voucherGet = Voucher::where('id', $value->voucher_id)->first();
            $value->amount = $voucherGet->amount;
            $value->description = $voucherGet->name;
            $value->discount_type = $voucherGet->discount_type;
            $value->image = $voucherGet->image;
            $value->display_type = $type;
            $value->points = $points->value_points ?? 0;
            $value->point_type = $points->type ?? '';
            $value->assign_through = ($value->assign_through) ? $value->assign_through : 'redeemed';
        }
        $voucher = $voucher->sortByDesc('sort_date');
        return $voucher->values()->all();

    }//---- End of getUserVouchers() ----//

    /**
     * @param $user
     * @param string $card_id
     * @param string $venue_id
     * @return array
     */
    private
    function getUserPunchCard($user, $card_id = '', $venue_id = '')
    {
        $stampId = $card_id . "_" . $user->user_id . "_" . config('constant.punch_card');
        $index = ElasticsearchUtility::generateIndexName($user->company_id, $venue_id);
        $stampCard = ElasticsearchUtility::stampCardDetail($index, (string)$stampId);
        if ($stampCard['hits']['hits'] > 0 && isset($stampCard['hits']['hits'][0][self::SOURCE])) {
            $stampCard['hits']['hits'][0][self::SOURCE][self::FIRST_NAME] = $user->user_first_name;
            $stampCard['hits']['hits'][0][self::SOURCE][self::USER_ID] = $user->user_id;
            $stampCard['hits']['hits'][0][self::SOURCE][self::LAST_NAME] = $user->user_family_name;
            $stampCard['hits']['hits'][0][self::SOURCE][self::USER_IMAGE] = $user->user_avatar;
            $stampCard['hits']['hits'][0][self::SOURCE][self::COMPANY_ID] = $user->company_id;

            return [self::STATUS => true, self::MESSAGE => 'Stamp Card data retrieve successfully', 'data' => $stampCard['hits']['hits'][0][self::SOURCE]];
        }
        $stampCard = [
            self::FIRST_NAME => $user->user_first_name,
            self::USER_ID => $user->user_id,
            self::LAST_NAME => $user->user_family_name,
            self::USER_IMAGE => $user->user_avatar,
            self::CUSTOM_DOC_TYPE => config('constant.punch_card'),
            self::PERSONA_ID => $user->user_id,
            "quantity" => 0,
            "punch_card_count" => 0,
            self::COMPANY_ID => $user->company_id
        ];
        $punchCards = PunchCard::whereId($card_id)->first();
        $punchCards[self::IMAGE] = url('/') . '/' . $punchCards[self::IMAGE];
        $punchCards['business_images'] = json_decode($punchCards['business_images']);
        $punchCards['businesses'] = json_decode($punchCards['businesses']);
        $stampCard['punch_card_rule'] = $punchCards;
        return [self::STATUS => true, self::MESSAGE => 'Stamp Card data retrieve successfully', 'data' => $stampCard];
    }//---- End of getUserPunchCard() ----//


    public
    function updateAllUserVenues()
    {
        $user = User::where([self::COMPANY_ID => config('constant.COMPANY_ID'), 'user_type' => 'app'])->get();
        foreach ($user as $users) {
            $users->save();
            $this->registerUserToElasticSearch($users);
        }
    }

    public
    function venueWiseCharityCoinsCount($start_date = "", $end_date = "")
    {
        $listDontatedCoins = UserCharityCoins::whereUserIdAndVenueId(request()->user_id, request()->venue_id)
            ->where(self::STATUS, "!=", "user")
            ->when($start_date, function ($query, $start_date) use ($end_date) {
                return $query->whereDate(self::UPDATED_AT, ">=", $start_date);
            })
            ->when($end_date, function ($query, $end_date) {
                return $query->whereDate(self::UPDATED_AT, "<=", $end_date);
            })
            ->groupBy("charity_id")
            ->groupBy(DB::raw('Date(updated_at)'))
            ->get(
                array(
                    "user_charity_coins.id as coin_ids", self::USER_ID, "store_id", self::COMPANY_ID, "charity_id", self::VENUE_ID, self::STATUS, self::CREATED_AT, self::UPDATED_AT,
                    DB::raw('COUNT(coins) as "coins"')
                )
            );
        foreach ($listDontatedCoins as $value) {
            $value->charity_name = $this->getCharityName($value->charity_id);
            $value->created_at = $value->updated_at;
        }
        return $listDontatedCoins;
    }


    public
    function exportRegisteredUsers()
    {
        $start_date = date("Y-m") . "-1";
        $end_date = date(self::YMD);
        $users = User::select(["users.created_at", "users.user_first_name", "users.user_family_name", "users.email", 'venues.venue_name'])
            ->leftJoin('venues', 'venues.venue_id', '=', 'users.default_venue')
            ->whereDate("users.created_at", ">=", $start_date)->whereDate("users.created_at", "<=", $end_date)
            ->orderBy("users.created_at", "ASC")
            ->get();
        return Excel::download(new UsersExport($users), 'registered_users_' . $start_date . "to" . $end_date . ".xlsx");

    }


    /**
     * @param Request $request
     * @return array
     */
    public
    function userSurveys(Request $request)
    {

        try {
            return (new Client(['headers' => []]))
                ->request('POST', config('constant.POS_URL') . 'getWimpyEmployee', [
                    'json' => ["identifier" => $request->identifier]
                ])->getBody();
        } catch (Exception $e) {
            return [self::STATUS => false, self::MESSAGE => self::ERROR . $e->getMessage()];
        }
    }//---- End of getWaitronDetail() ----//

    public
    function getSurveys()
    {
        try {
            $surveys = SurveyFront::with('questions', 'questions.answers')->get();
            return ['status' => true, 'message' => 'survey data retrieve successfully', 'data' => $surveys];
        } catch (\Exception $e) {
            return ['status' => false, 'message' => 'something went wrong', 'data' => []];
        }
    }

    /**
     * @param Request $request
     * @return array
     */
    public
    function surveyQuestions(Request $request)
    {
        try {
            if (!$request->survey_id)
                return ['status' => false, 'message' => 'Survey id is required', 'data' => []];
            $questions = SurveyQuestion::with('answers')->where('survey_id', $request->get('survey_id'))->get();
            return ['status' => true, 'message' => 'question data retrieve successfully', 'data' => $questions];
        } catch (\Exception $e) {
            return ['status' => false, 'message' => 'something went wrong', 'data' => []];
        }
    }

    /**
     * @param Request $request
     * @return array
     */
    public
    function answerQuestion(Request $request)
    {
        try {
            $request_data = $request->all();
            if (!isset($request_data['questions'])) {
                return ['status' => false, 'message' => 'questions array is required', 'data' => []];
            }
            if (!isset($request_data['survey_id'])) {
                return ['status' => false, 'message' => 'survey_id is required', 'data' => []];
            }
            $request_data['questions'] = json_decode($request_data['questions'], true);
            $survey_id = $request_data['survey_id'];
            $survey_answers_array = [];
            UserSurveyAnswer::where(['user_id' => $request->user()->user_id, 'survey_id' => $survey_id])->delete();
            foreach ($request_data['questions'] as $question) {
                $answer_ids = explode(',', $question['answers']);
                foreach ($answer_ids as $answer_id) {
                    if (isset($answer_id) && $answer_id != "") {
                        $temp = [
                            'user_id' => $request->user()->user_id,
                            'survey_id' => $survey_id,
                            'question_id' => $question['question_id'],
                            'answer_id' => $answer_id,
                            'created_at' => date('Y-m-d H:i:s'),
                            'updated_at' => date('Y-m-d H:i:s')
                        ];
                        $survey_answers_array[] = $temp;
                    }
                }
            }
            $result = UserSurveyAnswer::insert($survey_answers_array);
            if ($result) {
                return ['status' => true, 'message' => 'Survey submitted successfully', 'data' => []];
            } else {
                return ['status' => false, 'message' => 'Something went wrong', 'data' => []];
            }

        } catch (\Exception $e) {
            return ['status' => false, 'message' => $e->getMessage(), 'data' => []];
        }
    }


    public
    function getUserDetailForUDB(Request $request)
    {
        ElasticsearchUtility::getUserVouchers(92);
        exit;
        if ($request->has(self::USER_ID) && $request->user_id) {
            return ['stamp_card' => [], 'vouchers' => [], 'badges' => []];

        }
    }


    private
    function getLoyaltyPoints($request)
    {
        $dataReturn = ['point_balance' => 0, self::REDEEMED_POINTS => ['redeem_price_value' => 0, 'redeem_point_value' => 0]];
        $allPoints = DB::table('lt_transations')->selectRaw('sum(lt_transations.value_points) as points_total,type')
            ->where(self::SOLDI_ID, $request->soldi_id)
            ->groupBy('lt_transations.type')
            ->get();
        $point_type_qry = DB::table('lt_points')->where(self::VENUE_ID, $request->default_venue)->where("lt_point_type", "value")->first();
        if ($point_type_qry) {
            $redeem_points_qry = DB::table('lt_redeem_values')->where("lt_point_id", $point_type_qry->lt_point_id)->first();
            if ($redeem_points_qry) {
                $dataReturn[self::REDEEMED_POINTS]['redeem_price_value'] = $redeem_points_qry->red_price_velue;
                $dataReturn[self::REDEEMED_POINTS]['redeem_point_value'] = $redeem_points_qry->red_point_velue;
            }
        }
        if ($allPoints) {
            $creditAmount = $allPoints[0]->points_total ?? 0;
            $debitAmount = $allPoints[1]->points_total ?? 0;
            $dataReturn['point_balance'] = $creditAmount - $debitAmount;
            return [self::STATUS => true, 'data' => $dataReturn];
        }
        return [self::STATUS => true, 'data' => $dataReturn];
    }


    public
    function sendVerificationGiftCard($phoneNumber = '', $code = '', $name = '')
    {

        try {
            $phoneNumber = substr_replace($phoneNumber, '+', 0, 2);
            $guzzle = new GuzzleClient();
            $resp = new Response();
            $driver = new Twilio($guzzle, $resp, [
                self::ACCOUNT_ID => Config::get('constant.TWILIOID'),
                self::API_TOKEN => Config::get('constant.TWILIOAPI'),
            ]);
            $client = new awsClient($driver);
            $msg = [
                'to' => $phoneNumber,
                'from' => Config::get('constant.TWILLIONUMBER'),
                self::CONTENT => 'Hi ' . $name . ', Your Gift Card Claim ' . $code . ', put this in and Claim your gift card. Team ',
            ];

            $client->send($msg);
            return true;
        } catch (\Exception $e) {
            return $e->getMessage();
        }

    }//--- End of sendVerificationSms() ---//

    public
    function saveUserPreferences(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'type' => 'required',
                'field_label' => 'required',
                'value' => 'required',
            ]);
            if ($validator->fails()) {
                return ['status' => false, 'message' => $validator->errors()->first(), 'data' => []];
            }

            Log::channel(self::CUSTOM)->info('saveUserPreferences', ['saveUserPreferences_request' => $request->all()]);

            if (lcfirst($request->type) == 'products') {
                $user_custom_field = UserCustomField::where('field_label', $request->field_label)->first();
                if ($user_custom_field) {
                    $res = UserCustomFieldData::updateOrCreate(
                        ["user_id" => $request->user()->user_id, "custom_field_id" => $user_custom_field->id],
                        ["user_id" => $request->user()->user_id, "custom_field_id" => $user_custom_field->id, "value" => filter_var($request->value, FILTER_VALIDATE_BOOLEAN),
                            "multiselect_value" => ""]
                    );
                    if ($res) {
                        $res = (new ElasticsearchUtility())->bulkUserDataInsertNew(User::where('user_id', $request->user()->user_id)->get(), '');
                    }
                }
            } else if ($request->type == 'channel_types' || $request->type == 'Channel Types') {
                $userID = $request->user()->user_id;
                $channel = lcfirst(($request->field_label == 'In App messages') ? 'push' : $request->field_label);
                $channel_status = filter_var($request->value, FILTER_VALIDATE_BOOLEAN);
                $data = [];
                //get channel types
                $sys_notificaiton = UserNotification::where(['notification_type' => 'system', 'channel' => $channel])->where('user_id', $userID)->first();
                if ($sys_notificaiton) {
                    $data = [
                        'user_id' => $userID,
                        'channel' => $channel,
                        'notification_type' => 'system',
                        'subscribed' => $channel_status,
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    ];
                    UserNotification::updateOrCreate([
                        'user_id' => $userID,
                        'channel' => $channel,
                        'notification_type' => 'system'
                    ], $data);
                } else {
                    //create RDS entry
                    $data = [
                        'user_id' => $userID,
                        'channel' => $channel,
                        'notification_type' => 'system',
                        'subscribed' => $channel_status,
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    ];
                    UserNotification::updateOrCreate([
                        'user_id' => $userID,
                        'channel' => $channel,
                        'notification_type' => 'system'
                    ], $data);
                }


                $market_notificaiton = UserNotification::where(['notification_type' => 'marketing', 'channel' => $channel])->where('user_id', $userID)->first();
                if ($market_notificaiton) {
                    $data = [
                        'user_id' => $userID,
                        'channel' => $channel,
                        'notification_type' => 'marketing',
                        'subscribed' => $channel_status,
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    ];
                    UserNotification::updateOrCreate([
                        'user_id' => $userID,
                        'channel' => $channel,
                        'notification_type' => 'marketing'
                    ], $data);
                }
                (new ElasticsearchUtility())->bulkUserDataInsertNew(User::where('user_id', $request->user()->user_id)->get(), '');
            } else if ($request->type == 'notification_types' || \request()->type == 'Notification Types') {
                $userID = $request->user()->user_id;
                $field_label = 'marketing';
                $field_value = filter_var($request->value, FILTER_VALIDATE_BOOLEAN);
                if ($request->field_label == 'Promotions')
                    $field_label = 'system';

                //off check
                $res = UserNotification::where(['user_id' => $userID, 'notification_type' => $field_label,])->where('channel', 'like', '%' . $request->field_label . '%')->first();

                if ($res) {
                    UserNotification::where(['user_id' => $userID, 'notification_type' => $field_label, 'channel' => $request->field_label])->update(['subscribed' => $field_value]);
                } else {

                    if ($request->field_label == 'Promotions')
                        $request->request->add(['field_value' => $field_value, 'field_label' => $request->field_label, 'notification_type' => 'system']);

                    if ($request->field_label == 'News')
                        $request->request->add(['field_value' => $field_value, 'field_label' => $request->field_label, 'notification_type' => 'marketing']);

                    $this->saveUserWithChannel($userID);
                }
                (new ElasticsearchUtility())->bulkUserDataInsertNew(User::where('user_id', $request->user()->user_id)->get(), '');
            }

            $data = $this->getUserPreferences($request);
            return ['status' => true, 'data' => $data['data'], 'message' => 'Preference saved'];
        } catch (\Exception $e) {
            Log::channel(self::CUSTOM)->info('saveUserPreferences_error', ['error' => $e->getMessage(), 'line' => $e->getLine()]);
            return ['status' => false, 'data' => [], 'message' => 'Server error'];
        }
    }

    public
    function getUserPreferences(Request $request)
    {
        try {
            $user_id = $request->user()->user_id;
            $data = [];
            $prod_transform = [];
            $custom_fields = UserCustomField::where('field_name', '!=', 'gigya_integrated')->get();
            foreach ($custom_fields as $custom_field) {
                $user_custom_field_data = UserCustomFieldData::where('custom_field_id', $custom_field->id)->where('user_id', $user_id)->first();
                $temp = [];
                if ($user_custom_field_data) {
                    $temp['value'] = (bool)$user_custom_field_data->value;
                } else {
                    $temp['value'] = false;
                }
                $temp['field_label'] = $custom_field->field_label ?? "";
                $prod_transform[] = $temp;
            }


            //get channel types
            $sys_notifications = UserNotification::where(['user_id' => $user_id, 'notification_type' => 'system'])->get();
            if ($sys_notifications->count() == 0) {
                $request->request->add(['system' => true]);
                $this->saveChannels($request->user());
            } else {
                $channel_types = UserNotification::where(['user_id' => $user_id, 'notification_type' => 'system'])->get();
                $channel_transform = [];
                foreach ($channel_types as $channel_type) {
                    if ($channel_type->channel != 'letterbox' and $channel_type->channel != 'post' and $channel_type->channel != 'Promotions' and $channel_type->channel != 'News' and $channel_type->channel != '') {


                        $temp['value'] = (bool)$channel_type->subscribed;
                        $temp['field_label'] = ucfirst(($channel_type->channel == 'push') ? 'In App messages' : $channel_type->channel);
                        $channel_transform[] = $temp;
                    }
                }
            }

            //get notification types

            $notification_types = [];

            $sys_notifications = UserNotification::where(['user_id' => $user_id, 'notification_type' => 'system'])->get();
            $temp = [];
            $promotions = $sys_notifications->where('channel', 'Promotions')->first();
            if ($promotions) {
                $temp['field_label'] = $promotions->channel;
                $temp['value'] = ($promotions->subscribed) ? true : false;
            } else {
                $temp['field_label'] = 'Promotions';
                $temp['value'] = false;
            }

            $notification_types[] = $temp;


            $temp = [];
            $market_notifi = UserNotification::where(['user_id' => $user_id, 'notification_type' => 'marketing'])->get();

            $news = $market_notifi->where('channel', 'News')->first();
            if ($news) {
                $temp['field_label'] = $news->channel;
                $temp['value'] = ($news->subscribed) ? true : false;
            } else {
                $temp['field_label'] = 'News';
                $temp['value'] = false;
            }

            $notification_types[] = $temp;

            $final_arr = [];

            $final_arr[] = ['name' => 'Products', 'value' => $prod_transform];
            $final_arr[] = ['name' => 'Channel Types', 'value' => $channel_transform];
            $final_arr[] = ['name' => 'Notification Types', 'value' => $notification_types];


            return ['status' => true, 'data' => $final_arr, 'message' => ""];
        } catch (\Exception $e) {
            Log::channel('custom')->info('getUserPreferences()', ['error' => $e->getMessage()]);
            return ['status' => false, 'data' => [], 'message' => ""];
        }
    }

    public
    function userPreferences(Request $request)
    {
        $valiadtor = Validator::make($request->all(), [
            'name' => self::REQUIRED,
            self::STATUS => self::REQUIRED,
            'type' => self::REQUIRED,
        ]);

        if ($valiadtor->fails()) {
            $errors = $valiadtor->errors();
            $mess[self::STATUS] = false;
            foreach ($errors->get('name') as $message) {
                $mess[self::MESSAGE] = 'name is missing';
                return $mess;
            }
            foreach ($errors->get(self::STATUS) as $message) {
                $mess[self::MESSAGE] = 'status is missing';
                return $mess;
            }
            foreach ($errors->get('type') as $message) {
                $mess[self::MESSAGE] = 'type is missing';
                return $mess;
            }
        }
        $dataNewArray = [];
        $user = $request->user();
        $dataArray = json_decode($user->food_preference, true);
        if ($user->food_preference && !empty($dataArray)) {
            if (!$this->find_key_value($dataArray, 'name', $request->name)) { // search value in the array
                array_push($dataArray, ['name' => $request->name, 'type' => $request->type, self::STATUS => $request->status]);
            }

            if ($request->status == 'false') {
                $dataArray = $this->removeElementWithValue($dataArray, 'name', $request->name);
            }
            $newArray = [];
            foreach ($dataArray as $data) {
                array_push($newArray, $data);
            }

            $user->food_preference = json_encode($newArray);
            $user->save();
            return [self::STATUS => true, self::MESSAGE => 'Your food preferences have been updated', 'food_preference' => $user->food_preference];
        } else {
            array_push($dataNewArray, ['name' => $request->name, 'type' => $request->type, self::STATUS => $request->status]);
            $user->food_preference = json_encode($dataNewArray);
            $user->save();
            return [self::STATUS => true, self::MESSAGE => 'Your food preferences have been updated', 'food_preference' => $user->food_preference];
        }
    }//---- End of

    public
    function addUserToES(Request $request)
    {
        $users = User::get();
        $chunks = $users->chunk(5000);
        foreach ($chunks as $chunk) {
            (new ElasticsearchUtility())->bulkUserDataInsertNew($chunk);
        }
        return 'count : ' . $users->count();
    }

    public
    function updateUserStatus()
    {
        Log::channel(self::CUSTOM)->info('deleteMemberTypeRequestSoldi', ['request' => request()->all()]);
        try {
            $userIDs = [];
            $memberShip = '';
            $source = '';
            if (count(request()->userData) > 0) {
                foreach (request()->userData as $value) {
                    $memberShip = $value[self::MEMBER_GROUP];

                    if (!empty($value[self::MEMBER_GROUP])) {
                        $data = [self::MEMBER, $value[self::MEMBER_GROUP]];
                        $membtype = $value[self::MEMBER_GROUP];
                        $source .= "ctx._source['groups'] = ['Member','$membtype'];";
                    } else {
                        $data = [self::MEMBER];
                        $source .= "ctx._source['groups'] = ['Member'];";
                    }

                    $user = User::where(self::SOLDI_ID, $value[self::USER_ID])->first();
                    if ($user) {
                        Log::channel(self::CUSTOM)->info('updateUserStatus', ['users' => $user, '$source' => $source]);
                        $user->groups = json_encode($data);
                        $user->save();
                        $userIDs[] = $user->user_id;
                    }
                }
                if (count($userIDs) > 0) {

                    $query = [
                        'script' => [
                            'source' => $source
                        ],
                        'query' => [
                            'bool' => [
                                'must' => [
                                    [self::MATCH => [self::CUSTOM_DOC_TYPE => config('constant.demographic')]],
                                    [
                                        "terms" => [
                                            "persona_id" => $userIDs
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ];
                    $response = ElasticsearchUtility::updateByQuery('', $query);
                    sleep(3);

                    if (empty($memberShip) || $memberShip == 'Staff' || $memberShip == 'Student') {
                        Log::channel(self::CUSTOM)->info('DeleteUserVouchers', ['DeleteUserVouchers' => 'Yes']);

                        VoucherUser::where('group_id', '>', '1')->whereIn('user_id', $userIDs)->delete();

                    }

                    if (!empty($memberShip)) {
                        foreach ($userIDs as $id) {

                            (new GamificationController())->changeMemberShip($id);
                        }
                    }
                }
                return [self::STATUS => true, self::MESSAGE => 'Data Successfully Dumped'];
            } else {
                return [self::STATUS => false, self::MESSAGE => 'No Data for update'];
            }
        } catch (\Exception $e) {
            Log::channel(self::CUSTOM)->info('Error While Update User', ['customError' => $e->getMessage(), 'line' => $e->getLine()]);
            return [self::STATUS => false, self::MESSAGE => 'No Data for update'];
        } catch (QueryException $e) {

            return ['status' => false, 'message' => 'An active user already exists with this email'];
        }
    }//----- End of updateUserStatus() -----//

    public
    function countTotalRecord()
    {
        $counter = DB::table("settings")->where(["type" => "csv_counter"])->first();
        $data = json_decode($counter->field2, true);
        return $data;

    }

    public
    function getUserStores()
    {
        $stores = User::groupBy("store_name")->get(["store_name as value", "store_name as label"]);
        return ["status" => true, "data" => $stores];
    }

    public
    function resetCounter()
    {
        return Config::get("csv_counter.CSV_COUNTER");
    }

    public
    function resetCsvCounter()
    {
        // DB::table("settings")->where(["type"=>"csv_counter"])->update("field2",json_encode(["status"=>"done","count"=>0]));
        DB::table("settings")->where(["type" => "csv_counter"])->update(["field2" => json_encode(["status" => "done", "count" => 0])]);

    }

    public
    function getVenuesDetails($json)
    {
        $json = collect($json)->pluck('venue_id');
        $business = (new VenueController())->getSoldiBusinessAgainstBusinessid();


        $businessData = collect($business['data'])->whereIn('business_id', $json);
        return array_values($businessData->toArray());
    }

    public
    function userStores()
    {
        $user = User::where("user_id", request()->user_id)->first();


        if (!empty($user)) {

            //check for swimart
            if (empty(config('constant.SOLDI_DEFAULT_PATH'))) {
                $user_venue_relations = UserVenueRelation::where('user_id', $user->user_id)->get();
                $user_venue_arr = [];
                foreach ($user_venue_relations as $user_venue_relation) {
                    $temp = [];
                    $venue = Venue::where('venue_id', $user_venue_relation->venue_id)->first();
                    if ($venue) {
                        $temp['business_name'] = $venue->venue_name;
                        $temp['lastTransactionDate'] = '';
                        $user_venue_arr[] = $temp;
                    }
                }
                return ["status" => true, "data" => $user_venue_arr];
            }

            $subscribedVenues = (new ElasticSearchController())->getUserSubscribedVenues(request()->user_id);
            $r = collect($subscribedVenues)->pluck("created_at", "venue_id");

            $data = $this->getVenuesDetails($subscribedVenues);
            $venueData = [];
            if (count($subscribedVenues) > 0) {
                foreach ($subscribedVenues as $value) {
                    $name = Venue::where('venue_id', $value['venue_id'])->first();
                    $venueData[] = ['label' => $name->venue_name, 'name' => $name->venue_name ?? '', 'id' => $value['venue_id'], 'venue_id' => $value['venue_id']];
                }
            }

            $data = collect($data);

            $finalArray = [];

            foreach ($r as $key => $value) {
                $business = $data->where('business_id', $key)->first();

                if ($business) {
                    $finalArray[] = ['lastTransactionDate' => date('d-m-Y', strtotime($value)), 'business_name' => ($business->business_name == 'All') ? $business->store_name : $business->business_name];
                }
            }

            return ["status" => true, "data" => $finalArray, 'organisations' => $venueData, 'all_organisation' => Venue::get(['venue_id as id', 'venue_name as name', 'venue_id'])];
        } else {
            $data = [];

            foreach ($data as $key => $value) {
                $value->business_name = $value->store_name;
            }
            return ["status" => true, "data" => $data];
        }
    }

    public
    function redeemVoucher()
    {
        return (new PaymentController())->updateVoucherStatus(['111021759'], 221);
    }

    public
    function getUserSubscribedVenues($userID)
    {
        $subscribedVenues = UserVenueRelation::where(["user_id" => $userID])->get();
        return $subscribedVenues ? $subscribedVenues : [];
    }

    public
    function updateUserPassword()
    {
        $this->getUserInfo('updateUserPassword');
        $user = User::where('user_id', request()->user_id)->first();
        if ($user) {

            if ($this->password_check) {
                if ($this->checkValidPassword()) {
                    return [self::STATUS => false, self::MESSAGE => "How'd you like to add some character to your password? At least one upper case, lower case,numeric and special character, please."];
                }
            }
            $user->password = Hash::make(request()->password);
            $user->save();
            return ['status' => true, 'message' => 'Password Reset Successfully'];
        } else {
            return ['status' => false, 'message' => 'User not exists'];
        }
    }

    public
    function forgotPasswordByEmail()
    {
        $this->getUserInfo('forgotPasswordByEmail');
        $timeStamps = strtotime(date('Y-m-d h:i:s a', strtotime('+3 hours')));
        $user = User::where('user_id', request()->user_id)->first();
        if ($user) {
            $base64 = base64_encode(json_encode(['user_id' => request()->user_id, 'time' => $timeStamps]));
            $link = url('/') . '/api/update-user/' . $base64;
            //get short link
            $link = (new Utility())->getShortLink($link);

            $this->send_email($user->email, $user->user_first_name, 'Reset Password', $user->user_id, $link, 'reset_email_password', $region_type = 'uk');
            return ['status' => true, 'message' => 'Email sent successfully'];
        } else {
            return ['status' => false, 'message' => 'User not exists'];
        }
    }

    public
    function passwordUpdateByEmail($time)
    {
        $this->getUserInfo('passwordUpdateByEmail');
        $data = json_decode(base64_decode($time), true);
        $currentTime = strtotime(date('Y-m-d h:i:s a'));
        if ($currentTime <= $data['time']) {
            return view('reset_password', ['error' => false, 'message' => 'Link is Valid', 'user_id' => $data['user_id']]);
        } else {
            return view('reset_password', ['error' => true, 'message' => 'Link is expired', 'user_id' => 0]);
        }
    }

    public
    function updateUserOnSoldi($user)
    {
        try {
            $apiKey = '';
            $secrete = '';
            $venueDetail = $this->getVenuesInformation();
            if(!$venueDetail['statis']){
                return ['status' => false, 'message' =>'venue detail not found'];
            }
            $business_id = $venueDetail['data']['company_id'];
            $apiKey = $venueDetail['data']['api_key'];
            $secrete = $venueDetail['data']['secret_key'];


            $client1 = new Client([
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-API-KEY' => $apiKey,
                    'SECRET' => $secrete
                ]
            ]);
            $parms = [
                'customer_id' => $user->soldi_id,
                'business_id' => $business_id,
                'f_name' => $user->user_first_name,
                'l_name' => $user->user_family_name,
                'email_addr' => $user->email,
                'mobile_nbr' => $user->user_mobile ?? '',
                'code' => $user->postal_code ?? '',
                'gender' => ($user->gender == 'Male' || $user->gender == '') ? '1' : (($user->gender == 'Female' || $user->gender == 'female' || $user->gender == 'F') ? '0' : '2'),
                'street_1' => $user->address ?? "",
                'street_2' => $user->address2 ?? "",
                'suburb' => $user->suburb ?? '',
                'city' => $user->city,
                'country' => $user->country,
                'province' => $user->state,
                'image' => \url('/users/') . '/' . $user->user_avatar,
                'comp_name' => \request()->company_name
            ];

            if (\request()->has('membership_type')) {
                $parms['type'] = \request()->membership_type;
            }



            $response = $client1->request('PUT', config('constant.SOLDI_DEFAULT_PATH') . '/customer/edit_customer', [
                'json' => $parms
            ]);
            $soldi_res = $response->getBody()->getContents();
            $soldi_arr = json_decode($soldi_res);
            if (config('constant.BOOKING_ENGINE_URL') and \config('constant.BOOKING_ENGINE_KEY')) {
                $this->updateUserOnBookingEngine($user, $user->soldi_id, []);
            }
            Log::channel('custom')->info('updateUserOnSoldi_r', ['updateUserOnSoldi_r' => $soldi_arr, 'param' => $parms]);
            return ['status' => true];
        } catch (\Exception $e) {
            Log::channel('custom')->error('updateUserOnSoldi_error', ['updateUserOnSoldi_error' => $e->getMessage()]);
        }
    }

    private function createUserData($user_image)
    {
        $request = (object)request()->all();
        $venueDetail = $this->getVenuesInformation();

        $company_id=$venueDetail['data']['company_id'];

        Log::channel('custom')->info('user_type', ['user_type' => request()->all()]);

        return [
            self::USER_FIRST_NAME => $request->first_name ?? '',
            self::USER_FAMILY_NAME => $request->last_name ?? '',
            self::COMPANY_ID => $company_id,
            self::EMAIL => (\request()->has('email') and !empty($request->email)) ? $request->email : null,
            self::USER_MOBILE => $request->phone ?? null,
            'dob' => (request()->has('dob') and $request->dob) ? date(self::YMD, strtotime($request->dob)) : NULL,
            self::USER_AVATAR => $user_image ?? '',
            self::SOLDI_ID => $request->soldi_id ?? 0,
            self::IS_ACTIVE => 0,
            self::ACTIVATION_TOKEN => rand(1111, 9999),
            self::EXPIRY_TIME => Carbon::now()->addMinute(5),
            self::DEBUG_MOD => $this->getAppEnvoirnment() ?? 0,
            self::DEVICE_TOKEN => $request->device_token ?? '',
            'device_type' => $request->device_type ?? '',
            self::GENDER => \request()->gender ?? '',
            self::STORE_DATA => $request->store_data ?? 0,
            'region_type' => $regionType ?? '',
            'client_customer_id' => $this->checkUniqueCustomerID(),
            'user_type' => $request->user_type ?? 'app'
        ];


    }

    private function getVirtualStore()
    {
        return [
            'business_id' => '117',
            'user_id' => '219',
            'business_mobile' => '1234567890',
            'business_name' => 'PETstock NZ',
            'business_details' => '<p>PETstock NZ</p>',
            'business_tagline' => 'PETstock NZ',
            'merchant_account_id' => '',
            'address' => 'Auckland ',
            'postcode' => '55567',
            'distance' => '5,299.67 mi',
            'lat_long' => '',
            'api_key' => 'NTNkZWI3MzI5YWMwYTgwN2RhODdmOW',
            'secret_key' => 'NGZjZmU1OWNjN2Q5NTFiY2Q3MWFkOG',
            'business_image' => [
                'image' => 'https://solditestbucket1.s3.amazonaws.com/b_1252/profile_images/1576925261petstocklogo.png',
                'thumb1' => 'https://solditestbucket1.s3.amazonaws.com/b_1252/profile_images/thumbs/s_1576925261petstocklogo.png',
                'thumb2' => 'https://solditestbucket1.s3.amazonaws.com/b_1252/profile_images/thumbs/s2_1576925261petstocklogo.png',
                'thumb3' => 'https://solditestbucket1.s3.amazonaws.com/b_1252/profile_images/thumbs/m_1576925261petstocklogo.png',
            ],
            'services' =>
                [
                    [
                        'name' => 'dogWash',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'idTags',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'h2oTest',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'puppyPreSchool',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'puppySchoolL1',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'puppySchoolL2',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'adoptionCat',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'adoptionSmallAnimal',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'adoptionBird',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'liveBird',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'liveReptile',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'liveSmallAnimal',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'liveMarine',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'grooming',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'cattery',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'vet',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                    [
                        'name' => 'equine',
                        'description' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
                        'active' => 0,
                    ],
                ],
            'business_settings' =>
                [
                    'currency' => '$',
                    'tax_type' => 'GST',
                    'tax_value' => '10.00',
                    'max_tables' => '0',
                ],
            'is_open' => 1,
            'close_in' => 305.58,
            'state' => 'Open',
            'restaurant_state' => 'Open now - Closes 7:30PM',
            'operation_hours' =>
                [
                    [
                        'is_open' => '1',
                        'day' => 'Monday',
                        'open_at' => '8:15',
                        'close_at' => '18:00',
                    ],
                    [
                        'is_open' => '1',
                        'day' => 'Tuesday',
                        'open_at' => '10:10',
                        'close_at' => '19:00',
                    ],
                    [
                        'is_open' => '1',
                        'day' => 'Wednesday',
                        'open_at' => '9:00',
                        'close_at' => '19:30',
                    ],
                    ['is_open' => '1',
                        'day' => 'Thursday',
                        'open_at' => '9:45',
                        'close_at' => '19:00',
                    ],
                    [
                        'is_open' => '1',
                        'day' => 'Friday',
                        'open_at' => '11:30',
                        'close_at' => '17:00',
                    ],

                    [
                        'is_open' => '1',
                        'day' => 'Saturday',
                        'open_at' => '10:00',
                        'close_at' => '18:00',
                    ],
                    [
                        'is_open' => '1',
                        'day' => 'Sunday',
                        'open_at' => '10:00',
                        'close_at' => '18:30',
                    ]
                ]
        ];
    }

    public function submitSlip(Request $request)
    {
        try {
            set_time_limit(0);

            Log::channel('user')->info('submitSlip()', ['submitSlip()' => $request->all()]);

            $validator = Validator::make($request->all(), [
                'slip' => 'required|max:10000',
                'receipt_id' => 'required|nullable'
            ]);
            if ($validator->fails()) {
                return ['status' => false, 'message' => ($validator->errors()->first('slip')) ? $validator->errors()->first('slip') : $validator->errors()->first('receipt_id'), 'data' => 0];
            }

            //$files = $request->file('slip');

            $files = $request->allFiles();
            Log::channel('user')->info('all_files', ['all_files' => $files]);
            $files = $files['slip'];

            // Log::channel('user')->info('all_files_decode',['all_files_decode' => json_decode($files)]);

            Log::channel('user')->info('$files', ['$files' => $files]);
            Log::channel('user')->info('type()', ['type()' => gettype($files)]);
            // Log::channel('user')->info('$files',['$files'=> count($files)]);

            $images = [];
            $fileName = '';
            foreach ($files as $file) {

                $fileName = (new FilesController())->uploadRecieptFile($file);

                $imageID = ReceiptImages::create([
                    'image' => $fileName,
                    'receipt_id' => \request()->receipt_id
                ]);
                $images[] = $imageID->id;
            }
            return ['status' => true, 'message' => (count($images) > 0) ? 'Successfully Inserted' : 'data not inserted'];
        } catch (ClientException $e) {
            Log::channel('user')->error('ClientException', ['ClientException' => $e->getMessage()]);
            return ['status' => false, 'message' => $e->getMessage(), 'data' => 0];
        } catch (\Exception $e) {
            Log::channel('user')->error('exception_submit_slip', ['exception_submit_slip' => $e->getMessage()]);
            return ['status' => false, 'message' => $e->getMessage(), 'data' => 0];
        }
    }

    public function getStamps(Request $request)
    {
        try {

            $user = $request->user();
            if (!$user)
                return ['status' => false, 'message' => 'user not exists', 'data' => []];

            $stamps_arr = [];
            $mysql_punches = PunchCard::all()->toArray();

            foreach ($mysql_punches as $mysql_punch) {
                $user_stamp = UserStamp::where(['user_id' => $user->user_id, 'punch_id' => $mysql_punch['id']]);
                $voucher = Voucher::where('id', $mysql_punch['voucher_id'])->first();
                $image = '';
                if ($mysql_punch['image']) {
                    $image = url('/') . '/' . $mysql_punch['image'];
                } else {
                    $image = ($voucher) ? url('/') . '/' . $voucher->image : '';
                }

                $temp = [
                    "name" => $mysql_punch['name'],
                    "description" => $mysql_punch['description'],
                    "punch_card_count" => $mysql_punch['no_of_use'],
                    "image" => $image,
                    "amount" => isset($voucher) ? $voucher->amount : 0,
                    'points' => ($mysql_punch['points']) ? $mysql_punch['points'] : 0,
                    'product_data' => (isset($mysql_punch['punch_card_data']) and $mysql_punch['punch_card_data']) ? json_decode($mysql_punch['punch_card_data'], true) : [],
                ];

                if ($user_stamp) {
                    $quantity = (new RecipeController())->getUserStamps($mysql_punch['id']);
                    $temp['quantity'] = $quantity[0]['quantity'];


                } else {
                    $temp['quantity'] = 0;
                }
                $stamps_arr[] = $temp;
            }
            return ['status' => true, 'message' => '', 'data' => $stamps_arr];

        } catch (\Exception $e) {
            Log::channel('custom')->error('getStamps_error', ['getStamps_error' => $e->getMessage(), 'number' => $e->getLine()]);
            return [self::STATUS => true, self::MESSAGE => $e->getMessage()];
        }//.... end of try-catch() .....//
    }//--- End of listPunchCard() ---//

    public function verifyUserEmail($data)
    {
        if (!empty($data)) {
            $decoded = json_decode(base64_decode(urldecode($data)));
            $user = User::where('user_id', $decoded->user_id)->first();
            if ($user) {
                if ($user->is_verified) {
                    return view('verify_email', ['status' => false, 'message' => 'Already verified your account']);
                }
                $user->is_verified = 1;
                $user->save();
                return view('verify_email', ['status' => true, 'message' => 'Your account is verified now']);
            } else {
                return view('verify_email', ['status' => false, 'message' => 'user not exists']);
            }
        } else {
            return view('verify_email', ['status' => false, 'message' => 'Error getting data']);
        }
    }

    public function getUserData()
    {
        $user = User::where(['user_id' => \request()->user_id])->first();
        return ['status' => true, 'data' => $user];
    }

    public function getOffers(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'zone' => 'required',
            ]);

            if ($validator->fails())
                return response($validator->errors(), 400);
            $zone = explode(',', \request()->zone);
            $offers = RecipeOffer::Where(function ($query) use ($zone) {
                for ($i = 0; $i < count($zone); $i++) {
                    $query->orwhere('location', 'like', '%' . $zone[$i] . '%');
                }
            })->orderBy('priority', 'ASC')->get();
            $offers->map(function ($offer) {
                if (!empty($offer->image)) {
                    return $offer->image = url('/') . '/' . $offer->image;
                } else {
                    return $offer->image = '';
                }
            });
            return ['status' => true, 'data' => $offers, 'message' => ''];
        } catch (\Exception $e) {
            return ['status' => false, 'data' => [], 'message' => ''];
        }

    }

    public function getCategories()
    {
        $categories = ShopCategory::all();
        foreach ($categories as &$category) {
            $category->image = url('/venue_category') . '/' . $category->image;
            $category->businesses = json_decode($category->category_shops);
        }
        return ['status' => true, 'data' => $categories];
    }

    public function getShops(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'category_id' => 'required|exists:venue_categories,id',
            ]);
            //Log::channel('custom')->info('getShops',['getShops'=>$request->all()]);
            if ($validator->fails()) {
                $errors = $validator->errors();
                foreach ($errors->get('category_id') as $message)
                    $mess['category_id'] = $message;
                return $mess;
            }//..... end if() .....//
            $venue_categories = DB::table('venue_category')->where('category_id', $request->get('category_id'))->get();
            $shops = [];
            $user_lat_long = explode(',', $request->coordinates);
            foreach ($venue_categories as $venue_category) {
                $business_id = $venue_category->venue_id;
                $api_key = config('constant.SOLDI_API_KEY');
                $api_secret = config('constant.SOLDI_SECRET');


                $companyName = $this->app_name;

                $http = new \GuzzleHttp\Client();
                $response = $http->get(config('constant.SOLDI_DEFAULT_PATH') . "/restaurants/list?type=$companyName&business_id=$business_id", [
                    'headers' => ['X-API-KEY' => $api_key, 'SECRET' => $api_secret],

                ]);
                $d = json_decode($response->getBody());
                if (isset($d->data[0])) {

                    if ($request->coordinates and !empty($request->coordinates)) {
                        if (isset($d->data[0]->lat_long) and $d->data[0]->lat_long != "") {
                            $shop_lat_long = explode(',', $d->data[0]->lat_long);
                            $d->data[0]->distance = round($this->distance($user_lat_long[0], $user_lat_long[1], $shop_lat_long[0], $shop_lat_long[1], 'K'));
                        } else {
                            $d->data[0]->distance = '';
                        }


                    } else {
                        $d->data[0]->distance = '';
                    }

                    array_push($shops, $d->data[0]);

                }
            }

            return ['status' => 200, 'message' => '', 'success' => "TRUE", 'data' => $shops];


            $category = ShopCategory::where('id', $request->get('category_id'))->first();
            $data = [];
            $category_shops = json_decode($category->category_shops);
            if ($category_shops) {
                if ($request->coordinates and !empty($request->coordinates)) {
                    $temp = [];
                    foreach ($category_shops as $shop) {

                        $api_key = $shop->api_key;
                        $api_secret = $shop->secret_key;
                        $companyName = config('constant.COMPANY_NAME');
                        $http = new \GuzzleHttp\Client();
                        $business_id = $shop->business_id;
                        $response = $http->get(config('constant.SOLDI_DEFAULT_PATH') . "/restaurants/list?type=$companyName&business_id=$business_id", [
                            'headers' => ['X-API-KEY' => $api_key, 'SECRET' => $api_secret],

                        ]);
                        $d = json_decode($response->getBody());
                        $shop = isset($d->data[0]) ? $d->data[0] : $shop;
                        $user_lat_long = explode(',', $request->coordinates);
                        if ($shop->lat_long == '' and $shop->lat_long == null) {
                            $shop->distance = '';
                        } else {
                            $shop_lat_long = explode(',', $shop->lat_long);
                            $shop->distance = round($this->distance($user_lat_long[0], $user_lat_long[1], $shop_lat_long[0], $shop_lat_long[1], 'K'));
                        }

                        $temp[] = $shop;
                    }
                    $data = $temp;
                } else {
                    $temp = [];
                    foreach ($category_shops as $shop) {
                        $api_key = $shop->api_key;
                        $api_secret = $shop->secret_key;
                        $companyName = config('constant.COMPANY_NAME');
                        $http = new \GuzzleHttp\Client();
                        $business_id = $shop->business_id;
                        $response = $http->get(config('constant.SOLDI_DEFAULT_PATH') . "/restaurants/list?type=$companyName&business_id=$business_id", [
                            'headers' => ['X-API-KEY' => $api_key, 'SECRET' => $api_secret],

                        ]);
                        $d = json_decode($response->getBody());
                        $shop = isset($d->data[0]) ? $d->data[0] : $shop;
                        $shop->distance = '';
                        $temp[] = $shop;
                    }
                    $data = $temp;
                }
            }

            return ['status' => 200, 'message' => '', 'success' => "TRUE", 'data' => $data];
        } catch (\Exception $e) {
            Log::channel('custom')->info('getShops_error', ['getShops_error' => $e->getMessage()]);
            return ['status' => false, 'data' => [], 'message' => $e->getMessage()];
        }
    }

    public function distance($lat1, $lon1, $lat2, $lon2, $unit)
    {
        if (($lat1 == $lat2) && ($lon1 == $lon2)) {
            return 0;
        } else {
            $theta = $lon1 - $lon2;
            $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
            $dist = acos($dist);
            $dist = rad2deg($dist);
            $miles = $dist * 60 * 1.1515;
            $unit = strtoupper($unit);

            if ($unit == "K") {
                return ($miles * 1.609344);
            } else if ($unit == "N") {
                return ($miles * 0.8684);
            } else {
                return $miles;
            }
        }
    }

    public function contactUs()
    {
        $name = \request()->first_name . ' ' . \request()->last_name;
        $contactNo = \request()->contact_no;
        $enquiryAbout = \request()->enquiry_about;
        $email = \request()->email;
        $question = \request()->question;

        $email_body = "
        <p><strong>Name:- $name </strong></p><br/>
        <p><strong>Contact No:- $contactNo</strong></p><br/>
        <p><strong>Email:- $email</strong></p><br/>
        <p><strong>Enquiry About:- $enquiryAbout </strong></p><br/>
        <p><strong>Question:- $question</strong></p>
        ";

        $this->sendEmailToVerification('admin', $enquiryAbout, $email_body);
        return ['status' => true, 'message' => 'Enquiry submitted successfully'];
    }

    public function sendReferalCode()
    {
        $refree = \request()->user();
        $column = '';
        if (\request()->has('email') and !empty(\request()->email)) {
            $email = \request()->email;
            $column = 'email';

        } else if (\request()->has('phone') and !empty(\request()->phone)) {
            $email = \request()->phone;
            $column = 'user_mobile';
        }
        $user = User::where($column, 'like', "%$email%")->first();
        $refreeName = $refree->user_first_name . ' ' . $refree->user_family_name;
        if (!$user) {
            $name = \request()->first_name . ' ' . \request()->last_name;
            $enquiryAbout = 'Refer Friend';

            $userExists = PastReferals::where(['email' => \request()->email, 'user_id' => $refree->user_id, 'is_signup' => 0])->orWhere('phone', \request()->phone)->first();
            if ($userExists) {
                $refrenceid = $userExists->id;
                PastReferals::where('email', \request()->email)->orWhere('phone', \request()->phone)->update([
                    'user_id' => $refree->user_id,
                    'email' => \request()->email ?? '',
                    'phone' => \request()->phone ?? '',
                    'name' => $name,
                    'is_signup' => 0,
                    'created_at' => Carbon::now()
                ]);
            } else {
                $refrenceid = DB::table('past_referals')->insertGetId([
                    'user_id' => $refree->user_id,
                    'email' => \request()->email ?? '',
                    'phone' => \request()->phone ?? '',
                    'name' => $name,
                    'is_signup' => 0,
                    'created_at' => Carbon::now()
                ]);

            }

            $link = \config('constant.WUHU_WEB') . 'register?info=' . base64_encode(json_encode(['refree_id' => $refree->user_id, 'reference_id' => $refrenceid]));
            if ($this->send_email_vp) {
                //call event trigger
                $trigger_type = "$.refer_trigger";
                $data = [
                    'user_id' => [$refree->user_id],
                    'trigger_type' => 'refer',
                    'referred_name' => $name,
                    'referred_email' => request()->email,
                    'referred_sms' => request()->phone,
                    'refer_link' => $link
                ];
                (new VCTrigger())->callVCTrigger($data, $trigger_type);
            } else {
                if (\request()->has('phone') and !empty(\request()->phone)) {

                    $sms = \config('constant.REFERAL_SMS');
                    $vars = ['|FirstName|' => $name, '|LINK|' => $link];
                    $sms = strtr($sms, $vars);
                    $this->sendSms(request()->phone, $sms, $route = null);
                }

                if (request()->has('email') and !empty(request()->email)) {
                    $email_body = '';
                    $emailTemplate = EmailTemplate::select('html')->where(self::TITLE, 'ReferralFriend')->first();
                    if ($emailTemplate) {
                        $vars = ['$reffered_name' => $name, '$refferee_name' => $refreeName, '|FirstName|' => $refreeName, '|LINK|' => $link];
                        $email_body = strtr($emailTemplate->html, $vars);
                    } else {
                        $email_body = "
                <p>Hi:- $name</p>
        <p><strong>Mr. $refreeName ask you to join our app. </strong></p><br/>
        <p>Please click on link below to join our app</p><br/>
        <p><strong>APP URL:- <a href=" . $link . ">Click Here<a/></strong></p><br/>
        ";
                    }
                    $this->sendEmailToVerification(request()->email, $enquiryAbout, $email_body);
                }
            }

            return ['status' => true, 'message' => 'Successfully referred'];
        } else {
            return ['status' => false, 'message' => 'User already Exists'];
        }

    }

    private function insertUserAddresses($json_decode)
    {
        $user_id = '';
        if (\request()->has('user_id') and !empty(\request()->user_id)) {
            $user_id = \request()->user_id;
        } else {
            $user_id = \request()->user()->user_id;
        }
        $addresses = [];
        foreach ($json_decode as $value) {
            $addresses[] = [
                'user_id' => $user_id,
                'address' => $value['Description'] ?? '',
                'street_number' => $value['street_1'] ?? '',
                'street_name' => $value['street_2'] ?? '',
                'city' => $value['city'] ?? '',
                'state' => $value['state'] ?? '',
                'suburb' => $value['subrub'] ?? '',
                'latitude' => $value['latitude'] ?? '',
                'longitude' => $value['longitude'] ?? '',
                'country' => $value['country'] ?? '',
                'postal_code' => $value['postal_code'] ?? '',
                'is_default' => $value['is_default'] ?? 1,
                'address2' => $value['address2'] ?? '',
                'address_type' => $value['address_type'] ?? '',
            ];
        }
        UserAddresses::where('user_id', $user_id)->delete();
        UserAddresses::insert($addresses);
        return ['status' => true];
    }

    private function getUserAddresses($user_id, $type)
    {
        if ($type == 'api')
            $userAddress = UserAddresses::where('user_id', $user_id)->get(['address as Description', 'street_number as street_1',
                'street_name as street_2', 'city', 'state', 'country', 'suburb as subrub', 'latitude', 'longitude', 'is_default', 'postal_code', 'address2']);
        else
            $userAddress = UserAddresses::where('user_id', $user_id)->get(['address', 'address2', 'street_number',
                'street_name', 'city', 'state', 'country', 'suburb', 'latitude', 'longitude', 'is_default', 'postal_code', 'address_type', 'business_name', 'address_description']);

        if ($userAddress) {
            foreach ($userAddress as $key => $value) {
                $userAddress[$key]['search'] = '';
                $userAddress[$key]['address_type'] = ($value->address_type) ? $value->address_type : '';
                $userAddress[$key]['business_name'] = ($value->business_name) ? $value->business_name : '';
                $userAddress[$key]['address_description'] = ($value->address_description) ? $value->address_description : '';
            }
            return json_encode($userAddress->toArray());
        } else {
            return json_encode([]);
        }
    }

    public function getAddresses()
    {
        $values = $this->getUserAddresses(\request()->persona_id, 'web');
        if (count(json_decode($values, true)) > 0) {
            $finalArray = $values;
        } else {

            $finalArray = json_encode([['address' => '', 'street_number' => '', 'street_name' => '', 'country' => '', 'city' => '', 'state' => '', 'suburb' => '', 'latitude' => '', 'longitude' => '', 'is_default' => 1, 'address2' => '', 'postal_code' => '', 'search' => '', 'address_type' => '', '', 'business_name' => '', 'address_description' => '']]);
        }
        $settings = Setting::where('type', 'province_state')->first();
        $province = '';
        if ($settings) {
            $province = $settings->field1;
        } else {
            $province = 'State';
        }
        return ['status' => true, 'data' => $finalArray, 'setting' => $province];
    }

    public function updateUserAddressWeb()
    {
        $finalData = [];
        foreach (\request()->address as $value) {
            $finalData[] = [
                "address" => $value['address'],
                "street_name" => $value['street_name'],
                "street_number" => $value['street_number'],
                "city" => $value['city'],
                "state" => $value['state'],
                "country" => $value['country'],
                "suburb" => $value['suburb'],
                "latitude" => $value['latitude'],
                "longitude" => $value['longitude'],
                "is_default" => $value['is_default'],
                'user_id' => \request()->persona_id,
                'address2' => $value['address2'] ?? '',
                'postal_code' => $value['postal_code'] ?? '',
            ];
        }
        UserAddresses::where('user_id', \request()->persona_id)->delete();
        UserAddresses::insert($finalData);
        return ['status' => true, 'data' => $this->getUserAddresses(\request()->persona_id, 'web')];

    }

    private function addUserAddress($user)
    {
        //Log::channel('user')->info('user_address', ['user_address' => $user->address]);
        UserAddresses::updateOrCreate(['user_id' => $user->user_id], [
            "address" => $user->address ?? '',
            "address2" => $user->address2 ?? '',
            "street_name" => $user->street_name ?? '',
            "street_number" => $user->street_number ?? '',
            "city" => $user->city ?? '',
            "state" => $user->state ?? '',
            "country" => $user->country ?? '',
            "suburb" => $user->suburb ?? '',
            "latitude" => $user->lat ?? '',
            "longitude" => $user->long ?? '',
            "postal_code" => $user->postal_code ?? '',
            "is_default" => 1,
            'user_id' => $user->user_id
        ]);
        return ['status' => true];
    }

    public function importUserAddress()
    {
        $userSettings = Setting::where('type', 'insert_count')->first();
        $take = 0;
        $offset = 5000;
        $delete = false;
        $userCounts = User::count();
        if ($userSettings) {
            $take = $userSettings->field1;
        }
        $users = User::skip($take)->take($offset)->get();

        Log::channel('user')->info('importUserAddress', ['user_count' => $users->count(), 'take' => $take]);

        foreach ($users as $user) {
            $this->addUserAddress($user);
        }
        if ($userSettings) {
            $total = ($userSettings->field1 + 5000);
            Setting::where('type', 'insert_count')->update(['field1' => $total]);
        } else {
            Setting::create(['field1' => 5000, 'type' => 'insert_count']);
        }
        if ($take <= $userCounts) {
            $delete = true;
            return $this->importUserAddress();
        }


//        if(!$delete){
//            Setting::where('type','insert_count')->delete();
//        }
        return ['status' => true, 'message' => 'successfully inserted data'];
    }

    private function updateUserProfileAddress(string $string, $address, $user_id)
    {
        $user = UserAddresses::where('user_id', $user_id)->first();
        if ($user) {
            $user->{$string} = $address;
            $user->save();
            return ['status' => true];
        } else {
            UserAddresses::create([
                $string => $address,
                'user_id' => $user_id,
                'is_default' => 1,
                'address_type' => 'Residential'
            ]);
        }
        return ['status' => true];
    }

    /**
     * @return array
     */
    public function assignValueStatusPoints()
    {
        try {

            $userID = json_decode(request()->user_ids, true);
            $valuePoints = request()->value_points ?? 0;
            $statusPoints = request()->status_points ?? 0;
            $userData = [];
            foreach ($userID as $value) {
                $userData[] = ['soldi_id' => $value, 'company_id' => Config::get('constant.company_id'), 'venue_id' => '0', 'order_amount' => 0, 'lt_rule_id' => 1, 'status' => 1, 'customer_id' => $value, 'rule_for' => 'store', 'source' => 'campaign', 'type' => 'credit', 'point_id' => 1, 'value_points' => $valuePoints, 'created_at' => time(), 'updated_at' => time(), 'wi_code' => 0, 'user_id' => $value];


                //call event trigger
                $data = [
                    'user_id' => $value,
                    'points' => (int)$valuePoints,
                    'trigger_type' => 'points'
                ];
                $trigger_type = "$.points_trigger";

                (new VCTrigger())->callVCTrigger($data, $trigger_type);

            }

            DB::table('lt_transations')->insert(
                $userData
            );
            return ['status' => true, 'message' => 'Successfully insert data'];
        } catch (\Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }

    private function filterActivityListing()
    {
        if (\request()->has('month') and !empty(\request()->month)) {
            $month = request()->month;
            $startDate = date('Y-m-d H:i:s', strtotime("first day of $month"));
            $endDate = date('Y-m-d H:i:s', strtotime("last day of $month"));
        } else {
            $startDate = date('Y-m-d', strtotime('today - 30 days'));
            $endDate = date('Y-m-d', strtotime("today"));
        }


        if (\request()->filter == 'voucher') {
            $voucher = $this->getUserVouchers('voucher', $startDate, $endDate);
            return ['status' => true, 'data' => $voucher, 'filter_type' => \request()->filter];
        } else if (\request()->filter == 'mission') {
            $mission = $this->getUserMissions('mission', $startDate, $endDate);
            return ['status' => true, 'data' => $mission, 'filter_type' => \request()->filter];
        } else if (\request()->filter == 'receipt') {
            $receipt = $this->getReceiptDetails('receipt', $startDate, $endDate);
            return ['status' => true, 'data' => $receipt, 'filter_type' => \request()->filter];
        } else if (\request()->filter == 'All') {
            $new_array = [];
            $voucher = $this->getUserVouchers('voucher', $startDate, $endDate);
            $mission = $this->getUserMissions('mission', $startDate, $endDate);
            $receipt = $this->getReceiptDetails('receipt', $startDate, $endDate);
            if (count($voucher) > 0) {
                foreach ($voucher as $value)
                    $new_array[] = $value;
            }
            if (count($mission) > 0) {
                foreach ($mission as $value)
                    $new_array[] = $value;
            }
            if (count($receipt) > 0) {
                foreach ($receipt as $value)
                    $new_array[] = $value;
            }
            $new_array = collect($new_array)->sortByDesc('created_at');

            return ['status' => true, 'data' => $new_array->values()->all(), 'filter_type' => \request()->filter];
        } else {
            return ['status' => false, 'message' => 'Invalid filter'];
        }
    }

    private function getAllPointsForUser($type)
    {
        $points = Lt_Transaction::where('user_id', \request()->user_id)->get(['type', 'user_id', 'value_points', 'created_at']);
        foreach ($points as $value)
            $value->display_type = $type;

        $data = $points->sortByDesc('created_at');
        return $data->values()->all();

    }

    private function getUserMissions($string, $startDate, $endDate)
    {
        $user = \request()->user();
        $mission = MissionUserEntry::whereNull('receipt_id')->where('user_id', $user->user_id)->whereDate('created_at', '>=', $startDate)->whereDate('created_at', '<=', $endDate)->get(['created_at', 'mission_id', 'user_id', 'id']);
        foreach ($mission as $key => $value) {

            $points = Lt_Transaction::whereNotnull('mission_entry_id')->where(['mission_entry_id' => $value->id, 'user_id' => request()->user_id, 'type' => 'credit'])->first();
            $missionData = Mission::where('id', $value->mission_id)->first();
            $info = json_decode($missionData->info, true);
            $badge = Badge::where('id', isset($info['badge_id']) ? $info['badge_id'] : 0)->first();
            if ($badge) {

                //get state
                $state = BadgeState::where('badge_id', $badge->id)->first();
                if ($state) {
                    if (isset($state->state_image) and $state->state_image != "") {
                        $value->mission_image = isset($state->state_image) ? url('/badges') . '/' . $state->state_image : "";
                    } else {
                        $value->mission_image = isset($badge->image) ? url('/badges') . '/' . $badge->image : "";
                    }


                }

            } else {
                $value->mission_image = '';
            }
            $value->name = 'MISSION COMPLETED';
            $value->description = $missionData->description ?? '';
            $value->display_type = $string;

            $value->points = ($points) ? $points->value_points : 0;
            $value->voucher_id = '';
            $value->point_type = $points->type ?? '';
        }
        $data = $mission->sortByDesc('created_at');
        return $data->values()->all();
    }

    private
    function getReceiptDetails($string, $startDate, $endDate)
    {
        $user = \request()->user();
        $receipts = UserReceipts::where('user_id', $user->user_id)->whereDate('created_at', '>=', $startDate)->whereDate('created_at', '<=', $endDate)->get(['image', 'created_at', 'submissionid', 'points', 'id', 'detail']);
        $missionData = [];
        foreach ($receipts as $value) {
            $value->image = ($value->image != '') ? $value->image : url('/images/defaultImage.png');
            $value->name = 'TILL SLIP SCAN';
            $value->receipt_id = $value->id;
            $value->point_type = 'credit';
            $value->display_type = $string;

            $value->missions = $this->getReceiptMissions($value->id);

        }
        $data = $receipts->sortByDesc('created_at');
        return $data->values()->all();
    }

    /**
     * @return int
     *  Function for checking unique customer id
     */
    public
    function checkUniqueCustomerID()
    {
        $memberShipID = mt_rand(1000000, 9999999);
        if (User::where('client_customer_id', $memberShipID)->exists()) {
            return $this->checkUniqueCustomerID();
        } else {
            return $memberShipID;
        }
    }//----End of checkUniqueCustomerID() -----//

    /**
     * @param $user
     * @return false|\Psr\Http\Message\StreamInterface|string
     * @throws GuzzleException
     *  Register User To Booking Engine
     */
    public
    function registerUserToBookingEngine($user = null)
    {

        try {
            $dob = date('d-m-Y', strtotime($user->dob));


            $parm = [
                'first_name' => $user->user_first_name,
                'last_name' => $user->user_family_name,
                'dob' => $dob,
                'email' => $user->email,
                'password' => \request()->password,
                'phone' => \request()->phone,
                "address" => request()->address ?? '',
                "address2" => request()->address2 ?? '',
                "street_name" => request()->street_name ?? '',
                "street_number" => request()->street_number ?? '',
                "city" => request()->city ?? '',
                "state" => request()->state ?? '',
                "country" => request()->country ?? '',
                "suburb" => request()->suburb ?? '',
                "latitude" => request()->lat ?? '',
                "longitude" => request()->long ?? '',
                "postal_code" => request()->postal_code ?? '',
                'image' => request()->pos_image,
                'member_type' => \request()->member_type ?? '',

            ];
            if (\request()->has('auth_code') and (\request()->auth_code || \request()->auth_code == 'true')) {
                $accessToken = $this->getAccessTokens($user);
                $parm['auth_code'] = $accessToken['access_token'] ?? $accessToken->access_token;

            }
            $res = (new Client([
                'headers' => [
                    'SECRET-KEY' => config('constant.BOOKING_ENGINE_KEY')
                ]
            ]))->request('POST', \config('constant.BOOKING_ENGINE_URL') . 'api/save-customer', [
                'form_params' => $parm
            ]);

            $response = json_decode($res->getBody()->getContents());
            Log::channel('user')->info('registerUserToBookingEngine()', ['information' => $res->getBody()->getContents(), 'response' => $response]);
            return $response;
        } catch (\Exception $e) {

            $res = $e->getResponse(); //$res->getStatusCode()
            if ($res) {
                $jsonBody = $res->getBody()->getContents();
            } else {
                $jsonBody = '{}';
            }

            $response['status'] = false;
            $response['result'] = json_decode($jsonBody);
            Log::channel('user')->info('registerUserToBookingEngine()', ['information' => $response, 'response' => $response]);

            return $response;

        }
    }

    /**
     * @param $email
     * @return array
     */
    public
    function checkUserByProperty($email)
    {
        $user = User::where(['email' => $email, 'is_active' => 1])->first();

        if ($user)
            return ['status' => true, 'data' => $user];
        else
            return ['status' => false, 'data' => (new \stdClass())];
    }//----- End of checkUserByProperty() ------//

    public
    function getUserBusiness($userid)
    {
        return UserAddresses::where(['user_id' => $userid, 'is_default' => 1])->first();
    }

    function curl_get_file_contents($URL)
    {
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return $contents;
        else return FALSE;
    }

    private
    function updateUserOnBookingEngine($user, $soldi_id, $soldiBusiness)
    {
        Log::channel('user')->info('updateUserOnBookingEngine()', ['information' => [
            'booking_engine_id' => $user->booking_engine_id,
            'soldi_customer_id' => $soldi_id,

        ]]);

        $data = [
            "booking_engine_id" => $user->booking_engine_id,
            "soldi_customer_id" => $soldi_id,
            "phone" => \request()->phone,
            "first_name" => \request()->first_name,
            "last_name" => \request()->last_name,
            "gender" => \request()->gender,
            'country' => $user->country,
            'address' => $user->address,
            'street_number' => $user->address2,
            'street_name' => $user->address2,
            'city' => $user->city,
            'postal_code' => $user->postal_code,
            'state' => $user->state,
            'suburb' => $user->suburb,
            'member_type' => \request()->member_type ?? '',
            'engage_user_id' => $user->user_id,

        ];
        if (count($soldiBusiness) > 0) {
            $data['soldi_api_key'] = $soldiBusiness['data']['API_KEY'];
            $data['soldi_secret_key'] = $soldiBusiness['data']['SECRET_KEY'];
            $data['soldi_business_id'] = $soldiBusiness['data']['store_id'];
            $data['soldi_store_name'] = \request()->business_name ?? '';
        }
        if (\request()->has('pos_image') and !empty(\request()->pos_image)) {
            $data["image"] = \request()->pos_image;
        } else {
            $data['image'] = \url('/users/') . '/' . $user->user_avatar;
        }
        $endPoint = 'api/update-customer';
        if (request()->has('member_type') and \request()->member_type == 'Admin') {
            $endPoint = 'api/from-engage/update-vendor';
        }
        $res = (new Client([
            'headers' => [
                'SECRET-KEY' => config('constant.BOOKING_ENGINE_KEY')
            ]
        ]))->request('POST', \config('constant.BOOKING_ENGINE_URL') . $endPoint, [
            'form_params' => $data
        ]);

        $response = json_decode($res->getBody()->getContents());
        Log::channel('user')->info('updateUserOnBookingEngine()', ['$data' => $data, 'information' => $res->getBody()->getContents(), 'response' => $response]);
        return $response;
    }

    private
    function saveUserWithChannel($user)
    {
        $data = [
            'user_id' => $user,
            'channel' => \request()->field_label,
            'notification_type' => \request()->notification_type,
            'subscribed' => \request()->field_value,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        UserNotification::updateOrCreate([
            'user_id' => $user,
            'channel' => request()->field_label,
            'notification_type' => request()->type,
        ], $data);
        return ['status' => true, 'message' => 'successfully updated'];
    }

    public
    function getCustomerData()
    {
        $userid = 0;
        if (\request()->has('user_id') and !empty(\request()->user_id)) {
            $userid = \request()->user_id;
        } else {
            $userid = \request()->user()->user_id;
        }
        $user = User::where('user_id', $userid)->first();
        if ($user) {
            $user->user_avatar = ($user->user_avatar) ? \url('users/' . $user->user_avatar) : \url('images/demographicIcon@2x.png');
            return ['status' => true, 'data' => $user];
        } else {
            return ['status' => false, 'mesage' => 'User with this id not exists'];
        }
    }

    public
    function getCustomerAddress()
    {
        return ['status' => true, 'data' => json_decode($this->getUserAddresses(\request()->user_id, 'api'), true)];
    }

    private
    function addUserOnKnox($user)
    {
        $data = [];
        if (\request()->has('extra_data')) {
            $dataRecieve = json_decode(request()->extra_data, true);

            $data['country_id'] = $dataRecieve['country'] ?? '';
            $data['state_id'] = $dataRecieve['state'] ?? '';
            $data['comp_mobile'] = $dataRecieve['business_phone'] ?? '';
            $data['default_company_id'] = \config('constant.KNOX_COMPANY_ID');
            $data['txt_skype'] = $dataRecieve['business_skype'] ?? '';
            $data['linkedin_link'] = $dataRecieve['linkedin_link'] ?? '';
            $data['twitter_link'] = $dataRecieve['twitter_link'] ?? '';
            $data['facebook_link'] = $dataRecieve['facebook_link'] ?? '';
            $data['companyType'] = $dataRecieve['business_type'] ?? '';
            $data['txteemail'] = $user->email;
            $data['email'] = $user->email;
            $data['business_buss_regno'] = $dataRecieve['reg_number'] ?? '';
            $data['memo'] = $dataRecieve['business_tagline'] ?? '';
            $data['first_name'] = $dataRecieve['business_contact_name'] ?? '';
            $data['firstName'] = $user->user_first_name;
            $data['lastName'] = $user->user_family_name;
            $data['txtephone'] = $user->user_mobile;
            $data['group_id'] = 14;
            $data['password'] = \request()->password;
            $data['business_name'] = $dataRecieve['businessname'] ?? '';
            $data["businessType"] = $dataRecieve['business_industry'] ?? '';


            $res = (new Client([
                'headers' => [
                    'X-API-KEY' => config('constant.Knox_X_API_KEY'),
                    'secret' => config('constant.Knox_Secret')
                ]
            ]))->request('POST', \config('constant.Knox_Url') . '/create-company', [
                'form_params' => $data
            ]);

            $response = json_decode($res->getBody()->getContents(), true);
            Log::channel('user')->info('addUserOnKnox()', ['addUserOnKnox' => $data, 'response' => $response]);
            return $response;
        } else {
            return ['status' => false, 'message' => 'Please Provide Business Detail'];
        }
    }

    private
    function addSoldiBusiness($user, $knoxRseponse, $edit = true)
    {
        $data = [

            "knox_business_id" => $knoxRseponse['business_id'] ?? 0,
            "soldi_store_id" => request()->soldi_store_id ?? 0,
            "soldi_emp_id" => request()->soldi_emp_id ?? 0,
            'contact_fname' => $user->user_first_name,
            'contact_lname' => $user->user_family_name,
            'contact_email' => $user->email,
            'password' => \request()->password,
            'businessname' => '',
            'business_type' => 'retailer',
            'access_pin' => '',
            'parent_business_id' => 0,
            'address_1' => '',
            'address_2' => '',
            'country' => '',
            'state' => '',
            'city' => '',
            'emp_role' => 0,
            'engage_user_id' => $user->user_id


        ];
        if (\request()->has('extra_data')) {
            $dataRecieve = json_decode(request()->extra_data, true);
            $data['businessname'] = $dataRecieve['businessname'] ?? '';
            $data['business_type'] = $dataRecieve['business_type'] ?? '';
            $data['business_phone'] = $dataRecieve['business_phone'] ?? '';
            $data['access_pin'] = $dataRecieve['access_pin'] ?? '';
            $data['address_1'] = $dataRecieve['address_1'] ?? '';
            $data['address_2'] = $dataRecieve['address_2'] ?? '';
            $data['reg_number'] = $dataRecieve['reg_number'] ?? '';
            $data['city'] = $dataRecieve['city'] ?? '';
            $data['country'] = $dataRecieve['country'] ?? '';
            $data['state'] = $dataRecieve['state'] ?? '';
            $data['emp_role'] = $dataRecieve['emp_role'] ?? '';
            $data['comp_logo'] = $dataRecieve['comp_logo'] ?? '';
            $data['bg_logo'] = $dataRecieve['bg_logo'] ?? '';
            $data['business_tagline'] = $dataRecieve['business_tagline'] ?? '';
            $data['business_details'] = $dataRecieve['business_details'] ?? '';
            $data['comp_type'] = $dataRecieve['comp_type'] ?? '';
            $data['restaurant_type'] = $dataRecieve['restaurant_type'] ?? '';
            $data['business_sefurl'] = $dataRecieve['business_sefurl'] ?? '';
            $data['business_contact_name'] = $dataRecieve['business_contact_name'] ?? '';
            $data['business_email'] = $dataRecieve['business_email'] ?? '';
            $data['business_mobile'] = $dataRecieve['business_mobile'] ?? '';
            $data['business_website'] = $dataRecieve['business_website'] ?? '';
            $data['business_street_1'] = $dataRecieve['business_street_1'] ?? '';
            $data['business_street_2'] = $dataRecieve['business_street_2'] ?? '';
            $data['business_industry'] = $dataRecieve['business_industry'] ?? '';
            $data['dateadded'] = $dataRecieve['dateadded'] ?? '';
            $data['facebook_link'] = $dataRecieve['facebook_link'] ?? '';
            $data['twitter_link'] = $dataRecieve['twitter_link'] ?? '';
            $data['linkedin_link'] = $dataRecieve['linkedin_link'] ?? '';
            $data['business_skype'] = $dataRecieve['business_skype'] ?? '';
            $data['business_website'] = $dataRecieve['business_website'] ?? '';
            $data['business_code'] = $dataRecieve['business_code'] ?? '';
            $data['parent_user_id'] = $dataRecieve['parent_user_id'] ?? '';
            $data['parent_business_id'] = $dataRecieve['parent_business_id'] ?? '';
            $data['booking_id'] = $user->booking_engine_id ?? 0;
            \request()->merge(['business_name' => $dataRecieve['businessname'] ?? '']);

        }
        if (\request()->has('soldi_store_id')) {
            $data['soldi_business_id'] = \request()->soldi_store_id;
        }
        if (\request()->has('soldi_emp_id')) {
            $data['soldi_emp_id'] = \request()->soldi_emp_id;
        }
        $res = (new Client([
            'headers' => [
                'X-API-KEY' => (\request()->country == 'New Zealand') ? \config('constant.SOLDI_IRE_APIKEY') : config('constant.SOLDI_API_KEY'),
                'SECRET' => (request()->country == 'New Zealand') ? \config('constant.SOLDI_IRE_SECRET') : config('constant.SOLDI_SECRET')
            ]
        ]))->request('POST', \config('constant.SOLDI_DEFAULT_PATH') . '/business/register', [
            'form_params' => $data
        ]);

        $response = json_decode($res->getBody()->getContents(), true);
        Log::channel('user')->info('addSoldiBusiness()', ['addSoldiBusiness' => $data, 'soldiResponse' => $response, 'headers' => [
            'X-API-KEY' => (\request()->country == 'New Zealand') ? \config('constant.SOLDI_IRE_APIKEY') : config('constant.SOLDI_API_KEY'),
            'SECRET' => (request()->country == 'New Zealand') ? \config('constant.SOLDI_IRE_SECRET') : config('constant.SOLDI_SECRET')
        ]]);

        if (!$edit) {
            $this->updateUserOnBookingEngine($user, $user->user_id, $response);
        }

        if ($response['success'] == 'TRUE' and $edit) {
            // $this->addVenue($response);
        }
        return $response;
    }

    private
    function addVenue($response)
    {
        $dataRecieve = json_decode(request()->extra_data, true);
        $venueImage = '';
        $company_id = (\request()->country == 'New Zealand') ? config('constant.COMPANY_IRE_ID') : \config('constant.COMPANY_ID');
        if (\request()->has('pos_image') and !empty(request()->pos_image)) {
            $file_name = basename(request()->pos_image);
            $path = public_path() . '/venue_category/' . $file_name;
            file_put_contents($path, $this->curl_get_file_contents(request()->pos_image));
            $venueImage = $file_name;
        }


        $data = $venueData = [
            'venue_name' => $dataRecieve['businessname'] ?? request()->company_name,
            "address" => $dataRecieve['address_1'] ?? '' . ',' . $dataRecieve['address_2'] ?? '',
            'additional_information' => json_encode($dataRecieve),
            'email' => $dataRecieve['business_email'],
            'venue_id' => $response['data']['store_id'],
            'company_id' => $company_id
        ];

        if (!empty($venueImage)) {
            $data['image'] = $venueImage;
        }

        Venue::create($data);
        return true;
    }

    public
    function updateVendorDetails()
    {
        $user = User::where('email', request()->emp_email_addr)->first();
        $existsUser = null;
        if (!empty(request()->new_email)) {
            $existsUser = User::where('email', request()->new_email)->first();
        }

        if ($user and !$existsUser) {
            if (!empty(request()->new_email)) {
                $user->email = request()->new_email;
            }
            $user->user_mobile = request()->emp_phone;
            $user->user_first_name = request()->first_name;
            $user->user_family_name = request()->last_name;
            if (\request()->has('password') and !empty(\request()->password)) {
                $user->password = Hash::make(request()->password);
            }
            $user->save();
            UserAddresses::where('user_id', $user->user_id)->update([
                "address" => \request()->address ?? '',
                "address2" => $dataRecieve['address_2'] ?? '',
                "street_name" => request()->street_name ?? '',
                "street_number" => request()->street_number ?? '',
                "city" => request()->city ?? '',
                "state" => \request()->state ?? '',
                "country" => \request()->country ?? '',
                "is_default" => 1,
                'user_id' => $user->user_id
            ]);
            $userAddress = UserAddresses::where(['user_id' => $user->user_id, 'is_default' => 1])->first();

            if ($userAddress) {
                $user->address = $userAddress->address;
                $user->address2 = $userAddress->address2;
                $user->city = $userAddress->city;
                $user->state = $userAddress->state;
                $user->country = $userAddress->country;
                $user->postal_code = $userAddress->postal_code;
                $user->suburb = $userAddress->suburb;
            }
            $dataRecieve = json_decode(\request()->extra_data, true);
            /*  Venue::where('venue_id', \request()->soldi_store_id)->update([
                  'venue_name' => request()->company_name,
                  'additional_information' => json_encode($dataRecieve),
                  'email' => request()->new_email,
              ]);*/
            $userData = User::where('user_id', $user->user_id)->first();
            $this->addSoldiBusiness($userData, [], false);
            return $this->updateVenueInformation();

        } else {
            return ['status' => false, 'message' => ($existsUser) ? 'User with same email already exists' : 'User with email not exists'];
        }
    }

    private
    function updateVenueInformation()
    {
        $data = [
            "id" => request()->knox_business_id,
            "owner_email" => request()->emp_email_addr,
            "password" => request()->password,
            "user_name" => request()->emp_f_name . ' ' . request()->emp_l_name,
            "txtephone" => request()->emp_phone,
            "business_name" => request()->business_name,
            "owner_first_name" => request()->emp_f_name,
            "owner_last_name" => request()->emp_l_name,
            "owner_contact" => request()->business_contact_name,
            "business_tagline" => request()->business_tagline,
            "choice" => "",
            "email" => request()->emp_email_addr,
            "comp_mobile" => request()->business_phone,
            "count_name" => request()->country_name,
            "state_name" => request()->province_state,
            "business_industry" => request()->business_industry,
            "company_type" => request()->business_type,
            'business_buss_regno' => request()->business_buss_regno,
            'facebook_link' => request()->facebook_link,
            'twitter_link' => request()->twitter_link,
            'linkedin_link' => request()->linkedin_link,
            'txt_skype' => request()->business_skype,
            'new_email' => (!empty(request()->new_email)) ? request()->new_email : request()->emp_email_addr
        ];
        Log::channel('user')->info('updateVenueInformation()', ['updateVenueInformation' => $data]);
        $res = (new Client([
            'headers' => [
                'X-API-KEY' => config('constant.Knox_X_API_KEY'),
                'secret' => config('constant.Knox_Secret'),
                'Content-Type' => 'application/x-www-form-urlencoded'
            ]
        ]))->request('POST', \config('constant.Knox_Url') . '/api/ApiController/companyUpdate', [
            'form_params' => $data
        ]);

        $response = json_decode($res->getBody()->getContents(), true);

        Log::channel('user')->info('updateVenueInformation()', ['updateVenueInformation' => $data, 'response' => $response]);
        return $response;
    }

    public
    function curl_post_async($url, $params)
    {
        foreach ($params as $key => &$val) {
            if (is_array($val)) $val = implode(',', $val);
            $post_params[] = $key . '=' . urlencode($val);
        }
        $post_string = implode('&', $post_params);

        $parts = parse_url($url);

        $fp = fsockopen("ssl://" . $parts['host'],
            isset($parts['port']) ? $parts['port'] : 443,
            $errno, $errstr, 30);


        $out = "POST " . $parts['path'] . " HTTP/1.1\r\n";
        $out .= "Host: " . $parts['host'] . "\r\n";
        $out .= "Content-Type: application/x-www-form-urlencoded\r\n";
        $out .= "Content-Length: " . strlen($post_string) . "\r\n";
        $out .= "Connection: Close\r\n\r\n";
        if (isset($post_string)) $out .= $post_string;

        fwrite($fp, $out);
        fclose($fp);

    }

    public
    function multiThreadImportVendorData()
    {

        // Defining Threads
        $threads = 2;
        if (\request()->threads) $threads = \request()->threads;

        // Creating Setting
        $settings = Setting::where('type', 'multi_customer_count')->first();
        if (!$settings) {
            Setting::create(['type' => 'multi_customer_count', 'field1' => 0, 'field2' => 0]);

            $settings = Setting::where('type', 'multi_customer_count')->first();
        }

        $counter = $settings->field1;


        // Reset
        if (\request()->reset) {
            if ($settings) {
                $settings->field1 = 0;
                $settings->field2 = 0;
                $settings->save();
            }
            echo "Setting Reset";
            exit;
        }


        $customerArr = (new FixesController())->get_csv_file(public_path(\request()->filePath), $counter, $counter + ($threads - $settings->field2));
        echo "Threads: " . $settings->field2 . "<hr>";
        $cycle = $threads - $settings->field2;
        echo "This Cycle: " . $cycle . "<hr>";

        $this_count = 0;
        foreach ($customerArr as $value) {

            $this_count++;
            echo $counter;
            echo "<hr>";

            // Updating Counter
            $settings->field1 = ++$counter;
            $settings->save();


            $this->curl_post_async(url('api/import-customer'), $value);
            // $this->curlInBackground($value,url('api/import-customer'));


        }


        echo "Finished $this_count";
        echo '<meta http-equiv="refresh" content="2">';

    }

    public
    function importVendorData()
    {
        $settings = Setting::where('type', 'multi_customer_count')->first();
        $settings->field2 = $settings->field2 + 1;
        $settings->save();


        try {
            $value = \request()->all();

            Log::channel('user')->info('importVendorData', ['requestRecieve62765' => $value]);


            $data = [
                'email' => $value['customer_email_addr'],
                'password' => 'Plutus123',
                'first_name' => $value['customer_f_name'],
                'last_name' => $value['customer_l_name'],
                'phone' => (!empty($value['customer_mob_nbr'])) ? $value['customer_mob_nbr'] : null,
                'gender' => ($value['customer_gender'] == 0) ? 'female' : (($value['customer_gender'] == 1) ? 'male' : 'other'),
                "address" => (isset($value['customer_addr_1']) and !empty($value['customer_addr_1'])) ? $value['customer_addr_1'] : '',
                "address2" => (isset($value['customer_addr_2']) and !empty($value['customer_addr_2'])) ? $value['customer_addr_2'] : '',
                "street_name" => (isset($value['street_name']) and !empty($value['street_name'])) ? $value['street_name'] : '',
                "street_number" => (isset($value['street_number']) and !empty($value['street_number'])) ? $value['street_number'] : '',
                "city" => (isset($value['city']) and !empty($value['city'])) ? $value['city'] : '',
                "state" => (isset($value['state']) and !empty($value['state'])) ? $value['state'] : '',
                "country" => (isset($value['customer_country']) and !empty($value['customer_country'])) ? $value['customer_country'] : '',
                "suburb" => (isset($value['customer_suburb']) and !empty($value['customer_suburb'])) ? $value['customer_suburb'] : '',
                "postal_code" => (isset($value['customer_code']) and !empty($value['customer_code'])) ? $value['customer_code'] : '',
                "is_default" => 1,
                "bypass_activation" => true,
                "disable_killbill" => false,
                'disable_booking_engine' => false,
                'business_id' => $value['business_id'],
                'venue_id' => $value['business_id'],
                'member_type' => 'Customer',
                'auth_code' => true


            ];

            Log::channel('user')->info('importVendorData', ['requestRecieve627651' => $value]);
            if (!empty($value['profile_image'])) {
                $user_image = '';
                if ($value['profile_image'] and !empty($value['profile_image'])) {
                    $file_name = basename($value['profile_image']);
                    $path = base_path() . self::USER_PATH . '/' . $file_name;
                    file_put_contents($path, $this->curl_get_file_contents($value['profile_image']));
                    $thumbs = base_path() . self::USER_PATH_THUMB . $file_name;
                    file_put_contents($thumbs, $this->curl_get_file_contents($value['profile_image']));
                    $user_image = $file_name;
                }
                $data['user_avatar'] = $user_image;
            }

            $petsData = DB::table('temp_pets')->where('email', $value['customer_email_addr'])->first();

            $myRequest = new \Illuminate\Http\Request();
            $myRequest->setMethod('POST');

            $myRequest->headers->set('Country', ($value['business_id'] == \config('constant.COMPANY_ID')) ? 'aus' : 'nz');

            $myRequest->request->add($data);
            \request()->request->add($data);
            $responseData = $this->register((object)$myRequest);

            if ($petsData and $responseData['status']) {
                $petDetails = json_decode($petsData->pets, true);
                foreach ($petDetails as $newDetails) {
                    $newPet = [
                        'user_id' => $responseData['user_id'],
                        'name' => $newDetails['name'] ?? '',
                        'sub_class_id' => $newDetails['sub_class_id'] ?? 0,
                        'variant_id' => $newDetails['variant_id'] ?? 0,

                        'gender' => $newDetails['gender'] ?? '',

                        'colour' => $newDetails['colour'] ?? '',
                        'behaviour' => $newDetails['behaviour'] ?? '',
                        'medical' => $newDetails['medical'] ?? '',
                        'type_id' => $newDetails['type_id'] ?? '',
                        'note' => $newDetails['note'] ?? '',
                        'pronto_id' => $newDetails['pronto_id'] ?? 0,
                        'be_pet_id' => $newDetails['id'] ?? 0,
                    ];

                    if (!empty($newDetails['dob'])) {
                        $newPet['dob'] = $newDetails['dob'];
                    }
                    $pet = UserPets::create($newPet);

                    $user_pets = UserPets::where('id', $pet->id ?? $pet['id'])->get()->toArray();
                    foreach ($user_pets as $key => $value) {
                        $user_pets[$key]['engage_pet_id'] = $value['id'];
                        $user_pets[$key]['be_pet_id'] = $value['be_pet_id'] ?? 0;
                    }
                    $user = User::where('user_id', $responseData['user_id'])->first();
                    (new PetController())->addDataToBookingEngin($user_pets, $user, '');
                }
            }


        } catch (\Exception $e) {
            echo $e->getMessage();
            Log::channel('user')->info('importVendorData', ['Error' => $e->getMessage(), 'line' => $e->getLine()]);
        }


        $settings = Setting::where('type', 'multi_customer_count')->first();
        $settings->field2 = abs($settings->field2 - 1);
        $settings->save();

    }

    private
    function assignUserAgainstVenue($user_id, $venue_id)
    {
        $venue = Venue::where(['company_id' => $venue_id, 'is_default' => 1])->first();
        $venueFirst = Venue::where(['company_id' => $venue_id])->first();
        $venue_id = '';
        if ($venue) {
            $venue_id = $venue->venue_id;
        } else {
            if ($venueFirst) {
                $venue_id = $venueFirst->venue_id;
            }
        }
        UserVenueRelation::create([
            'user_id' => $user_id,
            'venue_id' => $venue_id
        ]);
        return ['status' => true, 'messge' => 'Insert Data to venue'];
    }

    /**
     * @param $user
     * @throws GuzzleException
     * Register on Gigya
     */
    private
    function registerUserOnGigya($user)
    {
        $countryAbbrevations = DB::table('geo')->where('country_name', 'like', '%' . $user->country . '%')->first();
        $stateAbbrevations = DB::table('geo')->where('subdivision_1_name', 'like', '%' . $user->state . '%')->first();
        $addreeData = [
            "email" => ($user->email) ? $user->email : 'AnnaSHare@dayrep.com',
            "mobileNumber" => $user->user_mobile,
            "address" => [
                "houseNameOrNumber" => "",
                "addressLine1" => "1 Street Name",
                "addressLine2" => "Village",
                "cityName" => "city",
                "postalCode" => "ABC123",
                "stateOrProvince" => "AB",
                "addressCountry" => 'GB'
            ]
        ];
        $data = ["profile" => ["header" => ["isoLanguage" => "EN", "isoCountry" => "GB", "brandCode" => "BH0162", "campaignId" => "CN000631", "origin" => "Website", "formType" => "Sign Up", "entity" => "PRM 2.6"],
            "consumerIdentity" => ["unileverId" => "12345678", "hashedUnileverId" => "A1B2C3D4E5", "firstName" => $user->user_first_name, "lastName" => $user->user_family_name, "middleName" => "", "preferredName" => $user->user_first_name, "honorificPrefix" => "", "honorificSuffix" => "",
                "gender" => ($user->gender == 'Male' || $user->gender == 'male') ? 'M' : (($user->gender == 'Female' || $user->gender == 'female' || $user->gender == 'F') ? 'F' : 'O'),
                "dateOfBirth" => ($user->dob) ? $user->dob : '1963-10-25'
            ],
            "contactDetail" => $addreeData,
            "optInStatus" => ["brandEmailConsent" => \request()->system, "brandSMSConsent" => \request()->system, "unileverEmailConsent" => \request()->marketing, "unileverSMSConsent" => request()->marketing, "legalAgeConsent" => true],
            "additionalSubscription" => [["serviceId" => "SVC_GB_BH0162_EML_Newsletter", "optIn" => true]],
            "questionAndAnswers" => [["questionId" => 10, "answerId" => [5678, 9121], "answerText" => "Example answer"]
            ]
        ]
        ];
        $res = (new Client([
            'headers' => [
                'X-Link-Secret-Key' => config('constant.LINK_SECRET'),
                'Content-Type' => 'application/json'
            ]
        ]))->request('POST', \config('constant.LINK_URL') . 'consumer_interaction_create', [
            'json' => $data
        ]);

        $response = json_decode($res->getBody()->getContents(), true);

        Log::channel('user')->info('registerUserOnGigya()', ['addreeData' => $data, 'response' => $response]);

    }//----- End of registerUserOnGigya() -----//


    public
    function faqFeedBack()
    {
        $user = \request()->user()->user_id;
        FaqFeedBack::updateOrCreate(['user_id' => $user, 'feedback_id' => request()->feedback_id], [
            'user_id' => $user,
            'feedback_id' => \request()->feedback_id,
            'feed_back' => filter_var(\request()->feed_back, FILTER_VALIDATE_BOOLEAN),

        ]);
        return ['status' => true, 'message' => 'Thanks for your feedback'];
    }

    public
    function checkAutoLogin()
    {
        $myRequest = new \Illuminate\Http\Request();
        $myRequest->setMethod('POST');
        $myRequest->request->add(['is_auth' => true, 'debug_mod' => $this->getAppEnvoirnment() ?? '', 'device_token' => \request()->device_token ?? '', 'device_type' => \request()->device_type ?? '', 'device_id' => \request()->device_id ?? '']);
        return $this->loginUser($myRequest);
    }

    private
    function updateTimerForNotifications($user)
    {
        if (DB::table('user_verifications')->where(['user_id' => $user->user_id])->first()) {
            DB::table('user_verifications')->where(['user_id' => $user->user_id])->update([
                'created_at' => Carbon::now()
            ]);
        } else {
            DB::table('user_verifications')->insert([
                'user_id' => $user->user_id,
                'created_at' => Carbon::now()
            ]);
        }

    }

    public
    function getUserInfo($methodName)
    {
        try {
            $ipaddress = \request()->ip();
            $data['SCRIPT_NAME'] = $_SERVER['SCRIPT_NAME'] ?? '';
            $data['HTTP_USER_AGENT'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $data['HTTP_HOST'] = $_SERVER['HTTP_HOST'] ?? '';
            $data['SERVER_ADDR'] = $_SERVER['SERVER_ADDR'] ?? '';
            $data['SERVER_PROTOCOL'] = $_SERVER['SERVER_PROTOCOL'] ?? '';
            $data['PHP_SELF'] = $_SERVER['PHP_SELF'] ?? '';
            $data['GATEWAY_INTERFACE'] = $_SERVER['GATEWAY_INTERFACE'] ?? '';
            $data['SERVER_NAME'] = $_SERVER['SERVER_NAME'] ?? '';
            $data['SERVER_SOFTWARE'] = $_SERVER['SERVER_SOFTWARE'] ?? '';
            $data['REQUEST_METHOD'] = $_SERVER['REQUEST_METHOD'] ?? '';
            $data['REQUEST_TIME'] = $_SERVER['REQUEST_TIME'] ?? '';
            $data['QUERY_STRING'] = $_SERVER['QUERY_STRING'] ?? '';
            $data['REMOTE_ADDR'] = $_SERVER['REMOTE_ADDR'] ?? '';
            $data['REMOTE_PORT'] = $_SERVER['REMOTE_PORT'] ?? '';
            Log::channel('password')->info('PasswordUpdate', ['ip' => $ipaddress, 'request_param' => \request()->all(), 'Action' => $methodName, 'request_detail' => $data]);
        } catch (\Exception $e) {
            return true;
        }
    }

    public function checkValidPassword()
    {
        $status = false;
        if (\request()->has('password'))
            if (preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*(_|[^\w])).+$/', \request()->password) == 0) {
                $status = true;
            }

        return $status;
    }

    /**
     * @return array
     */
    public function updateWeakPassword()
    {
        $user = \request()->user();
        if ($this->checkValidPassword()) {
            return ['status' => false, 'message' => "How'd you like to add some character to your password? At least one upper case, lower case,numeric and special character, please."];
        }
        $user->password = Hash::make(\request()->password);
        $user->save();

        return ['status' => true, 'message' => "Password updated successfully"];
    }//----- End of updateWeakPassword() -----//

    public
    function getSlipUrl(Request $request)
    {
        try {
            set_time_limit(0);

            Log::channel('user')->info('submitSlip()', ['submitSlip()' => $request->all()]);

            $validator = Validator::make($request->all(), [
                'receipt_id' => 'required|nullable'
            ]);
            if ($validator->fails()) {
                return ['status' => false, 'message' => ($validator->errors()->first('slip')) ? $validator->errors()->first('slip') : $validator->errors()->first('receipt_id'), 'data' => 0];
            }

            $files = $request->slip;
            Log::channel('user')->info('all_files', ['all_files' => $files]);

            $images = [];

            foreach ($files as $file) {
                $file_name = basename($file);
                $path = 'uploads/' . $file_name;
                file_put_contents(public_path($path), $this->curl_get_file_contents($file));
                $imageID = ReceiptImages::create([
                    'image' => $path,
                    'receipt_id' => \request()->receipt_id
                ]);
                $images[] = $imageID->id;
            }
            return ['status' => true, 'message' => (count($images) > 0) ? 'Successfully Inserted' : 'data not inserted'];
        } catch (ClientException $e) {
            Log::channel('user')->error('ClientException', ['ClientException' => $e->getMessage()]);
            return ['status' => false, 'message' => $e->getMessage(), 'data' => 0];
        } catch (\Exception $e) {
            Log::channel('user')->error('exception_submit_slip', ['exception_submit_slip' => $e->getMessage()]);
            return ['status' => false, 'message' => $e->getMessage(), 'data' => 0];
        }
    }

    private function getReceiptMissions($id)
    {
        $data = [];
        $missions = MissionUserEntry::where('receipt_id', $id)->get();
        if ($missions->isNotEmpty()) {
            foreach ($missions as $value) {
                $points = Lt_Transaction::whereNotnull('mission_entry_id')->where(['mission_entry_id' => $value->id, 'user_id' => request()->user_id, 'type' => 'credit'])->first();
                $missionData = Mission::where('id', $value->mission_id)->first();
                $info = json_decode($missionData->info, true);
                $badge = Badge::where('id', isset($info['badge_id']) ? $info['badge_id'] : 0)->first();
                $image = '';
                if ($badge) {

                    //get state
                    $state = BadgeState::where('badge_id', $badge->id)->first();
                    if ($state) {
                        if (isset($state->state_image) and $state->state_image != "") {
                            $image = isset($state->state_image) ? url('/badges') . '/' . $state->state_image : "";
                        } else {
                            $image = isset($badge->image) ? url('/badges') . '/' . $badge->image : "";
                        }


                    }

                }


                $data[] = ['name' => 'MISSION COMPLETED', 'description' => $missionData->description, 'display_type' => 'mission', 'points' => ($points) ? $points->value_points : 0, 'voucher_id' => '', 'point_type' => $points->type ?? 'credit', 'mission_image' => $image];
            }
        }
        return $data;
    }

    private function getAppEnvoirnment()
    {
        return (App::environment('Development')) ? 0 : 1;
    }

    public function getVenuesInformation()
    {
        if (\request()->has('venue_id')) {
            $venue = Venue::where('venue_id', \request()->venue_id)->first();
            if ($venue and $venue->company_id)
                return ['status' => true, 'data' => $venue->toArray()];
            else
                return ['status' => false, 'data' => []];
        } else {
            $venue = Venue::where(['is_default' => 1])->first();
            if ($venue and $venue->company_id)
                return ['status' => true, 'data' => $venue->toArray()];
            else
                return ['status' => false, 'data' => []];
        }
    }

}

