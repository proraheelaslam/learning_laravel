<?php

namespace App\Http\Controllers\API;

use App\Mail\TestEmail;
use App\Models\EmailTemplate;
use App\Models\UserNotification;
use App\Models\UserVenueRelation;
use App\User;
use App\Utility\TagReplacementUtility;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\API\UserApiController;

class TestEmailController extends Controller
{
    const DEFAULT                   = 'default';


    public function sendEmail(Request $request)
    {

        //$res = DB::table("venue_configurations_test_alerts")->where("venue_id",request()->venue_id)->first();
        $usersEmail = request()->email;
        $users = User::whereIn("email",$usersEmail)->get();
        $html = "";
        $data = EmailTemplate::select('html')->where('id', $request->template_id)->first();
        if($users){
            foreach ($users as $key => $value){

                //check if user can receive email
//                $user_notification = UserNotification::where('user_id',$value->user_id)->where('channel','email')->first();
//                if($user_notification) {
//                    if($user_notification->subscribed) {
//                        if(!empty($data))
//                            $html = $data->html;
//
//                        $html = (new TagReplacementUtility())->generateTagText($html,0,$value->user_id,$request->template_id);
//                        (new UserApiController())->sendEmailToVerification($value->email, 'test email', $html);
//                    }
//                }
                if(!empty($data))
                    $html = $data->html;

                //get user venue id
                $venue_id = 0;
                $user_venue = UserVenueRelation::where('user_id',$value->user_id)->first();
                if($user_venue) {
                    $venue_id = $user_venue->venue_id;
                }

                //get survey id
                $survey_id = 0;
                if($request->survey_id) {
                    $survey_id = $request->survey_id;
                }
                Log::channel('custom')->info('sendEmail_req', [
                    $request->all()
                ]);
                $html = (new TagReplacementUtility())->generateTagText($html,$venue_id,$value->user_id,$request->template_id,$survey_id);
                (new UserApiController())->sendEmailToVerification($value->email, 'test email', $html);
            }

        }
        return ['status' => true,'message' =>'Successfully send'];
    }


    public function sendSms()
    {
        try {

            if (empty($route)) {
                $route = self::DEFAULT;
            }

            $http = new \GuzzleHttp\Client();
            $message = request()->channel_data['message'];

            if(request()->current_channel == "sms"){
                foreach (request()->mobile as $key => $value){
                    $users = User::where("user_mobile",$value)->first();
                    //get user venue id
                    $venue_id = 0;
                    $user_venue = UserVenueRelation::where('user_id',$users->user_id)->first();
                    if($user_venue) {
                        $venue_id = $user_venue->venue_id;
                    }
                    $user_message = (new TagReplacementUtility())->generateTagText($message,$venue_id,$users->user_id??0);

                    $response = $http->post(config('constant.JAVA_URL') . 'sendSMS', [
                        'headers' => array(),
                        'json' => [
                            'mobile' => $value,
                            "route" => "default",
                            'message_txt' => $user_message,
                        ]
                    ]);
                    $smsResponse = json_decode($response->getBody(), true);
                }
            }else{

                foreach (request()->push as $key => $value){
                    $users = User::where("user_id",$value)->first();
                    $user_message = (new TagReplacementUtility())->generateTagText($message,request()->venue_id,$users->user_id??0);
                    $response = $http->post(config('constant.JAVA_URL') . 'sendTestPushToUser', [
                        'headers' => array(),
                        'json' => [
                            'notification_type' => "push",
                            'petronID' => $value,
                            'message' => $user_message
                        ]
                    ]);
                    $smsResponse = json_decode($response->getBody(), true);

                }
            }



            if ($smsResponse["status"]) {
                return ["status"=>true,"message"=>"Sms sent successfully"];
            } else {
                return ["status"=>false,"message"=>"Something went wrong"];
            }
        } catch (\Exception $e) {
            return ["status"=>false,"message"=>$e->getMessage()];

        }
    }//--- End of sendSms() ---//

}
