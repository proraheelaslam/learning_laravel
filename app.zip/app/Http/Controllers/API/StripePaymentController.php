<?php

namespace App\Http\Controllers\API;

use App\Models\Setting;
use App\User;
use App\Utility\ElasticsearchUtility;
use Carbon\Carbon;
use Elasticsearch\Common\Exceptions\ClientErrorResponseException;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use mysql_xdevapi\Exception;
use App\Models\PunchCard;
use App\Http\Controllers\API\PaymentController;

class StripePaymentController extends Controller
{
    public $country;
    public $KB_CLIENT = '';
    public $app_name = "";

    public function __construct()
    {
        set_time_limit(0);
        $appName = config('constant.APP_NAME');
        $this->app_name = str_replace('engage-', '', $appName);

        $this->KB_CLIENT = (new Client([
            'auth' => [config('constant.KILL_BILL_USER_NAME'), config('constant.KILL_BILL_PASSWORD')],
            'headers' => [
                'Content-Type' => 'application/json',
                'x-killbill-apikey' =>  config('constant.KILL_BILL_APIKEY'),
                'x-killbill-apisecret' => config('constant.KILL_BILL_SECRET'),
                "x-killbill-createdby" => $this->app_name
            ]
        ]));

        $setting = Setting::where('type', 'payment_method')->first();
        if ($setting) {
            $this->payment_method = $setting->field1;
        } else {
            $this->payment_method = 'barclay';
        }

        //Log::channel('custom')->info('KBDETAILS', ['KB' => $this->KB_CLIENT]);
        Log::channel('custom')->info('StripePaymentController', ['StripePaymentController' => true]);

    }

    /**
     * @param string $user
     * @return array
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function registerUserToKB($user = '')
    {

        try {

            $dataPost = ["name" => $user->user_first_name . ' ' . $user->user_family_name, "firstNameLength" => strlen($user->user_first_name), "email" => $user->email, "phone" => $user->user_mobile, "currency" => "AUD", "billCycleDayLocal" => 1, "timeZone" => "UTC", "referenceTime" => Carbon::now()->toIso8601String(), "address2" => "Test Addresss", "postalCode" => "PO 23443"];

            if (!$user->kill_bill_id) {
                $ukClient = (new Client([
                    'auth' => [config('constant.KILL_BILL_USER_NAME'), config('constant.KILL_BILL_PASSWORD')],
                    'headers' => [
                        'Content-Type' => 'application/json',
                        'x-killbill-apikey' => config('constant.KILL_BILL_APIKEY'),
                        'x-killbill-apisecret' => config('constant.KILL_BILL_SECRET'),
                        "x-killbill-createdby" => $this->app_name
                    ]
                ]));

                $response = $ukClient->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/accounts", [
                    'json' => $dataPost
                ])->getHeaders();


                if (array_key_exists('Location', $response)) {

                    $url = $response['Location'][0];

                    User::where('user_id',$user->user_id)->update([
                        'kill_bill_id' =>basename($url)
                    ]);
                    $ukClient->request('POST', $url . '/tags', [
                        'json' => ["00000000-0000-0000-0000-000000000001"]
                    ]);
                }
            }

//            if (!$user->kilbill_ire_id) {
//
//                $this->resgisterToIRE($dataPost, $user);
//            }
            return ['status' => true];
        } catch (\Exception $e) {
            return ['status' => false, 'message' => 'Error occured due' . $e->getMessage()];
        }
    }//----- End of registerUserToKB() -----//

    /**
     * @param Request $request
     * @return array
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function addUserCards(Request $request)
    {
        try {

            Log::channel('custom')->info('addUserCardsInput',['addUserCardsInput '=> $request->all()]);
            $user = $request->user();

                $kilbillI = request()->user()->kill_bill_id;

           // $kilbillI = $user->kill_bill_id;

            //check if users exists on kill bill
            if(empty($kilbillI)) {
                return ['status' => false, 'message' => 'User not exists on killbill'];
            }
            $newPaymentMethodId = $request->has('newPaymentMethodId') ? $request->newPaymentMethodId: null;
            $cardToken = $request->has('token_id') ? $request->token_id: null;
            $status = ($request->quick_pay) ? 'true' : 'false';
            $card_holder_name = $request->cardholder_name;
            $cardData = ["pluginName" => "plutus-stripe", "pluginInfo" => ["externalPaymentMethodId" => "external", "isDefaultPaymentMethod" => (bool)$status,
                "properties" => [
                    ["key" => $newPaymentMethodId!=null?"newPaymentMethodId":"cardToken", "value" => $newPaymentMethodId!=null?$newPaymentMethodId:$cardToken, "isUpdatable" => true],
                    ["key" => "cardHolderName", "value" => $card_holder_name, "isUpdatable" => true]
                ]]];


            Log::channel('custom')->info('$cardData',['$cardData '=>$cardData]);

            $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/accounts/$kilbillI/paymentMethods?isDefault=" . $status . "&payAllUnpaidInvoices=false", [
                'json' => $cardData
            ]);
            $response = $response->getHeaders();

            if (array_key_exists('Location', $response)) {
                $url = $response['Location'][0];
                Log::channel('custom')->info('kbPaymentMehtodId',['kbPaymentMehtodId '=>$url]);
                $recievedLink = $this->cardLinkGeneration($url);
                return ['status' => 200, 'message' => 'Card is added successfully', 'link' => $recievedLink['data']];
            }
        } catch (ClientException $e) {
            $responseData = json_decode($e->getResponse()->getBody(true), true);
            Log::channel('custom')->info('addUserCards()',['addUserCards() '=>$responseData]);
            return ['status' => false, 'message' => 'Error while adding card'];
        }
    }//----- End of addUserCards() -----//

    /**
     * @param $url
     * @return array
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function cardLinkGeneration($url)
    {
        $response = $this->KB_CLIENT->request('GET', $url . "?includedDeleted=false&withPluginInfo=true&audit=NONE")->getBody();
        return ['data' => json_decode($response)->pluginInfo->properties[0]->value ?? ''];
    }//----- End of cardLinkGeneration() ----//

    /**
     * @return array
     */
    public function getUserCardsKB()
    {
        try {
            if(request()->header('Country') == 'ire'){
                $accountId = request()->user()->kill_bill_id;
            }else {
                $accountId = request()->user()->kill_bill_id;
            }
            //$accountId = '05847abc-c9c2-4e77-83b9-6fa53eee0497';
            if(empty($accountId)) {
                return ['status' => 500, 'message' => 'User not exists on killbill'];
            }
//            $accountId = User::where('user_id',5560)->first()->kill_bill_id;
            Log::channel('custom')->info('check data',['CHEKCIDS'=>$accountId]);
            $request = $this->KB_CLIENT->get(config('constant.KILL_BILL_URL') . '/1.0/kb/accounts/' . $accountId . '/paymentMethods?withPluginInfo=true&includedDeleted=false&audit=NONE')->getBody()->getContents();
            $data = collect(json_decode($request, true));
            Log::channel('custom')->info('cards_response',['cards_response'=>$data]);
            $dataArray = [];
            foreach ($data as $value) {
                $card_obj = [];
                if ($value['pluginName'] == "plutus-stripe") {
                    foreach ($value['pluginInfo']['properties'] as $key => $val) {

                        if ($key == 1) {

                            $val = json_decode($val['value'], true);
                            $card_obj['card_type'] = $val['brand'];
                            $card_obj['is_default'] = $value['isDefault'];
                            $card_obj['card_last'] = $val['last4'];
                            $card_obj['expiry_month'] = $val['expMonth'];
                            $card_obj['expiry_year'] = $val['expYear'];
                            $card_obj['card_id'] = $value['paymentMethodId'];
                            $card_obj['card_name'] = isset($val['card_name']) ? $val['card_name'] : request()->user()->user_first_name . ' ' . request()->user()->user_family_name;
                            $dataArray[] = $card_obj;
                        }
                    }
                }
            }
            Log::channel('custom')->info('cards_response_final',['cards_response_final'=>$dataArray]);
            return ['status' => ($data->isNotEmpty()) ? 200 : 200, 'data' => $dataArray];
        } catch (ClientException $e) {
            $responseData = json_decode($e->getResponse()->getBody(true),true);
            Log::channel('custom')->info('getUserCardsKB_error', ['getUserCardsKB_error' => $responseData]);
            return ['status' => 500, 'message' => 'error Occured' . $e->getMessage()];
        }
    }//----- End of getUserCardsKB() -----//

    public function killbillPaymentData(Request $request, $region = 'uk')
    {
        $request_arr = $request->all();
        $kbPaymentOrMethodID = isset($request->kbPaymentId) ? $request->kbPaymentId : $request->kbPaymentMethodId;
        Log::channel('custom')->info('Kill Bill Response', ['KILLBILLRESPONSE' => $request->all()]);
        Log::channel('custom')->info('Kill Bill Region', ['KILLBILL REGION' => $region]);

        $requestKeys = array_keys($request_arr);
        Log::channel('custom')->info('client', ['clientHeader' => [
            'auth' => ($region == 'uk') ? [config('constant.KILL_BILL_USER_NAME'), config('constant.KILL_BILL_PASSWORD')] : [config('constant.KILL_BILL_IRE_USER_NAME'), config('constant.KILL_BILL_IRE_PASSWORD')],
            'headers' => [
                'Content-Type' => 'application/json',
                'x-killbill-apikey' => ($region == 'uk') ? config('constant.KILL_BILL_APIKEY') : config('constant.KILL_BILL_IRE_APIKEY'),
                'x-killbill-apisecret' => ($region == 'uk') ? config('constant.KILL_BILL_SECRET') : config('constant.KILL_BILL_IRE_SECRET'),
                "x-killbill-createdby" => $this->app_name,
                "KILLBILURL" => config('constant.KILL_BILL_URL') . "/1.0/kb/paymentGateways/notification/barclay-card?" . $requestKeys[0] . "=" . $kbPaymentOrMethodID
            ]
        ]]);
        try {
            $response = (new Client([
                'auth' => ($region == 'uk') ? [config('constant.KILL_BILL_USER_NAME'), config('constant.KILL_BILL_PASSWORD')] : [config('constant.KILL_BILL_IRE_USER_NAME'), config('constant.KILL_BILL_IRE_PASSWORD')],
                'headers' => [
                    'Content-Type' => 'application/json',
                    'x-killbill-apikey' => ($region == 'uk') ? config('constant.KILL_BILL_APIKEY') : config('constant.KILL_BILL_IRE_APIKEY'),
                    'x-killbill-apisecret' => ($region == 'uk') ? config('constant.KILL_BILL_SECRET') : config('constant.KILL_BILL_IRE_SECRET'),
                    "x-killbill-createdby" => $this->app_name
                ]
            ]))->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/paymentGateways/notification/barclay-card?" . $requestKeys[0] . "=" . $kbPaymentOrMethodID);
            $httpcode = $response->getStatusCode();

            Log::channel('custom')->info('httpcode of card', ['httpcode' => $httpcode, 'ResponseKILLBILL' => $response]);

            if ($httpcode == 200) {
                if ($request->has('kbPaymentId')) {

                    $soldi_order_id = $this->paymentToSoldi($request->kbPaymentId, $region, '');

                    Log::channel('custom')->info('soldi_id', ['soldiId' => $soldi_order_id]);
                    Log::channel('custom')->info('KILLBILL', ['KBILLCREDENTIALS' => [
                        'auth' => ($region == 'uk') ? [config('constant.KILL_BILL_USER_NAME'), config('constant.KILL_BILL_PASSWORD')] : [config('constant.KILL_BILL_IRE_USER_NAME'), config('constant.KILL_BILL_IRE_PASSWORD')],
                        'headers' => [
                            'Content-Type' => 'application/json',
                            'x-killbill-apikey' => ($region == 'uk') ? config('constant.KILL_BILL_APIKEY') : config('constant.KILL_BILL_IRE_APIKEY'),
                            'x-killbill-apisecret' => ($region == 'uk') ? config('constant.KILL_BILL_SECRET') : config('constant.KILL_BILL_IRE_SECRET'),
                            "x-killbill-createdby" => $this->app_name
                        ]
                    ]]);
                    return view('card_detail', ["soldi_order_id" => $soldi_order_id ?? 0]);
                }
                if ($request->has('kbPaymentMethodId')) {
                    $cardData = $this->getCardDetailsData($request->kbPaymentMethodId, $region)['status'];


                    if (!$cardData)
                        return view('card_detail', ["cardData" => false]);
                }


                return view('card_detail');

            } else {
                return view('payment_failed');
            }
        } catch (ClientException $e) {

            $responseData = json_decode($e->getResponse()->getBody(true),true);
            Log::channel('custom')->info('KillBillPaymentDataException', ['KillBillPaymentDataException' => $responseData]);
            return view('payment_failed',['status' => false, 'message' => $responseData['causeMessage']]);

        }
    }//------ End of killbillPaymentData() ------//

    /**
     * Get client secret
     */
    public function getClientSecret() {
        try
        {
            $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/paymentGateways/notification/plutus-stripe", [
                'body' => 'operation=clientSecret'
            ]);
            $response = $response->getBody();
            $clientSecret = json_decode($response->getContents())->clientSecret;
            Log::channel('custom')->info('getKillbillSecret()', ['getKillbillSecret()' => $response->getContents()]);
            return ['status' => 200, 'message' => 'Client secret found','data' => $clientSecret];
        } catch (ClientException $e) {
            $responseData = json_decode($e->getResponse()->getBody(true), true);
            Log::channel('custom')->info('getKillbillSecret(exception)', ['getKillbillSecret(exception)' => $responseData]);
            return ['status' => 500, 'message' => 'Client secret not found','data' => []];
        }
    }

    /**
     * @param Request $request
     * @return array
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function makeOrder()
    {
        $request = \request()->all();
        try {
          //  Log::channel('custom')->info('merchant_account_id', ['merchant_account_id' => $request->merchant_account_id]);
         /*
            if($request->merchant_account_id == "" or $request->merchant_account_id == null) {
                return ['status' => 400,'message' => 'Merchant id is required'];
            }*/
            Log::channel('custom')->info('makeOrder_request_receive', ['makeOrderRequest' => request()->all()]);
            if(request()->payment_by == 'cash') {
                $responseFromSoldi = $this->paymentToSoldi('',request()->header('Country'), $request->all());
                //$this->assignPunchCardUser($request->all());

                return ['status' => 200,'message' => 'Order is placed','data' =>
                    ['order_str' => [
                        'order_id' => $responseFromSoldi->data->order_str->order_id ?? 0,
                        'gatewayErrorCode' => '',
                        'gatewayErrorMsg' => '',
                        'client_secret' => '',
                        'payment_method' => ''

                    ]]];
            }
            else {
                //first payment to killbill
                $user = request()->user();
                $dataArray = [];
                $order_items = json_decode(request()->order_items);
                $amount = 0;
                if(\request()->has('split_data')){
                    foreach (json_decode(request()->split_data,true) as $value){
                        if($value['payment_by'] =='card'){
                            $amount = $value['ordamount'];
                        }
                    }
                    $dataArray[] = ['description' => 'Purchase Items', 'amount' => $amount, 'itemType' => 'EXTERNAL_CHARGE'];
                }elseif (\request()->has('giftCard')){
                    $amount = request()->amount;
                    $dataArray[] = ['description' => 'Purchase Items', 'amount' => \request()->amount, 'itemType' => 'EXTERNAL_CHARGE'];
                }else {
                    foreach ($order_items as $items) {
                        $totalAmount = 0;
                        $totalAmount = round((($items->prd_unitprice * $items->prd_qty) - $items->discount_amt), 2);
                        $dataArray[] = ['description' => $items->prd_name, 'amount' => $totalAmount, 'itemType' => 'EXTERNAL_CHARGE'];
                        $amount = $amount + $totalAmount;
                    }
                }

                $accountId = request()->user()->kill_bill_id;
                if (!\request()->has('engage_transaction_id') and request()->has('is_quick_pay') and request()->is_quick_pay) {
                    $cardData = collect($this->getUserCardsKB()['data']);
                    Log::channel('custom')->info('makeOrder_card_data', ['cardData' => $cardData]);
                    if ($cardData->isNotEmpty()) {
                        $cardData = $cardData->filter(function ($item) {

                            return $item['is_default'] == true;
                        });
                        $defaultCard = $cardData->values();
                        Log::channel('custom')->info('makeOrder_default_card', ['$defaultCard' => $defaultCard]);
                        if ($defaultCard->isNotEmpty()) {
                            $request['card_detail'] = json_encode([['paymentMethodId' => $defaultCard[0]['card_id'],
                                'card_type' => $defaultCard[0]['card_type']
                            ]
                            ]);

                        } else {
                            return ['status' => false, 'message' => 'Please add default card first'];
                        }
                    } else {
                        return ['status' => false, 'message' => 'Please add default card first.'];
                    }
                }

                request()->merge(['bCommit' => 'false', 'region' => request()->header('Country')]);
                if(\request()->has('payment_data')){
                    $carPayment = json_decode(request()->payment_data['card_detail'], true);
                }else{
                    $carPayment = json_decode(request()->card_detail, true);
                }

                Log::channel('custom')->error('makeOrder_card_payment', ['$carPayment' => $carPayment]);
                \request()->merge(['card_id' =>$carPayment[0]['paymentMethodId'] ]);
                $request['card_id'] = $carPayment[0]['paymentMethodId'];

                if(isset($carPayment[0]['card_type'])) {
                    request()->merge(['card_type' => $carPayment[0]['card_type']]);
                }
                else {
                    $request['card_type'] = '';
                }
                $response = "";
                try {
                    $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/invoices/charges/$accountId?autoCommit=true", [
                        'json' => $dataArray
                    ])->getBody();
                    Log::channel('custom')->info('makeOrder_invoices_charges', ['invoices/charges' => $response]);
                } catch (ClientException $e) {
                    $responseData = json_decode($e->getResponse()->getBody(true), true);
                    Log::channel('custom')->error('makeOrder_invoices_charges_error', ['invoices/charges' => $response]);
                    return ['status' => 500, 'message' => "Failed to process your payment"];
                }
                $recieveResponse1 = collect(json_decode($response));


                if ($recieveResponse1) {
                    $card_details = json_decode(request()->card_detail);
                    //calculate discount amount
                    $ord_items = collect(json_decode(request()->order_items,true));
                    $discount_amt = 0;
                    foreach ($ord_items as $ord_item) {
                        $discount_amt = isset($ord_item['discount_amt']) ? $ord_item['discount_amt'] : 0 + $discount_amt;
                    }


                    Log::channel('custom')->info('makeOrder_invoice_charges_response', ['$receiveRespose' => $recieveResponse1,'paymentMethodId' => request()->card_id,'amount_due' => round((request()->amount_due - $discount_amt), 2),'accountId' => $accountId]);
                    $receiveRespose = $this->getInvoiceUrl($recieveResponse1, request()->card_id, round($amount, 2), $accountId);
                    Log::channel('custom')->info('makeOrder_invoice_response', ['$receiveRespose' => $receiveRespose]);
                    if ($receiveRespose['status']) {
                        $data = explode('/', ltrim($receiveRespose['data']));


                        \request()->merge(['bCommit' => 'true']);

                        if(\request()->has('engage_transaction_id')){
                            DB::table('user_temp_payments')->where('invoice_id',\request()->engage_transaction_id)
                                ->update([ 'user_id' => $accountId, 'finale_payment' => json_encode(request()->all()), 'created_at' => Carbon::now(), 'updated_at' => Carbon::now(), 'payment_id' => $data[6]]);
                        }else{
                            DB::table('user_temp_payments')->insert([
                                ['invoice_id' => $recieveResponse1[0]->invoiceId, 'user_id' => $accountId, 'finale_payment' => json_encode(request()->all()), 'created_at' => Carbon::now(), 'updated_at' => Carbon::now(), 'payment_id' => $data[6]]
                            ]);
                        }


                        Log::channel('custom')->info('paymentMethodId', ['paymentMethodId' => request()->paymentMethodId]);
                        Log::channel('custom')->error('kb_payment_id', ['kb_payment_id' => $data[6]]);

                        //place order to soldi
                        $responseFromSoldi ='';
                        $engageTransactionID =0;
                        if(\request()->has('engage_transaction_id')){
                            $engageTransactionID = \request()->engage_transaction_id;
                        }else{
                            $responseFromSoldi = $this->paymentToSoldi($data[6],request()->header('Country'), request()->all());
                            if ($responseFromSoldi->success == 'TRUE') {
                                DB::table('user_temp_payments')->where('payment_id',$data[6])->delete();
                            }
                            else {
                                return ['status' => 500, 'message' => "Your order was not accepted!"];
                            }
                        }

                        //call get payment detail api
                        try {
                            $paymentResponse = $this->KB_CLIENT->request('GET', config('constant.KILL_BILL_URL') . "/1.0/kb/payments/$data[6]?withPluginInfo=true&withAttempts=false&audit=NONE")->getBody();
                            $paymentResponse = json_decode($paymentResponse);
                            Log::channel('custom')->info('$paymentResponse',['$paymentResponse'=>$paymentResponse]);

                            $client_secret = '';
                            $payment_method = '';
                            $gatewayErrorCode = '';
                            $gatewayErrorMsg = '';

                            foreach ($paymentResponse->transactions[0]->properties as $property) {
                                if($property->key == 'responseBody') {
                                    $propertyVal = json_decode($property->value);
                                    Log::channel('custom')->info('$propertyVal', ['$propertyVal' => $propertyVal]);
                                    $client_secret = $propertyVal->client_secret??'';
                                    $payment_method = $propertyVal->charges->data[0]->payment_method??'';
                                }
                            }
                            $gatewayErrorCode = $paymentResponse->transactions[0]->gatewayErrorCode;
                            $gatewayErrorMsg = $paymentResponse->transactions[0]->gatewayErrorMsg;
                            $responseUrl ='';
                            if($this->payment_method =='world_pay' and $paymentResponse->transactions[0]->status =='SUCCESS'){
                                $dataRecieve= (new PaymentController())->paymentToSoldi($data[6],$data->region??$data['region'],'');
                            }elseif ($this->payment_method =='world_pay' and  $paymentResponse->transactions[0]->status =='PENDING'){
                                Log::channel('custom')->info('Pending',['pending' => $data[6],'account' => $accountId]);
                                $responseUrl = $this->getPreAuthorizedLink($accountId, $data[6],$paymentResponse->paymentMethodId);

                            }elseif(request()->has('split_data')){

                            }else {
                                $this->assignPunchCardUser(request()->all(), $responseFromSoldi->data->order_str->order_id??$responseFromSoldi->data->order_id);
                            }
                            return ['status' => 200,'message' => 'Order is placed','data' =>
                                ['order_str' => [
                                    'order_id' => $responseFromSoldi->data->order_str->order_id ?? $responseFromSoldi->data->order_id??$dataRecieve??0,
                                    'gatewayErrorCode' => $gatewayErrorCode,
                                    'engage_transaction_id'=>$engageTransactionID,
                                    'gatewayErrorMsg' => $gatewayErrorMsg,
                                    'client_secret' => $client_secret,
                                    'order_amount' => $amount,
                                    'payment_method' => $payment_method,
                                    'payment_method_id' =>$data[6],
                                    'client_html' => $responseUrl
                                ]]];
                        }
                        catch(ClientException $e) {
                            $responseData = json_decode($e->getResponse()->getBody(true), true);
                            Log::channel('custom')->error('payment detail', ['payment detail response' => $responseData]);
                            return ['status' => false, 'message' => 'Failed to process your payment'];
                        }
                        //return $this->getPaymentLink($accountId, $data[6], $card_details[0]->paymentMethodId);
                    }
                    return ['status' => false, 'message' => 'Failed to process your payment'];
                }
                else {
                    return ['status' => 500, 'message' => "Failed to process your payment"];
                }
            }

        } catch (\Exception $e) {
            Log::channel('custom')->error('makeOrder()', ['makeOrder()' => $e->getMessage(),'makeOrder_error_line' => $e->getLine()]);
            return ['status' => 500,'message' => $e->getMessage()];
        }

    }//------ End of userPaymentKB() ------//

    /**
     * @param $responseData
     * @param $cardDetail
     * @param $dueAmount
     * @param $user
     * @return array
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function getInvoiceUrl($responseData, $paymentMethodId, $dueAmount, $user)
    {
        try {
            $jsonData = [
                'paymentMethodId' => $paymentMethodId,
                'targetInvoiceId' => $responseData[0]->invoiceId,
                'accountId' => $user,
                'purchasedAmount' => round($dueAmount, 2)
            ];
            Log::channel('custom')->info('$jsonData', ['$jsonData' => $jsonData]);
            $invoiceId = $responseData[0]->invoiceId;
            $merchantId = \request()->merchant_account_id??'';
            if(empty($merchantId)) {
                Log::channel('custom')->info('car detail', ['invoice_url' => config('constant.KILL_BILL_URL') . "/1.0/kb/invoices/$invoiceId/payments?externalPayment=false"]);
                $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/invoices/$invoiceId/payments?externalPayment=false", [
                    'json' => $jsonData
                ])->getHeaders();
            }else{
                Log::channel('custom')->info('car detail', ['invoice_url' => config('constant.KILL_BILL_URL') . "/1.0/kb/invoices/$invoiceId/payments?externalPayment=false&pluginProperty=merchantAccountID=$merchantId"]);
                $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/invoices/$invoiceId/payments?externalPayment=false&pluginProperty=merchantAccountID=$merchantId", [
                    'json' => $jsonData
                ])->getHeaders();
            }
            Log::channel('custom')->info('$response_invoice', ['$response_invoice' => $response]);
            if (array_key_exists('Location', $response)) {
                $url = $response['Location'][0];
                Log::channel('custom')->info('invoice url', ['invoice url' => $url]);
                return ['status' => true, 'data' => $url];
            }

            else {
                Log::channel('custom')->info('invoice url', ['invoice url' => 'else']);
                return ['status' => false, 'data' => ''];
            }



        } catch (ClientException $e) {
            $responseData = json_decode($e->getResponse()->getBody(true), true);
            Log::channel('custom')->error(['getInvoiceUrl' => ['getInvoiceUrl' => $responseData]]);
            return ['status' => false, 'data' => ''];
        }
    }//----- End of getInvoiceUrl() -----//

    /**
     * @param $accountID
     * @param $paymentID
     * @param $paymentMethodId
     * @return array
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function getPaymentLink($accountID, $paymentID, $paymentMethodId)
    {
        try {
            $jsonData = ["formFields" => [["key" => "operation", "value" => "getPaymentUrl", "isUpdatable" => true], ["key" => "kbPaymentId", "value" => $paymentID, "isUpdatable" => true]]];

            $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/paymentGateways/hosted/form/$accountID?paymentMethodId=$paymentMethodId", [
                'json' => $jsonData
            ])->getBody()->getContents();

            return ['status' => true, 'link' => json_decode($response)->formUrl];

        } catch (\Exception $e) {
            return ['status' => false];
        }
    }//----- End of getPaymentLink() -----//

    /**
     * @param Request $request
     * @return array
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function deleteCard(Request $request)
    {
        try {
            Log::channel('custom')->info(['card data' => ['card data' => $request->all()]]);
            $paymentMethodId = $request->payment_method_id;

            $response = $this->KB_CLIENT->request('DELETE', config('constant.KILL_BILL_URL') . "/1.0/kb/paymentMethods/$paymentMethodId?deleteDefaultPmWithAutoPayOff=true&forceDefaultPmDeletion=true")->getBody()->getContents();
            Log::channel('custom')->info('Card Delete', ['CardDelete' => $response]);

            return ['status' => 200, 'message' => "Card Deleted Successfully"];
        } catch (\Exception $e) {
            Log::channel('custom')->error('Card Delete', ['CardDelete' => $e->getMessage()]);
            if (strpos($e->getMessage(), '"code":7019') !== false) {
                return ['status' => 500, 'message' => 'Default card cannot be deleted'];
            }
            return ['status' => 500, 'message' => 'Card not deleted'];
        }
    }//----- End of deleteCard() ------//

    /**
     * @param string $kbPaymentId
     * @return array|int
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function paymentToSoldi($kbPaymentId = '', $region = '', $finaleData = [])
    {
        /*        if (!empty($kbPaymentId)) {
                    $paymentDetails = DB::table('user_temp_payments')->where('payment_id', $kbPaymentId)->first();
                    $finaleData = json_decode($paymentDetails->finale_payment, true);
                    $finaleData['payment_id'] = $kbPaymentId;
                    $finaleData['region'] = $region;
                    $finaleData['card_id'] = json_decode($finaleData['card_detail'], true)[0]['paymentMethodId'];
                }*/


        try {
            /*         $APIKEY = config('constant.SOLDI_API_KEY');
                     $SECRET = config('constant.SOLDI_SECRET');*/
            if(\request()->has('api_key') and request()->has('secret_key')) {
                $APIKEY = \request()->api_key;
                $SECRET = \request()->secret_key;
            }else{
                $APIKEY = config('constant.SOLDI_API_KEY');
                $SECRET = config('constant.SOLDI_SECRET');
            }

            Log::channel('custom')->info('forwarding Data to soldi', ['$APIKEY' => $APIKEY, '$SECRET' => $SECRET]);
            $finaleData['payment_id'] = $kbPaymentId;
            Log::channel('custom')->info('forwarding Data to soldi', ['dataToSOldi' => $finaleData]);
            $url = '';
            if(\request()->has('gift_card') ){
                $url = '/giftcard/purchase';

            }else {
                $url = '/orders/placeorder';

            }
            $response = (new Client([
                'headers' => [
                    'Content-Type' => 'application/json',
                    'X-API-KEY' => $APIKEY,
                    'SECRET' => $SECRET
                ]
            ]))->request('POST', config('constant.SOLDI_DEFAULT_PATH') .$url , [
                'json' => $finaleData
            ]);

            $soldi_res = $response->getBody()->getContents();
            $soldi_res = json_decode($soldi_res);
            Log::channel('custom')->info('Soldi Response', ['SoldiResponse1' => $response->getBody()]);
            Log::channel('custom')->info('Soldi Response', ['SoldiResponse' => $soldi_res]);
            return $soldi_res;
        } catch (Exception $e) {
            Log::channel('custom')->error('Response ', ['ResponseSoldi' => $e->getMessage()]);
            return ["status" => false, "message" => "Error " . $e->getMessage()];
        }
    }//----- End of paymentToSoldi() -----//

    /**
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function insertAllUser()
    {
        $users = User::whereNotNull('soldi_id')->where('soldi_id', '!=', '0')->whereNull('kill_bill_id')->get();

        foreach ($users as $user)
            $this->registerUserToKB($user);

        return ['status' => true];
    }//----- End of insertAllUser() -----//

    /**
     * @param Request $request
     * @return array
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function refundDataToKB(Request $request)
    {
        try {
            Log::channel('custom')->info(['Refund data' => ['RefundData' => $request->all()]]);
            $jsonData = ['paymentId' => $request->payment_id, 'amount' => $request->amount, 'currency' => $request->currency];

            $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/payments/hosted/$request->payment_id/refunds/", [
                'json' => $jsonData
            ])->getBody()->getContents();

            Log::channel('custom')->info('Refund Data', ['REFUNDRESPOSNE' => $response]);

            return ['status' => true, 'message' => "Refund data Successfully"];
        } catch (\Exception $e) {
            Log::channel('custom')->error('Card Delete', ['CardDelete' => $e->getMessage()]);
        }
    }//---- End of refundDataToKB() -----//

    /**
     * @param $kbPaymentMethodId
     * @return array
     */
    public function getCardDetailsData($kbPaymentMethodId, $region)
    {
        $request = (new Client([
            'auth' => ($region == 'uk') ? [config('constant.KILL_BILL_USER_NAME'), config('constant.KILL_BILL_PASSWORD')] : [config('constant.KILL_BILL_IRE_USER_NAME'), config('constant.KILL_BILL_IRE_PASSWORD')],
            'headers' => [
                'Content-Type' => 'application/json',
                'x-killbill-apikey' => ($region == 'uk') ? config('constant.KILL_BILL_APIKEY') : config('constant.KILL_BILL_IRE_APIKEY'),
                'x-killbill-apisecret' => ($region == 'uk') ? config('constant.KILL_BILL_SECRET') : config('constant.KILL_BILL_IRE_SECRET'),
                "x-killbill-createdby" => $this->app_name
            ]
        ]))->get(config('constant.KILL_BILL_URL') . "/1.0/kb/paymentMethods/$kbPaymentMethodId?includedDeleted=false&withPluginInfo=true&audit=NONE", [], [])->getBody();
        $data = collect(json_decode($request, true));
        if ($data->isNotEmpty()) {
            foreach ($data['pluginInfo']['properties'] as $data) {
                if ($data['key'] == 'cardInfo' && empty($data['value']))
                    return ['status' => false];
            }
            return ['status' => true];
        }
        return ['status' => true];
    }//----- End of getCardDetailsData() -----//

    /**
     * @param $data
     * @param $user
     * @return array
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    private function resgisterToIRE($data, $user)
    {
        try {
            $data['currency'] = 'EUR';

            Log::channel('custom')->info('Ireland register', ['REGISTERTO' => $data]);
            $ireClient = (new Client([
                'auth' => [config('constant.KILL_BILL_IRE_USER_NAME'), config('constant.KILL_BILL_IRE_PASSWORD')],
                'headers' => [
                    'Content-Type' => 'application/json',
                    'x-killbill-apikey' => config('constant.KILL_BILL_IRE_APIKEY'),
                    'x-killbill-apisecret' => config('constant.KILL_BILL_IRE_SECRET'),
                    "x-killbill-createdby" => $this->app_name
                ]
            ]));
            $requestForIRE = $ireClient->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/accounts", [
                'json' => $data
            ])->getHeaders();

            if (array_key_exists('Location', $requestForIRE)) {
                Log::channel('custom')->info('Response Irelans', ['Data' => $requestForIRE]);

                $ukUrl = $requestForIRE['Location'][0];

                User::where('user_id',$user->user_id)->update([
                    'kilbill_ire_id' =>basename($ukUrl)
                ]);
                $ireClient->request('POST', $ukUrl . '/tags', [
                    'json' => ["00000000-0000-0000-0000-000000000001"]
                ]);
                return ['status' => true];
            }
        }catch (\Exception $e){
            Log::channel('custom')->error('EROOR Register',['EROORINIRE'=>$e->getMessage()]);
        }
    }//----- End of resgisterToIRE() ------//

    /**
     * @param string $data
     * @return array|\Psr\Http\Message\StreamInterface
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function assignPunchCardUser($data = [],$orderId = 0)
    {
        try {
            $user = User::where('soldi_id',$data['customer_id'])->first();
            //get category_product_punch
            $punchCards = PunchCard::where('redemption_type', 'category_product')->where('business_id',request()->business_id)
                ->whereNotNull('voucher_id')->whereNull('deleted_at')->get();
            Log::channel('custom')->info('$punchCards',['$punchCards'=>$punchCards]);
            foreach ($punchCards as $punchCard){
                if($punchCard->rule_on == 'product') {
                    $ord_items = collect(json_decode($data['order_items'],true));
                    Log::channel('custom')->info('$ord_items',['$ord_items'=> $ord_items->toArray()]);
                    $product = $ord_items->where('prd_id',$punchCard->product_id)->first();
                    if($product['prd_qty'] > 0) {
//                        \request()->request->add([
//                            'company_id' => \config('constant.COMPANY_ID'),
//                            'stampid' => $punchCard->id,
//                            'userID' => $user->user_id,
//                            'stampassign' => $product['prd_qty'],
//                            'notify' => true,
//                            'addStamps' => true,
//                            'voucher_apply_count' => $punchCard['no_of_use'],
//                        ]);
                        Log::channel('custom')->info('stampCardAssign()_before_product',['stampCardAssign()_before_product'=>\request()->all()]);


                        $amount = $data['amount_due'];
                        $through = "Product Stamp";
                        $user_id = $data['user_id'];
                        request()->merge(["company_id" => \config('constant.COMPANY_ID'),
                            "venue_id" => "295255", "stampid" => $punchCard->id, "userID" => $user_id,
                            "mrcht_id" => "0", "stampassign" => $product['prd_qty'],
                            'business_name' => $punchCard->business_name != null ? $punchCard->business_name : '',
                            'addStamps' => false, 'notify' => true, 'assign_through' => $through]);

                        (new ElasticSearchController())->stampCardAssign();
                    }
                }
                else {
                    //Log::channel('custom')->info('order_items_log',['order_items_log'=> json_decode($data['order_items'],true)]);
                    $ord_items = collect(json_decode($data['order_items'],true));

                    $prod_qty_count = 0;
                    $ord_items = $ord_items->where('cate_id',$punchCard->category_id)->all();
                    foreach($ord_items as $ord_item) {
                        $prod_qty_count = $prod_qty_count +  $ord_item['prd_qty'];
                    }
                    Log::channel('custom')->info('$category_count',['$category_count'=> $prod_qty_count]);
                    if($prod_qty_count > 0){
                        $business = json_decode($punchCard->businesses);
//                        \request()->request->add([
//                            'company_id' => \config('constant.COMPANY_ID'),
//                            'stampid' => $punchCard->id,
//                            'userID' => $user->user_id,
//                            'stampassign' => $prod_qty_count,
//                            'notify' => true,
//                            'addStamps' => true,
//                            'voucher_apply_count' => $punchCard['no_of_use'],
//                            'business_name' => isset($business[0]) ? $business[0]->business_name : ''
//                        ]);
                        Log::channel('custom')->info('stampCardAssign()_category before',['stampCardAssign()_category before'=>\request()->all()]);
                             $through = "Category Stamp";
                        $user_id = $data['user_id'];
                        request()->merge(["company_id" => \config('constant.COMPANY_ID'),
                            "venue_id" => "295255", "stampid" => $punchCard->id, "userID" => $user_id,
                            "mrcht_id" => "0", "stampassign" => $prod_qty_count,
                            'business_name' => $punchCard->business_name != null ? $punchCard->business_name : '',
                            'addStamps' => false, 'notify' => true, 'assign_through' => $through]);
                        (new ElasticSearchController())->stampCardAssign();
                    }

                }
            }

            //get transaction_value punch
            //$punchCard = PunchCard::where('redemption_type', 'transaction_value')->where('business_id',request()->business_id)->whereNull('deleted_at')->get();
            $punchCard = PunchCard::where('redemption_type', 'transaction_value')->where('business_id',request()->business_id)
                ->whereNotNull('voucher_id')->whereNull('deleted_at')->get();
            foreach ($punchCard as $punchData) {
                //calculate discount amount
                $discount_amt = 0;
                $ord_items = collect(json_decode($data['order_items'],true));
                foreach ($ord_items as $ord_item) {
                    $discount_amt = isset($ord_item['discount_amt']) ? $ord_item['discount_amt'] + $discount_amt : 0 + $discount_amt;
                }
                Log::channel('custom')->info('punch_discount' . $discount_amt);
                $punch = intval(($data['amount_due'] - $discount_amt) / $punchData->transaction_threshold);
                Log::channel('custom')->info('transaction_threshold' . $punchData->transaction_threshold);
                Log::channel('custom')->info('amound_due' . $data['amount_due']);
                Log::channel('custom')->info('Punch after divide' . $punch);
                //----- If punch is greater than zero;
                if($punch > 0){
                    $business = json_decode($punchData->businesses);
//                    \request()->request->add([
//                        'company_id' => \config('constant.COMPANY_ID'),
//                        'stampid' => $punchData->id,
//                        'userID' => $user->user_id,
//                        'stampassign' => $punch,
//                        'notify' => true,
//                        'addStamps' => true,
//                        'voucher_apply_count' => $punchData['no_of_use'],
//                        'business_name' => isset($business[0]) ? $business[0]->business_name : ''
//                    ]);
                    Log::channel('custom')->info('stampCardAssign() before',['stampCardAssign() before'=>\request()->userID]);
                    $user_id = $data['user_id'];
                    $amount = $data['amount_due'];
                    $through = "From Transaction: $amount invoice # $orderId";
                    request()->merge(["company_id" => \config('constant.COMPANY_ID'),
                        "venue_id" => "295255", "stampid" => $punchData->id, "userID" => $user_id,
                        "mrcht_id" => "0", "stampassign" => $punch,
                        'business_name' => $punchData->business_name != null ? $punchData->business_name : '',
                        'addStamps' => false, 'notify' => true, 'assign_through' => $through]);

                    Log::channel('custom')->info('stampCardAssign()_before',['stampCardAssign()_before'=>\request()->all()]);

                    (new ElasticSearchController())->stampCardAssign();
                }
            }
        } catch (\Exception $e) {
            Log::channel('custom')->error('Error Occured in punch card assign' . $e->getMessage());
        }
    }//------ End of assignPunchCardUser() -------//

    /**
     * @param $punch_card_data
     * @param $json_decode
     * @return bool
     */
    private function applicablePunchCard($punch_card_data, $json_decode)
    {
        $exists = false;
        $availType = collect($punch_card_data);

        $paymentProducts = collect($json_decode);

        $productIDs = $availType->where('voucher_avail_type', 'product')->pluck('voucher_avail_type_id');
        $categoryIDs = $availType->where('voucher_avail_type', 'category')->pluck('voucher_avail_type_id');
        $find = $paymentProducts->whereIn('prd_id', $productIDs);
        $categoryFind = $paymentProducts->whereIn('cate_id', $categoryIDs);
        //------ For Product Exists
        if ($find->isNotEmpty())
            $exists = true;

        //------ For Category Exists
        if ($categoryFind->isNotEmpty())
            $exists = true;

        return $exists;
    }//------- End of applicablePunchCard() ------//

    /**
     * @return array
     */
    public function valideteIbsVouchers()
    {
        try {

            if (request()->header('app-key') and (request()->header('app-key') === \config('constant.IBS_VERIFICATION')) and request()->voucher_code) {
                $query = [
                    "query" => [
                        'bool' => [
                            'must' => [
                                [ 'match' => [ 'custom_doc_type' => config('constant.user_integrated_voucher') ]],
                                [ 'term' => [ 'voucher_code' => [ "value" => request()->voucher_code ]]]
                            ]
                        ]
                    ]
                ];
                if (request()->has('customer_id')) {
                    $user = User::where('client_customer_id', request()->customer_id)->first();
                    if($user)
                        $query['query']['bool']['must'][] = ['term' => ['persona_id' => $user->user_id]];
                    else
                        return ['status'=>false,'message'=>'User Not Exists'];

                }

                $validVoucher = ElasticsearchUtility::count(config('constant.ES_INDEX_BASENAME'), $query);
                if($validVoucher>0)
                    return ['status' => true, 'message' => 'Voucher exists'];
                else
                    return ['status' => false, 'message' => 'Voucher not exists'];
            } else {
                return ['status' => false, 'message' => (!request()->header('app-key')   and !request()->voucher_code) ? 'Please enter valid app key and voucher' : ((!request()->voucher_code) ? "Please Provide Voucher Code" : ((request()->header('app-key') !== \config('constant.IBS_VERIFICATION')) ? "Invalid App Key" : "Please provide a valid app key"))];
            }
        } catch (\Exception $e) {
            return ['message' => $e->getMessage()];
        }
    }//----- End of valideteIbsVouchers() ------//

    public function updateVoucherStatus($voucherCodes = [], $userId = '')
    {
        if(count($voucherCodes) > 0) {
            Log::channel('custom')->info('voucher codes',['voucher codes'=>$voucherCodes]);
            $query = [
                'script' =>
                    [
                        'source' => 'ctx._source.uses_remaining -=1',
                        'lang' => 'painless',
                    ],
                'query' => ['bool' => ['must' =>
                    [['term' => ['custom_doc_type' => 'user_integrated_voucher']], ['terms' => ['voucher_code' => $voucherCodes]], ['term' => ['persona_id' => $userId]], ['range' => ['uses_remaining' => ['gt' => '0']]]],

                ]]];
            Log::channel('custom')->info('voucher update query',['voucher update query'=>$voucherCodes]);
            return ElasticsearchUtility::updateByQuery(config('constant.ES_INDEX_BASENAME'), $query);
        }
    }
    public function getVouhcerCodes($finaleData) {
        $order_items = json_decode($finaleData['order_items'],true);
        Log::channel('custom')->error('order items',['order items'=>$order_items]);
        $arr = [];
        foreach ($order_items as $item) {
            if(isset($item['voucher_code']) and $item['voucher_code'] != '') {
                $arr[] = $item['voucher_code'];
            }
        }
        if(count($arr) > 0) {
            $arr = array_unique($arr);
            return $arr;
        } else {
            return [];
        }
    }

    public function updatePaymentStatus(Request $request)
    {
        try {
            Log::channel('custom')->info('updatePaymentStatus',['updatePaymentStatus'=>$request->all(),'content' => \request()->getContent()]);
            $stripeData = $request->all();
            if(\request()->has('engage_invoice_id') || $request->has('MD')){
                if(request()->has('engage_invoice_id')) {
                    $data = DB::table('user_temp_payments')->where('invoice_id', \request()->engage_invoice_id ?? $request->MD)->first();
                    $dataRecieve = (new PaymentController())->paymentToSoldi($data->payment_id ?? $data['payment_id'], $data->region ?? $data['region'], '');
                    if($dataRecieve>0) {
                        return ['status' => true, 'message' => 'successfully updated','soldi_id' => $dataRecieve];
                    }else{
                        return ['status' => false, 'message' => 'Order Not Completed','soldi_id' => $dataRecieve];
                    }
                }else{
                    if( $request->PaRes=='IDENTIFIED') {
                        $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/paymentGateways/notification/world_pay?pluginProperty=threeDSResponseCode=IDENTIFIED", [
                            'body' => "kbPaymentId=$request->MD"
                        ]);
                        $dataRecieve = (new PaymentController())->paymentToSoldi($request->MD, 'uk', '');
                        if ($dataRecieve > 0) {
                            return view('card_detail', ["soldi_order_id" => $dataRecieve ?? 0]);
                        } else {
                            return view('card_detail', ["soldi_order_id" => $dataRecieve ?? 0]);
                        }
                    }else if( $request->has('PaymentStatus') and $request->PaymentStatus=='Authorised'){
                        $data = DB::table('user_temp_payments')->where('payment_id', \request()->PaymentId)->first();
                        $dataRecieve = (new PaymentController())->paymentToSoldi(request()->PaymentId, $data->region ?? $data['region'], '');
                        if($dataRecieve>0) {
                            return ['status' => true, 'message' => 'successfully updated','soldi_id' => $dataRecieve];
                        }else{
                            return ['status' => false, 'message' => 'Order Not Completed','soldi_id' => $dataRecieve];
                        }
                    }else{
                        return view('card_detail', ["soldi_order_id" =>  0]);
                    }
                }

            }
            if(!\request()->has('MD') and ((isset($stripeData['type']) and ($stripeData['type'] == 'payment_intent.succeeded')) || (isset($stripeData['PaymentStatus']) and $stripeData['PaymentStatus'] =='Authorised'))) {
                //update payment status to killbill
                $kb_payment_id = $stripeData['data']['object']['metadata']['kb_payment_id']??$stripeData['PaymentStatus'];
                $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/paymentGateways/notification/plutus-stripe", [
                    'body' => "kbPaymentId=$kb_payment_id"
                ]);
                if($response->getStatusCode() == 200) {
                    //update payment status in mysql
                }

                if( $stripeData['data']['object']['metadata']['kb_payment_id']){
                    $data = DB::table('user_temp_payments')->where('payment_id', $stripeData['data']['object']['metadata']['kb_payment_id'])->first();
                    if($data) {
                        $dataRecieve = (new PaymentController())->paymentToSoldi($data->payment_id ?? $data['payment_id'], $data->region ?? $data['region'], '');
                        if ($dataRecieve > 0) {
                            return ['status' => true, 'message' => 'successfully updated', 'soldi_id' => $dataRecieve];
                        } else {
                            return ['status' => false, 'message' => 'Order Not Completed', 'soldi_id' => $dataRecieve];
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            Log::channel('custom')->error('updatePaymentStatusError',['updatePaymentStatusError'=> $e->getMessage()]);
        }
    }



    public function makeOrderOld(Request $request)
    {
        $soldi_res->data->order_str->order_id ?? 0;
        try {
            $responseFromSoldi  = $this->paymentToSoldi('','',$request->all());

            return ['status' => 200,'message' => 'Order is placed','data' => ['order_str' => ['order_id' => $order_id]]];
        } catch (\Exception $e) {
            Log::channel('custom')->error('Error Occured in make order assign' . $e->getMessage());
            return ['status' => false,'message' => $e->getMessage()];
        }
    }//------ End of assignPunchCardUser() -------//

    public function test() {
        try {
            $paymentResponse = $this->KB_CLIENT->request('GET', config('constant.KILL_BILL_URL') . "/1.0/kb/payments/d2b9b411-04ed-4ada-b2a4-4c9f9d75ca47?withPluginInfo=true&withAttempts=false&audit=NONE")->getBody();
            $paymentResponse = json_decode($paymentResponse);
            $client_secret = '';
            $payment_method = '';
            $gatewayErrorCode = '';
            $gatewayErrorMsg = '';

            foreach ($paymentResponse->transactions[0]->properties as $property) {
                if($property->key == 'responseBody') {
                    $propertyVal = json_decode($property->value);
                    Log::channel('custom')->info('$propertyVal', ['$propertyVal' => $propertyVal]);
                    $client_secret = $propertyVal->client_secret;
                    $payment_method = $propertyVal->charges->data[0]->payment_method;
                }
            }
            $gatewayErrorCode = $paymentResponse->transactions[0]->gatewayErrorCode;
            $gatewayErrorMsg = $paymentResponse->transactions[0]->gatewayErrorMsg;
            return ['status' => 200,'message' => 'Order is placed','data' =>
                ['order_str' => [
                    'order_id' => $responseFromSoldi->data->order_str->order_id ?? 0,
                    'gatewayErrorCode' => $gatewayErrorCode,
                    'gatewayErrorMsg' => $gatewayErrorMsg,
                    'client_secret' => $client_secret,
                    'payment_method' => $payment_method

                ]]];

        }
        catch(\Exception $e) {
            Log::channel('custom')->error('payment detail', ['payment detail response' => $e->getMessage()]);
            return ['status' => false, 'message' => 'Failed to process your payment'];
        }
    }


    public function getPreAuthorizedLink($acountid,$kbpaymentid,$paymentMethodId)
    {
        $data = ["formFields" => [["key" => "kbPaymentId", "value" => $kbpaymentid, "isUpdatable"=> true]]];
        $paymentResponse = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/paymentGateways/hosted/form/$acountid?paymentMethodId=$paymentMethodId", [
            'json' => $data
        ])->getBody();
        Log::channel('custom')->info('getPreAuthorizedLink', ['getPreAuthorizedLink' => $paymentResponse]);

        $paymentResponse =json_decode($paymentResponse);
        return $paymentResponse->properties->clientHtml;

    }

    public function loadHtmlData($html){
        $content = "";
        $doc = new \DOMDocument();
        $doc->loadHTML($html);
        $foo = $doc->getElementsByTagName('body');
        $bar = $doc->createElement('script','  var userAgent = window.navigator.userAgent.toLowerCase(),
        var obj ={status:true}
        ios = /iphone|ipod|ipad/.test( userAgent );
function clickEvent() {

        // if iPhone
        if (ios) {
            window.webkit.messageHandlers.MobileEvent.postMessage(obj);
        } else {

            // For Android
            if(window.MobileEvent)
                window.MobileEvent.textFromWeb(obj);
        }
    }

    window.onload = clickEvent;');
        $first = $doc->documentElement->appendChild($bar);
        /* $first->appendChild($bar);*/

        $content = $doc->saveHTML();

    return $content;

    }
}
