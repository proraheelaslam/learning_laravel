<?php

namespace App\Http\Controllers\API;

use App\Models\Gym;
use App\Models\Setting;
use App\Models\SurveyQueue;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Validation\Validator;

class SitesApiController extends Controller
{
    //
    public function getGyms(Request $request)
    {
        $sites = Gym::get();
        $data['status'] = true;
        $data['message'] = 'Data found!';
        $data['content_list'] = $sites;
        return json_encode($data);
    }

    public function getGymTimetable(Request $request)
    {
        $data = [];
        $cat = [
            ['state' => 'NSW'],
            ['state' => 'ACT'],
            ['state' => 'QLD'],
            ['state' => 'TA'],
            ['state' => 'NT'],
            ['state' => 'SA'],
            ['state' => 'VIC'],
            ['state' => 'WA'],
        ];
        foreach ($cat as $k => $c) {
            $cat[$k]['contents'] = Gym::whereState($c['state'])->get();
        }
        $data['status'] = true;
        $data['message'] = 'Data found!';
        $data['content_list'] = $cat;


        return $data;
    }

    public function getTagsSettings()
    {
        $settings = Setting::where('type','tag_settings')->first();
        $tags = json_decode($settings->field2,true) ?? [];

        //get meta tags
        $meta_arr = ['tagTitle' => "Meta"];
        $queues = SurveyQueue::select('meta')->get()->toArray();
        foreach ($queues as $queue) {
            $meta = json_decode($queue['meta'],true);
            if(isset($meta) and count($meta) > 0) {
                foreach ($meta as $key => $value) {
                    //$arr[] = ['id' => $key, 'text' => ucwords(str_replace('_',' ',$key))];
                    $meta_arr['tags'][] = ['subTitle' => ucwords(str_replace('_',' ',$key)), 'tagName' => $key,'status' => true];
                }
            }
        }

        if(isset($meta_arr['tags'])) {
            $tags_arr = collect($meta_arr['tags']);
            $tags_arr = $tags_arr->unique('subTitle');
            $tags_arr = $tags_arr->values()->all();
            $meta_arr['tags'] = $tags_arr;
        }

        if(isset($meta_arr['tags']))
            $tags[] = $meta_arr;
        
        return ['status' => true,'data' => $tags];
    }

    public function saveTagsSettings()
    {
        Setting::updateOrCreate(['type' => 'tag_settings'],['type' => 'tag_settings','field2' => request()->data]);
        return ['status' => true, 'message' => 'Updated Successfully'];
    }


}
