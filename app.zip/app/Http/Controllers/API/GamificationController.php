<?php

namespace App\Http\Controllers\API;

use App\Exports\GameMissionExport;
use App\Exports\SurveyStatsJsonExport;
use App\Models\Badge;
use App\Models\BadgeState;
use App\Models\Campaign;
use App\Models\CompetitionUserEntry;
use App\Models\GameUserEntry;
use App\Models\Mission;
use App\Models\MissionUserEntry;
use App\Models\Recipe;
use App\Models\Segment;
use App\Models\Setting;
use App\Models\SurveyFront;
use App\Models\SurveyQuestionAnswers;
use App\Models\SurveyQueue;
use App\Models\UserReceipts;
use App\Models\Venue;
use App\Utility\ElasticsearchUtility;
use App\Utility\Gamification;
use App\Http\Controllers\Controller;
use App\Utility\Segmentation;
use App\Utility\TagReplacementUtility;
use App\Utility\VCTrigger;
use Carbon\Carbon;
use Exception;
use GuzzleHttp\Client;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;
use App\User;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Intervention\Image\ImageManagerStatic as Image;

class GamificationController extends Controller
{
    /*sonar constants*/
    const USER_SIGNUP = 'user_sign_up';
    const USER_GPS_DETECT = 'user_gps_detect';
    const TITLE = 'title';
    const START_DATE = 'start_date';
    const END_DATE = 'end_date';
    const DATE_FORMAT = 'Y-m-d';
    const STATUS = 'status';
    const SCAN_QR_CODE = 'scan_qr_code';
    const VALUE = 'value';
    const TRIGGERS = 'triggers';
    const MESSAGE = 'message';


    private $gObj;
    private $games;
    private $userMissions;
    private $segmentation;
    public $missionsFound;
    public $qrCodeIsCompetition;
    public $campaignsData;
    public $setting;
    public $userFound;

    public function __construct()
    {
        $this->gObj = new Gamification;
        $this->missionsFound = false;
        $this->qrCodeIsCompetition = $this->gObj->qrCodeIsCompetition();
        $this->getSettings();

    }//..... end of __construct() .....//

    /**
     * @return array|Collection
     * Handle customer scan qr code.
     */
    public function customerScannedQrCode()
    {
        $validation = Validator::make(request()->all(), [
            'qr_code' => 'required'
        ]);
        $key = "qr_code_" . request()->qr_code . "_" . request()->user()->user_id;

        //...... stop multiple requests  .....//
        $key_exists = Redis::get($key);
        if ($key_exists) {
            $diff = time() - Redis::get($key);
            if ($diff <= 5) {
                return [self::STATUS => false, self::MESSAGE => ''];
            } else {
                Redis::set($key, strtotime(date("Y-m-d H:i:s")));
            }
        } else {
            Redis::set($key, strtotime(date("Y-m-d H:i:s")));
        }
        //...... end of stop multiple requests  .....//

        if ($validation->fails()) {
            return [self::STATUS => false, self::MESSAGE => 'Please provide missing params: QR code'];
        }//...... end if() ......//

        $this->segmentation = new Segmentation(ElasticsearchUtility::generateIndexName(config('constant.COMPANY_ID'), request()->user()->default_venue));
        $this->filterCampaignsForActiveGamesAndMissions();
        $qrCodesMissions = $this->checkMissionsForQrCodes();


        if ($qrCodesMissions->isEmpty()) {
            return [self::STATUS => false, self::MESSAGE => 'Stuck in a glitch? Try scanning the QR code again, or check out our help section..', self::TRIGGERS => []];
        }

        $this->userMissions = $this->gObj->setActiveMissions($qrCodesMissions, request()->user());

        if ($this->userMissions->isEmpty()) {
            if ($qrCodesMissions->isNotEmpty()) {
                if ($this->gObj->lastEntry) {
                    return [self::STATUS => ($this->qrCodeIsCompetition) ? true : false, 'type' => ($this->qrCodeIsCompetition) ? "petpack" : "normal", self::MESSAGE => "Qr Code is already scanned.", self::TRIGGERS => []];
                }
                //..... this message will be changed letter  ......//
                return [self::STATUS => false, self::MESSAGE => "Stuck in a glitch? Try scanning the QR code again, or check out our help section.", self::TRIGGERS => []];
            } else {
                return [self::STATUS => $this->qrCodeIsCompetition ? true : false, self::MESSAGE => "Whoops! You have just scanned this code. Find a different code or come back later for another token .", self::TRIGGERS => []];
            }
        }


        $response = $this->gObj->processMissions($this->userMissions, request()->user());
        Redis::del($key);
        return [self::STATUS => true, 'type' => ($this->qrCodeIsCompetition) ? "petpack" : "normal", self::MESSAGE => !empty($response) ? "Yay! You’ve scanned one of the Pet Pack!" : "And scanned. Good work!", self::TRIGGERS => $response];
    }//..... end of customerScannedQrCode() .....//

    /**
     * Check if campaign has active games/missions.
     */
    private function filterCampaignsForActiveGamesAndMissions(): void
    {
        $campaigns = $this->gObj->getGamificationCampaigns();
        $this->games = $this->gObj->retrieveActiveGamesFromCampaigns($campaigns, request()->user());

    }//..... end of filterCampaignsForActiveGamesAndMissions() ......//

    /**
     * @return Collection
     * Check mission segment for specific qr code.
     */
    private function checkMissionsForQrCodes(): Collection
    {
        $userMissions = collect([]);
        $this->games->each(function ($game) use (&$userMissions) {
            $game->missions->each(function ($mission) use (&$userMissions, $game) {
                $this->missionsFound = true;
                $mission->venue_id = $game->venue_id;
                $mission->campaign_id = $game->campaign_id;
                $segments = explode(',', $mission->target_segments);

                if ($this->filterUserInSegments($segments, ['type' => self::SCAN_QR_CODE, self::VALUE => request()->qr_code])) {

                    Segment::whereIn('id', $segments)->get(['id', 'query_parameters'])->each(function ($value) use (&$mission) {
                        $qr_code = json_decode($value->query_parameters);
                        if ($qr_code[0]->name == self::SCAN_QR_CODE) {
                            $mission->interval = $qr_code[0]->value->interval;
                            return false;
                        }
                    });

                    $userMissions->push($mission);
                }

            });
        });
        return $userMissions;
    }//..... end of checkMissionsForQrCodes() .....//

    /**
     * @param $segmentIds
     * @param array $extraConditions
     * @return bool
     * Check if user lies in segment.
     */
    private function filterUserInSegments($segmentIds, $extraConditions = [], $userId): bool
    {

        if ($this->segmentsHasExtraConditions($segmentIds, $extraConditions)) {
            $users = $this->getUserBySegments($segmentIds, request()->user()->user_id);

            if (in_array(request()->user()->user_id, $users)) {
                return true;
            }

            return false;
        }//..... end if() .....//

        return false;
    }//..... end of filterUserInSegments() ......//

    /**
     * @param $segmentIds
     * @param $condition
     * @return bool
     * Check if segment has extra condition like qr code etc.
     */
    private function segmentsHasExtraConditions($segmentIds, $condition): bool
    {
        $found = false;

        Segment::whereIn('id', $segmentIds)->get(['id', 'query_parameters'])
            ->each(function ($segment) use (&$found, $condition) {
                if (!$found) {
                    foreach (json_decode($segment->query_parameters) as $qp) {

                        switch ($condition['type']) {
                            case self::SCAN_QR_CODE:
                                return ($qp->name == $condition['type'] && $qp->value->qr_code == $condition[self::VALUE]) ? $found = true : $found;
                                break;
                            case self::USER_SIGNUP:
                                return ($qp->name == $condition['type']) ? $found = true : $found;
                                break;
                            case self::USER_GPS_DETECT:
                                return ($qp->name == $condition['type'] && $qp->value == $condition[self::VALUE]) ? $found = true : $found;
                                break;
                            case 'user_optional_field':
                                return ($qp->name == $condition['type']) ? $found = true : $found;
                                break;
                            case 'transaction_amount':
                                return ($qp->name == $condition['type']) ? $found = true : $found;
                                break;
                            case 'target_users':
                                return ($qp->name == $condition['type']) ? $found = true : $found;
                                break;
                            case 'old_user':
                                return ($qp->name == $condition['type']) ? $found = true : $found;
                                break;
                            case 'referral_user':
                                return ($qp->name == $condition['type']) ? $found = true : $found;
                                break;
                            case 'member_group':
                                return ($qp->name == $condition['type']) ? $found = true : $found;
                                break;
                            case 'receipt_scanning':
                                return ($this->findMissionCondition($qp, $condition)) ? $found = true : $found;
                                break;
                            case 'completed_survey':
                                return ($this->findSurveyInSegmentation($qp, $condition)) ? $found = true : $found = false;
                            case 'transaction_scan':
                                return ($this->getFindProduct($qp,$condition))?$found = true:$found;
                                break;
                            case 'seen_videos':
                                return ($this->findVideoInSegment($qp,$condition))?$found = true:$found;
                            case 'completed_profile':
                                return ($qp->name == $condition['type'])?$found = true:$found;
                                break;
                            case 'complete_missions':
                                return ($this->completeMissions($qp,$condition))?$found = true:$found;
                                break;
                            case 'walkthrough_completed':
                                return ($qp->name == $condition['type']) ? $found = true : $found;
                                break;

                        }
                    }
                }//..... end if() .....//
            });

        return $found;
    }//..... end of segmentsHasExtraConditions() .....//

    /**
     * @return array
     * Get Campaign's Games and missions statistics for frontend.
     */
    public function loadCampaignStatistics(): array
    {
        $campaign = $this->getCampaignById(request()->campaign_id);
        return [
            'campaign_title' => $campaign ? $campaign->name : '',
            'games' => $campaign ? $this->populateGamesStatistics($campaign->games) : []
        ];
    }//..... end of loadCampaignStatistics() .....//

    /**
     * @param array $games
     * @return mixed
     * Populate games' statistics.
     */
    private function populateGamesStatistics($games = [])
    {
        return $games->map(function ($game) {
            $gStatus = $this->getGameCompletionStatistics($game->id);
            return [
                'id' => $game->id,
                self::TITLE => $game->title,
                self::START_DATE => $game->start_date,
                self::END_DATE => $game->end_date,
                'completion' => $gStatus,
                // 'inProgress'    => $this->getGameInProgressStatistics($game->id) - $gStatus,
                'inProgress' => $this->getInprogressMission($game->id),
                'missions' => $this->getMissionsStatistics($game->missions),
                'url' => URL::signedRoute('export.game.mission.members', ['type' => 'game', 'id' => $game->id])
            ];
        });
    }//..... end of populateGamesStatistics() ......//

    /**
     * @param $missions
     * @return mixed
     * Populate missions statistics.
     */
    private function getMissionsStatistics($missions)
    {
        return $missions->map(function ($mission) {
            return [
                'id' => $mission->id,
                self::TITLE => $mission->title,
                self::START_DATE => $mission->start_date,
                self::END_DATE => $mission->end_date,
                'completion' => $this->getMissionCompletionStatistics($mission->id),
                'url' => URL::signedRoute('export.game.mission.members', ['type' => 'mission', 'id' => $mission->game_id, 'mid' => $mission->id])
            ];
        });
    }//..... end of getMissionsStatistics() .....//

    /**
     * @param $id
     * @return mixed
     * Get Statistics of a mission.
     */
    private function getMissionCompletionStatistics($id)
    {
        return MissionUserEntry::where('mission_id', $id)->count();
    }//..... end of getMissionCompletionStatistics() .....//

    /**
     * @param $id
     * @return mixed
     * Get Game completion statistics.
     */
    private function getGameCompletionStatistics($id)
    {
        return GameUserEntry::where('game_id', $id)->count();
    }//..... end of getGameCompletionStatistics() ......//

    /**
     * @param $game_id
     * @return mixed
     * Get Game in Progress statistics.
     */
    private function getGameInProgressStatistics($game_id)
    {
        return MissionUserEntry::where('game_id', $game_id)->groupBy('mission_id')->get()->count();
    }//..... end of getGameInProgressStatistics() ......//

    /**
     * @param $id
     * @return mixed
     * Get Campaign By id.
     */
    private function getCampaignById($id)
    {
        return Campaign::whereId($id)->with(['games.missions'])->first();
    }//..... end of getCampaignById() .....//

    /**
     * @return BinaryFileResponse
     * Export Game/Mission involved users list.
     */
    public function exportGameMissionMembers(): BinaryFileResponse
    {
        if (!request()->hasValidSignature()) {
            abort(401);
        }

        $members = request()->type === 'mission'
            ? $this->missionMembers(request()->id, request()->mid)
            : $this->gameMembers(request()->id);

        return Excel::download(new GameMissionExport($members), 'game_mission_members_list.xlsx');
    }//..... end of exportGameMissionMembers() .....//

    /**
     * @return BinaryFileResponse
     * Download Competition members list.
     */
    public function exportCompetitionMembers()
    {
        $members = CompetitionUserEntry::where('competition_user_entries.competition_id', request()->id)
            ->where('competition_user_entries.in_draw', 1)
            // ->groupBy('competition_user_entries.user_id')
            ->join('users', 'users.user_id', '=', 'competition_user_entries.user_id')
            ->leftJoin('venues', 'venues.venue_id', '=', 'users.default_venue')
            ->orderBy('competition_user_entries.created_at', 'ASC')
            ->get(['competition_user_entries.created_at', 'users.user_first_name', 'users.user_family_name', 'users.user_mobile', 'users.email', 'venues.venue_name']);
        return Excel::download(new GameMissionExport($members), 'competition_members_list.xlsx');
    }//..... end of exportCompetitionMembers() .....//

    /**
     * @param $id
     * @return Collection
     * Get all members that are involved in a game.
     */
    private function gameMembers($id): Collection
    {
        return GameUserEntry::where('game_user_entries.game_id', $id)
            ->join('users', 'users.user_id', '=', 'game_user_entries.user_id')
            ->leftJoin('venues', 'venues.venue_id', '=', 'users.default_venue')
            ->get(['game_user_entries.created_at', 'users.user_first_name', 'users.user_family_name', 'users.user_mobile', 'users.email', 'venues.venue_name']);
    }//..... end of gameMembers() .....//

    /**
     * @param $game_id
     * @param $mission_id
     * @return mixed
     * Get all members that are involved in mission.
     */
    private function missionMembers($game_id, $mission_id): Collection
    {
        return MissionUserEntry::where('mission_users_entries.game_id', $game_id)
            ->where('mission_users_entries.mission_id', $mission_id)
            ->join('users', 'users.user_id', '=', 'mission_users_entries.user_id')
            ->leftJoin('venues', 'venues.venue_id', '=', 'users.default_venue')
            //->groupBy('mission_users_entries.user_id')
            ->get(["mission_users_entries.created_at", 'users.user_first_name', 'users.user_family_name', 'users.user_mobile', 'users.email', 'venues.venue_name']);
    }//..... end of missionMembers() .....//

    public function saveMissionLogs($missionData)
    {
        return true;
    }//..... end of saveVoucherToEs() .....//

    /**
     * @param $userID
     * @return Collection
     */
    public function userSignupMissions(Request $request)
    {


        $user = User::whereUserId($request->user_id)->first();
        $this->segmentation = new Segmentation(ElasticsearchUtility::generateIndexName(config('constant.COMPANY_ID'), 295255));
        $this->filterCampaignsActiveGamesAndMissions($request->user_id);

        $signUpmissions = $this->checkMissionsForSignUp($user);
        $this->userMissions = $this->gObj->setActiveMissions($signUpmissions, $user);

        $this->gObj->processMissions($this->userMissions, $user);
        return $this->userMissions;
    }//--- End of userSignupMissions() ---//

    private function checkMissionsForSignUp()
    {
        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segments = explode(',', $mission->target_segments);

                    if ($this->filterCheckSegments($segments, ['type' => self::USER_SIGNUP])) {
                        $userMissions->push($mission);
                    }
                });
        });

        return $userMissions;
    }

    /**
     * @param $segments
     * @param $array
     * @return bool
     */
    private function filterCheckSegments($segments, $array)
    {

        if ($this->segmentsHasExtraConditions($segments, $array)) {
            return true;
        }

        return false;
    }//..... end of filterCheckSegments() .....//

    /**
     * @param $userid
     */
    private function filterCampaignsActiveGamesAndMissions($userid): void
    {
        $campaigns = $this->gObj->getGamificationCampaigns();
        $this->games = $this->gObj->retrieveActiveGamesFromCampaigns($campaigns, User::whereUserId($userid)->first());
    }//..... end of filterCampaignsForActiveGamesAndMissions() ......//

    /**
     * @param Request $request
     * @return array|Collection
     */
    public function userLocationDetection($venueId)
    {

        $this->segmentation = new Segmentation(ElasticsearchUtility::generateIndexName(config('constant.COMPANY_ID'), $venueId));

        $this->filterCampaignsForActiveGamesAndMissions();

        $gpsMissions = $this->checkMissionsVenueID();
        $this->userMissions = $this->gObj->setActiveMissions($gpsMissions, request()->user());
        $this->gObj->processMissions($this->userMissions, request()->user());
        return [self::STATUS => true, self::MESSAGE => 'Location is detected successfully'];
    }

    private function checkMissionsVenueID()
    {
        $userMissions = collect([]);
        $this->games->each(function ($game) use (&$userMissions) {
            $game->missions->each(function ($mission) use (&$userMissions, $game) {
                $mission->venue_id = $game->venue_id;
                $mission->campaign_id = $game->campaign_id;
                $segments = explode(',', $mission->target_segments);

                if ($this->filterUserForLocation($segments, ['type' => self::USER_GPS_DETECT, self::VALUE => request()->venue_id])) {
                    Segment::whereIn('id', $segments)->get(['id', 'query_parameters'])->each(function ($value) use (&$mission) {
                        $qr_code = json_decode($value->query_parameters);
                        if ($qr_code[0]->name == self::USER_GPS_DETECT) {
                            $mission->interval = (int)$qr_code[0]->interval * 60;
                            return false;
                        }
                    });
                    $userMissions->push($mission);
                }

            });
        });
        return $userMissions;
    }

    private function filterUserForLocation(array $segments, array $array)
    {

        if ($this->segmentsHasExtraConditions($segments, $array)) {
            return true;
        }

        return false;
    }//..... end of filterUserForLocation() .....//

    public function userOptionalFields(Request $request, $user)
    {

        $this->segmentation = new Segmentation(ElasticsearchUtility::generateIndexName(config('constant.COMPANY_ID'), $request->venue_id));

        $this->filterCampaignsForOptionalFields($user);

        $optionalMissions = $this->checkMissionsForOptionalFields();
        $this->userMissions = $this->gObj->setActiveMissions($optionalMissions, $user);
        $this->gObj->processMissions($this->userMissions, $user);
        return true;
    }

    private function filterCampaignsForOptionalFields($user): void
    {
        $campaigns = $this->gObj->getGamificationCampaigns();
        Log::channel('custom')->info('$campaigns',['$campaigns'=>$campaigns]);
        $this->games = $this->gObj->retrieveActiveGamesFromCampaigns($campaigns, $user);
    }

    private function checkMissionsForOptionalFields()
    {
        $userMissions = collect([]);
        $this->games->each(function ($game) use (&$userMissions) {
            $game->missions->each(function ($mission) use (&$userMissions, $game) {
                $mission->venue_id = $game->venue_id;
                $mission->campaign_id = $game->campaign_id;
                $segments = explode(',', $mission->target_segments);

                if ($this->filterUserOptionalFields($segments, ['type' => 'user_optional_field'])) {
                    $userMissions->push($mission);
                }
            });
        });

        return $userMissions;
    }

    private function filterUserOptionalFields(array $segments, array $array)
    {

        if ($this->segmentsHasExtraConditions($segments, $array)) {
            return true;
        }

        return false;
    }//..... end of filterCampaignsForActiveGamesAndMissions() ......//

    private function getInprogressMission($game_id)
    {

        return DB::table("missions")->whereGameId($game_id)
            ->where(self::START_DATE, "<=", date(self::DATE_FORMAT))
            ->where(self::END_DATE, ">=", date(self::DATE_FORMAT))->count();
    }

    private function getUserBySegments($segmentIds, $userID)
    {
        try {

            $segments = Segment::whereIn('id', $segmentIds)->get();
            $userData = [];
            foreach ($segments as $value) {
                $query = json_decode($value->query, true);
                $query['query']['bool']['must'][] = ['match' => ['persona_id' => $userID]];

                $userFromES = (new ElasticsearchUtility())->getAllData($query, config('constant.ES_INDEX_BASENAME'));

                foreach ($userFromES as $value) {
                    $userData[] = $value['_id'];
                }
            }

            return array_unique($userData);
        } catch (Exception $e) {
            Log::channel('custom')->error('getUserBySegments :', ['getUserBySegments' => $e->getMessage()]);
            return [self::STATUS => false, self::MESSAGE => "Error " . $e->getMessage()];
        }

    }


    //========================  end of testing server  functions  ===============//

    public function surveyList()
    {
        return [self::STATUS => true, "data" => SurveyFront::get(['id', self::TITLE])];
    }

    /**
     * @param $venueId
     * @return array
     */
    public function userAssignStampCardTransaction($user)
    {

        $this->segmentation = new Segmentation(config('constant.ES_INDEX_BASENAME'));
        $this->filterCampaignsActiveGamesAndMissions($user->user_id);

        $signUpmissions = $this->checkMissionsForTransaction($user);

        $this->userMissions = $this->gObj->setActiveMissionsForTransactions($signUpmissions, $user);

        $this->gObj->processMissions($this->userMissions, $user);
        if ($this->userMissions->isNotEmpty()) {
            return [self::STATUS => true, 'data' => $this->userMissions];
        } else {
            return [self::STATUS => false];
        }
    }

    /**
     * @return Collection
     */
    private function checkMissionsForTransaction()
    {
        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segments = explode(',', $mission->target_segments);

                    if ($this->filterCheckSegments($segments, ['type' => 'transaction_amount'])) {
                        $userMissions->push($mission);
                    }
                });
        });

        return $userMissions;
    }//---- End of checkMissionsForTransaction() -----//

    public function groupList()
    {
        return [self::STATUS => true, "data" => DB::table('groups')->get(['group_id as id', 'group_name'])];
    }

    public function assignStampCardOldNewUser($user)
    {

        $this->segmentation = new Segmentation(config('constant.ES_INDEX_BASENAME'));
        $this->filterCampaignsActiveGamesAndMissionsForUser($user->user_id);

        $signUpmissions = $this->checkMissionsForOldNewUser($user);


        if ($signUpmissions->isNotEmpty()) {

            $this->userMissions = $this->gObj->setActiveMissionsForTransactions($signUpmissions, $user);

            $this->gObj->processMissions($this->userMissions, $user);
            if ($this->userMissions->isNotEmpty()) {
                return [self::STATUS => true, 'data' => $this->userMissions];
            } else {
                return [self::STATUS => false];
            }
        } else {
            return [self::STATUS => false, self::MESSAGE => 'Mission for old user is not created'];
        }
    }

    /**
     * @return Collection
     */
    private function checkMissionsForOldNewUser($user)
    {

        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions, &$user) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game, &$user) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segmentId = explode(',', $mission->target_segments);

                    if ($this->filterUserInSegmentsForSignUp($segmentId, ['type' => self::USER_SIGNUP], $user)) {
                        $userMissions->push($mission);
                    }

                });
        });

        return $userMissions;
    }//---- End of checkMissionsForTransaction() -----//

    private function filterCampaignsActiveGamesAndMissionsForUser($userid): void
    {
        $campaigns = $this->gObj->getGamificationCampaignsFor();
        $this->games = $this->gObj->retrieveActiveGamesFromCampaigns($campaigns, User::whereUserId($userid)->first());
    }

    private function filterUserInSegmentsForSignUp($segmentIds, $extraConditions = [], $user): bool
    {

        if ($this->segmentsHasExtraConditions($segmentIds, $extraConditions)) {

            $users = $this->getUserBySegments($segmentIds, $user->user_id ?? $user['user_id']);


            if (in_array($user->user_id ?? $user['user_id'], $users)) {
                Log::channel('custom')->info('sfsdf', ['$user' => $user]);
                return true;
            }

            return false;
        }//..... end if() .....//

        return false;
    }//..... end of filterUserInSegments() ......//

    /**
     * @param $user
     * @return array
     */
    public function userRefferalAssignReward($user)
    {

        $this->segmentation = new Segmentation(config('constant.ES_INDEX_BASENAME'));
        $this->filterCampaignForStudentVoucher($user);

        $signUpmissions = $this->checkMissionsForRefferalAssign($user);

        $this->userMissions = $this->gObj->setActiveMissionsForTransactions($signUpmissions, $user);

        if ($this->setting == 'Automatic')
            $this->gObj->processMissions($this->userMissions, $user);
        else
            $this->gObj->processManualMissions($this->userMissions, $user);


        Log::channel('custom')->info('refferal', ['refferal' => $user, 'mission' => $this->userMissions]);
        if ($this->userMissions->isNotEmpty()) {
            return [self::STATUS => true, 'data' => $this->userMissions];
        } else {
            return [self::STATUS => false];
        }
    }

    /**
     * @return Collection
     */
    private function checkMissionsForRefferalAssign()
    {
        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segments = explode(',', $mission->target_segments);

                    if ($this->filterCheckSegments($segments, ['type' => 'referral_user'])) {
                        $userMissions->push($mission);
                    }
                });
        });

        return $userMissions;
    }//---- End of checkMissionsForTransaction() -----//

    /**
     * @param array $segmentId
     * @param $condition
     * @return bool
     */
    private function getSegmenTDetails(array $segmentId, $condition)
    {
        $found = false;
        Segment::whereIn('id', $segmentId)->get(['id', 'query_parameters'])
            ->each(function ($segment) use (&$found, $condition) {
                if (!$found) {
                    foreach (json_decode($segment->query_parameters) as $qp) {

                        switch ($condition['type']) {

                            case self::USER_SIGNUP:
                                return $found = ($qp->value) ? 1 : 0;
                                break;
                            default:
                                return $found = 0;
                        }
                    }
                }//..... end if() .....//
            });
        return $found;
    }//----- end of getSegmenTDetails() ------//

    /**
     * @return array
     */
    public function changeMemberShip($id)
    {

        $user = User::where('user_id', $id)->first();

        $this->segmentation = new Segmentation(config('constant.ES_INDEX_BASENAME'));
        $this->filterCampaignForStudentVoucher($user);//Filter campaign with user region
        $signUpmissions = $this->checkMissionsForMembership($user);

        $this->userMissions = $this->gObj->setActiveMissionsForTransactions($signUpmissions, $user);


        if ($this->userMissions->isNotEmpty()) {
            $this->gObj->processMissions($this->userMissions, $user);
            Log::channel('custom')->info('changeMemberShip', ['changeMemberShip' => $this->userMissions]);
            return [self::STATUS => true, 'data' => $this->userMissions];
        } else {
            return [self::STATUS => false];
        }
    }//---- End of changeMemberShip() ----//

    /**
     * @param $user
     * @return Collection
     */
    private function checkMissionsForMembership($user)
    {
        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions, &$user) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game, &$user) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segmentId = explode(',', $mission->target_segments);


                    Log::channel('custom')->info('segments', ['segments' => $segmentId]);
                    if ($this->filterUserInSegmentsForSignUp($segmentId, ['type' => 'member_group'], $user)) {
                        $userMissions->push($mission);
                    }

                });
        });

        return $userMissions;
    }//----- End of checkMissionsForMembership() ------//


    /**
     * @param $userid
     */
    private function filterCampaignForStudentVoucher($user): void
    {
        $campaigns = $this->gObj->getGamificationCampaignsForStudent($user);
        $this->games = $this->gObj->retrieveActiveGamesFromCampaigns($campaigns, $user);
    }//..... end of filterCampaignsForActiveGamesAndMissions() ......//

    public function gamedWithBadges()
    {
        $user = \request()->user();
        $campaigns = $this->gObj->getGameCampaignForBadge($user);
        $this->games = $this->gObj->retrieveActiveGamesFromCampaigns($campaigns, null);

        $dataCreation = $this->createDataForMission($user);
        return ['status' => true, 'data' => $dataCreation->toArray()];
    }

    public function createDataForMission($user)
    {
        //dd($user);
        $userMissions = collect([]);
        $gameData = collect([]);
        $pushData = false;
        $completed = true;
        $countData = 0;
        $perCent = 0;

        $this->games->each(function ($game) use (&$userMissions, &$pushData, &$completed, &$gameData, &$user, &$countData, &$perCent) {

            $game->missions->each(
                function ($mission) use (&$userMissions, &$pushData, &$completed, $game, &$user, &$gameData, &$countData, &$perCent) {
                    $missionOuntcomeData = json_decode($mission->outcomes);
                    $gameMissions = json_decode($game->missions);


                    $mission->outcomes = json_decode($mission->outcomes);

                    $missionEntry = MissionUserEntry::where(['user_id' => $user->user_id, 'mission_id' => $mission->id, 'game_id' => $mission->game_id])->first();
                    $segmentId = explode(',', $mission->target_segments);
                    $surveyId = $this->findSurveyMissions($game->missions);
                   $video = $this->findVideoMissions($game->missions);

                   $outcomes = $this->outcomeValues($mission->outcomes, $mission);
                    $completeProfile = '';
                   $dataFinde = $this->filterMissionSegement(explode(',',$mission->target_segments));
                    if($dataFinde['name'] !=''){
                        $completeProfile = $dataFinde['name'];

                    }
                   Log::channel('custom')->info('segments', ['segments' => $segmentId,'mission_id' => $mission->id,'gameCount' => count($gameMissions),'missionFilter' => $dataFinde]);

                        if (!empty($outcomes)) {
                            $countData = $countData + 1;
                            $pushData = true;
                            if (!isset($outcomes['points'])) {
                                $outcomes['points'] = (string)0;
                            }

                            if ($missionEntry) {
                                if (isset($outcomes['percentage'])) {
                                    $perCent = $outcomes['percentage'];
                                }
                            }
                            if (!isset($outcomes['badge_name']) and !isset($outcomes['badge_id'])) {
                                $outcomes['badge_name'] = '';
                                $outcomes['badge_image'] = '';
                                $outcomes['badge_id'] = '';
                                $outcomes['percentage'] = '';
                            }

                            Log::channel('custom')->info('check', ['user_id' => $user->user_id]);
                            if ($missionEntry and count($gameMissions) > 1) {
                                $outcomes['percentage'] = $perCent;
//                                $mission->repeat
                                $completed = true;
                                $userMissions->push(['mission_id' => $mission->id,'mission_description' =>$mission->description,'mission_type' => $completeProfile,'survey_id' =>$surveyId, 'completed' => $completed,
                                    'mission_name' => $mission->title, 'outcomes' => $outcomes,'video' => $video
                                ]);
                            } else if ($missionEntry and count($gameMissions) == 1) {
                                if (isset($outcomes['percentage']))
                                    $outcomes['percentage'] = 100;

                                $userMissions->push(['mission_id' => $mission->id,'mission_description' =>$mission->description,'mission_type' => $completeProfile,'survey_id' =>$surveyId, 'completed' => true,
                                    'mission_name' => $mission->title, 'outcomes' => $outcomes,'video' => $video
                                ]);
                            } else if (!$missionEntry and count($gameMissions) > 1) {
                                if (isset($outcomes['percentage']))
                                    $outcomes['percentage'] = $perCent;

                                $userMissions->push(['mission_id' => $mission->id,'mission_description' =>$mission->description,'mission_type' => $completeProfile,'survey_id' => $surveyId, 'completed' => false,
                                    'mission_name' => $mission->title, 'outcomes' => $outcomes,'video' => $video
                                ]);
                            } else if (!$missionEntry and count($gameMissions) == 1) {
                                if (isset($outcomes['percentage']))
                                    $outcomes['percentage'] = 0;

                                $userMissions->push(['mission_id' => $mission->id,'mission_description' =>$mission->description,'mission_type' => $completeProfile,'survey_id' => $surveyId, 'completed' => false,
                                    'mission_name' => $mission->title, 'outcomes' => $outcomes,'video' => $video
                                ]);
                            }

                            $completed = 0;
                        } else {

                            $pushData = false;
                        }
                   /* }else{
                        $pushData = false;
                    }*/


                });
            if ($pushData) {
                $gameData->push(['game_id' => $game->id, 'game_name' => $game->title, 'missions' => $userMissions->toArray()]);
                $userMissions = collect([]);
                $countData = 0;
            }

        });

        return $gameData;
    }

    private function outcomeValues($outcomes, $mission)
    {
        $outcomesData = [];
        $missionCount = 0;

        foreach ($outcomes as $value) {
            $missionCount = $missionCount + 1;
            $outcomesData[] = $this->outcomDataResponse($value->action_value,$mission);
        }

        $result = array_reduce($outcomesData, 'array_merge', array());
        return $result;
    }

    private function outcomDataResponse($action_value,$mission)
    {
        $data = [];

        foreach ($action_value as $value) {
            if ($value->value->type == 'badge') {

                $badge = Badge::where('id', $value->value->other->content->badge_id)->first();
                if (isset($value->value->other->content->state_id)) {
                    $badgeState = BadgeState::where('id', $value->value->other->content->state_id)->first();
                } else {
                    $badgeState = false;
                }
                if ($badge and $badgeState) {
                    $data = ['badge_name' => $badge->title, 'badge_id' => $badge->id, 'badge_image' => \url('/badges/' . $badgeState->state_image), 'percentage' => $badgeState->progression, 'state_name' => $badgeState->state_name];
                }
            } else if ($value->value->type == 'point') {
                $data = ['points' => isset($value->value->other->content->points->{'Value Points'})?$value->value->other->content->points->{'Value Points'}:0];
            }
        }
        return $data;
    }

    private function getSettings()
    {
        $settings = Setting::where('type', 'mission_trigger')->first();
        if ($settings) {
            $this->setting = $settings->field1;
            return $this->setting;
        } else {
            $this->setting = 'Automatic';
            return $this->setting;
        }
    }

    public function collectMissionOutComes()
    {
        $user = request()->user();
        $missionID = \request()->mission_id;
        $game_id = \request()->game_id;
        if (!\request()->has('mission_id')) {
            return ['status' => false, 'message' => 'Provide Mission Id'];
        }

        $mission = Mission::where('id', $missionID)->first();
        $missionsData = Mission::where('game_id', $game_id)->get();
        $this->gObj->processManualOutComes($mission, $user);
        $this->gObj->checkUserIfQualifyTheGame($missionsData);
        return ['status' => true, 'message' => 'Successfully trigger misisons',];
    }

    public function rewardOnScanReciept($user_id = null, $brandName, $isUnilever, $allBrand, $unileverCount, $brandCount,$products,$productCount,$referenceID,$productId,$totalAmount)
    {
        $user = User::where('user_id', $user_id)->first();
        $user->transaction_amount = $totalAmount;
        $this->userFound = $user;
        if (!$user) {
            return ['status' => false, 'message' => 'user not exists'];
        }
        $this->segmentation = new Segmentation(ElasticsearchUtility::generateIndexName(config('constant.COMPANY_ID'), ''));

        $this->filterCampaignsForOptionalFields($user);

        $optionalMissions = $this->checkMissionsForScanReciept($brandName, $isUnilever, $allBrand, $unileverCount, $brandCount,$products,$productCount,$productId);
        $this->userMissions = $this->gObj->setActiveMissionsForTransactions($optionalMissions, $user);
        Log::channel('custom')->info('rewardOnScanReciept', ['rewardOnScanReciept' => $this->userMissions, 'brandName' => $brandName, 'isUnilever' => $isUnilever, 'user' => $user]);
        $response = $this->gObj->processCompletedMissions($this->userMissions, $user,$referenceID);
        return $response;
    }

    private function checkMissionsForScanReciept($brandName, $isUnilever, $allBrand, $unileverCount, $brandCount,$products,$productCount,$productId)
    {

        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions, $brandName, $isUnilever, $allBrand, $unileverCount, $brandCount,$products,$productCount,$productId) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game, $brandName, $isUnilever, $allBrand, $unileverCount, $brandCount,$products,$productCount,$productId) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segments = explode(',', $mission->target_segments);
                    if ($this->filterCheckSegments($segments, ['type' => 'receipt_scanning', 'brand' => $brandName, 'is_unilever' => $isUnilever, 'brandData' => $allBrand, 'unileverCount' => $unileverCount, 'brandCount' => $brandCount,'product_id'=>$products,'product_count' =>$productCount,'product_ids' => $productId])) {

                        $userMissions->push($mission);
                    }
                });
        });

        return $userMissions;
    }

    private function findMissionCondition($qp, $condition)
    {

        if ($qp->name != $condition['type']) {
            return false;
        }
        if(!isset($qp->value->products)){
            $qp->value->products =[];
        }
        if(!isset($qp->value->is_all_product)){
            $qp->value->is_all_product=0;
        }
        Log::channel('custom')->info('findMissionCondition', ['findMissionCondition' => $qp, 'condition' => $condition]);
        $valueFind = [];
        $count = 0;
        $productCount=0;
        if ($qp->value->brandName and (!$qp->value->is_all)) {
            $searchedValue = $condition['brand'];
            $valueFind = array_filter(
                $qp->value->brandName,
                function ($e) use (&$searchedValue) {
                    return $e->label == $searchedValue;
                }
            );
        } else if ($qp->value->brandName and ($qp->value->is_all)) {
            $array = $condition['brandData'];

            foreach ($qp->value->brandName as $value) {
                foreach ($array as $newValue) {
                    if ($value->label == $newValue) {
                        $count = $count + 1;
                    }
                }
            }

        }else if($qp->value->products and ($qp->value->is_all_product)){
            foreach ($qp->value->products as $value) {
                foreach ($condition['product_ids'] as $newValue) {
                    if ($value == $newValue) {
                        $productCount = $productCount + 1;
                    }
                }
            }
        }

        if (($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and (empty($qp->value->brandName)) and (!$qp->value->is_first) and ($qp->value->total_quantity === 0) and (count($qp->value->products) == 0) ) {
            return true;
        } else if ((!empty($qp->value->brandName)) and (count($valueFind) > 0) and (!$qp->value->is_unilever) and (!$qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity === 0)  and (count($qp->value->products) == 0)) {
            return true;
        } else if ((!empty($qp->value->brandName)) and (count($valueFind) > 0) and (!$qp->value->is_unilever) and ($qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity === 0)  and (count($qp->value->products) == 0)) {
            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }
        } else if ((!empty($qp->value->brandName)) and (count($qp->value->brandName) == $count) and (!$qp->value->is_unilever) and (!$qp->value->is_first) and ($qp->value->is_all) and ($qp->value->total_quantity === 0)  and (count($qp->value->products) == 0)) {
            return true;
        } else if ((!empty($qp->value->brandName)) and (count($valueFind) > 0) and (!$qp->value->is_unilever) and (!$qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['brandCount'])  and (count($qp->value->products) == 0)) {
            return true;
        } else if ((!empty($qp->value->brandName)) and (count($qp->value->brandName) == $count) and (!$qp->value->is_unilever) and ($qp->value->is_first) and ($qp->value->is_all) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['brandCount'])  and (count($qp->value->products) == 0)) {
            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }

        } else if ((!empty($qp->value->brandName)) and (count($qp->value->brandName) == $count) and (!$qp->value->is_unilever) and (!$qp->value->is_first) and ($qp->value->is_all) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['brandCount'])  and (count($qp->value->products) == 0)) {
            return true;
        } else if ((!empty($qp->value->brandName)) and (count($valueFind) > 0) and (!$qp->value->is_unilever) and ($qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['brandCount'])  and (count($qp->value->products) == 0)) {
            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }

        } else if ((!empty($qp->value->brandName)) and (count($qp->value->brandName) == $count) and (!$qp->value->is_unilever) and ($qp->value->is_first) and ($qp->value->is_all) and ($qp->value->total_quantity === 0)  and (count($qp->value->products) == 0)) {
            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }

        } else if (($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and (empty($qp->value->brandName)) and ($qp->value->is_first) and ($qp->value->total_quantity === 0)  and (count($qp->value->products) == 0)) {
            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }
        } else if (($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and (empty($qp->value->brandName)) and (!$qp->value->is_first) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['unileverCount'])  and (count($qp->value->products) == 0)) {
            return true;

        } else if (($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and (empty($qp->value->brandName)) and ($qp->value->is_first) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['unileverCount'])  and (count($qp->value->products) == 0)) {
            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }
        } else if ((!empty($qp->value->brandName)) and (count($valueFind) > 0) and ($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and (!$qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity === 0)  and (count($qp->value->products) == 0)) {

            return true;
        } else if ((!empty($qp->value->brandName)) and (count($valueFind) > 0) and ($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and ($qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity === 0)  and (count($qp->value->products) == 0)) {

            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }
        } else if ((!empty($qp->value->brandName)) and (count($qp->value->brandName) == $count) and ($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and ($qp->value->is_first) and ($qp->value->is_all) and ($qp->value->total_quantity === 0)  and (count($qp->value->products) == 0)) {

            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }
        } else if ((!empty($qp->value->brandName)) and (count($valueFind) > 0) and ($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and ($qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['unileverCount']) and ($qp->value->total_quantity == $condition['brandCount'])  and (count($qp->value->products) == 0)) {

            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }
        } else if ((!empty($qp->value->brandName)) and (count($qp->value->brandName) == $count) and ($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and (!$qp->value->is_first) and ($qp->value->is_all) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['unileverCount']) and ($qp->value->total_quantity == $condition['brandCount'])  and (count($qp->value->products) == 0)) {
            return true;
        } else if ((!empty($qp->value->brandName)) and (count($qp->value->brandName) == $count) and ($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and (!$qp->value->is_first) and ($qp->value->is_all) and ($qp->value->total_quantity === 0)) {

            return true;
        } else if ((!empty($qp->value->brandName)) and (count($qp->value->brandName) == $count) and ($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and (!$qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['unileverCount']) and ($qp->value->total_quantity == $condition['brandCount'])  and (count($qp->value->products) == 0)) {

            return true;
        } else if ((!empty($qp->value->brandName)) and (count($qp->value->brandName) == $count) and ($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and ($qp->value->is_first) and ($qp->value->is_all) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['unileverCount']) and ($qp->value->total_quantity == $condition['brandCount'])  and (count($qp->value->products) == 0)) {

            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }
        }  else if ((!empty($qp->value->brandName)) and (count($qp->value->brandName) == $count) and ($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and (!$qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['unileverCount']) and ($qp->value->total_quantity == $condition['brandCount'])  and (count($qp->value->products) == 0)) {

            return true;
        } else if (!($qp->value->brandName) and (!$qp->value->is_unilever)  and (!$qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity == 0) and (count($qp->value->products )>0) and in_array($condition['product_id'], $qp->value->products)) {

            return true;
        }else if (empty($qp->value->brandName) and (!$qp->value->is_unilever)  and ($qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity == 0) and (count($qp->value->products )>0) and (in_array($condition['product_id'],$qp->value->products))) {
            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }
        } else if (empty($qp->value->brandName) and ($qp->value->is_unilever)  and ($qp->value->is_unilever == $condition['is_unilever']) and (!$qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity == 0) and (count($qp->value->products )>0) and (in_array($condition['product_id'],$qp->value->products))) {
                return true;

        } else if (!empty($qp->value->brandName) and (count($valueFind) > 0)  and ($qp->value->is_unilever)  and ($qp->value->is_unilever == $condition['is_unilever']) and (!$qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity == 0) and (count($qp->value->products )>0) and (in_array($condition['product_id'],$qp->value->products))) {
            return true;

        } else if (empty($qp->value->brandName)  and (!$qp->value->is_unilever)   and (!$qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity > 0) and (count($qp->value->products )>0) and (in_array($condition['product_id'],$qp->value->products)) and ($qp->value->total_quantity == $condition['product_count'])) {
            return true;

        }else if (empty($qp->value->brandName)  and (!$qp->value->is_unilever)   and (!$qp->value->is_first) and ($qp->value->is_all_product) and ($qp->value->total_quantity == 0) and (count($qp->value->products )>0) and (count($qp->value->products ) == $productCount)) {
            return true;

        }else if (empty($qp->value->brandName)  and (!$qp->value->is_unilever)   and ($qp->value->is_first) and ($qp->value->is_all_product) and ($qp->value->total_quantity == 0) and (count($qp->value->products )>0) and (count($qp->value->products ) == $productCount)) {
            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }

        } else if ((!empty($qp->value->brandName)) and (count($qp->value->brandName) == $count) and ($qp->value->is_unilever) and ($qp->value->is_unilever == $condition['is_unilever']) and ($qp->value->is_first) and ($qp->value->is_all) and ($qp->value->total_quantity > 0) and ($qp->value->total_quantity == $condition['unileverCount']) and ($qp->value->total_quantity == $condition['brandCount'])  and (in_array($condition['product_ids'],$qp->value->products)) and ($qp->value->total_quantity == $condition['product_count'])) {

            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }
        }else if ((empty($qp->value->brandName))  and (!$qp->value->is_unilever) and ($qp->value->is_first) and (!$qp->value->is_all) and ($qp->value->total_quantity == 0) and (count($qp->value->products )== 0) ) {

            $userRecipet = UserReceipts::where('user_id', $this->userFound->user_id)->count();
            if ($userRecipet == 1 || !$userRecipet) {
                return true;
            } else {
                return false;
            }
        }else {

            return false;
        }

    }

    public function listSurveys(Request $request)
    {
        $surveys = SurveyFront::with('questions', 'questions.answers')->orderBy(request()->orderBy, request()->orderType);
        $total = $surveys->count();

        $surveys = $surveys->when(request()->nameSearch, function ($q) {
            return $q->where('title', 'like', '%' . request()->nameSearch . '%');
        })->skip(request()->offset)->take(request()->limit)->get();
        foreach ($surveys as $value){
            $json = json_decode($value->json);
            if(isset($json->logo)){
                $value->logo_image = $json->logo;
            }else{
                $value->logo_image = 'images/defaultImage.png';
            }
        }

        return ['status' => true, 'data' => $surveys, 'total' => $total];
    }


    public function saveSurvey(Request $request)
    {

        $allData = json_decode($request->data);
//        print_r($allData);exit;
        /*print_r($allData->pages[0]->elements);exit;

        dd($allData->name);*/



        if(isset($allData->logo)){
            if(!preg_match("/(uploads|image-picker)/i", $allData->logo)) {
                $path = 'uploads/survey_logo' . time() * rand() . ".png";


                $image = $allData->logo;
                $response = file_put_contents(public_path($path), base64_decode(substr($image, strpos($image, ",") + 1)));

                if ($response)
                    Image::make(public_path($path))
                        ->save(public_path($path));
                $allData->logo = $path;
            }
        }
        foreach ($allData->pages as $pageKey => $pageValue) {

            if (isset($pageValue->elements)) {
                foreach ($allData->pages[$pageKey]->elements as $index => $row) {
//            dd($allData->pages[0]->elements[$index]);

                    if ($row->type == 'imagepicker') {

                        foreach ($row->choices as $key => $singleImage) {

//                    dd($allData->pages[0]->elements[$index]->choices[$key]->imageLink);

                            $image = $singleImage->imageLink;

//                        only upload base64 encoded images
                            if (!preg_match("/(uploads|image-picker)/i", $image)) {

                                $path = 'uploads/survey_' . time() * rand() . ".png";

                                $allData->pages[$pageKey]->elements[$index]->choices[$key]->imageLink = $path;

                                $response = file_put_contents(public_path($path), base64_decode(substr($image, strpos($image, ",") + 1)));

                                if ($response)
                                    Image::make(public_path($path))
                                        // resize the image to a width of 800 and constrain aspect ratio (auto height)
                                        ->resize(600, null, function ($constraint) {
                                            $constraint->aspectRatio();
                                        })
                                        ->save(public_path($path));
                                //->fit(200)

                                $allData->pages[$pageKey]->elements[$index]->choices[$key]->imageLink = $path;
                            }
                        }
                    }
                }
            } else {
                return ['status' => false, 'message' => "Please Add Survey Fields"];
            }
        }


//        print_r($allData);exit;

        $title = $allData->title ?? 'Untitled Survey';
        $description = $allData->description ?? 'Survey Description';

        $survey = SurveyFront::updateOrCreate(
            ['id' => $request->edit_id],
            [
                'title' => $title,
                'description' => $description,
                'json' => json_encode($allData)
            ]);
        if ($survey) {
            return ['status' => true, 'survey' => $survey];
        }
        return ['status' => true];

        /*$survey = SurveyFront::updateOrCreate(
            ['id' => $request->edit_id],
            ['title' => $request->data]);
        if($survey) {
            return ['status' => true, 'survey' => $survey];
        }
        return ['status' => true];*/
    }
    public static function isBase64Encoded($str)
    {
        try
        {
            return (bool) preg_match('/data:image\/([a-zA-Z]*);base64,([^"]*)/g', $str);
        }
        catch(Exception $e)
        {
            // If exception is caught, then it is not a base64 encoded string
            return false;
        }

    }
    public function getSurveyJson(Request $request)
    {
        $id = $request->id;
        $user_id = $request->user_id;

        $survey = SurveyFront::whereId($id)->first();

        if ($survey) {
            $survey_json = $this->replaceTagsOfSurveyForm($user_id,$survey);
            return ['status' => true, 'message' => 'Success', 'json' => json_encode($survey_json)];
       //     return ['status' => true, 'message' => 'Success', 'json' => $survey->json];
        }
        return ['status' => false, 'message' => 'Invalid Survey Id'];
    }

    public function replaceTagsOfSurveyForm($user_id,$survey) {
        try {
            //get user survey queue
            $survey_queue = SurveyQueue::where(['user_id' => $user_id,'survey_id' => $survey->id])->first();
            $json_data = json_decode($survey->json);
            if($survey_queue) {
                if($survey_queue->csv_data) {
                    $json_csv = json_decode($survey_queue->csv_data,true);
                    if(isset($json_data->pages)) {
                        foreach ($json_data->pages as &$page) {
                            foreach($page->elements as &$data) {
                                //dd($data->title);
                                $html = (new TagReplacementUtility())->generateTagText($data->title,0,$user_id,0,$survey->id,[],0,$json_csv);
                                $data->title = $html;
                            }
                        }
                    }
                }
            }
            //if survey is send manually
            else {
                if(isset($json_data->pages)) {
                    foreach ($json_data->pages as &$page) {
                        foreach($page->elements as &$data) {
                            //dd($data->title);
                            $html = (new TagReplacementUtility())->generateTagText($data->title,0,$user_id,0,$survey->id,[],0);
                            $data->title = $html;
                        }
                    }
                }
            }



            Log::channel('custom')->info('$json_data', ['$json_data' => $json_data]);
            return $json_data;
        }
        catch (Exception $e) {
            Log::channel('custom')->info('replaceTagsOfSurveyForm_error', ['replaceTagsOfSurveyForm_error' => $e->getMessage(),'line' => $e->getLine(),'error_tract' => $e->getTrace()]);
        }
    }

    public function saveSurveyAnswers(Request $request)
    {

        try {
            $input['user_id'] = ($request->user_id) ?? 0;
            $input['edit_id'] = $request->edit_id;
            $input['json'] = json_encode($request->data);

            $pointsEarn = 0;
            $survey = SurveyQuestionAnswers::create($input);
            if ($request->user_id != 0) {
                $response = $this->surveyCompletedByUser($request->user_id, $request->edit_id);
                $getData = $this->completedMissionForUser($request->user_id,0);
                if(count($getData) >0){
                    foreach ($getData as $value) {
                        if(isset($value['points'])) {
                            $pointsEarn = ($pointsEarn + $value['points']);
                        }
                    }
                }
                if (count($response) > 0) {
                    foreach ($response as $value) {
                        if (isset($value['points'])) {
                            $pointsEarn = ($pointsEarn + $value['points']);
                        }
                    }
                }
            }


            if ($survey) {
                //update survey queue status
                \App\Models\SurveyQueue::where(['user_id' => ($request->user_id) ?? 0,'survey_id' => $request->edit_id])->update(['sent_status' => 'completed']);



                //make answer array
                $arr = [];
                $survey_front = SurveyFront::where('id',$survey->edit_id)->first();
                $json_data = json_decode($survey_front->json);


                $answer_json = json_decode($survey->json,true);
                if(isset($answer_json)) {
                    if(isset($json_data->pages)) {
                        foreach ($json_data->pages as $page) {
                            foreach($page->elements as $data) {
                                $answer = "";
                                if(isset($answer_json[$data->name])) {
//                                if(is_array($answer_json[$data->name])) {
//                                    $answer = implode(',',$answer_json[$data->name]);
//                                }
                                    //else {
                                    $answer = $answer_json[$data->name];
                                    //}
                                }
                                //Log::channel('custom')->info('saveSurveyAnswers_error', ['saveSurveyAnswers$data' => $data]);
                                $question = "";
                                if(property_exists($data,"title"))
                                    $question = $data->title;
                                else if(property_exists($data,"name"))
                                    $question = $data->name;

                                $temp = [
                                    'question' => $question,
                                    'comment' => isset($data->commentText) ? $data->commentText : "",
                                    'answer' => $answer
                                ];
                                $arr[] = $temp;
                            }
                        }



                    }
                }


                //call event trigger
                $trigger_type = "$.survey_trigger";

                $data = [];
                $data['user_id'] = [$request->user_id ?? 0];
                $data['answers'] = $arr;
                $data['survey_id'] = $survey->edit_id;
                $data['answer_record'] = $survey->id;
                $data['trigger_type'] = 'survey';

                (new VCTrigger())->callVCTrigger($data,$trigger_type);



                return ['status' => true, 'survey' => $survey, 'points' => $pointsEarn];
            } else {
                return ['status' => false];
            }
        }
        catch (Exception $e) {
            Log::channel('custom')->info('saveSurveyAnswers_error', ['saveSurveyAnswers_error' => $e->getMessage(),'line' => $e->getLine(),'error_tract' => $e->getTrace()]);
        }
    }


    public function saveQuestionAnswer(Request $request)
    {
        try {
            $question = SurveyQuestion::create(
                ['question' => $request->question,
                    'survey_id' => $request->edit_id,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ]);
            if ($question) {
                $answers = [];
                SurveyAnswer::where('question_id', $question->id)->delete();
                foreach ($request->answers as $ans) {
                    $temp = [
                        'question_id' => $question->id,
                        'answer' => $ans,
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    ];
                    $answers[] = $temp;
                }
                SurveyAnswer::insert($answers);
            } else {
                return ['status' => false, 'message' => 'Question could not saved'];
            }
            return ['status' => true];
        } catch (Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }


    public function updateQuestionAnswer(Request $request)
    {
        try {
            $question = SurveyQuestion::where(['id' => $request->question_id])->update(
                ['question' => $request->question,
                    'survey_id' => $request->edit_id,
                    'updated_at' => date('Y-m-d H:i:s')
                ]);
            if ($question) {
                $answers = [];
                SurveyAnswer::where('question_id', $request->question_id)->delete();
                foreach ($request->answers as $ans) {
                    $temp = [
                        'question_id' => $request->question_id,
                        'answer' => $ans,
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    ];
                    $answers[] = $temp;
                }
                SurveyAnswer::insert($answers);
            } else {
                return ['status' => false, 'message' => 'Question could not saved'];
            }
            return ['status' => true];
        } catch (Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }


    public function deleteSurvey($id)
    {
        $survey = SurveyFront::findOrfail($id);
        $survey->delete();
        return ['status' => $survey ? true : false];
    }


    public function exportSurveyStats(Request $request)
    {
        $admin_id = $request->get('user_id');
        $admin_email = $request->get('email');
        $admin_name = $request->get('name');

        $survey = SurveyFront::where('id', $request->get('id'))->first()->toArray();


        $questionsJson = json_decode($survey['json']);


        $questionsData = $questionsJson->pages;


        $elements = array_column($questionsData, 'elements');


        $questionAnswerHeader = [];
        foreach ($elements as $elementKey => $elementValue) {
            foreach ($elementValue as $key => $value) {
                $questionAnswerHeader[] = $value->name;
            }
        }


        $surveyAnswers = SurveyQuestionAnswers::where('edit_id', $request->get('id'))->with('user_details')->get()->toArray();

        $finalData = [];
        foreach ($surveyAnswers as $key => $row) {

            $finalData[] = $this->filterSurveyJson($admin_id, $admin_email, $admin_name, $questionAnswerHeader, $row);
        }

        return Excel::download(new SurveyStatsJsonExport(collect($finalData), $questionAnswerHeader), 'survey_stats.csv');
    }//..... end of exportSurveyStats() .....//

    private function filterSurveyJson($admin_id, $admin_email, $admin_name, $questionAnswerHeader, $row)
    {
        $json = (array)json_decode($row['json']);
        $surveyQuestionAnswers = collect($json);

        $requiredData = [];

        foreach ($questionAnswerHeader as $value) {
            if ($row['user_details']) {
                $requiredData['id'] = $row['user_id'];
                $requiredData['user_name'] = $row['user_details']['user_first_name'] . ' ' . $row['user_details']['user_family_name'];
                $requiredData['email'] = $row['user_details']['email'];
                $requiredData['date'] = $row['created_at'];

            } else {
                $requiredData['id'] = $admin_id;
                $requiredData['user_name'] = $admin_name;
                $requiredData['email'] = $admin_email;
                $requiredData['date'] = $row['created_at'];
            }
            @$requiredData[$value] = $surveyQuestionAnswers[$value];
        }
        return $requiredData;
    }//..... end of function spenderPercentage


    public function dumpUserInGroup($company_id)
    {
        DB::table("group_members")->whereGroupId(1)->delete();
        $users = User::get(['user_id']);
        foreach ($users as $key => $value) {
            $value->group_id = 1;
            $value->created_at = date("Y-m-d H:i:s");
            $value->updted_at = date("Y-m-d H:i:s");
            $value->company_id = $company_id;
        }
        $users = $users->chunk(100);
        foreach ($users as $key => $value) {
            DB::table("group_members")->insert($value->toArray());
        }
        return "successfully dumped";
    }

    private function surveyCompletedByUser($user_id, $edit_id)
    {

        $user = User::where('user_id', $user_id)->first();
        $this->userFound = $user;
        if (!$user) {
            return ['status' => false, 'message' => 'user not exists'];
        }
        $this->segmentation = new Segmentation(ElasticsearchUtility::generateIndexName(config('constant.COMPANY_ID'), ''));

        $this->filterCampaignsForOptionalFields($user);

        $optionalMissions = $this->checkMissionsForSurveyCompleted($edit_id);
        $this->userMissions = $this->gObj->setActiveMissionsForTransactions($optionalMissions, $user);
        Log::channel('custom')->info('rewardOnScanReciept', ['rewardOnScanReciept' => $this->userMissions]);
        $response = $this->gObj->processCompletedMissions($this->userMissions, $user);
        return $response;
    }

    private function checkMissionsForSurveyCompleted($edit_id)
    {

        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions, $edit_id) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game, $edit_id) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segments = explode(',', $mission->target_segments);
                    if ($this->filterCheckSegments($segments, ['type' => 'completed_survey', 'survey_id' => $edit_id])) {

                        $userMissions->push($mission);
                    }
                });
        });

        return $userMissions;
    }

    private function findSurveyInSegmentation($qp, $condition)
    {

        if ($qp->name == $condition['type']) {
            if ($condition['survey_id'] == $qp->value->survey_id) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private function filterForScanningRecipt($segmentId, $condition)
    {
        $found = '';

        Segment::whereIn('id', $segmentId)->get(['id', 'query_parameters'])
            ->each(function ($segment) use (&$found, $condition) {
                if (!$found) {
                    foreach (json_decode($segment->query_parameters) as $qp) {
                        switch ($condition['type']) {
                            case 'completed_survey':
                                return ($qp->name == $condition['type'])? $found = $qp->value->survey_id: $found ='';
                            case 'seen_videos':
                                return ($qp->name == $condition['type'])? $found = $qp->value->video_id: $found ='';


                        }
                    }
                }//..... end if() .....//
            });

        return $found;
    }

    private function findSurveyMissions($missions)
    {
        $surveyId='';
            foreach ($missions as $miss){
                $segments = explode(',', $miss->target_segments);
                $receiveId = $this->filterForScanningRecipt($segments, ['type' => 'completed_survey']);
                if(!empty($receiveId)) {
                    $surveyId = $receiveId;
                }
            }
        Log::channel('custom')->info('findSurveyMissions', ['findSurveyMissions' => $surveyId]);

            return $surveyId;
    }

    public function findVideoMissions($missions)
    {
        $surveyId=[];
        foreach ($missions as $miss){
            $segments = explode(',', $miss->target_segments);
            $receiveId = $this->filterForScanningRecipt($segments, ['type' => 'seen_videos']);
            if(!empty($receiveId)) {
               $recipe = DB::table('recipe_offers')->where('id',$receiveId)->first();
               $surveyId['video_id'] = $receiveId;
               $surveyId['video_url'] = $recipe->url??\url('/'.$recipe->video_link);
            }
        }
        Log::channel('custom')->info('findSurveyMissions', ['findSurveyMissions' => $surveyId]);

        return (object)$surveyId;
    }

    public function userFinalTransaction($user,$products,$region)
    {

        $this->segmentation = new Segmentation(config('constant.ES_INDEX_BASENAME'));
        $this->filterCampaignsActiveGamesAndMissionsUserRegion($user->user_id);

        $signUpmissions = $this->checkMissionsFinalTransaction($user,$products);

        $this->userMissions = $this->gObj->setActiveMissionsForTransactions($signUpmissions, $user);

        $this->gObj->processMissions($this->userMissions, $user);
        if ($this->userMissions->isNotEmpty()) {
            return [self::STATUS => true, 'data' => $this->userMissions];
        } else {
            return [self::STATUS => false];
        }
    }

    private function checkMissionsFinalTransaction($user,$products)
    {
        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions,$products) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game,$products) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segments = explode(',', $mission->target_segments);

                    if ($this->filterCheckSegments($segments, ['type' => 'transaction_scan','products' =>$products])) {
                        $userMissions->push($mission);
                    }
                });
        });

        return $userMissions;
    }//---- End of checkMissionsForTransaction() -----//

    private function getFindProduct($qp, $condition)
    {
        if($qp->name == $condition['type']){
            $count = false;
            $data = collect($qp->value->products);
            $data = $data->pluck('plu_ids');
            $newData = [];
            foreach ($data as $value){
                $char = rtrim(ltrim($value,','),',');
                $char = explode(',',$char);
                foreach ($char as $newChar)
                    $newData[] = $newChar;

            }
            foreach ($newData as $value){
                foreach ($condition['products'] as $cond){
                    if($cond === $value){
                        $count = true;
                    }
                }
            }
            if($count){
                return true;
            }else{
                return false;
            }

        }else{
            return false;
        }
    }

    public function checkMissionsForVideos($id,$video_id)
    {

        $user = User::where('user_id', $id)->first();

        $this->segmentation = new Segmentation(config('constant.ES_INDEX_BASENAME'));
        $this->filterCampaignsForOptionalFields($user);
        $signUpmissions = $this->filterMissionForVideos($user,$video_id);

        $this->userMissions = $this->gObj->setActiveMissionsForTransactions($signUpmissions, $user);


        if ($this->userMissions->isNotEmpty()) {
            $response= $this->gObj->processCompletedMissions($this->userMissions, $user);
            Log::channel('custom')->info('changeMemberShip', ['changeMemberShip' => $this->userMissions]);
            return $response;
        } else {
            return [self::STATUS => false];
        }
    }//---- End of changeMemberShip() ----//

    private function filterMissionForVideos($user,$video_id)
    {
        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions, &$user,$video_id) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game, &$user,$video_id) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segmentId = explode(',', $mission->target_segments);


                    Log::channel('custom')->info('segments', ['segments' => $segmentId]);
                    if ($this->filterCheckSegments($segmentId, ['type' => 'seen_videos','video_id' => $video_id])) {
                        $userMissions->push($mission);
                    }

                });
        });

        return $userMissions;
    }//----- End of checkMissionsForMembership() ------//

    private function findVideoInSegment($qp, $condition)
    {
        if($qp->name == $condition['type']){
            if($qp->value->video_id  == $condition['video_id']){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

    public function userRefferedScanSlip($id)
    {
        $user = User::where('user_id', $id)->first();
        if($user->referal_by) {
            $this->segmentation = new Segmentation(config('constant.ES_INDEX_BASENAME'));
            $this->filterCampaignsForOptionalFields($user);
            $signUpmissions = $this->filterMissionRefferdScan($user);

            $this->userMissions = $this->gObj->setActiveMissionsForTransactions($signUpmissions, $user);


            if ($this->userMissions->isNotEmpty()) {
                $response = $this->gObj->processCompletedMissions($this->userMissions, $user);
                return $response;
            } else {
                return [self::STATUS => false];
            }
        }else{
            return ['status' => false];
        }
    }

    private function filterMissionRefferdScan($user)
    {
        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions, &$user) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game, &$user) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segmentId = explode(',', $mission->target_segments);


                    Log::channel('custom')->info('segments', ['segments' => $segmentId]);
                    if ($this->filterCheckSegments($segmentId, ['type' => 'referral_user'])) {
                        $userMissions->push($mission);
                    }

                });
        });

        return $userMissions;
    }//----- End of checkMissionsForMembership() ------//

    public function completedProfileUser($id,$percentage)
    {
        $user = User::where('user_id', $id)->first();

        $this->segmentation = new Segmentation(config('constant.ES_INDEX_BASENAME'));
        $this->filterCampaignsForOptionalFields($user);
        $signUpmissions = $this->filterMissionCompletedProfile($user,$percentage);

        $this->userMissions = $this->gObj->setActiveMissionsForTransactions($signUpmissions, $user);


        if ($this->userMissions->isNotEmpty()) {
            $response= $this->gObj->processMissions($this->userMissions, $user);
            Log::channel('custom')->info('changeMemberShip', ['changeMemberShip' => $this->userMissions]);
            return $response;
        } else {
            return [self::STATUS => false];
        }
    }

    private function filterMissionCompletedProfile($user,$percentage)
    {
        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions, &$user,$percentage) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game, &$user,$percentage) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segmentId = explode(',', $mission->target_segments);

                    $missionEnteries = MissionUserEntry::where(['mission_id'=>$mission->id,'user_id' => $user->user_id])->first();
                    Log::channel('custom')->info('segments', ['segments' => $segmentId]);
                    if ($this->filterCheckSegments($segmentId, ['type' => 'completed_profile','percentage' =>$percentage]) and !$missionEnteries) {
                        $userMissions->push($mission);
                    }

                });
        });

        return $userMissions;
    }//----- End of checkMissionsForMembership() ------//

    /**
     * @param $qp
     * @param $condition
     * @return bool
     *
     * Function for match percentage
     */
    private function matchPercentage($qp, $condition)
    {
        if($qp->name ==$condition['type']){
           return  true;

        }else{
            return false;
        }
    }//----- End of matchPercentage() -----//

    /**
     * @param $userid
     *
     * Filter campaign for gamification campaign
     */
    private function filterCampaignsActiveGamesAndMissionsUserRegion($userid): void
    {
        $campaigns = $this->gObj->getGamificationCampaignsFor();
        $this->games = $this->gObj->retrieveActiveGamesFromCampaigns($campaigns, User::whereUserId($userid)->first());
    }//----- End of filterCampaignsActiveGamesAndMissionsUserRegion() ------//

    /**
     * @param $id
     * @param $percentage
     * @return array
     *  Function for processing mission for completed
     *  condition
     *
     */
    public function completedMissionForUser($id,$totalAmount)
    {
        $user = User::where('user_id', $id)->first();
        $user->transaction_amount =$totalAmount;

        $this->segmentation = new Segmentation(config('constant.ES_INDEX_BASENAME'));
        $this->filterCampaignsForOptionalFields($user);
        $signUpmissions = $this->filterCompleteMissionProfile($user);

        $this->userMissions = $this->gObj->setActiveMissionsForTransactions($signUpmissions, $user);


        if ($this->userMissions->isNotEmpty()) {
            $response = $this->gObj->processCompletedMissions($this->userMissions, $user);
            Log::channel('custom')->info('changeMemberShip', ['changeMemberShip' => $this->userMissions]);
            return $response;
        } else {
            return [self::STATUS => false];
        }
    }//----- End of completedMissionForUser() -----//

    /**
     * @param $user
     * @param $percentage
     * @return Collection
     *  Function for filtering the complete mission condition
     *  and after that assign mission
     *
     */
    private function filterCompleteMissionProfile($user)
    {
        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions, &$user) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game, &$user) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segmentId = explode(',', $mission->target_segments);


                    Log::channel('custom')->info('filterCompleteMissionProfile', ['segments' => $segmentId]);
                    if ($this->filterCheckSegments($segmentId, ['type' => 'complete_missions','user_id'=> $user->user_id])) {
                        $userMissions->push($mission);
                    }

                });
        });

        return $userMissions;
    }//----- End of filterCompleteMissionProfile() ------//

    /**
     * @param $qp
     * @param $condition
     * @return bool
     *  Function for complete missions
     */
    private function completeMissions($qp, $condition)
    {
        if($qp->name == $condition['type']){
            if($qp->value->mission_complete >0){
               $missionComplete =  MissionUserEntry::where('user_id',$condition['user_id'])->count();
               if($missionComplete == $qp->value->mission_complete){
                   return true;
               }else{
                   return false;
               }

            }else{
                return false;
            }
        }else{
            return false;
        }
    }//---- End of completeMissions() ----//

    public function completedWalkThrougMission($id)
    {
        $user = User::where('user_id', $id)->first();

        $this->segmentation = new Segmentation(config('constant.ES_INDEX_BASENAME'));
        $this->filterCampaignsForOptionalFields($user);
        $signUpmissions = $this->filterCompletedWalkThrough($user);

        $this->userMissions = $this->gObj->setActiveMissionsForTransactions($signUpmissions, $user);


        if ($this->userMissions->isNotEmpty()) {
            $response = $this->gObj->processCompletedMissions($this->userMissions, $user);
            Log::channel('custom')->info('changeMemberShip', ['changeMemberShip' => $this->userMissions]);
            return $response;
        } else {
            return [self::STATUS => false];
        }
    }//----- End of completedMissionForUser() -----//

    private function filterCompletedWalkThrough($user)
    {
        $userMissions = collect([]);

        $this->games->each(function ($game) use (&$userMissions, &$user) {
            $game->missions->each(
                function ($mission) use (&$userMissions, $game, &$user) {
                    $mission->venue_id = $game->venue_id;
                    $mission->campaign_id = $game->campaign_id;
                    $segmentId = explode(',', $mission->target_segments);


                    Log::channel('custom')->info('filterCompleteMissionProfile', ['segments' => $segmentId]);
                    if ($this->filterCheckSegments($segmentId, ['type' => 'walkthrough_completed','user_id'=> $user->user_id])) {
                        $userMissions->push($mission);
                    }

                });
        });

        return $userMissions;
    }//----- End of filterCompleteMissionProfile() ------//

    private function filterMissionSegement($target_segments)
    {
        $found = ['name' => '','found' => false];

        Segment::whereIn('id', $target_segments)->get(['id', 'query_parameters'])
            ->each(function ($segment) use (&$found) {
                if (!$found['found']) {
                    foreach (json_decode($segment->query_parameters) as $qp) {
                        $found['name'] = $qp->name;
                    }
                }//..... end if() .....//
            });

        return $found;
    }


}