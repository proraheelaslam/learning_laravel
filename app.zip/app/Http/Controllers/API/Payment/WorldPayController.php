<?php

namespace App\Http\Controllers\API\Payment;

use App\Http\Requests\Payment\AddCardRequest;
use App\Http\Requests\Payment\MakeInvoiceRequest;
use App\Http\Requests\Payment\PaymentVerifiedRequest;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repository\Payment\WorldpayInterface;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
/*use Vyuldashev\LaravelOpenApi\Annotations as OpenApi;*/

/**
 * will be transfer it to PaymentController
 * Class WorldPayController
 * @package App\Http\Controllers\API\Payment
 */
/**
 * @OpenApi\PathItem()
 */
class WorldPayController extends Controller
{
    /**
     * @var WorldpayInterface
     */
    private $_paymentService;

    /**
     * WorldPayController constructor.
     * @param WorldpayInterface $paymentService
     */
    public function __construct(WorldpayInterface $paymentService)
    {
//        parent::__construct();
        /**
         * @todo create new payment service base on plugin name in request header or path
         */
        $this->_paymentService = $paymentService;
    }
	public function initialDeviceSession(){
    	return $this->_paymentService->initialDeviceSession();
	}

	/**
	 * description create and authorize created invoice with 3ds
	 * @param MakeInvoiceRequest $request
	 * @return \Illuminate\Http\JsonResponse
     * @OpenApi\Operation(tags="payment")
     * @OpenApi\RequestBody(factory="MakeInvoiceRequestBody")
     * @OpenApi\Response(factory="MakeInvoiceResponse", statusCode=200)
	 */
    public function makeInvoice(MakeInvoiceRequest $request){
        return $this->_paymentService->makeInvoice($request->header('Country'),$request->validated());
    }

    /**
     * add payment method to KillBill service
     * @param AddCardRequest $request
     * @return mixed
     * @OpenApi\Operation(tags="payment")
     * @OpenApi\RequestBody(factory="AddNewCardRequestBody")
     * @OpenApi\Response(factory="AddCardResponse", statusCode=200)
     */
    public function addPaymentMethod(AddCardRequest $request){
       return  $this->_paymentService->addPaymentMethod($request->header('Country'),$request->validated());
    }

    /**
     * Continuous payment process after challenged
     * @param PaymentVerifiedRequest $request
     * @return mixed
     * @OpenApi\Operation(tags="payment")
     * @OpenApi\RequestBody(factory="PaymentAuthorizedRequestBody")
     * @OpenApi\Response(factory="PaymentAuthorizedResponse", statusCode=200)
     */
    public function paymentAuthorized(PaymentVerifiedRequest $request){
        return $this->_paymentService->paymentAuthorized($request->validated());
    }

    /**
     * get Current user list payment
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @OpenApi\Operation(tags="payment")
     * @OpenApi\Response(factory="ListPaymentResponse", statusCode=200)
     */
    public function getListPayment(Request $request): \Illuminate\Http\JsonResponse
    {
        return $this->_paymentService->getListPayment($request->header('Country'));
    }
}
