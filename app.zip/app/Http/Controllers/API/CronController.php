<?php

namespace App\Http\Controllers\API;

use App\Models\Lt_Transaction;
use App\Models\Setting;
use App\Models\UserReceipts;
use App\User;
use Carbon\Carbon;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CronController extends Controller
{
    public function getAllUserStatus()
    {
        //Get Waitron group id
        $groupData = DB::table('groups')->where('group_name', 'Waitron')->first();

        //Get Groups Members whose group is waitron
        $userData = DB::table('group_members')->where('group_id', $groupData->id)->get();


        $userMissions = collect([]);
        $userData->each(function ($item, $key) use (&$userMissions) {
            $find = User::whereUserId($item->user_id)->first();
            $userMissions->push($find->user_mobile);
        });

        if ($userMissions->isNotEmpty()) {
            //Curl Request to Pos for checking the waitron status
            $response = json_decode((new Client(['headers' => []]))
                ->request('POST', config('constant.POS_URL') . 'getWimpyEmployeesStatus', [
                    'json' => ["emp_phone_arr" => $userMissions->toArray()]
                ])->getBody());


            Log::channel('user')->info('Response From POS', ['ResponsePos' => $response]);

            //Delecte user entry from member group table for waitron
            if ($response->status) {
                $users = User::whereIn('user_mobile', $response->body)->pluck('user_id');
                DB::table('group_members')->where('group_id', $groupData->id)->whereIn('user_id', $users)->delete();
            }
        }
    }//----- End of getAllUserStatus() -----//

    public function expirePoints(Request $request) {
        set_time_limit(0);
        try {
            $client = $request->input('client');
            $sliding_scale = Setting::where(['type' => 'point_expiry_settings','field1' => 'sliding_scale'])->first();
            if($sliding_scale) {
                $num = $sliding_scale->field2;
                $time_type = json_decode($sliding_scale->field3);
                if(isset($time_type)) {
                    $time_type = $time_type->value;
                    $date = $this->getSpecifiedDate($num,$time_type);
                    //$points = Lt_Transaction::selectRaw('FROM_UNIXTIME(`created_at`,"%Y-%m-%d") AS "creation_date")->whereDate('created_at','<=',$date)->get();
                    $points = DB::select("SELECT * FROM (SELECT *,FROM_UNIXTIME(created_at,'%Y-%m-%d') AS 'creation_date' FROM lt_transations) AS new_table WHERE new_table.creation_date = '$date'");
                    foreach ($points as $point){
                        if($client == 'wuhu') {
                            $valid_receipt = UserReceipts::whereDate('created_at','>=',$date)
                                ->where('user_id',$point->user_id)->where('points','>',0)->first();

                            if(!$valid_receipt) {
                                //expire points
                                Lt_Transaction::where('lt_transation_id',$point->lt_transation_id)->update(['expiry_date' => Carbon::now()->subDays(1)->toDateString()]);

                            }
//                            else {
//                                echo "valid receipt---".$valid_receipt->created_at."-------".$point->user_id."<br>";
//                                echo "point---".$point->lt_transation_id."<br>";
//                            }

                        }
                        else {
                            //expire points
                            $point->expiry_date = Carbon::now()->subDays(1)->toDateString();
                            $point->save();
                        }
                    }
                }
                return response()->json(['status' => true,'message' => 'Points expired successfully']);
            }
            else {
                return response()->json(['status' => false,'message' => 'Setting not found']);
            }
        }
        catch (\Exception $e) {
            dd($e->getMessage());
        }
    }

    public function getSpecifiedDate($offset,$type) {
        $today = Carbon::now();
        switch ($type) {
            case 'day':
                return $today->subDays($offset)->toDateString();
            case 'week':
                return $today->subWeeks($offset)->toDateString();
            case 'month':
                return $today->subMonths($offset)->toDateString();
            default:
                return '';
        }
    }
}
