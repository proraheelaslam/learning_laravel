<?php


namespace App\Http\Controllers\API;


use App\Exports\MemberExportWithDetailsNew;
use App\Exports\VoucherUnusedReport;
use App\Http\Controllers\API\UsersController;
use App\Exports\ReportExporting;
use App\Http\Controllers\Controller;
use App\Models\MemberTransaction;
use App\Models\Setting;
use App\Models\Voucher;
use App\Models\VoucherUser;
use App\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Symfony\Component\HttpFoundation\StreamedResponse;

class VoucherReportController extends Controller
{
    public function __construct()
    {
        set_time_limit(0);
        ini_set('memory_limit', '-1');
        ini_set('display_errors', 1);
        ini_set("allow_url_fopen", 1);
    }
    public function getVoucherReport()
    {
        $id = request()->id;
        $voucherRecieve = Voucher::where('id',$id)->first();
        $filename = 'voucherReport_' . date('Y-m-d') . '.csv';
        $data = [];
        $memberTransaction = MemberTransaction::get();
        foreach ($memberTransaction as $value)
        {

            //order detail change
            //if($value->order_detail) {
                $res = json_encode((new UsersController())->getOrderDetail($value->id));
                $json = json_decode($res,true);
                //$json = json_decode($value->order_detail, true);
                foreach ($json as $v) {
                    if (!empty($v['voucher_code'])) {
                        $voucher = VoucherUser::where('voucher_code', $v['voucher_code'])->withTrashed()->first();
                        if ($voucher['voucher_id'] == $id) {
                            $user = User::where('user_id', $voucher->user_id)->first();

                            $data[] = ['date' => $value->date, 'transaction_id' => $value->transaction_id, 'client_member_id' => $user->client_customer_id, 'name' => $user->user_first_name . ' ' . $user->user_family_name, 'email' => $user->email
                                , 'amount' => $value->amount, $value->discount, 'voucher_amount' => ($voucherRecieve->amount > 0) ? $voucherRecieve->amount : '0', 'discount_type' => $voucherRecieve->discount_type
                            ];

                        }
                    }
                }
            //}
        }
        ob_end_clean();
        ob_start();
        return Excel::download(new ReportExporting($data), 'voucherReportID'.$id.'.xlsx');
    }

    function insertData()
    {
        $randomVoucher = Voucher::where(['id' => 30])->first();
        for($i = 0; $i<900000;$i++){
            foreach (User::get() as $value){
                $data =[
                    "user_id" => $value->user_id,
                    "company_id" => ($value->region_type =='uk')?config('constant.COMPANY_ID'):config('constant.COMPANY_IRE_ID'),
                    "voucher_start_date" => ($randomVoucher->isNumberOfDays)?date('Y-m-d H:i', strtotime('-1 days')):$randomVoucher->start_date,
                    "voucher_end_date" => ($randomVoucher->isNumberOfDays)?date('Y-m-d H:i', strtotime('+' . $randomVoucher->isNumberOfDays . ' days')):$randomVoucher->end_date,
                    "no_of_uses" => $randomVoucher->no_of_uses,
                    "uses_remaining" => $randomVoucher->no_of_uses,
                    "created_at" => date('Y-m-d H:i'),
                    "updated_at" => date('Y-m-d H:i'),
                    "voucher_id" => $randomVoucher->id,
                    "group_id" => $randomVoucher->group_id ?? 0,
                    "voucher_code" => $this->uniqueVoucherCode($randomVoucher->pos_ibs),

                ];
                VoucherUser::insert($data);
            }
        }
    }
    public function getIBSCode($ibs = 0)
    {
        $settings = Setting::where('type', 'configure_numbers')->first();
        $numberSetting = Setting::where('type', 'voucher_code_length')->first();
        if ($settings->field1 == 1) {
            $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
            $res = "";

            for ($i = 0; $i < 15; $i++)
                $res .= $chars[mt_rand(0, strlen($chars) - 1)];

            $code = str_split($res, 5);

            $first = $code[0] ?? '';
            $second = $code[1] ?? '';
            $third = $code[2] ?? '';
            $string = str_split($third, 2);
            $newString = $string[0] ?? "";
            return ($ibs) ? $ibs . $first . $second . $newString : $first . $second . $third;
        } else {
            $chars = "0123456789";
            $res = "";

            for ($i = 0; $i < (int)$numberSetting->field1; $i++)
                $res .= $chars[mt_rand(0, strlen($chars) - 1)];

            $code = str_split($res, 3);

            $first = $code[0] ?? '';
            $second = $code[1] ?? '';
            return ($ibs) ? $ibs . $first . $second : $first . $second;
        }
    }

    function uniqueVoucherCode($ibs='')
    {
        $voucherCode = $this->getIBSCode($ibs??0);
        $voucherFind = VoucherUser::where('voucher_code',$voucherCode)->exists();
        if($voucherFind){
            return $this->uniqueVoucherCode($ibs??0);
        }else{
            return $voucherCode;
        }
    }
    public function unusedVouchers()
    {

        $allVouchers =DB::table('voucher_users')->selectRaw('voucher_id, count(*) as total')->where(function ($query) {
            $query->where('uses_remaining', '=', 'no_of_uses')
                ->orWhere('uses_remaining','>','0');
        })->groupBy('voucher_id')->get();
        $data = [];

        foreach ($allVouchers as $value){
            $voucher = Voucher::where('id',$value->voucher_id)->first();
            $data[] = ['voucher_name' => $voucher->name, 'voucher_Count'=>$value->total];
        }


        ob_end_clean();
        ob_start();
        return Excel::download(new VoucherUnusedReport($data), 'voucherUnusedReport'.time().'.xlsx');
    }

    private function getAllVouchersFromEs($id)
    {
        return Voucher::where('id',$id)->first();
    }
}