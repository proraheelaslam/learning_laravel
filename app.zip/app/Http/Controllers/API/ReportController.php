<?php


namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Campaign;
use App\Models\Lt_Transaction;
use App\Models\MissionUserEntry;
use App\Models\NotificationEvent;
use App\Models\PunchCard;
use App\Models\StampCompleted;
use App\Models\UserAddresses;
use App\Models\UserNotification;
use App\Models\UserReceipts;
use App\Models\Voucher;
use App\Models\VoucherLog;
use App\Models\VoucherUser;
use App\User;
use Carbon\Carbon;
use Elasticsearch\ClientBuilder;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ReportController  extends Controller
{
    public $client;
    public $index;
    const FORMAT = 'Y-m-d';

    public function __construct()
    {
        set_time_limit(0);
        ini_set('memory_limit', '-1');
        ini_set('display_errors', 1);
        ini_set("allow_url_fopen", 1);
        $this->client = ClientBuilder::create()->setHosts([Config::get('constant.ES_URL')])->build();
        $this->index = config('constant.ES_INDEX_BASENAME');
    }

    public function unusedVouchers()
    {
        $filename = 'unusedVouchers_' . date('Y-m-d') . '.csv';

        $response = new StreamedResponse(function () use ($filename) {
            $handle = fopen(public_path('/uploads/') . $filename, 'w+');

            // Add CSV headers
            fputcsv($handle, [
                'Campaign Name',
                "unused"

            ]);

            VoucherUser::select('count(*) as total_count', 'voucher_id')->where(function ($query) {
                $query->where('uses_remaining', '=', 'no_of_uses')
                      ->orWhere('uses_remaining', '>', '0');

            })->groupBy('voucher_id')->chunk(10, function ($campaigns) use ($handle) {
                foreach ($campaigns as $value) {
                    $vouchers = $this->getAllVouchersFromEs($value->voucher_id);
                    fputcsv($handle, [
                        'voucher_name' => $vouchers->name,
                        "unused" => $value->total_count
                    ]);
                }
            });

            // Close the output stream
            fclose($handle);
        }, 200, [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename,
        ]);

        return $response;
    }

    private function getAllVouchersFromEs($id)
    {
        return Voucher::where('id', $id)->first();
    }

    public function unusedStamp()
    {
        $filename = 'unusedStamps_' . date('Y-m-d') . '.csv';

        $response = new StreamedResponse(function () use ($filename) {
            $handle = fopen(public_path('/uploads/') . $filename, 'w+');

            // Add CSV headers
            fputcsv($handle, [
                'Stamp Name',
                "unused",
                "unused Voucher"

            ]);

            PunchCard::chunk(10, function ($punch) use ($handle) {
                foreach ($punch as $value) {
                    $stamps = $this->getAllStampsFromEs($value->id);
                    $unusedVouchers = $this->getAllVouchersFromEs($value->id, 'punch_card');
                    fputcsv($handle, [
                        'Stamp Name' => $value->name,
                        "unused" => $stamps,
                        "unused Voucher" => $unusedVouchers
                    ]);
                }
            });

            // Close the output stream
            fclose($handle);
        }, 200, [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename,
        ]);

        return $response;
    }

    private function getAllStampsFromEs($id)
    {
        $query = [
            'size' => 0,
            "query" => [
                "bool" => [
                    "must" => [
                        ["match" => ["custom_doc_type" => "punch_card"]],
                        ["range" => ["quantity" => ["lt" => 5]]],
                        ["term" => ["punch_card_rule.id" => ["value" => $id]]]
                    ]
                ]
            ], 'aggs' => ['total_unused' => ['sum' => ['field' => 'quantity']]]
        ];

        $data = $this->client->search(['index' => $this->index, 'body' => $query]);
        return $data['aggregations']['total_unused']['value'];
    }

    public function count($index, $query)
    {
        $query = ['index' => $index, 'body' => $query];
        try {
            return $this->client->count($query)['count'];
        } catch (\Exception $e) {
            return 0;
        }//..... end of try() .....//
    }//..... end of count() .....//

    public function voucherDetailReport()
    {
        $filename = 'voucherDetailReport' . time() . '.csv';
        Log::channel('custom')->info('voucherDetailReport', ['fileName' => $filename]);
        if (request()->has('id')) {


            $response = new StreamedResponse(function () use ($filename) {
                $handle = fopen(public_path('/uploads/') . $filename, 'w+');

                // Add CSV headers
                fputcsv($handle, [
                    'Voucher Name',
                    'Membership ID',
                    'Email',
                    "Active Count",
                    "Redeemed Voucher"

                ]);

                VoucherUser::whereNotNull('user_id')->where('user_id', '!=', '0')->where(['voucher_id' => request()->id])->groupBy('user_id')->withTrashed()->chunk(500, function ($punch) use ($handle) {
                    foreach ($punch as $value) {
                        $userCount = VoucherUser::where(['user_id' => $value->user_id, 'voucher_id' => $value->voucher_id])->whereDate('voucher_start_date', '<=', date('Y-m-d 00:00:00'))->whereDate('voucher_end_date', '>=', date('Y-m-d 23:59:59'))->where('uses_remaining', '>', '0')->sum('uses_remaining');
                        $voucher = Voucher::where('id', $value->voucher_id)->first();
                        $memberShipID = User::where('user_id', $value->user_id)->first();
                        $redeemedCount = VoucherLog::where(['user_id' => $value->user_id, 'voucher_id' => $value->voucher_id])->count();
                        fputcsv($handle, ['voucher_name' => $voucher->name, 'membership_id' => $memberShipID['client_customer_id'], 'email' => $memberShipID['email'], 'Active_Count' => $userCount, 'redeemed_count' => $redeemedCount]);
                    }
                });

                // Close the output stream
                fclose($handle);
            }, 200, [
                'Content-Type' => 'text/csv',
                'Content-Disposition' => 'attachment; filename="' . $filename,
            ]);

            return $response;
        } else {
            $response = new StreamedResponse(function () use ($filename) {
                $handle = fopen(public_path('/uploads/') . $filename, 'w+');

                // Add CSV headers
                fputcsv($handle, [
                    'Voucher Name',
                    'Membership ID',
                    'Email',
                    "Active Count",
                    "Redeemed Voucher"

                ]);

                VoucherUser::whereNotNull('user_id')->where('user_id', '!=', '0')->groupBy('user_id')->withTrashed()->chunk(500, function ($punch) use ($handle) {
                    foreach ($punch as $value) {
                        $userCount = VoucherUser::where(['user_id' => $value->user_id, 'voucher_id' => $value->voucher_id])->whereDate('voucher_start_date', '<=', date('Y-m-d 00:00:00'))->whereDate('voucher_end_date', '>=', date('Y-m-d 23:59:59'))->where('uses_remaining', '>', '0')->sum('uses_remaining');
                        $voucher = Voucher::where('id', $value->voucher_id)->first();
                        $memberShipID = User::where('user_id', $value->user_id)->first();
                        $redeemedCount = VoucherLog::where(['user_id' => $value->user_id, 'voucher_id' => $value->voucher_id])->count();
                        fputcsv($handle, ['voucher_name' => $voucher->name, 'membership_id' => $memberShipID['client_customer_id'], 'email' => $memberShipID['email'], 'Active_Count' => $userCount, 'redeemed_count' => $redeemedCount]);
                    }
                });

                // Close the output stream
                fclose($handle);
            }, 200, [
                'Content-Type' => 'text/csv',
                'Content-Disposition' => 'attachment; filename="' . $filename,
            ]);

            return $response;
        }
    }

    public function allReportDat()
    {
        if ((request()->has('start_date') and !empty(request()->start_date)) and (request()->has('end_date') and !empty(request()->end_date))) {
            $userCreated = User::where('is_active', 1)->whereDate('created_at', '>=', request()->start_date)->whereDate('created_at', '<=', request()->end_date)->count();
            $userAll = User::where('is_active', 1)->whereDate('created_at', '>=', request()->start_date)->whereDate('created_at', '<=', request()->end_date)->get();
            $allIosUser = $userAll->where('device_type', 'ios')->count();
            $allAndroidUser = $userAll->where('device_type', 'android')->count();
            $usReciepts = UserReceipts::where('detail', 'like', '%"is_unilever":1%')->whereDate('created_at', '>=', request()->start_date)->whereDate('created_at', '<=', request()->end_date)->take(10)->get();
            foreach ($usReciepts as $value) {
                $user = User::where('user_id', $value->user_id)->first();
                $value->name = $user->user_first_name . ' ' . $user->family_name;
            }
        } else {
            $userCreated = User::where('is_active', 1)->count();
            $userAll = User::where('is_active', 1)->get();
            $allIosUser = $userAll->where('device_type', 'ios')->count();
            $allAndroidUser = $userAll->where('device_type', 'android')->count();
            $usReciepts = UserReceipts::where('detail', 'like', '%"is_unilever":1%')->take(10)->get();
            foreach ($usReciepts as $value) {
                $user = User::where('user_id', $value->user_id)->first();
                $value->name = $user->user_first_name . ' ' . $user->family_name;
            }
        }
        $lastThirty = User::where('is_active', 1)->whereDate('created_at', '>=', Carbon::today()->subDay(30))->get();
        $totalCountThirty = $lastThirty->count();
        $iosThirtyDays = $lastThirty->where('device_type', 'ios')->count();
        $androidThirtyDays = $lastThirty->where('device_type', 'android')->count();
        $todayRegistration = User::where('is_active', 1)->whereDate('created_at', Carbon::today())->count();

        return ['status' => true, 'total_users' => $userCreated, 'top_users' => $usReciepts, 'ios_users' => $allIosUser,
                'android_users' => $allAndroidUser, 'totalCountThirty' => $totalCountThirty,
                'iosThirtyDays' => $iosThirtyDays, 'androidThirtyDays' => $androidThirtyDays,
                'today_register' => $todayRegistration
        ];
    }

    public function demographicReportData()
    {
        $totalUser = $this->getUserGenderDetails();

        return ['status' => true, 'user_data' => $totalUser];
    }

    private function getUserGenderDetails()
    {
        if ((request()->has('star_date') and !empty(request()->star_date)) and (request()->has('end_date') and !empty(request()->end_date)))
            $users = User::whereDate('created_at', '>=', request()->start_date)->whereDate('created_at', '<=', request()->end_date)->where('is_active', 1)->get();
        else
            $users = User::where('is_active', 1)->get();

        $male = $users->filter(function ($data) {
            return strstr($data->gender, 'male') ||
                   strstr($data->gender, 'M') ||
                   strstr($data->gender, 'Male');
        })->count();

        $female = $users->filter(function ($data) {
            return strstr($data->gender, 'Female') ||
                   strstr($data->gender, 'F') ||
                   strstr($data->gender, 'female');
        })->count();

        $other = $users->filter(function ($data) {
            return strstr($data->gender, 'Other') ||
                   strstr($data->gender, 'O') ||
                   strstr($data->gender, 'other');
        })->count();

        $unknow = User::where(['is_active' => 1, 'gender' => ''])->count();
        $totalUser = $users->count();
        $averagePoints = 0;
        $missionCompleted = MissionUserEntry::count();
        $stampCardCompletd = StampCompleted::count();

        if ((request()->has('star_date') and !empty(request()->star_date)) and (request()->has('end_date') and !empty(request()->end_date)))
            $allPointSum = Lt_Transaction::whereDate('created_at', '>=', request()->start_date)->whereDate('created_at', '<=', request()->end_date)->where(['type' => 'credit'])->sum('value_points');
        else
            $allPointSum = Lt_Transaction::where(['type' => 'credit'])->sum('value_points');

        if ((request()->has('star_date') and !empty(request()->star_date)) and (request()->has('end_date') and !empty(request()->end_date)))
            $totalPointsCount = Lt_Transaction::whereDate('created_at', '>=', request()->start_date)->whereDate('created_at', '<=', request()->end_date)->where('type', 'credit')->count();
        else
            $totalPointsCount = Lt_Transaction::where('type', 'credit')->count();

        if ($totalPointsCount > 0) {
            $averagePoints = ($allPointSum / $totalPointsCount);
        }


        return ['male_count' => number_format((($male / $totalUser) * 100), '2', '.', ''),
                'female_count' => number_format((($female / $totalUser) * 100), '2', '.', ''),
                'other_count' => number_format((($other / $totalUser) * 100), '2', '.', ''),
                'unknown_count' => number_format((($unknow / $totalUser) * 100), '2', '.', ''),
                'total_users' => $users->count(), 'missionCompleted' => $missionCompleted,
                'stampCardCompletd' => $stampCardCompletd, 'averagePoints' => number_format($averagePoints, 2, '.', '')];
    }

    public function getMemberReport()
    {
        $user = User::where(['is_active' => 1]);

        if (request()->has('search') and !empty(request()->search)) {
            $user->where('user_first_name', 'like', '%' . request()->search . '%')->orWhere('user_family_name', 'like', '%' . request()->search . '%')
                 ->orWhere('user_family_name', 'like', '%' . request()->search . '%');
        }

        $res = $user->skip(request()->offset)->take(request()->limit)->get();
        foreach ($res as $value) {
            if (empty($value->user_avatar)) {
                $value->image = 'assets/images/usr_icon.png';
            } else {
                $value->image = 'users/thumbs/thumb_' . $value->user_avatar;
            }
        }

        return ['status' => true, 'total' => User::where(['is_active' => 1])->count(), 'data' => $res];
    }

    public function userPostalCodes()
    {
        $userAddress = UserAddresses::where('postal_code', '!=', '')->groupBy('postal_code')->get();
        $data = [];
        foreach ($userAddress as $value) {
            $userid = UserAddresses::where('postal_code', $value->postal_code)->get()->pluck('user_id');

            $usersGender = $this->findeUserGender($userid);
            $data[] = ['postal_code' => $value->postal_code, 'gender_data' => $usersGender];

        }
        return ['status' => true, 'data' => $data];
    }

    private function findeUserGender($userid)
    {
        $userGender = User::whereIn('user_id', $userid)->get();
        $male = 0;
        $userGender->each(function ($item) use (&$male) {
            if ($item->gender == 'Male' || $item->gender == 'M' || $item->gender == 'male') {
                $male = $male + 1;
            }
        });
        $female = $userGender->filter(function ($data) {
            return strstr($data->gender, 'Female') ||
                   strstr($data->gender, 'F') ||
                   strstr($data->gender, 'female');
        })->count();

        $other = $userGender->filter(function ($data) {
            return strstr($data->gender, 'Other') ||
                   strstr($data->gender, 'O') ||
                   strstr($data->gender, 'other');
        })->count();

        $unknow = User::whereIn('user_id', $userid)->where(['gender' => ''])->count();

        return ['male' => $male, 'female' => $female, 'unknown' => $unknow, 'other' => $other, 'total' => $userGender->count()];
    }

    public function genderSplitData()
    {
        $male = User::where('is_active', 1)->where(function ($q) {
            $q->where('gender', 'Male')->orWhere('gender', 'M')
              ->orWhere('gender', 'male');
        })->get();
        $thirtyMale = 0;
        $sixtyMale = 0;
        $nintyMale = 0;
        $nintyPlusMale = 0;
        foreach ($male as $value) {
            if (!empty($value->dob)) {
                if (Carbon::parse($value->dob)->age <= 30) {
                    $thirtyMale = $thirtyMale + 1;
                } else if (Carbon::parse($value->dob)->age > 30 and Carbon::parse($value->dob)->age <= 60) {
                    $sixtyMale = $sixtyMale + 1;
                } else if (Carbon::parse($value->dob)->age > 60 and Carbon::parse($value->dob)->age <= 90) {
                    $nintyMale = $nintyMale + 1;
                } else if (Carbon::parse($value->dob)->age > 90) {

                    $nintyPlusMale = $nintyPlusMale + 1;
                }
            }
        }

        $maleSeries = [$thirtyMale, $sixtyMale, $nintyMale, $nintyPlusMale];

        $feMale = User::where('is_active', 1)->where(function ($q) {
            $q->where('gender', 'Female')->orWhere('gender', 'F')
              ->orWhere('gender', 'female');
        })->get();

        $thirtyMale = 0;
        $sixtyMale = 0;
        $nintyMale = 0;
        $nintyPlusMale = 0;
        foreach ($feMale as $value) {
            if (!empty($value->dob)) {
                if (Carbon::parse($value->dob)->age <= 30) {
                    $thirtyMale = $thirtyMale + 1;
                } else if (Carbon::parse($value->dob)->age > 30 and Carbon::parse($value->dob)->age <= 60) {
                    $sixtyMale = $sixtyMale + 1;
                } else if (Carbon::parse($value->dob)->age > 60 and Carbon::parse($value->dob)->age <= 90) {
                    $nintyMale = $nintyMale + 1;
                } else if (Carbon::parse($value->dob)->age > 90) {

                    $nintyPlusMale = $nintyPlusMale + 1;
                }
            }
        }
        $femaleSeries = [$thirtyMale, $sixtyMale, $nintyMale, $nintyPlusMale];
        return ['status' => true, 'male' => $maleSeries, 'female' => $femaleSeries];
    }

    public function getEmailReportDetail()
    {
        $data = ['total_sent' => 0, 'total_delivered' => 0, 'total_unique_opened' => 0, 'total_unique_clicked' => 0];
        $date = [];
        if (request()->start_date != '' and request()->end_date != '') {
            $date = $this->generateDateRange(Carbon::parse(request()->start_date), Carbon::parse(request()->end_date));

        } else {

            $date = $this->generateDateRange(Carbon::now()->subDays(30), Carbon::now());
        }

        foreach ($date as $value) {
            $recieveData = DB::table('notification_events')
                             ->where(function ($query) {
                                 if (isset(request()->campaign_id)) {
                                     $query->where('campaign_id', request()->campaign_id);
                                 }
                                 if (isset(request()->user_id)) {
                                     $query->where('user_id', request()->user_id);
                                 }
                             })
                             ->where('timestamp', Carbon::parse($value)->timestamp)
                             ->get();

            $counTotal = $recieveData->where('event', '!=', 'delivered')->where('event', '!=', 'click')->count();
            $delivered = $recieveData->where('event', 'delivered')->count();
            $opened    = $recieveData->where('event', 'open')->groupBy('campaign_id')->count();
            $clicked   = $recieveData->where('event', 'click')->groupBy('campaign_id')->count();

            $data['total_sent']           = $data['total_sent'] + $counTotal;
            $data['total_delivered']      = $data['total_delivered'] + $delivered;
            $data['total_unique_opened']  = $data['total_unique_opened'] + $opened;
            $data['total_unique_clicked'] = $data['total_unique_clicked'] + $clicked;
        }

        return ['status' => true, 'data' => $data];
    }

    public function getClickedOpenData()
    {  $click = [];
        $opened = [];

        $date = [];
        if (request()->start_date != '' and request()->end_date != '') {
            $date = $this->generateDateRange(Carbon::parse(request()->start_date), Carbon::parse(request()->end_date));
        } else {
            $date = $this->generateDateRange(Carbon::now()->subDays(30), Carbon::now());



        }

        foreach ($date as $value) {
            $click[]  = DB::table('notification_events')
                          ->where(['event_type' => 'email', 'event' => 'click'])
                          ->where(function ($query) {
                              if (isset(request()->campaign_id)) {
                                  $query->where('campaign_id', request()->campaign_id);
                              }
                              if (isset(request()->user_id)) {
                                  $query->where('user_id', request()->user_id);
                              }
                          })
                          ->whereDate(DB::raw('FROM_UNIXTIME(`timestamp`,"%Y-%m-%d")'), $value)
                          ->count();
            $opened[] = DB::table('notification_events')
                          ->where(['event_type' => 'email', 'event' => 'open'])
                          ->where(function ($query) {
                              if (isset(request()->campaign_id)) {
                                  $query->where('campaign_id', request()->campaign_id);
                              }
                              if (isset(request()->user_id)) {
                                  $query->where('user_id', request()->user_id);
                              }
                          })
                          ->whereDate(DB::raw('FROM_UNIXTIME(`timestamp`,"%Y-%m-%d")'), $value)
                          ->count();
        }
        $data = ['clicked' => $click, 'opened' => $opened, 'datesData' => $date];
        return ['status' => true, 'data' => $data];
    }

    private function generateDateRange(Carbon $start_date, Carbon $end_date)
    {
        $dates = [];

        for ($date = $start_date->copy(); $date->lte($end_date); $date->addDay()) {
            $dates[] = $date->format(self::FORMAT);
        }

        return $dates;
    }

    public function getLeakDeliverData()
    {
        $click = [];
        $opened = [];
        $date = [];
        if (request()->start_date != '' and request()->end_date != '') {

            $date = $this->generateDateRange(Carbon::parse(request()->start_date), Carbon::parse(request()->end_date));
        } else {
            $date = $this->generateDateRange(Carbon::now()->subDays(30), Carbon::now());

        }
        foreach ($date as $value) {
            $deliverd = DB::table('notification_events')
                          ->where(['event_type' => 'email', 'event' => 'delivered'])
                          ->where(function ($query) {
                              if (isset(request()->campaign_id)) {
                                  $query->where('campaign_id', request()->campaign_id);
                              }
                              if (isset(request()->user_id)) {
                                  $query->where('user_id', request()->user_id);
                              }
                          })
                          ->whereDate(DB::raw('FROM_UNIXTIME(`timestamp`,"%Y-%m-%d")'), $value)
                          ->count();
            $total    = DB::table('notification_events')
                          ->where(['event_type' => 'email'])
                          ->where('event', '!=', 'delivered')
                          ->where(function ($query) {
                              if (isset(request()->campaign_id)) {
                                  $query->where('campaign_id', request()->campaign_id);
                              }
                              if (isset(request()->user_id)) {
                                  $query->where('user_id', request()->user_id);
                              }
                          })
                          ->whereDate(DB::raw('FROM_UNIXTIME(`timestamp`,"%Y-%m-%d")'), $value)
                          ->count();
            $click[] = ($total - $deliverd);
            $opened[] = $deliverd;

        }

        $data = ['processed' => $click, 'delivered' => $opened, 'datesData' => $date];
        return ['status' => true, 'data' => $data];
    }

    /**
     * @return array
     *
     * Sms report total Send,delivered
     */
    public function getSmsReportDetail()
    {
        $data = ['total_sent' => 0, 'total_delivered' => 0, 'accepted' => 0, 'undelivered' => 0];
        $date =[];
        if (request()->start_date != '' and request()->end_date != '') {
            $date = $this->generateDateRange(Carbon::parse(request()->start_date), Carbon::parse(request()->end_date));
        } else {
            $date = $this->generateDateRange(Carbon::now()->subDays(30), Carbon::now());

        }

        foreach ($date as $value) {

            $notificationData = NotificationEvent::where('event_type', 'sms')->whereDate(DB::raw('FROM_UNIXTIME(`timestamp`,"%Y-%m-%d")'),$value)->get();

            $sub = UserNotification::where(['notification_type' => 'system', 'channel' => 'sms','subscribed'=>1])->whereDate('created_at', $value)->count();
            $unsub = UserNotification::where(['notification_type' => 'system', 'channel' => 'sms','subscribed'=>0])->whereDate('created_at', $value)->count();
            $counTotal = (request()->campaign_id !='')?$notificationData->where('campaign_id',request()->campaign_id)->where('event', '!=','delivered')->where('event', '!=','unsubscribe')->count():$notificationData->where('event', '!=','delivered')->where('event', '!=','unsubscribe')->count();
            $delivered = (request()->campaign_id !='')?$notificationData->where('campaign_id',request()->campaign_id)->where('event', 'delivered')->count():$notificationData->where('event', 'delivered')->count();

            $data['total_sent'] = $data['total_sent'] + $counTotal;
            $data['total_delivered'] = $data['total_delivered'] + $delivered;
            $data['accepted'] = $data['accepted'] + $sub;
            $data['undelivered'] = $data['undelivered'] + $unsub;
        }


        return ['status' => true, 'data' => $data];
    }

    /**
     * @return array
     * Sms Report Bar Chart
     */
    public function getSubUnsubData()
    {
        $click = [];
        $opened = [];
        $date =[];
        if (request()->start_date != '' and request()->end_date != '') {
            $date = $this->generateDateRange(Carbon::parse(request()->start_date), Carbon::parse(request()->end_date));
        } else {
            $date = $this->generateDateRange(Carbon::now()->subDays(30), Carbon::now());
        }

        foreach ($date as $value) {
            $click[] = UserNotification::where(['notification_type' => 'system', 'channel' => 'sms','subscribed' => 1])->whereDate('created_at', $value)->count();
            $opened[] = UserNotification::where(['notification_type' => 'system', 'channel' => 'sms','subscribed' => 0])->whereDate('created_at', $value)->count();

        }
        $data = ['subscribed' => $click, 'unsubscribe' => $opened, 'datesData' => $date];
        return ['status' => true, 'data' => $data];
    }

    /**
     * @return array
     *
     * Sms Report Line Chart
     */
    public function getSendReadData()
    {
        $click = [];
        $opened = [];
        $date = [];
        if (request()->start_date != '' and request()->end_date != '') {
            $date = $this->generateDateRange(Carbon::parse(request()->start_date), Carbon::parse(request()->end_date));

        } else {
            $date = $this->generateDateRange(Carbon::now()->subDays(30), Carbon::now());

        }
        foreach ($date as $value) {
            //Delivered
            $clicks = NotificationEvent::where(['event_type' => 'sms', 'event' => 'delivered'])->whereDate(DB::raw('FROM_UNIXTIME(`timestamp`,"%Y-%m-%d")'),$value)->get();
            $click[] = (request()->campaign_id !='')?$clicks->where('campaign_id',request()->campaign_id)->count():$clicks->count();

            // Sent Data
            $openedData =  NotificationEvent::where(['event_type' => 'sms', 'event' => 'sent'])->whereDate(DB::raw('FROM_UNIXTIME(`timestamp`,"%Y-%m-%d")'),$value)->get();
            $opened[] =(request()->campaign_id !='')?$openedData->where('campaign_id',request()->campaign_id)->count():$openedData->count();

        }
        $data = ['sent' => $opened, 'read' =>$click , 'datesData' => $date];
        return ['status' => true, 'data' => $data];
    }

    public function searchCampaigns()
    {
        $campaigns = Campaign::where('name','like','%'.request()->name.'%')->get();
        return ['status' => true, 'data' => $campaigns];
    }

    /**
     * @return StreamedResponse
     */
    public function voucherStockReport()
    {
        $filename = 'voucher_stockreport_' .date('Y-m-d'). '.csv';
        Log::channel('custom')->info('voucherDetailReport', ['fileName' => $filename]);
        $response = new StreamedResponse(function () use ($filename) {
            $handle = fopen(public_path('/uploads/') . $filename, 'w+');

            // Add CSV headers
            fputcsv($handle, [
                'Voucher Name',
                'Voucher Quantity',
                'Redeemed',
                "Remaining"

            ]);

            Voucher::chunk(500, function ($punch) use ($handle) {
                foreach ($punch as $value) {
                    $userCount = VoucherUser::where(['voucher_id' => $value->id])->count();
                    $remaining = ($value->quantity - $userCount);
                    $remaining= ($remaining>0)?$remaining:0;

                    fputcsv($handle, ['voucher_name' => $value->name, 'voucher_quantity' => $value->quantity, 'redeemed_count' => $userCount,'remaining' => $remaining]);
                }
            });

            // Close the output stream
            fclose($handle);
        }, 200, [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename,
        ]);

        return $response;
    }//------ End of voucherStockReport() ------//


}
