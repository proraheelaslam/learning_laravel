<?php

namespace App\Http\Controllers\API;


use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;


class HeartbeatController extends Controller
{
    public $todo;

    public function __construct()
    {


    }//..... end of __construct() .....//

    public function heartbeat()
    {
        $response = [
            'message' => 'heartbeat',
            'result' => 'failure',
        ];

        $query_result = DB::select('select CURRENT_TIMESTAMP() as timestamp');
        if (is_array($query_result) && isset($query_result[0]->timestamp)) {
            $response['result'] = 'success';
            $response['timestamp'] = $query_result[0]->timestamp;
        }
        #$response['raw'] = $query_result;

        return $response;
    }
}
