<?php

namespace App\Http\Controllers\API;

use App\Models\PetAttributes;
use App\Models\UserPets;
use App\User;
use Carbon\Carbon;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Log;

class PetController extends Controller
{

    public function getPetDetails()
    {
        $column = '';
        $value = '';
        if (\request()->has('booking_id') and !empty(\request()->booking_id)) {
            $column = 'booking_engine_id';
            $value = request()->booking_id;
        }

        if (\request()->has('soldi_id') and !empty(request()->soldi_id)) {
            $column = 'soldi_id';
            $value = request()->soldi_id;
        }
        if (\request()->has('user_id') and !empty(request()->user_id)) {
            $column = 'user_id';
            $value = request()->user_id;
        }


        if (\request()->has('user_id') and !empty(\request()->user_id) and \request()->has('type')) {
            $pets = UserPets::where('user_id', \request()->user_id)->get();
            $data = [];
            if ($pets->isNotEmpty()) {

                foreach ($pets as $value) {
                    $typeDropDown = $this->getVarientDropDown( 'type_id','');
                    $subClassDropDown = $this->getVarientDropDown('sub_class_id',$value['type_id']);
                    $varitentDropDown = $this->getVarientDropDown('variant_id',$value['sub_class_id']);


                    $data[]['data'] = [
                        ['id' => $value->id, 'field_label' => 'name', 'field_name' => 'name', 'field' => $value->name, 'field_type' => 'text'],
                        ['id' => $value->id, 'field_label' => 'DOB', 'field_name' => 'DOB', 'field' => $value->dob, 'field_type' => 'date'],
                        ['id' => $value->id, 'field_label' => 'gender', 'field_name' => 'gender', 'field' => $value->gender ?? '', 'field_type' => 'dropdown', "dropdown_value" => [["id" => "Male", "name" => "Male"], ["id" => "Female", "name" => "Female"], ["id" => "Other", "name" => "Other"]],'selected' => $this->selectedgender($value)],
                        ['id' => $value->id, 'field_label' => 'image', 'field_name' => 'image', 'field' => $value->image, 'field_type' => 'text'],
                        ['id' => $value->id, 'field_label' => 'colour', 'field_name' => 'colour', 'field' => $value->colour, 'field_type' => 'text'],
                        ['id' => $value->id, 'field_label' => 'behaviour', 'field_name' => 'behaviour', 'field' => $value->behaviour, 'field_type' => 'text'],
                        ['id' => $value->id, 'field_label' => 'medical', 'field_name' => 'medical', 'field' => $value->medical, 'field_type' => 'text'],
                        ['id' => $value->id, 'field_label' => 'note', 'field_name' => 'note', 'field' => $value->note, 'field_type' => 'text'],
                        ['id' => $value->id, 'field_label' => 'type_id', 'field_name' => 'type_id', 'field' => $value->type_id, 'field_type' => 'dropdown', "dropdown_value" => $typeDropDown,'selected' => $this->defaultSelectedValue($value->type_id,'type_id') ],
                        ['id' => $value->id, 'field_label' => 'sub_class_id', 'field_name' => 'sub_class_id', 'field' => $value->sub_class_id, 'field_type' => 'dropdown', "dropdown_value" => $subClassDropDown,'selected' =>$this->defaultSelectedValue($value->sub_class_id,'sub_class_id') ],
                        ['id' => $value->id, 'field_label' => 'variant_id', 'field_name' => 'variant_id', 'field' => $value->variant_id, 'field_type' => 'dropdown', "dropdown_value" => $varitentDropDown,'selected' =>$this->defaultSelectedValue($value->variant_id,'variant_id')],

                        ];
                }
                return ['status' => true, 'data' => $data,'default_data' => $this->defaultData()];
            } else {
                $data[]['data'] = $this->defaultData();

                return ['status' => true, 'data' => $data,'default_data' => $this->defaultData()];
            }
        } else {

            $user = User::where($column, $value)->first();

            if ($user) {
                $pets = UserPets::where('user_id', $user->user_id)->get();


                return ['status' => true, 'data' => $pets];
            }
            return ['status' => false, 'message' => 'User Not exists'];
        }

    }

    /**
     * @return array
     * Add Pet details
     */
    public function addPetDetails()
    {
        try {

            Log::channel('user')->info('addPetDetails', ['addPetDetails' => \request()->all()]);
            $userid = '';
            $user = collect([]);
            if (\request()->has('booking_id') and !empty(\request()->booking_id)) {
                $column = 'booking_engine_id';
                $value = request()->booking_id;
                $user = User::where($column, $value)->first();
                $userid = ($user) ? $user->user_id : '';
            }

            if (\request()->has('soldi_id') and !empty(request()->soldi_id)) {
                $column = 'soldi_id';
                $value = request()->soldi_id;
                $user = User::where($column, $value)->first();
                $userid = ($user) ? $user->user_id : '';
            }
            if (\request()->has('user_id') and !empty(\request()->user_id)) {
                $user = User::where('user_id', request()->user_id)->first();
                $userid = \request()->user_id;
            }
            if (empty($userid)) {
                return ['status' => false, 'message' => 'User Not exist'];
            }
            $data = request()->data;
          /*  $data = collect($data)->map(function ($address) {

                $address['be_pet_id'] = 0;


                return $address;

            });*/
            $newData = $data;
            $bookingData = [];
            foreach ($newData as $key => $value) {

                $newMakeInd = [
                    'user_id' => $userid,
                    'name' => $value['name'] ?? '',
                    'sub_class_id' => $value['sub_class_id'] ?? 0,
                    'variant_id' => $value['variant_id'] ?? 0,
                    'dob' => $value['dob'] ?? '',
                    'gender' => $value['gender'] ?? '',

                    'colour' => $value['colour'] ?? '',
                    'behaviour' => $value['behaviour'] ?? '',
                    'medical' => $value['medical'] ?? '',
                    'type_id' => $value['type_id'] ?? '',
                    'note' => $value['note'] ?? '',
                    'pronto_id' => $value['pronto_id'] ?? 0,

                ];

                if (!empty($value['image'])) {
                    $newMakeInd['image'] = $value['image'] ?? '';
                }
                if ($value['id'] != 0) {
                    $pet = UserPets::where(['id' => $value['id'], 'user_id' => $userid])->first();

                    UserPets::where(['id' => $value['id'], 'user_id' => $userid])->update($newMakeInd);
                    $newMakeInd['engage_pet_id'] = $value['id'];
                    if(isset($value['be_pet_id'])){
                        $newMakeInd['be_pet_id'] = $value['be_pet_id'];
                    }else{
                        $newMakeInd['be_pet_id'] = ($pet->be_pet_id)?$pet->be_pet_id:$value['be_pet_id'];
                    }

                } else {
                    $data['user_id'] = $userid;
                    $pet = UserPets::create($newMakeInd);
                    $newMakeInd['engage_pet_id'] = $pet->id;
                    if(isset($value['be_pet_id'])){
                        $newMakeInd['be_pet_id'] = $value['be_pet_id'];
                    }else{
                        $newMakeInd['be_pet_id'] = 0;
                    }
                }
                $bookingData[] = $newMakeInd;
            }

            $recieveData = $this->addDataToBookingEngin(array_values($bookingData), $user, '');
            return ['status' => true, 'message' => 'Pet Information Added successfully', 'data' => UserPets::where('user_id', $userid)->get()];
        } catch (\Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * @return array
     */
    public function updatePetDetails()
    {
        try {
            $userid = '';
            if (\request()->has('booking_id') and !empty(\request()->booking_id)) {
                $column = 'booking_engine_id';
                $value = request()->booking_id;
                $user = User::where($column, $value)->first();
                $userid = ($user) ? $user->user_id : '';
            }

            if (\request()->has('soldi_id') and !empty(request()->soldi_id)) {
                $column = 'soldi_id';
                $value = request()->soldi_id;
                $user = User::where($column, $value)->first();
                $userid = ($user) ? $user->user_id : '';
            }
            if (\request()->has('user_id') and !empty(\request()->user_id)) {
                $user = User::where('user_id', \request()->user_id)->first();
                $userid = \request()->user_id;
            }
            if (empty($userid)) {
                return ['status' => false, 'message' => 'User Not exist'];
            }

            $data = request()->data;
            $bookingData = [];
            foreach ($data as $value) {
                $data = [];

                if (isset($value['name']) and !empty($value['name'])) {
                    $data['name'] = $value['name'];
                }

                if (isset($value['sub_class_id']) and !empty($value['sub_class_id'])) {
                    $data['sub_class_id'] = $value['sub_class_id'];
                }
                if (isset($value['variant_id']) and !empty($value['variant_id'])) {
                    $data['variant_id'] = $value['variant_id'];
                }
                if (isset($value['dob']) and !empty($value['dob'])) {
                    $data['dob'] = $value['dob'];
                }
                if (isset($value['gender']) and !empty($value['gender'])) {
                    $data['gender'] = $value['gender'];
                }
                if (isset($value['type_id']) and !empty($value['type_id'])) {
                    $data['type_id'] = $value['type_id'];
                }

                if (isset($value['image']) and !empty($value['image'])) {
                    $data['image'] = $value['image'];
                }

                if (isset($value['colour']) and !empty($value['colour'])) {
                    $data['colour'] = $value['colour'];
                }

                if (isset($value['behaviour']) and !empty($value['behaviour'])) {
                    $data['behaviour'] = $value['behaviour'];
                }
                if (isset($value['medical']) and !empty($value['medical'])) {
                    $data['medical'] = $value['medical'];
                }
                if (isset($value['note']) and !empty($value['note'])) {
                    $data['note'] = $value['note'];
                }
                if ($value['id'] != 0) {
                    $pet = UserPets::where(['id' => $value['id'], 'user_id' => $userid])->first();

                    UserPets::where(['id' => $value['id'], 'user_id' => $userid])->update($data);
                    $data['engage_pet_id'] = $value['id'];
                    $data['be_pet_id'] = $pet->be_pet_id ?? 0;
                } else {
                    $data['user_id'] = $userid;
                    $pet = UserPets::create($data);
                    $data['engage_pet_id'] = $pet->id;
                    $data['be_pet_id'] = 0;
                }

                $bookingData[] = $data;
            }
            $recieveData = $this->addDataToBookingEngin($bookingData, $user, '');
            return ['status' => true, 'message' => 'Pet Information Updated successfully'];
        } catch (\Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * @return array
     */
    public function deletePetDetail()
    {
        try {
            $userid = '';
            if (\request()->has('booking_id') and !empty(\request()->booking_id)) {
                $column = 'booking_engine_id';
                $value = request()->booking_id;
                $user = User::where($column, $value)->first();
                $userid = ($user) ? $user->user_id : '';
            }

            if (\request()->has('soldi_id') and !empty(request()->soldi_id)) {
                $column = 'soldi_id';
                $value = request()->soldi_id;
                $user = User::where($column, $value)->first();
                $userid = ($user) ? $user->user_id : '';
            }
            if (\request()->has('user_id') and !empty(\request()->user_id)) {
                $user = User::where('user_id', \request()->user_id)->first();
                $userid = \request()->user_id;
            }
            if (empty($userid)) {
                return ['status' => false, 'message' => 'User Not exist'];
            }
            $pet = UserPets::where(['id' => \request()->id, 'user_id' => $userid])->first();
            if ($pet) {
                $be_id = $pet->be_pet_id;
                $pet->delete();

                $recieveData = $this->addDataToBookingEngin([], $user, $be_id);
                return ['status' => true, 'message' => 'Pet Delete successfully'];
            } else {
                return ['status' => false, 'message' => 'Pet Information Not Found'];
            }

        } catch (\Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }

    public function savePetDetails()
    {
        $makeData = [];
        $ids = [];
        $user = User::where('user_id', request()->user_id)->first();
        foreach (request()->data as $key => $data) {
            $count = 0;
            foreach ($data['data'] as $key1 => $value) {
                if ($count >= 11) {

                } else {
                    if ($value['id'] != 0) {

                        if (!in_array($value['id'], $ids)) {
                            $ids[] = $value['id'];
                        }

                        UserPets::where('id', $value['id'])->update([
                            $value['field_label'] => $value['field']
                        ]);
                    } else {
                        if ($value['field'] != '') {
                            $makeData[$key][][$value['field_label']] = $value['field'];
                        }
                    }

                }
                $count++;
            }
        }
        $formatDat = [];

        if (count($makeData) > 0) {
            foreach ($makeData as $value) {
                $NewCount = 0;
                foreach ($value as $key => $newVal) {
                    if ($NewCount >= 11) {

                    } else {
                        $formatDat[array_key_first($newVal)] = $newVal[array_key_first($newVal)];
                    }
                    $NewCount++;

                }
                $formatDat['user_id'] = \request()->user_id;
                $pet = UserPets::create($formatDat);
                $ids[] = $pet->id;
            }
        }

        $user_pets = UserPets::whereIn('id', $ids)->get()->toArray();
        foreach ($user_pets as $key => $value) {
            $user_pets[$key]['engage_pet_id'] = $value['id'];
            $user_pets[$key]['be_pet_id'] = $value['be_pet_id'] ?? 0;
        }

        $recieveData = $this->addDataToBookingEngin($user_pets, $user, '');
        return ['status' => true, 'data' => $this->getUserDataForPets(),'default_data' => $this->defaultData()];
    }

    public function getUserDataForPets()
    {

        $pets = UserPets::where('user_id', \request()->user_id)->get();
        $data = [];
        if ($pets) {

            foreach ($pets as $value) {
                $typeDropDown = $this->getVarientDropDown( 'type_id','');
                $subClassDropDown = $this->getVarientDropDown('sub_class_id',$value['type_id']);
                $varitentDropDown = $this->getVarientDropDown('variant_id',$value['sub_class_id']);


                $data[]['data'] = [
                    ['id' => $value->id, 'field_label' => 'name', 'field_name' => 'name', 'field' => $value->name, 'field_type' => 'text'],
                    ['id' => $value->id, 'field_label' => 'DOB', 'field_name' => 'DOB', 'field' => $value->dob, 'field_type' => 'date'],
                    ['id' => $value->id, 'field_label' => 'gender', 'field_name' => 'gender', 'field' => $value->gender ?? '', 'field_type' => 'dropdown', "dropdown_value" => [["id" => "Male", "name" => "Male"], ["id" => "Female", "name" => "Female"], ["id" => "Other", "name" => "Other"]],'selected' => $this->selectedgender($value)],
                    ['id' => $value->id, 'field_label' => 'image', 'field_name' => 'image', 'field' => $value->image, 'field_type' => 'text'],
                    ['id' => $value->id, 'field_label' => 'colour', 'field_name' => 'colour', 'field' => $value->colour, 'field_type' => 'text'],
                    ['id' => $value->id, 'field_label' => 'behaviour', 'field_name' => 'behaviour', 'field' => $value->behaviour, 'field_type' => 'text'],
                    ['id' => $value->id, 'field_label' => 'medical', 'field_name' => 'medical', 'field' => $value->medical, 'field_type' => 'text'],
                    ['id' => $value->id, 'field_label' => 'note', 'field_name' => 'note', 'field' => $value->note, 'field_type' => 'text'],
                    ['id' => $value->id, 'field_label' => 'type_id', 'field_name' => 'type_id', 'field' => $value->type_id, 'field_type' => 'dropdown', "dropdown_value" => $typeDropDown,'selected' => $this->defaultSelectedValue($value->type_id,'type_id') ],
                    ['id' => $value->id, 'field_label' => 'sub_class_id', 'field_name' => 'sub_class_id', 'field' => $value->sub_class_id, 'field_type' => 'dropdown', "dropdown_value" => $subClassDropDown,'selected' =>$this->defaultSelectedValue($value->sub_class_id,'sub_class_id') ],
                    ['id' => $value->id, 'field_label' => 'variant_id', 'field_name' => 'variant_id', 'field' => $value->variant_id, 'field_type' => 'dropdown', "dropdown_value" => $varitentDropDown,'selected' =>$this->defaultSelectedValue($value->variant_id,'variant_id')],

                ];
            }
            return $data;
        }

        return [];
    }

    public function addDataToBookingEngin($data, $user, $deleteids)
    {
        \Illuminate\Support\Facades\Log::channel('user')->info('addDataToBookingEngin', ['addDataToBookingEngin' => $data, 'user' => $user, 'deleted_ids' => $deleteids]);
        if (config('constant.BOOKING_ENGINE_URL') and \config('constant.BOOKING_ENGINE_KEY')) {
            $res = (new Client([
                'headers' => [
                    'SECRET-KEY' => config('constant.BOOKING_ENGINE_KEY'),
                    'Content-Type' => 'application/json'
                ]
            ]))->request('POST', \config('constant.BOOKING_ENGINE_URL') . 'api/save-pet-engage', [
                'json' => ['user_id' => $user->booking_engine_id, 'data' => json_encode(array_values($data)), 'deleted_ids' => $deleteids]
            ]);

            $response = \GuzzleHttp\json_decode($res->getBody()->getContents(), true);

            \Illuminate\Support\Facades\Log::channel('user')->info('addDataToBookingEngin', ['addDataToBookingEngin' => $response]);
            if ($response['status']) {
                if (count($response['pet_ids']) > 0) {
                    foreach ($response['pet_ids'] as $value) {
                        UserPets::where('id', $value['engage_pet_id'])->update(['be_pet_id' => $value['be_pet_id']]);

                    }
                }
            }
            return ['status' => false];
        } else {
            return ['status' => false];
        }
    }

    public function updatePetProntoData()
    {
        try {
            $userid = '';
            if (\request()->has('booking_id') and !empty(\request()->booking_id)) {
                $column = 'booking_engine_id';
                $value = request()->booking_id;
                $user = User::where($column, $value)->first();
                $userid = ($user) ? $user->user_id : '';
            }

            if (\request()->has('soldi_id') and !empty(request()->soldi_id)) {
                $column = 'soldi_id';
                $value = request()->soldi_id;
                $user = User::where($column, $value)->first();
                $userid = ($user) ? $user->user_id : '';
            }
            if (\request()->has('user_id') and !empty(\request()->user_id)) {
                $user = User::where('user_id', \request()->user_id)->first();
                $userid = \request()->user_id;
            }
            if (empty($userid)) {
                return ['status' => false, 'message' => 'User Not exist'];
            }
            $pet = UserPets::where(['id' => \request()->id, 'user_id' => $userid])->first();
            if ($pet) {
                $pet->pronto_id = \request()->pronto_id;
                $pet->save();


                return ['status' => true, 'message' => 'Pet Information Updated successfully'];
            } else {
                return ['status' => false, 'message' => 'Pet Information Not Found'];
            }

        } catch (\Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }

    public function petDetailsAgainstPet()
    {
        $pet = UserPets::where('id', \request()->pet_id)->get();

        return ['status' => true, 'data' => $pet];
    }

    /**
     * @return array
     *  Add PetAttributes
     */
    public function addPetAttribute()
    {
        $data = \request()->data;
        if(\request()->has('data')) {
            foreach ($data as $value) {
                // Add update pet attributes
                if (!empty($value['type'])) {
                    PetAttributes::updateOrCreate(['attr_id' => $value['attr_id'], 'type' => $value['type']], [
                        'attr_id' => $value['attr_id'],
                        'value' => $value['value'],
                        'type' => $value['type'],
                        'parent_id' => $value['parent_id'],
                    ]);
                }

            }
        }
        if(\request()->has('delete_data')){
            foreach (\request()->delete_data as $value){
                if (!empty($value['type'])) {
                    if ($value['type']=='type_id') {
                        $class = PetAttributes::where(['attr_id' => $value['attr_id'],'type' => 'type_id'])->first();
                        if($class){
                            $sub_class_ids = PetAttributes::where(['attr_id' => $class->parent_id,'type' => 'sub_class_id'])->pluck('attr_id');
                            foreach($sub_class_ids as $sub_class_id){
                                PetAttributes::where(['parent_id' => $sub_class_id,'type' => 'variant_id'])->delete();
                            }
                            PetAttributes::where(['attr_id' => $class->parent_id,'type' => 'sub_class_id'])->delete();
                        }
                    }else if ($value['type']=='sub_class_id') {
                        PetAttributes::where(['parent_id' => $value['attr_id'],'type' => 'variant_id'])->delete();
                    }
                    PetAttributes::where(['attr_id' => $value['attr_id'],'type' => $value['type']])->delete();
                }
            }

        }

        return ['status' => true, 'message' => 'Successfully Inserted'];
    }

    private function getVarientDropDown($type, $parent_id)
    {
        $data = [];
            if(empty($parent_id)){
                foreach (PetAttributes::where('type', $type)->get() as $value) {

                    $data[] = ['id' => $value->attr_id, 'name' => $value->value];
                }
            }else{
                foreach (PetAttributes::where(['type' => $type,'parent_id'=> $parent_id])->get() as $value) {

                    $data[] = ['id' => $value->attr_id, 'name' => $value->value];
                }
            }
        return $data;
    }//---- End of addPetAttribute() ----//

    public function defaultData()
    {
        $typeDropDown = $this->getVarientDropDown('type_id','' );
        return [
            ["id" => 0, 'field_label' => 'name', 'field_name' => 'name', "field" => '', "field_type" => 'text'],
            ["id" => 0, 'field_label' => 'DOB', 'field_name' => 'DOB', "field" => '', "field_type" => 'date'],
            [
                "id" => 0,
                'field_label' => 'gender',
                'field_name' => 'gender',
                "field" => [],
                "field_type" => 'dropdown',
                "dropdown_value" => [["id" => "Male", "name" => "Male"], [
                    "id" => "Female",
                    "name" => "Female",

                ], ["id" => "Other", "name" => "Other"]],
                'selected' => []
            ],
            ["id" => 0, 'field_label' => 'image', 'field_name' => 'image', "field" => '', "field_type" => 'text'],
            ["id" => 0, 'field_label' => 'colour', 'field_name' => 'colour', "field" => '', "field_type" => 'text'],
            ["id" => 0, 'field_label' => 'behaviour', 'field_name' => 'behaviour', "field" => '', "field_type" => 'text'],
            ["id" => 0, 'field_label' => 'medical', 'field_name' => 'medical', "field" => '', "field_type" => 'text'],
            ["id" => 0, 'field_label' => 'note', 'field_name' => 'note', "field" => '', "field_type" => 'text'],
            ["id" => 0, 'field_label' => 'type_id', 'field_name' => 'type_id', "field" => [], "field_type" => 'dropdown', 'dropdown_value' => $typeDropDown,'selected'=>[]],
            ["id" => 0, 'field_label' => 'sub_class_id', 'field_name' => 'sub_class_id', "field" => [], "field_type" => 'dropdown', 'dropdown_value' => [],'selected'=>[]],
            ["id" => 0, 'field_label' => 'variant_id', 'field_name' => 'variant_id', "field" => [], "field_type" => 'dropdown', 'dropdown_value' => [],'selected'=>[]],

        ];
    }

    private function selectedgender($value)
    {
        $data = [];
        if(!empty($value)){
            if( ($value->gender == 'Male' || $value->gender == 'male')){
                $data[] = ['id' => ucfirst($value->gender) ,'name' => ucfirst($value->gender)];
            }
            if( ($value->gender == 'Female' || $value->gender == 'female')){
                $data[] = ['id' => ucfirst($value->gender) ,'name' => ucfirst($value->gender)];
            }
            if( ($value->gender == 'Other' || $value->gender == 'other')){
                $data[] = ['id' => ucfirst($value->gender) ,'name' => ucfirst($value->gender)];
            }
        }
        return $data;
    }

    private function defaultSelectedValue($value,$type)
    {
        $data = [];
        $petAttr = PetAttributes::where(['attr_id' => $value, 'type' => $type])->first();
        if($petAttr){
            $data[] = ['id' => $petAttr->attr_id,'name' => $petAttr->value];
        }
        return $data;
    }

    public function getPetAttribute()
    {


        $data = [];
        $petAttr = PetAttributes::where(['parent_id' => request()->id, 'type' => request()->type])->get();
        if($petAttr){
            foreach ($petAttr as $value){
                $data[] = ['id' => $value->attr_id,'name' => $value->value];
            }
        }
        return ['status' => true, 'data' => $data];

    }

}
