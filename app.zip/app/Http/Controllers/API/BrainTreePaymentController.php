<?php

namespace App\Http\Controllers\API;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Log;

class BrainTreePaymentController extends Controller
{
    public $country;
    public $KB_CLIENT = '';
    public $app_name = "";

    public function __construct()
    {
        set_time_limit(0);

        $appName = config('constant.APP_NAME');
        $this->app_name = str_replace('engage-', '', $appName);

        $this->KB_CLIENT = (new Client([
            'auth' => (request()->header('Country') == 'uk' || request()->header('Country') == 'aus') ? [config('constant.KILL_BILL_USER_NAME'), config('constant.KILL_BILL_PASSWORD')] : [config('constant.KILL_BILL_IRE_USER_NAME'), config('constant.KILL_BILL_IRE_PASSWORD')],
            'headers' => [
                'Content-Type' => 'application/json',
                'x-killbill-apikey' => (request()->header('Country') == 'uk' || request()->header('Country') == 'aus') ? config('constant.KILL_BILL_APIKEY') : config('constant.KILL_BILL_IRE_APIKEY'),
                'x-killbill-apisecret' => (request()->header('Country') == 'uk' || request()->header('Country') == 'aus') ? config('constant.KILL_BILL_SECRET') : config('constant.KILL_BILL_IRE_SECRET'),
                "x-killbill-createdby" => $this->app_name
            ]
        ]));
        Log::channel('custom')->info('Country', ['COUNTRY' => request()->header('Country')]);
        Log::channel('custom')->info('KBDETAILS', ['KB' => $this->KB_CLIENT]);

    }

    /**
     * @return array
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function addCardBraintree()
    {
        try {
            $status = (request()->is_default) ? 'true' : 'false';
            $cardData = ["pluginName" => "braintree", "pluginInfo" => ["externalPaymentMethodId" => "external", "isDefaultPaymentMethod" => true,
                "properties" => [["key" => "paymentMethodNonce", "value" => \request()->payment_token, "isUpdatable" => true]]]];

            $user = request()->user();

            $kilbillI = (request()->header('Country') == 'aus') ? $user->kill_bill_id : $user->kilbill_ire_id;


            $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/accounts/$kilbillI/paymentMethods?isDefault=$status&payAllUnpaidInvoices=false", [
                'json' => $cardData
            ]);
            $response = $response->getHeaders();
            Log::channel('custom')->info('addCardBraintree()', ['addCardBraintree()' => $response]);
            return ['status' => true, 'message' => 'Successfully Added'];
        } catch (ClientException $e) {
            $responseData = json_decode($e->getResponse()->getBody(true), true);
            Log::channel('custom')->info('addCardBraintree', ['addCardBraintree' => $responseData]);
            return ['status' => false, 'message' => $responseData['causeMessage']];
        }
    }//------ End of addCardBraintree() ------//

    public function getTokenBraintree()
    {
        $response = (new Client([
            'auth' => (request()->header('Country') == 'aus') ? [config('constant.KILL_BILL_USER_NAME'), config('constant.KILL_BILL_PASSWORD')] : [config('constant.KILL_BILL_IRE_USER_NAME'), config('constant.KILL_BILL_IRE_PASSWORD')],
            'headers' => [
                'Content-Type' => '*/*',
                'x-killbill-apikey' => (request()->header('Country') == 'aus') ? config('constant.KILL_BILL_APIKEY') : config('constant.KILL_BILL_IRE_APIKEY'),
                'x-killbill-apisecret' => (request()->header('Country') == 'aus') ? config('constant.KILL_BILL_SECRET') : config('constant.KILL_BILL_IRE_SECRET'),
                "x-killbill-createdby" => $this->app_name
            ]
        ]))->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/paymentGateways/notification/braintree", [
            'json' => ['body' => 'getToken']
        ]);
        $data = json_decode($response->getBody()->getContents());

        return ['status' => true, 'message' => $data->message];
    }

    public function getBrainTreeCardListing()
    {
        try {

            $accountId = (request()->header('Country') == 'uk' || request()->header('Country') == 'aus') ? request()->user()->kill_bill_id : request()->user()->kilbill_ire_id;
            // dd($accountId);
            Log::channel('custom')->info('getBrainTreeCardListing', ['getBrainTreeCardListing' => $accountId]);
            $request = $this->KB_CLIENT->get(config('constant.KILL_BILL_URL') . '/1.0/kb/accounts/' . $accountId . '/paymentMethods?withPluginInfo=true', [], [])->getBody()->getContents();
            $data = collect(json_decode($request, true));
            $cardData = [];
            foreach ($data as $value) {
                foreach ($value['pluginInfo']['properties'] as $pluginInfo) {
                    if ($pluginInfo['key'] == 'btInfo') {
                        $cardDetail = json_decode($pluginInfo['value']);
                        $cardData[] = [
                            "paymentMethodId" => $value['paymentMethodId'],
                            "isDefault" => $value['isDefault'],
                            "cardholderName" => ($cardDetail->cardholderName) ? $cardDetail->cardholderName : '',
                            "cardType" => ($cardDetail->cardType) ? $cardDetail->cardType : '',
                            "expirationMonth" => ($cardDetail->expirationMonth) ? $cardDetail->expirationMonth : '',
                            "expirationYear" => ($cardDetail->expirationYear) ? $cardDetail->expirationYear : '',
                            "imageUrl" => ($cardDetail->imageUrl) ? $cardDetail->imageUrl : '',
                            "last4" => ($cardDetail->last4) ? $cardDetail->last4 : '',
                            "maskedNumber" => ($cardDetail->maskedNumber) ? $cardDetail->maskedNumber : '',
                            "paymentMethodNonce" => ($cardDetail->paymentMethodNonce) ? $cardDetail->paymentMethodNonce : '',
                        ];
                    }
                }
            }

            return ['status' => ($data->isNotEmpty()) ? true : false, 'data' => $cardData];
        } catch (\Exception $e) {
            return ['status' => 'false', 'message' => 'error Occured' . $e->getMessage()];
        }
    }//----- End of getBrainTreeCardListing() -----//

    public function brainTreePayment()
    {
        try {
            $user = request()->user();
            $dataArray = [];
            $order_items = json_decode(request()->order_items);
            request()->request->add(['user_id' => $user->user_id]);
            $totalAmount = 0;
            $itemsData = '';
            foreach ($order_items as $items) {
                $discountAmount = 0;
                if ($items->discount_amt > ($items->prd_unitprice * $items->prd_qty)) {
                    $discountAmount = round(($items->discount_amt - ($items->prd_unitprice * $items->prd_qty)), 2);
                } else {
                    $discountAmount = round((($items->prd_unitprice * $items->prd_qty) - $items->discount_amt), 2);
                }
                $totalAmount += $discountAmount;
                $itemsData != "" && $itemsData .= ",";
                $itemsData .= $items->prd_name;

            }
            $totalAmount = round($totalAmount, 2);
            $dataArray[] = ['description' => 'Purchase Items', 'amount' => $totalAmount, 'itemType' => 'EXTERNAL_CHARGE'];
            $accountId = (request()->header('Country') == 'aus') ? request()->user()->kill_bill_id : request()->user()->kilbill_ire_id;

            // Generate Invoice from kill bill
            $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/invoices/charges/$accountId?autoCommit=true", [
                'json' => $dataArray
            ])->getBody();

            $recieveInvoiceResponse = collect(json_decode($response));
            $cardDetails = json_decode(request()->card_detail);
            //Get Payment detail against invoice
            $receiveRespose = $this->getInvoiceUrl($recieveInvoiceResponse, $cardDetails , $totalAmount, $accountId);
            if ($receiveRespose['status']) {

                // Forward payment data to soldi
                $soldiResponse = $this->paymentToSoldi();

                if ($soldiResponse->success == 'TRUE') {
                    return ['status' => true, 'message' => 'Payment done successful'];
                } else {
                    $this->refundDataToKB($cardDetails[0]->paymentMethodId,$totalAmount,(request()->header('Country')));
                    return ['status' => false, 'message' => $soldiResponse->message];
                }

            }
            return $receiveRespose;
        } catch (ClientException $e) {
            $responseData = json_decode($e->getResponse()->getBody(true), true);
            Log::channel('custom')->info('brainTreePayment', ['brainTreePayment' => $responseData]);
            return ['status' => false, 'message' => $responseData['causeMessage']];
        }
    }//------ End of brainTreePayment() --------//

    public function getInvoiceUrl($responseData, $cardDetail, $dueAmount, $user)
    {
        try {
            $jsonData = [
                'paymentMethodId' => $cardDetail[0]->paymentMethodId,
                'targetInvoiceId' => $responseData[0]->invoiceId,
                'accountId' => $user,
                'purchasedAmount' => $dueAmount
            ];
            Log::channel('custom')->info('$jsonData', ['$jsonData' => $jsonData]);
            $invoiceId = $responseData[0]->invoiceId;
            $nonceid = \request()->nonceid;
            $deviceData = \request()->deviceData;

            $queryBuild = "externalPayment=false&pluginProperty=nonceFromTheClient=$nonceid&pluginProperty=deviceDataFromTheClient=$deviceData";
            $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/invoices/$invoiceId/payments?".$queryBuild, [
                'json' => $jsonData
            ])->getHeaders();

            if (array_key_exists('Location', $response)) {
                $url = $response['Location'][0];
                Log::channel('custom')->info('invoice url', ['invoice url' => $url]);
                return ['status' => true, 'data' => $url];
            }


        } catch (ClientException $e) {
            $responseData = json_decode($e->getResponse()->getBody(true), true);
            Log::channel('custom')->info('getInvoiceUrl', ['getInvoiceUrl' => $responseData]);
            return ['status' => false, 'message' => $responseData['causeMessage']];
        }
    }//----- End of getInvoiceUrl() -----//

    /**
     * @return mixed|string
     */
    private function paymentToSoldi()
    {

        Log::channel('custom')->info('paymentToSoldi', ['paymentToSoldi' => request()->except(['Authorization','Accept'])]);
        $APIKEY = (\request()->header('Country') == 'aus') ? config('constant.SOLDI_API_KEY') : config('constant.SOLDI_IRE_APIKEY');
        $SECRET = (\request()->header('Country') == 'aus') ? config('constant.SOLDI_SECRET') : config('constant.SOLDI_IRE_SECRET');
        $response = (new Client([
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => $APIKEY,
                'SECRET' => $SECRET
            ]
        ]))->request('POST', config('constant.SOLDI_DEFAULT_PATH') . '/orders/placeorder', [
            'json' => \request()->except(['Authorization','Accept'])
        ]);
        $soldi_res = $response->getBody()->getContents();
        $soldi_res = json_decode($soldi_res);

        return $soldi_res;
    }//----- End of paymentToSoldi() ------//

    public function refundDataToKB($paymentid,$amount, $region)
    {
        try {
            $region = request()->header('Country');
            $jsonData = ['paymentId' => $paymentid, 'amount' => $amount, 'currency' => $region == 'aus' ? 'AUD' : 'NZD'];
            $response = $this->KB_CLIENT->request('POST', config('constant.KILL_BILL_URL') . "/1.0/kb/payments/$paymentid/refunds/", [
                'json' => $jsonData
            ])->getBody()->getContents();
            return ['status' => true, 'message' => "Payment refunded sussessfully"];
        } catch (\Exception $e) {
            Log::channel('custom')->info('Payment refund error', ['Payment refund error' => $e->getMessage()]);
            return ['status' => false, 'message' => "Payment not refunded"];
        }
    }//---- End of refundDataToKB() -----//
}
