<?php


namespace App\Http\Controllers\API;


use App\Http\Controllers\Controller;
use App\Models\UserCustomFieldData;
use Illuminate\Support\Facades\DB;

class FormController  extends Controller
{
    public $formFileds=[];

    public function __construct()
    {
        set_time_limit(0);
    }
    /**
     * @return array
     * Function for getting form data
     */
    public function getFormDetails()
    {
        $user = request()->user();
        $custom_fields = DB::table("user_custom_field")->whereNull('parent_id')->where('field_type','form')->get(['id as form_id','field_label']);
        $this->formFileds = DB::table("user_custom_field")->whereNotNull('parent_id')->get(['id as input_id','field_name','field_label','parent_id','field_type','field_select_values']);

        foreach ($custom_fields as $key=>$value){
            $value->form_data = $this->getFormData($value->form_id,$user->user_id);
        }
        return ['status' => true, 'message' => '','data' => $custom_fields];
    }//---- End of getFormDetails() ----//

    /**
     * @param $form_id
     * @param $userid
     * @return array
     */
    private function getFormData($form_id,$userid)
    {
        $data = [];
        foreach ( $this->formFileds  as $value ){

            if($value->parent_id  == $form_id ){
                $userData = $this->getFormFiledData($form_id,$value->input_id,$userid);
                if($userData->isNotEmpty()){
                    foreach ($userData as $userValue){
                        $data[] = [
                            'input_id' => $value->input_id,
                            'field_name' => $value->field_name,
                            'field_type' => $value->field_type,
                            'field_label' => $value->field_label,
                            'select_options' => $value->field_select_values,
                            'value' => ($userValue->value =='' and $value->field_type =='boolean')?'0':$userValue->value,
                            'index' => $userValue->form_index,
                        ];
                    }

                }else{
                    $data[] = [
                        'input_id' => $value->input_id,
                        'field_name' => $value->field_name,
                        'field_type' => $value->field_type,
                        'field_label' => $value->field_label,
                        'select_options' => $value->field_select_values,
                        'value' => ($value->field_type =='boolean')?'0':'',
                        'index' => 0
                    ];
                }

            }
        }

        return $data;
    }//----- End of getFormData() -----//

    /**
     * @param $form_id
     * @param $input_id
     * @param $user_id
     * @return \Illuminate\Support\Collection
     */
    private function getFormFiledData($form_id, $input_id,$user_id)
    {
        return DB::table("user_custom_field_data")->where(['user_id' => $user_id,'custom_field_id' => $input_id,'form_id' => $form_id])->get();
    }//----- End of getFormFiledData() ------//

    public function userFormData()
    {
      $formdata = json_decode(request()->data);
       foreach ($formdata as $value){
           foreach ($value->form_data as $forValue){
               $this->insertOrUpdateFormData($forValue,$value->form_id);
           }
       }
       return ['status' => true,'message' => 'Successfully added'];
    }

    private function insertOrUpdateFormData($forValue, $form_id)
    {
        $user = request()->user();
        UserCustomFieldData::updateOrCreate(['user_id'=>$user->user_id,'form_id' => $form_id,'custom_field_id' =>$forValue->input_id,'form_index' => $forValue->index],[
            'user_id' => $user->user_id,
            'custom_field_id' => $forValue->input_id,
            'form_id' => $form_id,
            'form_index' => $forValue->index,
            'value' => $forValue->value

        ]);
        return ['status' => true];
    }

    public function deleteCustomFormData()
    {
        $user = request()->user();
        $customForm = UserCustomFieldData::where(['form_id'=> request()->form_id,'form_index' => request()->index,'user_id'=>$user->user_id])->delete();
        return ['status' =>($customForm)?true:false,'message' => 'successfully delete'];
    }
}