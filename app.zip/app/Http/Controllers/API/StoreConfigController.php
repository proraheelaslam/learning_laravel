<?php

namespace App\Http\Controllers\API;

use App\Models\BusinessImage;
use App\Models\StoreClasses;
use App\Models\StoreConfig;
use App\Models\StoreSocialAccount;
use App\Models\UserStore;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class StoreConfigController extends Controller
{
    public function saveStoreConfiguration(FilesController $filesController)
    {

        $image = 'uploads/' . time() * rand() . ".png";

        $storeClasses = StoreConfig::updateOrCreate(['id' => request()->editId], $filesController->uploadBase64Image(request()->image, $image)
            ? array_merge(request()->except(['editId', 'image', 'facebook', 'instagram', 'twitter', 'youtube','business_imgages']), ['image' => $image])
            : request()->except(['editId', 'image', 'facebook', 'instagram', 'twitter', 'youtube','business_imgages']));
        $this->insertSocialMedia($storeClasses->id);
        $this->insertBusinessImages($storeClasses->id);

        return ['status' => true, 'message' => 'Stamp card saved successfully.'];
    }


    public function getListOfStoreConfiguration(Request $request)
    {
        if (\request()->has('orderBy')) {
            $punchCard = StoreConfig::with(['socials','businessImages'])->where('venue_id', $request->venue_id)->orderBy(request()->orderBy, request()->orderType);

            if (request()->has('search') && request()->search)
                $punchCard->where(function ($query) use ($request) {
                    $query->where('name', 'like', '%' . $request->search . '%')
                        ->orWhere('description', 'like', '%' . $request->search . '%');
                });

            $data = $punchCard->skip($request->offset)->take($request->limit)->get();
            foreach ($data as $value) {
                if (count($value->socials)>0) {
                    $value->twitter = $value->socials->where('key', 'twitter')->first()->value;
                    $value->facebook = $value->socials->where('key', 'facebook')->first()->value;
                    $value->instagram = $value->socials->where('key', 'instagram')->first()->value;
                    $value->youtube = $value->socials->where('key', 'youtube')->first()->value;
                } else {
                    $value->twitter = '';
                    $value->facebook = '';
                    $value->instagram = '';
                    $value->youtube = '';
                }
            }

            return [
                'status' => true,
                'total' => $punchCard->count(),
                'data' => $data
            ];
        } else {
            $storeConfig = StoreConfig::get();
            foreach ($storeConfig as $key => $value) {
                $storeClass = StoreClasses::where('id', $value->class_id)->first();
                $storeConfig[$key]->class_name = ($storeClass) ? $storeClass->class_name : '';
            }
            return ['status' => true, 'data' => $storeConfig];
        }

    }

    public function deleteStoreConfiguration()
    {
        StoreConfig::destroy(request()->id);
        return ['status' => true, 'message' => 'Store Config  deleted successfully.'];
    }

    public function getStoreInfo()
    {
        $data = StoreConfig::where('venue_id', \request()->venue_id)->get(['name as label', 'company_id as value', 'api_key', 'secret_key']);
        $default = StoreConfig::where('venue_id', request()->venue_id)->first();
        return ['status' => true, 'data' => $data, 'default' => $default];
    }

    /**
     * @param $id
     * Store Social Media Information
     */
    private function insertSocialMedia($id)
    {

        foreach (\request()->except('_token') as $key1 => $part) {

            if ($key1 == 'instagram' || $key1 == 'facebook' || $key1 === 'twitter' || $key1 === 'youtube') {
                if (!empty($part))
                    $fb = StoreSocialAccount::updateOrCreate(['key' => $key1, 'store_id' => $id], [
                        'key' => $key1,
                        'value' => $part,
                        'store_id' => $id ?? null,
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ]);
            }
        }
    }

    public function userBusinessData()
    {
        $venueData = [];
        $userBusiness = UserStore::where('user_id',\request()->user_id)->get();
        foreach ($userBusiness as $value) {
            $name = StoreConfig::where('id', $value['store_id'])->first();
            $venueData[] = ['label' => $name->name, 'name' => $name->name ?? '', 'id' => $value['id'],'store_id' => $value['store_id']];
        }

        return ['status'=> true,'data' => $venueData, 'all_organisation' => StoreConfig::get(['id', 'name'])];

    }

    public function addBusinessData()
    {
        foreach (request()->organisation_data as $value){
            UserStore::updateOrCreate(['user_id'=> \request()->user_id,'store_id' => $value['id']],['user_id'=> \request()->user_id,'store_id' => $value['id']]);
        }
        return ['status' => true, 'message' => 'Successfully updated'];
    }

    public function deleteUserBusiness()
    {
        $userBusiness = UserStore::where(['user_id' => \request()->user_id,'id' => \request()->id])->delete();
        return ['status' => true, 'message' => 'Successfully deleted'];
    }

    /**
     * @param $id
     * @return array
     *  Add Store Images
     */
    private function insertBusinessImages($id)
    {

        foreach (\request()->business_imgages as $imgage){
            if(!preg_match("/(uploads|image-picker)/i", $imgage['image'])) {
                $image = 'uploads/' . time() * rand() . ".png";
                $new = (new FilesController())->uploadBase64Image($imgage['image'], $image);
                BusinessImage::create([
                    'store_id' => $id,
                    'text' => $imgage['text'],
                    'image' => $image
                ]);
            }
        }
        return ['status' => true];

    }//----- End of insertBusinessImages() ------//

    /**
     * @return array
     *  Delete Store Images
     */
    public function deleteStoreImages()
    {
        $business = BusinessImage::where('id',\request()->id)->first();

        unlink($business->image);

        BusinessImage::where('id',\request()->id)->delete();
        return ['status' => true,'message' => 'Successfully Deleted'];
    }//----- End of deleteStoreImages() -----//
}
