<?php

namespace App\Http\Controllers\API;

use Carbon\Carbon;
use DOMDocument;
use Elasticsearch\Common\Exceptions\ClientErrorResponseException;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;


class ParseController extends Controller
{

    public $PARSE_CLIENT = '';

    public function __construct()
    {
        set_time_limit(0);
        $this->PARSE_CLIENT = (new Client([
            'headers' => [
                'Content-Type' => 'application/json',
                'X-Parse-Application-Id' =>  config('constant.PARSE_APP_ID'),
                'X-Parse-REST-API-Key' => config('constant.PARSE_API_KEY'),
                'X-Parse-Master-Key' => config('constant.PARSE_API_KEY')
            ]
        ]));
        Log::channel('custom')->info('parse url',['PARSE_URL'=>config('constant.PARSE_URL'),'parse_client' =>$this->PARSE_CLIENT ]);
    }

    public function getNews() {
        try {
            $response = $this->PARSE_CLIENT->request('GET', config('constant.PARSE_URL') . "/classes/SquizMatrixNews?order=-createdAt", [
                'json' => []
            ]);
            $response = json_decode($response->getBody()->getContents());
            return $response;
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('getNews error',['getNews error'=>$e->getMessage()]);
            return [];
        }
    }

    public function getEvents() {
        try {
            $cur_date = Carbon::now()->toDateString();
         /*   'where={"score":{"$gte":1000,"$lte":3000}}';
            $where = '{"type":"'.$type.'"}';*/

            //$where = '{"endDate": "$gte":'.$cur_date.'}';
            $response = $this->PARSE_CLIENT->request('GET', config('constant.PARSE_URL') . "/classes/SquizMatrixEvent?order=-startDate", [
                'json' => []
            ]);
            $response = json_decode($response->getBody()->getContents());
            //Log::channel('custom')->info('getEvents',['getEvents'=> json_encode($response)]);
            //file_put_contents("../parse.txt",$response);
/*
            $json_data = file_get_contents("../parse.txt");
            $response = json_decode($json_data);*/
            return $response;
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('getEvents error',['getEvents error'=>$e->getMessage()]);
            return [];
        }
    }

    public function getTermsAndConditions() {
        try {
            $where = '{"type":"terms_and_conditions"}';
            $response = $this->PARSE_CLIENT->request('GET', config('constant.PARSE_URL') . "/classes/SquizMatrixGeneral?where=$where", [
                'form_params' => [

                ]
            ]);
            $response = json_decode($response->getBody()->getContents());
            if(isset($response->results) and count($response->results) > 0) {
                return ['status' => true, 'data' => $response->results[0],'message' => 'Data found'];
            } else {
                return ['status' => false, 'data' => (object)[],'message' => 'Data not found'];
            }
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('getTermsAndConditions error',['getTermsAndConditions error'=>$e->getMessage()]);
            return ['status' => false];
        }
    }

    public function getGawlerAbout() {
        try {
            $data = [];
            $data['visitor'] = [];
            $data['history'] = [];
            $data['map'] = [];


            $where = '{"type":"visitor"}';
            $visitor_center = $this->PARSE_CLIENT->request('GET', config('constant.PARSE_URL') . "/classes/SquizMatrixGeneral?where=$where", [
                'form_params' => []
            ]);
            $visitor_center = json_decode($visitor_center->getBody()->getContents());

            if(isset($visitor_center->results) and count($visitor_center->results) > 0) {
                $data['visitor'] = $visitor_center->results[0];
            }

            $where = '{"type":"history"}';
            $history = $this->PARSE_CLIENT->request('GET', config('constant.PARSE_URL') . "/classes/SquizMatrixGeneral?where=$where", [
                'form_params' => []
            ]);
            $history = json_decode($history->getBody()->getContents());
            if(isset($history->results) and count($history->results) > 0) {
                $data['history'] = $history->results[0];
            }

            if(isset($visitor_center->results) and count($visitor_center->results) > 0) {
                $data['visitor'] = $visitor_center->results[0];
            }
            return ['status' => true, 'data' => $data,'message' => 'Data found'];
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('getTermsAndConditions error',['getTermsAndConditions error'=>$e->getMessage()]);
            return ['status' => false];
        }
    }

    public function getBinsWaste(Request $request) {
        try {
            $type = $request->get('type');
            $where = '{"type":"'.$type.'"}';
            $data = $this->PARSE_CLIENT->request('GET', config('constant.PARSE_URL') . "/classes/SquizMatrixGeneral?where=$where", [
                'form_params' => []
            ]);
            $data = json_decode($data->getBody()->getContents());
            if(property_exists($data,'results')) {
                return ['status' => true, 'data' => count($data->results) > 0 ? $data->results[0] : [],'message' => ''];
            }
            return ['status' => true, 'data' => [],'message' => ''];
        }
        catch (\Exception $e) {
            Log::channel('custom')->error('getBinsWaste error',['getBinsWaste error'=>$e->getMessage()]);
            return ['status' => false];
        }
    }


    public function getAboutMainCategories() {
        try {
            $data = $this->PARSE_CLIENT->request('GET', config('constant.PARSE_URL') . "/classes/SquizMatrixGeneral", [
                'form_params' => []
            ]);
            $data = json_decode($data->getBody()->getContents());
            if(property_exists($data,'results')) {
                $final_array = [];
                foreach ($data->results as $key => $value) {
                    $url_arr = parse_url($value->url);
                    $path = $url_arr['path'];
                    if(strpos($path,'about-gawler') !== false) {
                        $path_trim = str_replace('/about-gawler/','',$path);
                        $path_arr = explode('/',$path_trim);
                        if(count($path_arr) > 0) {
                            $temp = [];
                            $screen_headings = explode('/',$path_trim);
                            $heading = str_replace('-',' ',$screen_headings[0]);
                            $heading = strtoupper($heading);
                            $temp[$heading] = [];
                            $response = $this->checkData($data->results,$heading,$final_array);
                            if($key > 0) {
                                if(count($response) > 0) {
                                    $temp[$heading][] = $response;
                                    $final_array[] = $temp;
                                }
                            }
                            else {
                                $temp[$heading][] = $response;
                                $final_array[] = $temp;
                            }
                        }
                    }
                }
                //make final array
                $update_array = [];
                $tabs_data = [];

                foreach ($final_array as $arr) {
                    foreach ($arr as $key => $value) {
                        $tabs_data['name'] = $key;
                        $tabs_data['data'] = $value[0];
                        $update_array[] = $tabs_data;
                    }
                }
                return ['status' => true, 'data' => count($update_array) > 0 ? $update_array : [],'message' => ''];
            }
            return ['status' => true, 'data' => [],'message' => ''];
        }
        catch (\Exception $e) {
            dd($e->getTrace());
            Log::channel('custom')->error('getBinsWaste error',['getBinsWaste error'=>$e->getTrace()]);
            return ['status' => false];
        }
    }

    public function checkData($results,$search,$final_array) {
        $status = false;
            foreach ($final_array as $arr) {
                if(isset($arr[$search])) {
                    if(count($arr[$search][0]) > 0) {
                        $status = true;
                        break;
                    }
                }

            }
        if(!$status) {
            $data = [];
            foreach ($results as $key => $value) {
                $url_arr = parse_url($value->url);
                $path = $url_arr['path'];
                if(strpos($path,'about-gawler') !== false) {
                    $path_trim = str_replace('/about-gawler/','',$path);
                    $path_arr = explode('/',$path_trim);
                    if(count($path_arr) > 0) {
                        $screen_headings = explode('/',$path_trim);
                        $heading = str_replace('-',' ',$screen_headings[0]);
                        $heading = strtoupper($heading);
                        if($heading == $search) {
                            $htmlDom = new DOMDocument;
                            $htmlDom->loadHTML($value->body);
                            $imageTags = $htmlDom->getElementsByTagName('img');
                            if($imageTags->length > 0) {
                                foreach($imageTags as $imageTag){
                                    $image_url = $imageTag->getAttribute('src');
                                    break;
                                }
                                $value->leadImage = $image_url;
                            } else {
                                $value->leadImage =  url('/').'/images/no_image.png';;
                            }





                            $data[] = $value;
                        }
                    }
                }
            }
            return $data;
        }
        else {
            return [];
        }

    }


    public $arr = [
        'about-gawler/about',
        'about-gawler/gawler-heritage',
        'about-gawler/aboriginal-torres-strait-islanders',
        'about-gawler/art-culture',
        'about-gawler/art-culture/busking',
        'about-gawler/art-culture/activation',
        'about-gawler/art-culture/arts-culture-strategy',
        'about-gawler/art-culture/public-art-framework',
        'about-gawler/art-culture/public-art-in-gawler',
        'about-gawler/top-attractions',
        'about-gawler/place-to-park',
        'about-gawler/aboriginal-torres-strait-islanders/significant-local-areas',
        'your-council/elected-members',
        'your-council/agendas-and-minutes',
        'your-council/publications',
        'services/library',
        'services/customer-service',
        'recreation/gawler-aquatic-centre',
        'recreation/gawler-skate-park',
        'recreation/gawler-sport-community-centre',
        'your-council/volunteering',
    ];

    public $test_arr = [
        "about-gawler" => [
            "about",
            "gawler-heritage",
            "aboriginal-torres-strait-islanders",
            "art-culture" => [
                "busking",
                "activation",
                "arts-culture-strategy",
                "public-art-framework",
                "public-art-in-gawler"
            ],
            "top-attractions",
            "place-to-park",
            "aboriginal-torres-strait-islanders" =>  [
                "significant-local-areas",
            ]
        ],
        "services" => [
            "waste-and-recycling",
            "foodie",
            "library",
            "customer-service",
        ],
        "recreation" => [
            "parks-playgrounds",
            "gawler-aquatic-centre",
            "gawler-skate-park",
            "gawler-sport-community-centre",
        ],
        "your-council" => [
            "careers",
            "elected-members",
            "agendas-and-minutes",
            "publications",
            "volunteering",
        ],
    ];

    public $changed_arr = [

        "status" => true,
        "message" => "",
        "data" => [
            [
                'objectId' => 'ssRyV93QBg',
                'title' => 'About',
                "sub-categories" => []
            ],
            [
                'objectId' => 'FxlPstuAso',
                'title' => 'History',
                "sub-categories" => []
            ],
            [
                'objectId' => 'jfYAF4FJoy',
                'title' => 'Local Aboriginal Culture',
                "sub-categories" => []
            ],
            [
                'objectId' => '',
                'title' => 'art-culture',
                "sub-categories" => [
                    [
                        'objectId' => '2rFSiT4uaT',
                        'title' => 'Busking'
                    ],
                    [
                        'objectId' => 'erKuMBN7Zy',
                        'title' => 'Activation'
                    ],
                    [
                        'objectId' => 'm5y5BySqqJ',
                        'title' => 'Arts and Culture Strategy'
                    ],
                    [
                        'objectId' => 'm5y5BySqqJ',
                        'title' => 'Arts and Culture Strategy'
                    ],
                    [
                        'objectId' => 'Erz5TIadnP',
                        'title' => 'Public Art In Gawler'
                    ]

                ]
            ],

        ],

        /*"about-gawler" => [

            "about" => [
                'objectId' => 'ssRyV93QBg',
                'title' => 'About'
            ],
            "gawler-heritage" => [
                'objectId' => 'FxlPstuAso',
                'title' => 'History'
            ],
            "aboriginal-torres-strait-islanders" => [
                'objectId' => 'jfYAF4FJoy',
                'title' => 'Local Aboriginal Culture'
            ],

            "art-culture" => [
                "busking" => [
                    'objectId' => '2rFSiT4uaT',
                    'title' => 'Busking'
                ],
                "activation"  => [
                    'objectId' => 'erKuMBN7Zy',
                    'title' => 'Activation'
                ],
                "arts-culture-strategy" => [
                    'objectId' => 'm5y5BySqqJ',
                    'title' => 'Arts and Culture Strategy'
                ],
                "public-art-framework"  => [
                    'objectId' => '3J4YLMbgW1',
                    'title' => 'Public Art Framework'
                ],
                "public-art-in-gawler"  => [
                    'objectId' => 'Erz5TIadnP',
                    'title' => 'Public Art In Gawler'
                ],
            ],

            "top-attractions" => [
                'objectId' => 'cpK5WoweGX',
                'title' => 'Local Attractions'
            ],
            "place-to-park" => [
                'objectId' => 'IMwGyY7f5R',
                'title' => 'Places to Park'
            ],

        ]*/
    ];

    public function getMapData(Request $request)
    {
        $type = $request->type;
        $final_arr = [];
        $headings = DB::table('screen_headings')->whereNotNull('data')->where('parent',$type)->get();
        foreach($headings as $heading) {
            if(isset($heading->data)) {
                if(!empty($heading->url)) {
                    $temp= [];
                    $temp['objectId'] = "";
                    $temp['title'] = html_entity_decode($heading->name);
                    $temp['image'] = isset($heading->icon) ? url('/').'/parse_images/'.$heading->icon : '';
                    $temp['url'] = $heading->url;
                    $temp['sub-categories'] = [];

                }
                $data = json_decode($heading->data);
                if(count($data) == 1) {
                    $temp= [];
                    $temp['objectId'] = $data[0]->objectId;
                    $temp['title'] = html_entity_decode($heading->name);
                    $temp['image'] = isset($heading->icon) ? url('/').'/parse_images/'.$heading->icon : '';
                    $temp['url'] = "";
                    $temp['sub-categories'] = [];
                }
                else if(count($data) > 1) {
                    $temp = [];
                    $temp['objectId'] = "";
                    $temp['title'] = html_entity_decode($heading->name);
                    $temp['image'] = isset($heading->icon) ? url('/').'/parse_images/'.$heading->icon : '';
                    $temp['url'] = "";
                    foreach($data as $datum) {
                        $temp['sub-categories'][] = [
                            'objectId' => $datum->objectId,
                            'title' => html_entity_decode($datum->title)
                        ];
                    }
                }
                $final_arr[] = $temp;
            }
        }

        return ['status' => true,'message' => '','data' => $final_arr];
        return $this->changed_arr;

    }


    public function getHeadingsData() {
         try {
             $headings = DB::table('screen_headings')->get();
             $arr = [];
             foreach($headings as $heading) {
                 $parse_data = $this->getMapParseData();
                 $parse_arr = [];

                 foreach($parse_data as $parse_datum) {
                   //$temp['id'] = $parse_datum['objectId'];
                     $temp['label'] = $parse_datum['title'];
                     $temp['value'] = $parse_datum['objectId'];
                     $parse_arr[] = $temp;
                 }
                 $selected_arr = [];

                if(isset($heading->data) and $heading->data != null) {
                    $selected_data = json_decode($heading->data);
                    foreach($selected_data as $data) {
                        $selected_arr[] = $data->objectId;
                    }
                }

                $heading->data = $selected_arr;
                 $heading->url = empty($heading->url) ? "" : $heading->url ;
                 $heading->all_data = $parse_arr;
                 $arr[] = $heading;
             }
             return ['status' => true, 'data' => $arr,'message' => 'success'];
              }
         catch (\Exception $e) {
             return ['status' => true, 'data' => [],'message' => $e->getMessage()];
         }

    }

    public function saveMapData(Request $request) {
         try {
             $requestData = $request->all();

             //save new heading
             if($requestData['heading_data']['name'] != "") {
                 DB::table('screen_headings')->updateOrInsert([
                     'name' => $requestData['heading_data']['name'],
                     'parent' => $requestData['heading_data']['type']
                 ],[
                     'name' => $requestData['heading_data']['name'],
                     'parent' => $requestData['heading_data']['type'],
                     'data' => json_encode([]),
                     'url' => ""
                 ]);
             }

             foreach($requestData['map_data'] as $datum) {
                 $label_arr = $datum['all_data'];
                 $temp = [];
                 $final = [];
                 if($datum['url'] == "" and count($datum['data']) == 0) {
                     return ['status' => false,'message' => "Select URL or At least One Article"];
                     //DB::table('screen_headings')->where('id',$datum['id'])->update(['url' => '','data' => json_encode([])]);
                 }
                 //check for external link
                 else if($datum['url'] != "") {
                     DB::table('screen_headings')->where('id',$datum['id'])->update(['url' => $datum['url'],'data' => json_encode([])]);
                 }

                 else {
                     foreach($datum['data'] as $selected) {
                         foreach($datum['all_data'] as $all_data) {
                             if($all_data['value'] == $selected) {
                                 $temp['objectId'] = $selected;
                                 $temp['title'] = $all_data['label'];
                             }
                         }
                         $final[] = $temp;
                     }
                     DB::table('screen_headings')->where('id',$datum['id'])->update(['data' => json_encode($final)]);
                 }
             }
             return ['status' => true,'message' => 'Data mapped successfully'];
              }
         catch (\Exception $e) {
             return ['status' => false,'message' => $e->getMessage()];
          }

    }

    public function saveNewHeading(Request $request) {
        try {
            $requestData = $request->all();
            DB::table('screen_headings')->updateOrInsert([
                'name' => $requestData['heading_data']['name'],
                'parent' => $requestData['heading_data']['type']
            ],[
                'name' => $requestData['heading_data']['name'],
                'parent' => $requestData['heading_data']['type'],
                'data' => json_encode([]),
                'url' => ""
            ]);
            return ['status' => true, 'data' => [],'message' => 'New Heading Saved'];
        }
        catch (\Exception $e) {
            return ['status' => false, 'data' => [],'message' => $e->getMessage()];
        }

    }

    public function uploadParseImage(FilesController $filesController) {
        try {
            $image = '';
            if (request()->image !== 'null') {
                $image = time() * rand() . ".png";

                if (!$filesController->uploadParseIcon(request()->image, 'parse_images/' . $image))
                    $image = '';
            }
            DB::table('screen_headings')->where(['id' => request()->id])->update(['icon' => $image]);
            return ['status' => true,'message' => 'Image updated successfully','image' => url('/').'/parse_images/'.$image];
        }
        catch (\Exception $e) {
            return ['status' => true,'message' => $e->getMessage()];
        }
    }

    public function getMapParseData() {
        $data = $this->PARSE_CLIENT->request('GET', config('constant.PARSE_URL') . "/classes/SquizMatrixGeneral", [
            'form_params' => []
        ]);
        $data = json_decode($data->getBody()->getContents());

        //$json_data = file_get_contents("../parse.txt");
        //$data = json_decode($json_data);

        if (property_exists($data, 'results')) {
            $params_array = [];

            foreach ($data->results as $key => $value) {
                $url_arr = parse_url($value->url);
                $path_str = $url_arr['path'];
                $path_str = ltrim($url_arr['path'], '/');
                $params_array[] = [
                    "url" => $path_str,
                    "objectId" => $value->objectId,
                    "title" => html_entity_decode($value->title)
                ];
            }

           return $params_array;

            //$parse_array = $this->appendArray($params_array);
            /* dd(config('gawler_content.Data'));*/
        }
    }

    public function appendArray($params_array) {
        $paths = [];
        foreach ($params_array as $pathString) {
            // Split by the delimiter.
            $pathParts = explode('/', $pathString);
            // Build a nested assoc array representing the path.
            // Each key and value comes from the delimited parts of the string.
            // eg: site\projects\terrace_and_balcony\mexico.jpg
            // becomes: [
            //      'site' => [
            //              'projects' => [
            //                      'terrace_and_balcony' => [
            //                              'mexico.jpg'
            //                      ]
            //              ]
            //      ]
            // ]
            $path = [array_pop($pathParts)];
            foreach (array_reverse($pathParts) as $pathPart) {
                $path = [$pathPart => $path];
            }

            // Add it to a temp list.
            $paths[] = $path;
        }


// Now, merge all the paths together recursively at once.
        $tree = call_user_func_array('array_merge_recursive', $paths);
        dd($tree);
        return $tree;
    }


    public function addParseData(Request $request) {
        try {
 $data = [
     "endDate" => "2020-05-02"
 ];


            $response = $this->PARSE_CLIENT->request('PUT', config('constant.PARSE_URL') . "/classes/SquizMatrixEvent/LmxwLbNiES", [
                'json' => $data
            ]);
            $response = json_decode($response->getBody()->getContents());
            dd($response);
        }
        catch (\Exception $e) {
            dd($e->getMessage());
        }

    }

    public function deleteParseData(Request $request,$objectId) {
        try {
            $response = $this->PARSE_CLIENT->request('DELETE', config('constant.PARSE_URL') . "/classes/SquizMatrixNews/$objectId", [
                'json' => []
            ]);
            $response = json_decode($response->getBody()->getContents());
            dd($response);
        }
        catch (\Exception $e) {
            dd($e->getMessage());
        }

    }


    public function getArticleDetail(Request $request) {
        try {
            $object_id = $request->input('object_id');

            $response = $this->PARSE_CLIENT->request('GET', config('constant.PARSE_URL') . "/classes/SquizMatrixGeneral/$object_id", [
                'form_params' => [

                ]
            ]);
            $response = json_decode($response->getBody()->getContents());
            if(isset($response)) {

                if(!empty($response->leadImage)) {
                    $input['image_path'] = $response->leadImage;
                }
                else if(!empty($response->body)) {
                    $htmlDom = new DOMDocument;
                    @$htmlDom->loadHTML($response->body);
                    $imageTags = $htmlDom->getElementsByTagName('img');
                    if($imageTags->length > 0) {
                        foreach($imageTags as $imageTag){
                            $image_url = $imageTag->getAttribute('src');
                            break;
                        }
                        $response->leadImage = $image_url;
                    } else {
                        $response->leadImage =  url('/').'/images/no_image.png';
                    }
                }
                else  {
                    $response->leadImage =  url('/').'/images/no_image.png';
                }


                if(substr($response->abstract, 0, strlen($response->title)) === $response->title) {
                    $pos = strpos($response->abstract, $response->title);
                    if ($pos !== false) {
                        $new_abstract = substr_replace($response->abstract, '', $pos, strlen($response->title));
                        $new_abstract = ltrim($new_abstract,'.,');
                        $new_abstract = ucfirst(trim($new_abstract));
                        $response->abstract = $new_abstract;
                    }
                }
                if($response->title == 'Gawler Visitor Information Centre') {
                    $from = '/'.preg_quote('awler Visitor Information Centre', '/').'/';
                    $response->abstract = preg_replace($from, '', $response->abstract, 1);
                }




                $body = str_replace('%asset_listing%','',$response->body);
                $body = str_replace('="./?','="https://www.gawler.sa.gov.au?',$body);

                $response->body = $body;

                return ['status' => true, 'data' => $response,'message' => 'Data found'];
            } else {
                return ['status' => false, 'data' => (object)[],'message' => 'Data not found'];
            }
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('getTermsAndConditions error',['getTermsAndConditions error'=>$e->getMessage()]);
            return ['status' => false,'message' => $e->getMessage()];
        }
    }
}
