<?php

namespace App\Http\Controllers\API;
use App\Exports\MemberExport;
use App\Http\Controllers\API\ElasticSearchController;

use App\Http\Controllers\API\UserApiController;
use App\Exports\VCExport;
use App\Imports\VCImport;
use App\Models\Badge;
use App\Models\BadgeState;
use App\Models\CSVTemplate;
use App\Models\Games;
use App\Models\Groups;
use App\Models\Mission;
use App\Models\MissionUserEntry;
use App\Models\RecipeOffer;
use App\Models\Setting;
use App\Models\StoreConfig;
use App\Models\UserCustomField;
use App\Models\UserCustomFieldData;
use App\Models\UserReceipts;
use App\Utility\Utility;
use App\Utility\VCTrigger;
use DataTables;
use App\Imports\UserImport;
use App\Models\Campaign;
use App\Models\EmailTemplate;
use App\Models\PunchCard;
use App\Models\SurveyFront;
use App\Models\SurveyQueue;
use App\Models\SurveyReminder;
use App\Models\UserAddresses;
use App\Models\UserStamp;
use App\Models\UserVenueRelation;
use App\Models\VCampaign;
use App\Models\Venue;
use App\Models\Voucher;
use App\Models\VoucherUser;
use App\User;
use App\Utility\ElasticsearchUtility;
use App\Utility\Gamification;
use App\Utility\TagReplacementUtility;
use Carbon\Carbon;

use GuzzleHttp\Exception\ClientException;
use http\Env\Response;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\HeadingRowImport;
use Session;

use Image;
use function foo\func;


class VisualCampaignController extends Controller
{
    public $autoNumber=999999;
    public $app_name = '';

    public $csv_mappings = [];
    public $utility = null;
    public $treeHTML = "";

    public function __construct()
    {
        //set_time_limit(0);
        ini_set('memory_limit', '-1');
        ini_set('display_errors', 1);
        ini_set("allow_url_fopen", 1);

        $this->utility = (new Utility());

        $appName = config('constant.APP_NAME');
        $this->app_name = str_replace('engage-', '', $appName);

        $this->csv_mappings = [];



    }

    public function getUsers(Request $request) {

        if(request()->search_from == "es") {
            return $this->esSearch(request()->q);
        }

        $user_ids = [];
        if(request()->q) {
            $search = request()->q;
            if(is_numeric($search)) {
                $user_ids = User::where('client_customer_id', 'like', "%$search%")
                    ->orWhere('user_id', 'like', "%$search%")
                    ->orWhere('user_mobile', 'like', "%$search%")
                    ->pluck('user_id');
            }
            else {
                $nameSearch = explode(' ', $search);
                if (is_array($nameSearch) && isset($nameSearch[0]) && isset($nameSearch[1]) && count($nameSearch) >= 2) {

                    $user_ids = User::where('user_first_name', 'like', '%' . str_replace('%', '', $nameSearch[0]) . '%')
                        ->where('user_family_name', 'like', '%' . $nameSearch[1] . '%')
                        ->pluck('user_id');

                } else {
                    $user_ids = User::where('user_first_name', 'like', '%' . request()->q . '%')->orWhere('user_family_name', 'like', '%' . request()->q . '%')->orWhere('email', 'like', '%' . request()->q . '%')->pluck('user_id');
                }
            }



        }
        $arr = [];
        $users = User::whereIn('user_id',$user_ids)->take(10)->get();
        foreach ($users as $user) {
            $text = "";
            if($user->user_first_name)
                $text .= $user->user_first_name.' ';
            if($user->user_family_name)
                $text .= $user->user_family_name.' (';
            if($user->email)
                $text .= $user->email.') ';

            $text .= ": $user->user_id";


            $temp = [
                'id' => $user->user_id,
                'text' => $text
            ];
            $arr[] = $temp;
        }

        return response()->json(['results' => $arr], 200);
    }

    public function selectedUsers(Request $request) {
        $user = User::where('user_id',$request->user_id)->first();
        if($user) {
            $text = "";
            if($user->user_first_name)
                $text .= $user->user_first_name.' ';
            if($user->user_family_name)
                $text .= $user->user_family_name.' (';
            if($user->email)
                $text .= $user->email.') ';

            $text .= ": $user->user_id";


            $temp = [
                'id' => $user->user_id,
                'text' => $text
            ];
            return response()->json($temp, 200);
        }

    }

    public function esSearch($search) {
        request()->merge([
            "serchName" => $search,
            "sorting" => "persona_id",
            "sortingOrder" => "asc"
        ]);
        $arr = [];
        $dataRecieve =  ElasticsearchUtility::autoSuggestData(request(),\config('constant.ES_INDEX_BASENAME'));
        if(array_key_exists('hits', $dataRecieve)) {
            foreach ($dataRecieve['hits']['hits'] as $user) {
                $user = (object)$user['_source'];
                $text = "";
                if($user->persona_fname)
                    $text .= $user->persona_fname.' ';
                if($user->persona_lname)
                    $text .= $user->persona_lname.' (';
                if(isset($user->emails['personal_emails']))
                    $text .= $user->emails['personal_emails'].') ';

                $text .= ": $user->persona_id";


                $temp = [
                    'id' => $user->persona_id,
                    'text' => $text
                ];
                $arr[] = $temp;
            }

            return response()->json(['results' => $arr], 200);
        }
        return response()->json(['results' => []], 200);

    }

    public function saveVsCampaign(Request $request) {
        try {

            $requestData = json_decode($request->tabs,true);


            $tab_ids = VCampaign::pluck('tab_id');

            $requestData = collect($requestData);
            $requestData = $requestData->whereNotIn('id',$tab_ids);

            $requestData = $requestData->toArray();

            if(count($requestData) > 0) {
                foreach ($requestData as $requestDatum) {
                    $camp = Campaign::where('name',$requestDatum['name'])->first();
                    if($camp == null) {
                        $camp = new Campaign();
                    }
                    if($requestDatum['name'] != "Main") {
                        $camp->name = $requestDatum['name'];
                        $camp->company_id = config('constant.COMPANY_ID');
                        $camp->venue_id = 0;
                        $check = $camp->save();
                        if($check) {
                            DB::table('visual_campaigns')->insert(['campaign_id' => $camp->id,'tab_id' => $requestDatum['id']]);
                        }
                    }
                }
            }
            if($request->delete_tab != 0) {
                $v_camp = DB::table('visual_campaigns')->where('tab_id',$request->delete_tab)->first();
                if($v_camp) {
                    DB::table('visual_campaigns')->where('id',$v_camp->id)->delete();
                    Campaign::where('id',$v_camp->campaign_id)->delete();
                }
            }
            return response()->json(['status' => true,'message' => 'Campaign saved'],200);

        }
        catch(\Exception $e) {
            return response()->json(['status' => false,'message' => $e->getMessage()],500);
        }


    }


    public function getCampaignTemplateVS(Request $request){



        $skip = ($_GET["perPage"]) * $_GET['page'];
        $templats = EmailTemplate::select(["id","title as name","title as slug_name","created_at as date","updated_at","type","html"])
            ->where("title","!=","CampaignActivate")
            ->where("title","!=","CampaignActivated")
            ->orderBy("id","DESC");

        //if($request->user_role == "Admin"){
            //$templats->whereIn("created_by",$request->admin_ids);
            $total = \Illuminate\Support\Facades\DB::table("email_builder")
                ->where("title","!=","CampaignActivate")
                ->where("title","!=","CampaignActivated")
                ->count();
        //}
//        else{
//            $getAdminAndLoginUserTemplates = EmailTemplate::whereIn("created_by",$request->admin_ids)
//                ->orWhere("created_by",$request->user_id)->get(["id"]);
//            //---- check if user copy the template of admin. if yes then admin template will not be shown to franchise  ....//
//            $duplication = EmailTemplate::where("parent_id","!=",0)->where("created_by",$request->user_id)->pluck("parent_id");
//
//            $finalTemplates = $getAdminAndLoginUserTemplates->whereNotIn("id",$duplication)->pluck("id");
//
//            $templats->whereIn("id",$finalTemplates)->where("title","!=","CampaignActivate")
//                ->where("title","!=","CampaignActivated");
//            $total = DB::table("email_builder")->whereIn("id",$finalTemplates)
//                ->where("title","!=","CampaignActivate")
//                ->where("title","!=","CampaignActivated")
//                ->count();
//        }

        $templats = $templats->get();
        $fallback_user = DB::table('users')->first();
        $user_id = $fallback_user->user_id;

        foreach ($templats as $key => $value){
            //echo $value->date."=====";
            $value->date = (!empty($value->date) ? date("d-m-Y",strtotime($value->date)) : !empty($value->updated_at)) ? date("d-m-Y",strtotime($value->updated_at)) : "";

            $html = (new TagReplacementUtility())->generateTagText(
                $value->html ? $value->html : "",
                0,
                $user_id,
                $value->id
            );

            $value->html = $html;

        }
        return [

            "status"=>true,
            "data"=>$templats,
            "totalRecords"=>$total,
        ];
        //..... end of edit .....//
    }

    public function getEmailVS($id) {
        $template = EmailTemplate::where('id',$id)->select('html')->first();
        return response()->json($template);
    }



    public function sendFileUrlEmail(Request $request) {

        Log::channel('custom')->info('sendFileUrlEmail', ['sendFileUrlEmail ' => $request->all()]);
        $to_email = "";

        //check if override email is given
        if($request->override_email) {
            $to_email = $request->override_user_email;
        }
        else {
            //get reporting email
            $report_obj = DB::table('venue_configurations_test_alerts')->first();
            if($report_obj) {
                if($this->utility->IsNullOrEmptyString($report_obj->reporting_email)) {
                    return \response()->json(['message' => "Could not find reporting email"],500);
                }
                else {
                    $to_email = $report_obj->reporting_email;
                }
            }
            else {
                return \response()->json(['message' => "Could not find reporting email"],500);
            }
        }

        $file_urls = isset($request->file_url) ? [$request->file_url] : [];
        $html = "";
        $data = EmailTemplate::where('id', $request->template_id)->first();
        $html = (new TagReplacementUtility())->generateTagText($html,0,0,$request->template_id,0,[],0);
        (new UserApiController())->sendEmailToVerification($to_email, $data ? $data->subject : "No Subject", $html,$file_urls);
        return ['status' => true,'message' =>'Email send successfully'];
    }

    public function sendEmailVS(Request $request)
    {

        $html = "";
        $data = EmailTemplate::where('id', $request->template_id)->first();

        $register_unique_col = 'email';
        //Log::channel('custom')->info('sendEmailVS_req', ['sendEmailVS_req' => count($request->queue_data)]);
        //check if csv data is coming
        if($request->queue_data) {
            //check for unique field
            $setting = Setting::where('type', 'unique_setting')->first();
            $register_unique_col = 'email';
            if ($setting) {
                if ($setting->field1 == 'email')
                    $register_unique_col = 'email';
                else
                    $register_unique_col = 'user_mobile';
            } else {
                $register_unique_col = 'email';
            }

            $user_ids = [];
            $users_data = $request->queue_data;
            foreach ($users_data as $users_datum) {

                if(isset($users_datum[$register_unique_col]))
                {
                    $found_user = User::where($register_unique_col,$users_datum[$register_unique_col])->first();
                    if($found_user) {
                        $user_ids[] = $found_user->user_id;
                    } else {
                        if(isset($users_datum['email'])) {
                            if(!empty($data))
                                $html = $data->html;
                            (new UserApiController())->sendEmailToVerification($users_datum['email'], $data ? $data->subject : "No Subject", $html,[]);
                        }

                    }
                }
            }
            \request()->request->add(['user_ids' =>  $user_ids]);

        }

        //file url check
        if(isset($request->file_url) and $request->file_url != "") {
            try {
                return $this->sendFileUrlEmail($request);
            }
            catch (\Exception $e) {
                Log::channel('custom')->info('sendFileUrlEmail_error', ['sendFileUrlEmail_error' => $e->getMessage()]);
                return $e->getMessage();
            }
        }

        $user_ids = request()->user_ids;
        if($user_ids == null or count($user_ids) <= 0)
            return ['status' => false,'message' =>'Please select users'];

        if(($request->template_id == null) or ($request->template_id == 0))
            return ['status' => false,'message' =>'Please select template'];



        Log::channel('custom')->info('sendEmailVS', ['Data ' => $user_ids,'tempplate' => $request->template_id]);
        $users = User::whereIn("user_id",$user_ids)->get();



        if($users){
            Log::channel('custom')->info('in users', ['in users ' => 'in users']);
            foreach ($users as $key => $value){
                if(!empty($data))
                    $html = $data->html;

                //get user venue id
                $venue_id = 0;
                $user_venue = UserVenueRelation::where('user_id',$value->user_id)->first();
                if($user_venue) {
                    $venue_id = $user_venue->venue_id;
                }

                $voucher_id = 0;
                if(request()->voucher_id)
                    $voucher_id = request()->voucher_id;

                //get survey id
                $survey_id = 0;
                if($request->survey_id && $request->survey_id > 0) {
                    //change send_status to delivered

                    SurveyQueue::where(['user_id' => $value->user_id,'survey_id' => $request->survey_id])->update(['sent_status' => 'delivered']);

                    //$this->handleSurveyStatus($request->survey_id,$value->user_id,$request->reminder);
                    $survey_id = $request->survey_id;
                }
                Log::channel('custom')->info('sendEmail_req', [
                    $request->all()
                ]);
                $html = (new TagReplacementUtility())->generateTagText($html,$venue_id,$value->user_id,$request->template_id,$survey_id,[],$voucher_id,[],$request->queue_data,$register_unique_col);

                $to_email = request()->override_email ? request()->override_user_email : $value->email;
                //check if refer data is coming request
                if($request->referred_data) {
                    $refer_data = $request->referred_data;
                    $to_email = $refer_data['referred_email'];
                }
                (new UserApiController())->sendEmailToVerification($to_email, $data ? $data->subject : "No Subject", $html,[]);
            }

        }
        return ['status' => true,'message' =>'Email send successfully'];
    }

    public function handleSurveyStatus($survey_id,$user_id,$reminder) {
        try {
            if($reminder == null or $reminder == "") {
                return false;
            }
            $survey_queue = SurveyQueue::where(['user_id' => $user_id,'survey_id' => $survey_id])->first();
            if($survey_queue) {
                //check if survey_queue status is sent
                if($survey_queue->sent_status != 'completed' and $survey_queue->sent_status != 'queued') {
                    //now check reminders
                    //reminder 1
                    $reminder1 = SurveyReminder::where('queue_id',$survey_queue->id)->where('name','reminder1')->first();
                    if(!$reminder1) {
                        if($reminder['reminder1'] != "") {
                            $invite_date = Carbon::parse($survey_queue->created_at)->format('Y-m-d');
                            $invite_date = Carbon::parse($invite_date)->addDays($reminder['reminder1'])->toDateString();
                            $date = Carbon::now()->toDateString();
                            Log::channel('custom')->info('date', ['date' => $date,'inveite' => $invite_date]);
                            if($date == $invite_date) {
                                SurveyReminder::create([
                                    'queue_id' => $survey_queue->id,
                                    'name' => 'reminder1',
                                    'date' => $date
                                ]);
                                //change survey queue status to 'queued'
//                                $survey_queue->sent_status = 'queued';
//                                $survey_queue->save();
                            }
                        }
                    }
                    //reminder 2
                    $reminder2 = SurveyReminder::where('queue_id',$survey_queue->id)->where('name','reminder2')->first();
                    if(!$reminder2) {
                        if($reminder['reminder2'] != "") {
                            $invite_date = Carbon::parse($survey_queue->created_at)->format('Y-m-d');
                            $invite_date = Carbon::parse($invite_date)->addDays($reminder['reminder2'])->toDateString();
                            $date = Carbon::now()->toDateString();

                            if($date == $invite_date) {
                                SurveyReminder::çreate([
                                    'queue_id' => $survey_queue->id,
                                    'name' => 'reminder2',
                                    'date' => $date
                                ]);
                                //change survey queue status to 'queued'
//                                $survey_queue->sent_status = 'queued';
//                                $survey_queue->save();
                            }
                        }
                    }

                    //reminder 3
                    $reminder3 = SurveyReminder::where('queue_id',$survey_queue->id)->where('name','reminder3')->first();
                    if(!$reminder3) {
                        if($reminder['reminder3'] != "") {
                            $invite_date = Carbon::parse($survey_queue->created_at)->format('Y-m-d');
                            $invite_date = Carbon::parse($invite_date)->addDays($reminder['reminder3'])->toDateString();
                            $date = Carbon::now()->toDateString();
                            if($date == $invite_date) {
                                SurveyReminder::çreate([
                                    'queue_id' => $survey_queue->id,
                                    'name' => 'reminder3',
                                    'date' => $date
                                ]);
                                //change survey queue status to 'queued'
                                $survey_queue->sent_status = 'queued';
                                $survey_queue->save();
                            }
                        }
                    }
                }

                else {
                    // change queue status to delivered
                    $survey_queue->sent_status = 'delivered';
                    $survey_queue->save();
                }
            }
            else {

            }
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('handleSurveyStatus_error', ['handleSurveyStatus_error' => $e->getMessage()]);
        }

    }

    public function sendPushSms()
    {
        try {

            Log::channel('custom')->info('sendPushSms_VC', ['sendPushSms_VC' => request()->all()]);

            if (empty($route)) {
                $route = 'default';
            }

            $http = new \GuzzleHttp\Client();
            $message = request()->message;

            $users = User::whereIn('user_id',request()->user_ids)->get();
            //get survey id
            $survey_id = 0;
            $voucher_id = 0;
            if(request()->survey_id) {
                $survey_id = request()->survey_id;
            }
            if(request()->voucher_id)
                $voucher_id = request()->voucher_id;

            if(request()->current_channel == "sms"){
                Log::channel('custom')->info('remote_addr', ['remote_addr ' => $_SERVER['REMOTE_ADDR']]);

                foreach ($users as $user){
                    //get user venue id
                    $venue_id = 0;
                    $user_venue = UserVenueRelation::where('user_id',$user->user_id)->first();
                    if($user_venue) {
                        $venue_id = $user_venue->venue_id;
                    }
                    //test message condition
                    $test_message = "";
                    if($message == 'test__') {
                        $test_message = $user->user_first_name." ".$user->user_family_name.", "."you have received test sms";
                    }
                    else {
                        $test_message = request()->message;
                    }


                    //survey if check
                    if($survey_id > 0 and $message == '') {
                        //change send_status to delivered
                        //$this->handleSurveyStatus($survey_id,$user->user_id,request()->reminder);
                        //change send_status to delivered
                        SurveyQueue::where(['user_id' => $user->user_id,'survey_id' => $survey_id])->update(['sent_status' => 'delivered']);
                        $test_message = 'Hello '.$user->user_first_name.', you have a survey |SurveyName| |SurveyUrl|';
                    }

                    Log::channel('custom')->info('$message', ['$test_message' => $test_message]);
                    $user_message = (new TagReplacementUtility())->generateTagText($test_message,$venue_id,$user->user_id??0,0,$survey_id,[],$voucher_id);
                    Log::channel('custom')->info('$user_message', ['$user_message' => $user_message]);


                    $to_sms = request()->override_sms ? request()->override_number : $user->user_mobile;

                    //check if refer data is coming request
                    if(request()->referred_data) {
                        $refer_data = request()->referred_data;
                        $to_sms = $refer_data['referred_sms'];
                    }

                    $response = $http->post(config('constant.JAVA_URL') . 'sendSMS', [
                        'headers' => array(),
                        'json' => [
                            'mobile' => $to_sms,
                            "route" => "default",
                            'message_txt' => $user_message,
                        ]
                    ]);
                    $smsResponse = json_decode($response->getBody(), true);
                }
                return ['status' => true,'message' => 'Sms sent'];
            }
            else
                {
                foreach ($users as $user){

                    //test message condition
                    $test_message = "";
                    if($message == 'test__') {
                        $test_message = $user->user_first_name." ".$user->user_family_name.", "."you have received test push";
                    }
                    else {
                        $test_message = request()->message;
                    }
                    //survey if check
                    if($survey_id > 0 and $message == '') {
                        //change send_status to delivered
                        //$this->handleSurveyStatus($survey_id,$user->user_id,request()->reminder);
                        //change send_status to delivered
                        SurveyQueue::where(['user_id' => $user->user_id,'survey_id' => $survey_id])->update(['sent_status' => 'delivered']);
                        $test_message = 'Hello '.$user->user_first_name.', you have a survey |SurveyName| |SurveyUrl|';
                    }
                    Log::channel('custom')->info('$message', ['$test_message' => $test_message]);





                    $user_message = (new TagReplacementUtility())->generateTagText($test_message,0,$user->user_id??0,0,$survey_id,[],$voucher_id);
                    Log::channel('custom')->info('$user_message', ['$user_message' => $user_message]);

                    $final_stamps = 0;
                    //update scan data
                    if(\request()->scan_data && \request()->receipt_id) {

                        //get receipt
                        $receipt = UserReceipts::where('id',request()->receipt_id)->first();
                        Log::channel('custom')->info('receipt_stamps', ['receipt_stamps' => $receipt->stamp]);




                        if($receipt) {
                        Log::channel('custom')->info('receipt exists: ', ['receipt' => $receipt]);


//
//                            $receipt->detail = \request()->scan_data;
//                            $receipt->points = \request()->points ? \request()->points : 0;
//
//                            if(\request()->has('stamps')) {
//                                $receipt_stamps = $receipt->stamp;
//                                $final_stamps = \request()->stamps + $receipt_stamps;
//
//                                $receipt->stamp = $final_stamps;
//                                Log::channel('custom')->info('$final_stamps', ['$final_stamps' => $final_stamps]);
//                                Log::channel('custom')->info('stamps_VP', ['stamps_VP' => \request()->stamps]);
//                            }
//
//
//
//                            $receipt->save();


                            UserReceipts::where('id',\request()->receipt_id)->update([
                                'detail' => \request()->scan_data,
                                'points' => \request()->points ? \request()->points : 0,
                                'stamp' => \request()->stamps ? \request()->stamps : 0,
                            ]);


                        }


                    }




                    if(\request()->points)
                        $points = \request()->points;
                    else
                        $points = 0;



                    if(\request()->stamps) {
                        $stamps = \request()->stamps;
                    }
                    else {
                        $stamps = 0;
                    }


                    if(\request()->receipt_id)
                        $receipt_id = \request()->receipt_id;
                    else
                        $receipt_id = 0;


//                    $stamps = \request()->stamps ?  \request()->stamps : 0;
//                    $receipt_id = \request()->receipt_id ?  \request()->receipt_id : 0;


                    Log::channel('custom')->info('send_push_content', [

                        'json' => [
                            'notification_type' => "push",
                            'petronID' => $user->user_id,
                            'message' => $user_message,
                            'content' => [
                                'points' => intval($points),
                                'stamps' => intval($stamps),
                                'receiptId' => intval($receipt_id),
                                'resolve' => 0
                            ]
                        ]

                    ]);

                    $response = $http->post(config('constant.JAVA_URL') . 'sendTestPushToUser', [
                        'headers' => array(),
                        'json' => [
                            'notification_type' => "push",
                            'petronID' => $user->user_id,
                            'message' => $user_message,
                            'content' => [
                                'points' => intval($points),
                                'stamps' => intval($stamps),
                                'receiptId' => intval($receipt_id),
                                'resolve' => 0
                            ]
                        ]
                    ]);
                    //Log::channel('custom')->info('sendNotifications()_VP :', ['sendNotifications()_VP' => $response]);

                }
                    return ['status' => true,'message' => 'Push sent'];
            }

        } catch (\Exception $e) {
            Log::channel('custom')->info('sendPushSms_error', ['message' => $e->getMessage()]);
            return ["status"=>false,"message"=>$e->getMessage()];

        }
    }//--- End of sendSms() ---//



    public function getVouchersVS(Request $request)
    {

        if($request->venue_id <= 0 or $request->venue_id == null) {
            return response()->json(['results' => []], 200);
        }
        $venue = Venue::where('id',$request->venue_id)->first();


        $voucher = Voucher::where('company_id',$venue ? $venue->company_id : 0)->orderBy('created_at', 'desc');

        if (request()->has('q') && request()->q) {
            $voucher->where(function ($query) use ($request) {
                $query->where('name', 'like', '%' . request()->q . '%');
            });
        }

        if ($request->has('category')) {
            $voucher->where('category', '!=', 'Public Voucher');
        }
        $data =  $voucher->get();
        $arr = [];
        foreach ($data as $key => $value) {
            $temp = [
                'id' => $value->id,
                'text' => $value->name
            ];
            $arr[] = $temp;
        }
        return response()->json(['results' => $arr], 200);
    }//---- End of listAllVouchers() ----//



    public function assignVoucherVS()
    {
        try {
            $voucher = Voucher::where('id',\request()->voucher_id)->first();
            if($voucher) {


                //get venue
                $venue = Venue::where('id',\request()->venue_id)->first();

                //get campaign from name
                $camp = Campaign::where('name',\request()->camp_name)->first();

                \request()->request->add(['voucherdata' => $voucher,
                    'number_of_days' => 50,
                    'company_id' => $venue ? $venue->company_id : null,
                    'campaign_id' => $camp ? $camp->id : null
                    ]);





                if (request()->voucherdata['category'] != 'Public Voucher') {
                    $vouchers = json_decode(request()->voucherdata['voucher_avial_data'], true);
                    $data = [
                        'campaign_id' => \request()->campaign_id,
                        'voucher_id' => request()->voucherdata['id'],
                        'company_id' => request()->company_id,
                        "no_of_uses" => request()->voucherdata['no_of_uses'],
                        "uses_remaining" => request()->voucherdata['no_of_uses'],
                        "group_id" => request()->voucherdata['group_id'] ?? 0
                    ];
                    if (request()->number_of_days) {
                        $data['voucher_start_date'] = date('Y-m-d H:i', strtotime('-1 days'));
                        $data['voucher_end_date'] = date('Y-m-d H:i', strtotime('+' . request()->number_of_days . ' days'));
                    } else {
                        $data['voucher_start_date'] = date('Y-m-d H:i', strtotime(request()->start_date));
                        $data['voucher_end_date'] = date('Y-m-d H:i', strtotime(request()->end_date));
                    }
                    $users = User::whereIn('user_id',\request()->user_ids)->get();
                    try {
                        if (request()->voucherdata['voucher_type'] != 'group-voucher') {
                            foreach ($users as $user) {

                                $data['user_id'] = $user->user_id;
                                $data["voucher_code"] =  (new VoucherController())->uniqueVoucherCode(request()->voucherdata['pos_ibs']);
                                $data["created_at"] = date('Y-m-d h:i:s a');
                                $data["updated_at"] = date('Y-m-d h:i:s a');
                                VoucherUser::insert($data);

                            }
                            return ['status' => true, 'message' => 'voucher assign '];
                        } else {
                            $voucher_value = array_column($vouchers, 'voucher_value');
                            array_multisort($voucher_value, SORT_DESC, $vouchers);
                            $vouchersTemp = $vouchers;
                            (new VoucherController())->randomizeData($users, $vouchersTemp, $vouchers, $data);
                            return ['status' => true, 'message' => 'voucher assign '];
                        }
                    } catch (QueryException $e) {

                        if ($e->errorInfo[1]) {
                            return ['status' => false, 'message' => 'Duplicated Voucher Code'];
                        } else {
                            return ['status' => false, 'message' => $e->getMessage()];
                        }
                    }
                }
                else {
                    $users = User::whereIn('user_id',\request()->user_ids)->get();
                    $users_arr = [];
                    foreach ($users as $user) {
                        $users_arr[] = [
                            'id' => $user->user_id,
                            'name' => $user->user_first_name.' '.$user->user_family_name
                        ];
                    }

                    if (count($users) == 0) {
                        request()->merge(["no_of_uses" => request()->voucherdata['no_of_uses'],
                            "start_date" => request()->start_date,
                            "end_date" => request()->end_date,
                            "pos_ibs" => request()->voucherdata['pos_ibs'],
                            'isNumberOfDays' => request()->number_of_days,
                            "group_id" => request()->voucherdata['group_id'] ?? 0
                        ]);
                        return (new VoucherController())->assignPublicVoucher(request()->voucherdata['id'], 0,\request()->campaign_id);
                    } else {
                        request()->merge(["no_of_uses" => request()->voucherdata['no_of_uses'],
                            "start_date" => request()->start_date,
                            "end_date" => request()->end_date,
                            "pos_ibs" => request()->voucherdata['pos_ibs'],
                            'isNumberOfDays' => request()->number_of_days,
                            "group_id" => request()->voucherdata['group_id'] ?? 0
                        ]);
                        return (new VoucherController())->assignPublicVoucherUser($users_arr,\request()->campaign_id);
                    }
                }
            }
            return ['status' => false, 'message' => 'Voucher no exists'];
        }
        catch (\Exception $e) {
            Log::channel('custom')->error('assignVoucherVS_error',['assignVoucherVS_error' => $e->getMessage()]);
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }


    public function getPunchVs(Request $request)
    {

        if($request->venue_id <= 0 or $request->venue_id == null) {
            return response()->json(['results' => []], 200);
        }
        $venue = Venue::where('id',$request->venue_id)->first();

        $punchCard = PunchCard::where('company_id', $venue ? $venue->company_id : 0);
        if (request()->has('q') && request()->q) {
            $punchCard->where(function ($query) {
                $query->where('name', 'like', '%' . request()->q . '%');
            });
        }
        $punchCard = $punchCard->get(["id", "name as text"]);
        return response()->json(['results' => $punchCard], 200);
    }//------ End of getAllStampCard() ------//


    public function stampCardAssignVS()
    {
        try {

            Log::channel('custom')->error('stampCardAssignVS_req', ['stampCardAssignVS_req' => \request()->all()]);
            //validation
            if((request()->stampid == 0) or (request()->stampassign == 0)) {
                return ['status' => false, 'message' => 'select stamps number and stamp card'];
            }

            $users = User::whereIn('user_id',\request()->user_ids)->get();
            $venue = Venue::where('id',\request()->venue_id)->first();

            \request()->request->add(['company_id' =>  $venue ? $venue->company_id : 0,'notify' => true]);

            foreach($users as $user) {

                $credit = UserStamp::where(['user_id' => $user->user_id, 'punch_id' => request()->stampid, 'company_id' => request()->company_id])->sum('credit');
                $debit = UserStamp::where(['user_id' => $user->user_id, 'punch_id' => request()->stampid, 'company_id' => request()->company_id])->sum('debit');
                $punchCard = PunchCard::where(['id' => request()->stampid])->first()->toArray();
                //Log::channel('custom')->info('stampCardAssign()', ['punchCard', request()->all()]);
                if (count($punchCard) == 0) {
                    return ['status' => false, 'message' => 'Stamp card not exists'];
                }

                $through = "From Engage";

                $initialTotal = $credit - $debit;
                if ($initialTotal < 0)
                    $initialTotal = 0;
                $initial_points = ($initialTotal % (int)$punchCard['no_of_use']);
                $intial_stamps = (int)(($initialTotal) / (int)$punchCard['no_of_use']);
//1
                    UserStamp::insert([
                        'user_id' => $user->user_id,
                        'punch_id' => request()->stampid,
                        'company_id' => request()->company_id,
                        'venue_id' => 0,
                        'debit' => 0,
                        'credit' => request()->stampassign,
                        'created_at' => date('Y-m-d H:i'),
                        'updated_at' => date('Y-m-d H:i'),
                        'assign_through' => $through
                    ]);
                    $final_total = ($initialTotal) + (request()->stampassign);
                    //7
                    $final_points = $final_total % (int)$punchCard['no_of_use'];
                    $final_stamps = (int)(($final_total) / (int)$punchCard['no_of_use']);
                    //1
                    $numberOfVouchers = ($final_stamps) - ($intial_stamps);

                    if ($final_stamps > $intial_stamps) {
                        (new ElasticSearchController())->assignVoucher($numberOfVouchers, $punchCard['voucher_id'],$punchCard,$user->user_id);

                    }


            }
            return ['status' => true, "message" => "Stamps added"];
            
        } catch (\Exception $e) {
            Log::channel('custom')->error('stampCardAssignVS_error', ['stampCardAssignVS_error' => $e->getMessage()]);
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }//---- End of stampCardAssign() -----//


    public function assignPointsVS()
    {
        try {
            if(request()->pointassign <= 0)
                return ['status' => false, 'message' => 'Points should be greater than 0'];

            $users = User::whereIn('user_id',\request()->user_ids)->get();

            $venue = Venue::where('id',\request()->venue_id)->first();

            foreach ($users as $user) {
                DB::table('lt_transations')->insert(
                    ['soldi_id' => $user->soldi_id, 'company_id' => $venue ? $venue->company_id : 0,
                        'venue_id' => 0, 'order_amount' => 0, 'lt_rule_id' => 1, 'status' => 1,
                        'customer_id' => $user->soldi_id, 'rule_for' => 'optional', 'source' => request()->points_source,
                        'type' => 'credit', 'point_id' => request()->mission_id, 'value_points' => request()->pointassign,
                        'created_at' => time(), 'updated_at' => time(), 'wi_code' => 0,'user_id'=>$user->user_id]
                );

                //call event trigger
                $data = [
                    'user_id' => $user->user_id,
                    'points' => (int)request()->pointassign,
                    'trigger_type' => 'points'
                ];
                $trigger_type = "$.points_trigger";

                (new VCTrigger())->callVCTrigger($data, $trigger_type);

            }

            return ['status' => true, 'message'=>'Points updated successfully'];
        }
        catch (\Exception $e) {
            Log::channel('custom')->error('assignPointsVS_error', ['assignPointsVS_error' => $e->getMessage()]);
            return ['status' => false, 'message' => $e->getMessage()];
        }

    }//----- End of addUserPoints() -----//

    public function assignBadgeVS() {
        try {

            $users = User::whereIn('user_id',\request()->user_ids)->get();


            foreach ($users as $user) {
                DB::table('user_badges')->insert(
                    [
                        'user_id' => $user->user_id,
                        'badge_id' => \request()->badge_id,
                        'state_id' => \request()->state_id,
                        'created_at' => date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s')
                    ]
                );

            }
            return ['status' => true, 'message'=>'Badges given successfully'];
        }
        catch (\Exception $e) {
            Log::channel('custom')->error('assignPointsVS_error', ['assignPointsVS_error' => $e->getMessage()]);
            return ['status' => false, 'message' => $e->getMessage()];
        }

    }//----- End of addUserPoints() -----//


    public function getVenuesVS() {

        //return ["results"=>[["id"=>24,"text"=>"GBK IRE"],["id"=>25,"text"=>"GBK UK"]]];

        $venues = Venue::query();
        if (request()->has('q') && request()->q) {
            $venues->where(function ($query) {
                $query->where('venue_name', 'like', '%' . request()->q . '%');
            });
        }
        $venues = $venues->get(['id','venue_name as text']);

        return response()->json(['results' => $venues], 200);

    }
    public function getMemberGroups() {
        $memberGroups = Groups::get();
        $arr = [];
        foreach ($memberGroups as $memberGroup) {
                $arr[] = [
                    'id' => $memberGroup->group_name,
                    'text' => $memberGroup->group_name
                ];
        }
        return response()->json(['results' => $arr], 200);

    }

    public function getSurveysVS() {
        $surveys = SurveyFront::query();
        if (request()->has('q') && request()->q) {
            $surveys->where(function ($query) {
                $query->where('title', 'like', '%' . request()->q . '%');
            });
        }
        $surveys = $surveys->get(['id','title as text']);

        return response()->json(['results' => $surveys], 200);

    }

    public function getPunchCards() {
        $surveys = PunchCard::query();
        if (request()->has('q') && request()->q) {
            $surveys->where(function ($query) {
                $query->where('title', 'like', '%' . request()->q . '%');
            });
        }
        $surveys = $surveys->get(['id','name as text']);

        return response()->json(['results' => $surveys], 200);

    }


    public function getVideosVS() {
        $videos = RecipeOffer::whereNotNull('video_link')->orWhereNotNull('url');
        $videos = $videos->get(['id','title as text']);

        return response()->json(['results' => $videos], 200);

    }


    public function getSegmentUsers(Request $request) {
        try {

            $criterias = $request->all();
            if(count($criterias) > 0) {
                $criterias = json_decode (json_encode ($criterias), FALSE);
                $user = User::query();

                $check = $this->checkCriteria($criterias);

                if($check) {
                    foreach ($criterias as $criteria) {
                        Log::channel('custom')->info('$criteria', ['$criteria ' => $criteria]);

                        if($criteria->name == 'all_users' and $criteria->configured) {
                            return response()->json(User::where('user_type','app')->pluck('user_id'), 200);
                        }

                        if($criteria->name == 'postal_code' and $criteria->configured) {
                            if(count($criteria->value) > 0) {
                                $ids = UserAddresses::whereIn('postal_code',$criteria->value)->pluck('user_id');
                                $user->whereIn('user_id',$ids->toArray());
                            }
                        }

                        if($criteria->name == 'country' and $criteria->configured) {
                            if(count($criteria->value) > 0) {
                                $ids = UserAddresses::whereIn('country',$criteria->value)->pluck('user_id');
                                $user->whereIn('user_id',$ids->toArray());
                            }
                        }
                        if($criteria->name == 'state' and $criteria->configured) {
                            if(count($criteria->value) > 0) {
                                $ids = UserAddresses::whereIn('state',$criteria->value)->pluck('user_id');
                                $user->whereIn('user_id',$ids->toArray());
                            }
                        }

                        if($criteria->name == 'city' and $criteria->configured) {
                            if(count($criteria->value) > 0) {
                                $ids = UserAddresses::whereIn('city',$criteria->value)->pluck('user_id');
                                $user->whereIn('user_id',$ids->toArray());
                            }
                        }

                        if($criteria->name == 'members' and $criteria->configured) {
                            $user->whereIn('user_id',$criteria->value);
                        }

                        if($criteria->name == 'age' and $criteria->configured) {
                            if($criteria->value != "" and $criteria->value != null) {
                                $age = explode('-',$criteria->value);
                                $lte = Carbon::now()->subYears((int) $age[0])->format('Y-m-d');
                                $gte = Carbon::now()->subYears((int) end($age))->format('Y-m-d');
                                $user->whereDate('dob','>=', $gte)->whereDate('dob', '<=', $lte);

                            }
                        }
                        if($criteria->name == 'dob' and $criteria->configured) {


                            if($criteria->start_date != "" and $criteria->start_date != null) {
                                $start_date = Carbon::parse($criteria->start_date)->toDateString();
                                $user->whereDate('dob','>=', $start_date);
                            }
                            if($criteria->end_date != "" and $criteria->end_date != null) {
                                $end_date = Carbon::parse($criteria->end_date)->toDateString();
                                $user->whereDate('dob','<=', $end_date);
                            }
                        }
                        if($criteria->name == 'user_status' and $criteria->configured) {
                            Log::channel('custom')->info('$criteria->value', ['$criteria->value ' => $criteria->value]);
                            if($criteria->value) {
                                $user->where('is_active',1);
                            }
                            else {
                                $user->where('is_active',0);
                            }
                        }

                        if($criteria->name == 'gender' and $criteria->configured) {
                            if(count($criteria->value) > 0) {
                                $value = $criteria->value;
                                $gender = [];
                                foreach ($value as $key => $gen){
                                    if($gen == "male")
                                        array_push($gender,"male");
                                    else if ($gen == "female")
                                        array_push($gender,"female");
                                    else if ($gen == "other")
                                        array_push($gender,"other");
                                    else
                                        array_push($gender,"");
                                }
                                $user->whereIn('gender',$gender);
                            }
                        }
//                    else {
//                        Log::channel('custom')->info('no criteria else', ['no criteria else ' => 'no criteria else']);
//                        $user->where('user_id','<', 0);
//                    }
                    }
                }
                else {
                    return response()->json([], 200);
                }

                $query = str_replace(array('?'), array('\'%s\''), $user->toSql());
                $query = vsprintf($query, $user->getBindings());

                Log::channel('custom')->info('user_query', ['user_query ' => $query]);
                $users = $user->pluck('user_id');
                Log::channel('custom')->info('filter_users', ['filter_users ' => $users->count()]);
                if($users->count() > 0) {
                    return response()->json($users, 200);
                }
                return response()->json([], 200);

            }
            else {
                return response()->json([], 200);
            }
        }
        catch(\Exception $e) {
            Log::channel('custom')->error('getSegmentUsers_error', ['getSegmentUsers_error ' => $e->getMessage() , 'line' => $e->getLine()]);
            return response()->json([], 200);
            return response()->json(['status' => false,'message' => $e->getMessage(),'line' => $e->getLine()],500);
        }



    }

    private function checkCriteria($data) {
        $status = false;
        foreach ($data as $datum) {
            if($datum->configured) {
                $status = true;
                break;
            }
        }
        return $status;
    }

    public function triggerVS($data,$path) {
//        $user_ids = [3];
//        $data = [];
//        $data['user_id'] = $user_ids;

        try {
            $endpoint = config('constant.VC_URL');
            Log::channel('custom')->info('triggerVS_req', ['triggerVS_req' => "$endpoint/$path",'data' => $data]);
            if(isset($endpoint)) {
                $http = new \GuzzleHttp\Client();
                $response = $http->request("POST","$endpoint/$path", [
                    'headers' => array(),
                    'json' => $data,
                    'timeout' => 0.000000001
                ]);
            }
            return ;
        }
        catch (ClientException $e) {
            //$responseData = json_decode($e->getResponse()->getBody(),true);
            Log::channel('custom')->info('triggerVS_error', ['triggerVS_error' => $e->getMessage()]);
            return ;
        }
    }

    public function updateTriggerVS() {
        return 'success';
    }

    public function readHeaderCSV(Request $request) {
        $file_path = $request->file_path;

        //check if file name is of current date name
        if(strpos($file_path, 'current_date') !== false) {
            $now = str_replace('/','',Carbon::now()->format('m/d/Y'));
            $file_path = str_replace('[current_date]',$now,$file_path);

        }


        $file_path = str_replace('/public','',$file_path);

        $row = 1;
        $path = url("$file_path");

        $headers = [];
        $count = 0;

       // $headings = (new HeadingRowImport)->toArray(public_path($file_path));
//        dd("asdasd",$headings);

        try {
            if((is_file(public_path($file_path))) && (file_exists(public_path($file_path)))){
                $array = (new UserImport)->toArray(public_path($file_path));
                if(isset($array[0])) {
                    if(isset($array[0][0])) {
                        $arr = [];
                        $count = 1;
                        foreach ($array[0][0] as $header) {
                            $arr[] = [
                                'id' => $count,
                                'sheetname' => $header,
                                'map_name' => 'none',
                                'multi_select' => "",
                                "multi_select_value" => ""
                            ];
                            $count++;
                        }
                        //get custom fields data
//                        $custom_fields = [];
//                        $custom_data = (new VenueController())->getVenue($request);
//
//                        foreach ($custom_data['all_custom_fields'] as $custom_field) {
//                            if($custom_field->parent_id == null or $custom_field->parent_id == "") {
//                                $custom_fields[] = $custom_field;
//                            }
//                        }
                        return \response()->json(['mapping' => $arr, 'custom_fields' => []],200);
                    }
                }
            }
            else {
                return \response()->json(['mapping' => [], 'custom_fields' => []],200);
            }

        }
        catch (\Exception $e) {

            Log::channel('custom')->info('readHeaderCSV_error', [
                $e->getMessage()
            ]);
            return \response()->json(['mapping' => [], 'custom_fields' => []],200);
        }



        //$array = Excel::toArray(new UserImport, public_path($file_path));
        dd('aaa',$array);

        $res = (new Client())->request('GET', $path)->getBody()->getContents();




        //if (($handle = fopen($path, "r")) !== FALSE) {
           $handle =
            dd(fgetcsv(true, 1000, ","));
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                if($count == 1) {
                    break;
                }
                $num = count($data);
                //echo "<p> $num fields in line $row: <br /></p>\n";
                $row++;
                for ($c=0; $c < $num; $c++) {
                    $headers[] = $data[$c];
                    //echo $data[$c] . "<br />\n";

                }
                $count++;
            }

            fclose($handle);
        //}
        $arr = [];
        $count = 1;
        foreach ($headers as $header) {
            $arr[] = [
                'id' => $count,
                'sheetname' => $header,
                'map_name' => 'none'
            ];
            $count++;
        }
        return \response()->json($arr);
    }


    public function getQueueUsers(Request $request) {
        try {
            $take = $request->users_limit ? $request->users_limit : 5;

            $reminder = $request->reminder;
            $count = 0;
            if($reminder['reminder1'] != "")
                $count++;
            if($reminder['reminder2'] != "")
                $count++;
            if($reminder['reminder3'] != "")
                $count++;




           // $ids = SurveyQueue::where('sent_status','queued')->orWhere('sent_status','delivered')->take($take)->pluck('id');
            //SurveyQueue::whereIn('id',$ids)->update(['sent_status' => 1]);

            $final_arr = [];
            $survey_queue = SurveyQueue::where('sent_status','queued')->orWhere('sent_status','delivered')->get();



            foreach ($survey_queue as $item) {
                $temp = [];
                if($item->status == 'delivered') {
                    $reminder_count = SurveyReminder::where('queue_id',$item->id)->count();
                    if($reminder_count <= $count) {
                        $temp['user_id'] = $item->user_id;
                        $temp['survey_id'] = $item->survey_id;
                    }
                }
                else {
                    $temp['user_id'] = $item->user_id;
                    $temp['survey_id'] = $item->survey_id;
                }
                $final_arr[] = $temp;
            }



            //$survey_queue = SurveyQueue::whereIn('id',$ids)->get(['user_id','survey_id']);


            return response()->json($final_arr, 200);

        } catch (\Exception $e) {
            Log::channel('custom')->info('getQueueUsers_error', [
                $e->getMessage()
            ]);
            return response()->json([],500);
        }

    }

    public function unlinkCSV(Request $request) {
        try {
            Log::channel('custom')->info('unlinkCSV_req', [
                'unlinkCSV_req' => $request->all()
            ]);

            unlink(base_path() . $request->filename);

        }
        catch (\Exception $e) {
            Log::channel('custom')->info('unlink_error', [
                'unlink_error' => $e->getMessage()
            ]);
            return response()->json(['file_name' => '','error' => $e->getMessage()],500);
        }
    }

    public function uploadCSV(Request $request) {
        try {


            if($request->file_csv) {
                $csv_file = $request->file_csv;
                $name = 'vc_'.time() .  '.' . $csv_file->getClientOriginalExtension();
                //Storage::disk("public/uploads")->put($name, $csv_file);
                $csv_file->move(public_path('/uploads'), $name);



                return response()->json(['file_name' => $name],200);

            }
            else {
                return response()->json(['file_name' => ''],500);
            }
        }
        catch (\Exception $e) {
            return response()->json(['file_name' => '','error' => $e->getMessage()],500);
        }

    }
    public function getComments() {
        try {
            $comments_arr = [];
            $survey_front = SurveyFront::all();
            foreach ($survey_front as $survey) {
                $json_data = json_decode($survey->json);
                if(isset($json_data->pages[0])) {
                    foreach($json_data->pages[0]->elements as $data) {
                        if(isset($data->commentText)) {
                            $comments_arr[] = ['id' => $data->commentText, 'text' => $data->commentText];
                        }
                    }
                }
            }

            if(count($comments_arr) > 0) {
                $comments_arr = collect($comments_arr);

                $unique = $comments_arr->unique('text');
                $unique_arr = $unique->values()->all();
            }
            else {
                $unique_arr = [];
            }
            return response()->json(['comments' => $unique_arr],200);
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('getComments_error', [
                $e->getMessage()
            ]);
            return response()->json(['comments' => [],'error' => $e->getMessage()],500);
        }
    }


    public function getQueueIds() {
        $ids = DB::table('queue_ids')->select('queue_id')->distinct()->get();
        return response()->json(['ids' => $ids],200);
    }

    public function getMeta() {
        try {
            $arr = [];
            $arr[] = ['id' => 'admin', 'text' => 'Admin'];
            $queues = SurveyQueue::select('meta')->get()->toArray();
            foreach ($queues as $queue) {
                $meta = json_decode($queue['meta'],true);
                if(isset($meta) and count($meta) > 0) {
                    foreach ($meta as $key => $value) {
                        $arr[] = ['id' => $key, 'text' => ucwords(str_replace('_',' ',$key))];
                    }
                }
            }
            if(count($arr) > 0) {
                $arr = collect($arr);
                $unique = $arr->unique('id');
                $unique_arr = $unique->values()->all();
                return response()->json(['meta' => $unique_arr],200);
            }
            return response()->json(['meta' => []],200);
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('getMeta', [
                $e->getMessage()
            ]);
            return response()->json(['meta' => []],200);
        }
    }
    public function replaceTags(Request $request) {
        try {
            $subject = $request->subject ?? "";
            $message = $request->message ?? "";
            $user_id = $request->user_id;
            $survey_id = $request->survey_id;
            $survey_answers = $request->survey_answers;
//            Log::channel('custom')->info('$survey_answers', [
//                $survey_answers[0]['question']
//            ]);

            $subject = (new TagReplacementUtility())->generateTagText($subject,0,$user_id,0,$survey_id,$survey_answers);
            $message = (new TagReplacementUtility())->generateTagText($message,0,$user_id,0,$survey_id,$survey_answers);

            return \response()->json(['subject' => $subject, 'message' => $message],200);
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('replaceTags_error', [
                $e->getMessage()
            ]);
            return \response()->json(['subject' => '', 'message' => ''],500);
        }
    }
    public function getQueueData() {
        try {

            //return json_decode(file_get_contents('../stores.txt'),true);


            $check_arr = ['queued','delivered','clicked','completed'];
            $arr = DB::table('survey_queue')
                ->select('sent_status', DB::raw('count(*) as total'))
                ->groupBy('sent_status')
                ->get();

            foreach ($check_arr as $check) {
                if($arr->firstWhere('sent_status',$check) == null) {
                    $arr->push((object)['sent_status' => $check,'total' => 0]);
                }
            }
            return \response()->json($arr,200);
        }
        catch (\Exception $e) {
            return \response()->json([],200);
        }
    }
    public function delQueueData(Request $request) {
        try {

            $del_id = $request->del_id;
            if(isset($del_id)) {
                SurveyQueue::where('id',$del_id)->where('survey_queue_id',$request->queue_id)->delete();
                return \response()->json(['success' => true]);
            }


            $status = $request->status;
            $id = $request->id;
            if($status == 'all') {
                SurveyQueue::where('id','>',0)->where('survey_queue_id',$id)->delete();
            }
            else {
                SurveyQueue::where('sent_status',$status)->where('survey_queue_id',$id)->delete();
            }

            return $this->getQueueData();
        }
        catch (\Exception $e) {
            return \response()->json([],200);
        }
    }
    public function createCsvFile(Request $request) {
        $file_path = $request->filename;
        $file_path = str_replace('/public','',$file_path);

        $return_file = $request->filename;

        if (strpos($file_path, '[current_time]') !== false) {
            $date = Carbon::now()->format('m/d/Y');
            $date = str_replace('/','',$date);
            $file_path = str_replace('[current_time]',$date,$file_path);
            $return_file = str_replace('[current_time]',$date,$return_file);
        }
        if(!(is_file(public_path($file_path))) && (!file_exists(public_path($file_path)))){
            touch(public_path($file_path));
        }
        return ['filename' => $return_file];
    }


    public function getAddressData(Request $request) {
        if($request->has('country')) {
            $user_addresses = UserAddresses::select('country')->distinct()->get()->toArray();
        } else if($request->has('state')) {
            $user_addresses = UserAddresses::select('state')->distinct()->get()->toArray();
        } else if($request->has('city')) {
            $user_addresses = UserAddresses::select('city')->distinct()->get()->toArray();
        }
        else {
            $user_addresses = UserAddresses::select('postal_code')->distinct()->get()->toArray();
        }
        $arr = [];
        foreach ($user_addresses as $address) {
            $id = $address[array_keys($address)[0]];
            if($id != "" and $id != null) {
                $arr[] = [
                    'id' => $id,
                    'text' => $id
                ];
            }

        }


        return response()->json(['results' => $arr], 200);

    }



    public function getSoldiStoresVS($venue_id = 0)
    {
        try {
//dd(json_decode(file_get_contents('../stores.txt')));
            //return json_decode(file_get_contents('../stores.txt'),true);
            //get company id from venue
            $venue = Venue::select('company_id')->where('id',$venue_id)->first();
            $company_id = $venue->company_id;
            $companyName = $this->app_name;
            if($company_id ==  config('constant.COMPANY_ID')) {
                $api_key = config('constant.SOLDI_API_KEY');
                $api_secret = config('constant.SOLDI_SECRET');
            }
            else {
                $api_key = config('constant.SOLDI_IRE_APIKEY');
                $api_secret = config('constant.SOLDI_IRE_SECRET');
                if ($companyName == 'gbk') {
                    $companyName = 'gbkire';
                }
            }

            Log::channel('custom')->info('data', ['SOLDI_APIKEY' => $api_key, 'api_secret' => $api_secret,'companyName',$companyName]);

            $response = (new Client())->get(config('constant.SOLDI_DEFAULT_PATH') . "/restaurants/list?type=$companyName", [
                'headers' => [
                    "SECRET" => $api_secret,
                    "X-API-KEY" => $api_key,
                    "content-type" => "application/x-www-form-urlencoded"
                ]
            ]);


//            {
//                "id": '13',
//            "pid": '1',
//            "name": "Vuejs",
//            "checked":true
//
//        }
            if ($response->getStatusCode() == '200') {
                $businesses = (json_decode($response->getBody()->getContents()))->data;
                $arr = [];
                $arr[] = ['id' => 0,'text' => 'Select Business'];
                //make treeview array
                foreach ($businesses as $value) {




                    $arr[] = [
                        'id' => $value->business_id,
                        'text' => $value->business_name
                    ];

                }
                return response()->json(['results' => $arr], 200);
            } else {
                return [];
            }
        } catch (\Exception $e) {
            Log::channel('custom')->info('getSoldiStoresVS_error', [
                $e->getMessage()
            ]);
            return [];
        }//..... end of try-catch() .....//
    }//..... end of getBusiness() .....//




    public function getBusinessCategoryVS($business_id,$venue_id)
    {
        try {

           // return json_decode(file_get_contents('../test.txt'));

            //get company id from venue
            $venue = Venue::select('company_id')->where('id',$venue_id)->first();
            $company_id = $venue->company_id;


            if($company_id ==  config('constant.COMPANY_ID')) {
                $api_key = config('constant.SOLDI_API_KEY');
                $api_secret = config('constant.SOLDI_SECRET');
            }
            else {
                $api_key = config('constant.SOLDI_IRE_APIKEY');
                $api_secret = config('constant.SOLDI_IRE_SECRET');
            }





//            if (request()->has(self::COMPANY_ID) && (request()->company_id == config('constant.COMPANY_IRE_ID'))) {
//                $api_key = config('constant.SOLDI_IRE_APIKEY');
//                $api_secret = config('constant.SOLDI_IRE_SECRET');
//
//            }
//
//            if($this->app_name == 'gawler') {
//                $api_key = $request->api_key;
//                $api_secret = $request->secret;
//            }


            $response = (new \GuzzleHttp\Client())->get(config('constant.SOLDI_DEFAULT_PATH') . '/pos/menuslist?business_id=' . $business_id, [
                'headers' => [
                    "SECRET" => $api_secret,
                    "X-API-KEY" => $api_key,
                    "content-type" => "application/x-www-form-urlencoded"
                ]
            ]);
            $newData = [];
            //dd((json_decode($response->getBody()->getContents())));
            if ($response->getStatusCode() == '200') {
                foreach ((json_decode($response->getBody()->getContents()))->data as $value) {

                    $cateData = [];
                    if (count($value->cate_items) == 0) {
                        if (count($value->subcategories) > 0) {
                            foreach ($value->subcategories as $subcategoryValues) {
                                if (count($subcategoryValues->cate_items) > 0) {
                                    foreach ($subcategoryValues->cate_items as $subItems) {
                                        $cateData[] = $subItems;
                                    }
                                } else if (count($subcategoryValues->subcategories) > 0) {

                                    if (count($subcategoryValues->subcategories) > 0) {
                                        foreach ($subcategoryValues->subcategories as $level2) {
                                            foreach ($level2->cate_items as $level2items)
                                                $cateData[] = $level2items;
                                        }
                                    }

                                }
                            }

                            $value->cate_items = $cateData;

                        } else {

                            $value->cate_items = $value->subcategories[0]->cate_items;
                        }
                    }
                    foreach ($value->cate_items as $productItems) {
                        $string = '';

                        if (isset($productItems->metadata_array->PLU_Product) && count($productItems->metadata_array->PLU_Product) > 0) {

                            foreach ($productItems->metadata_array->PLU_Product as $value1) {
                                if (!empty($value1->value)) {
                                    $string = $string . $value1->value . ',';
                                }
                            }
                        }


                        $productItems->voucher_plu_ids = rtrim($string, ',');

                        $value->voucher_plu_idd = "," . rtrim($string, ',') . ',';
                        $productItems->voucher_plu_idd = "," . rtrim($string, ',') . ',';

                    }
                    $newData[] = $value;
                }

                $arr = [];

               /* foreach ($newData as $value) {
                    $temp = [
                        'header' => $value->cate_name
                    ];
                    if(count($value->cate_items) > 0) {
                        $prd_arr = [];
                        $prd_index = 0;
                        foreach ($value->cate_items as $cate_item) {
                            $prd_arr[$prd_index]['header'] = $cate_item->prd_name;

                            if(count($cate_item->variants_array) > 0) {
                                $var_index = 0;
                                foreach($cate_item->variants_array as $variant) {
                                    $prd_arr[$prd_index]['items'][]['header'] = $variant->prd_name;
                                    $var_index++;
                                }
                            }

                            $prd_index++;
                        }
                        $temp['items'] = $prd_arr;

                    }
                    $arr[] = $temp;
                }*/



//                foreach ($newData as $value) {
//                    $arr[] = [
//                        'id' => 'cat_'.$value->cate_id,
//                        'pid' => '',
//                        'name' => $value->cate_name
//                    ];
//                    if(count($value->cate_items) > 0) {
//                        foreach ($value->cate_items as $cate_item) {
//                            $arr[] = [
//                                'id' => 'prd_'.$cate_item->prd_id,
//                                'pid' => 'cat_'.$value->cate_id,
//                                'name' => $cate_item->prd_name,
//                                'plu_id' => (isset($cate_item->voucher_plu_ids) and $cate_item->voucher_plu_ids != "") ? $cate_item->voucher_plu_ids: ""
//                            ];
//                            if(count($cate_item->variants_array) > 0) {
//                                foreach ($cate_item->variants_array as $variant) {
//                                    $arr[] = [
//                                        'id' => $variant->prd_id,
//                                        'pid' => 'prd_'.$cate_item->prd_id,
//                                        'name' => $variant->prd_name,
//                                        'plu_id' => (isset($cate_item->voucher_plu_ids) and $cate_item->voucher_plu_ids != "") ? $cate_item->voucher_plu_ids: ""
//                                    ];
//                                }
//
//                            }
//                        }
//                    }
//                }



                foreach ($newData as $value) {
                    $arr[] = [
                        'Id' => 'cat_'.$value->cate_id,
                        'Title' => $value->cate_name,
                        'ParentId' => null,
                    ];
                    if(count($value->cate_items) > 0) {
                        foreach ($value->cate_items as $cate_item) {
                            $arr[] = [
                                'Id' => $cate_item->prd_name.'|'.'prd_'.$cate_item->prd_id.'|'.((isset($cate_item->voucher_plu_ids) and $cate_item->voucher_plu_ids != "") ? $cate_item->voucher_plu_ids: ""),
                                'Title' => $cate_item->prd_name,
                                'ParentId' => 'cat_'.$value->cate_id,
                                //'plu_id' => (isset($cate_item->voucher_plu_ids) and $cate_item->voucher_plu_ids != "") ? $cate_item->voucher_plu_ids: ""
                            ];
                            if(count($cate_item->variants_array) > 0) {
                                foreach ($cate_item->variants_array as $variant) {
                                    $arr[] = [
                                        'Id' => $variant->prd_name.'|'.'prd_'.$variant->prd_id.'|'.((isset($cate_item->voucher_plu_ids) and $cate_item->voucher_plu_ids != "") ? $cate_item->voucher_plu_ids: ""),
                                        'Title' => $variant->prd_name,
                                        'ParentId' => $cate_item->prd_name.'|'.'prd_'.$cate_item->prd_id.'|'.((isset($cate_item->voucher_plu_ids) and $cate_item->voucher_plu_ids != "") ? $cate_item->voucher_plu_ids: ""),
                                        //'plu_id' => (isset($cate_item->voucher_plu_ids) and $cate_item->voucher_plu_ids != "") ? $cate_item->voucher_plu_ids: ""
                                    ];
                                }

                            }
                        }
                    }
                }

                return $arr;
            }
            else {
                return [];
            }
        } catch (\Exception $e) {
            Log::channel('custom')->info('getBusinessCategoryVS_error', [
                $e->getMessage()
            ]);
            return [];
        }//..... end of try-catch() .....//
    }//..... end of getBusinessCategory() .....//



    public function getAllVouchersVS() {
        try {

            //return json_decode(file_get_contents('../stores.txt'),true);
            $arr = [];
            Voucher::all()->each(function ($voucher) use (&$arr) {
                $temp = [
                    'id' => $voucher->id,
                    'text' => $voucher->name
                ];
                $arr[] = $temp;
            });
            return response()->json(['results' => $arr], 200);
        }
        catch (\Exception $e) {

        }
    }

    public function getSiteStores() {
        try {

            //return json_decode(file_get_contents('../stores.txt'),true);
            $arr = [];
            StoreConfig::all()->each(function ($voucher) use (&$arr) {
                $temp = [
                    'id' => $voucher->id,
                    'text' => $voucher->name
                ];
                $arr[] = $temp;
            });
            return response()->json(['results' => $arr], 200);
        }
        catch (\Exception $e) {

        }
    }

    public function getQueueUsersVS(Request $request) {

        $survey_queue = SurveyQueue::with('user')
            ->where('sent_status',$request->type)
            ->where('survey_queue_id',$request->queue_id);

        return DataTables::eloquent($survey_queue)
            ->addColumn('id', function ($survey_queue_obj) {
                return $survey_queue_obj->id;
            })
            ->addColumn('client_customer_id', function ($survey_queue_obj) {
                return isset($survey_queue_obj->user) ? $survey_queue_obj->user->client_customer_id : "";
            })
            ->addColumn('name', function ($survey_queue_obj) {
                return isset($survey_queue_obj->user) ? $survey_queue_obj->user->user_first_name : "";
            })
            ->addColumn('email', function ($survey_queue_obj) {
                return isset($survey_queue_obj->user) ? $survey_queue_obj->user->email : "";
            })
            ->addColumn('action', function ($survey_queue_obj) {
                return '<button  class="btn delete_user"  id="'.$survey_queue_obj->id.'"><i class="fa fa-trash"></i> Flush</button>';
            })
            //->rawColumns(['id','action'])
            ->toJson();
    }

    public function createCSV(Request $request) {
        try {
            Log::channel('custom')->info('createCSV_req', [
                'createCSV_req' => $request->all()
            ]);

            $port = $request->port;
            $file_name = $request->filename;
            $append_file = $request->append_file;

            $headings = $request->headings;
            $data_arr = $request->data_arr;
            //dd($data_arr);


            if(!$append_file) {
                $file_name = str_replace('/public','',$file_name);
                Excel::store(new VCExport($data_arr,$headings), $file_name,'local');
            }
            else {
                //load old file
                $file_name = str_replace('/public','',$file_name);
                $exist_arr = [];
                try {
                    $array = Excel::toArray(new VCImport, public_path($file_name));
                    foreach ($array as $value) {
                        foreach ($value as $key => $val) {
                            $exist_arr[$key] = $val;
                        }
                    }
                }
                catch(\Exception $e) {
                    Log::channel('custom')->info('file_not_found', [
                        'file_not_found' => $e->getMessage()
                    ]);
                }
                //merge array
                $result = count($exist_arr) > 0 ? array_merge( $exist_arr ?? [], $data_arr ) : $data_arr;
                Excel::store(new VCExport($result,$headings), $file_name,'local');
            }
            $csv_file_path = (new Utility())->IsNullOrEmptyString($port) ? url('/').$file_name : url('/').':'.$port.$file_name;

            return response()->json(['file_path' => $csv_file_path],200);
        }
        catch(\Exception $e) {
            Log::channel('custom')->info('createCSV_error', [
                'createCSV_error' => $e->getMessage()
            ]);
            return response()->json(['file_path' => ""],500);
        }
    }

    public function addUpdateUserOLD(Request $request) {
        try {
            $this->csv_mappings = $request->csv_mappings;



            $address_attrs = ['address','address2','street_number','street_name','country','city','state','suburb','postal_code'];

            $setting = Setting::where('type', 'unique_setting')->first();
            $register_unique_col = 'email';
            if ($setting) {
                if ($setting->field1 == 'email' || $setting->field1 == 'phone')
                    $register_unique_col = $setting->field1;
                else
                    $register_unique_col = 'email';
            } else {
                $register_unique_col = 'email';
            }

            $req_data = $request->queue_data;

           // Log::channel('custom')->info('$req_data', ['$req_data' => $req_data ]);

            $success = 0;
            $failed = 0;

            foreach ($req_data as $req_datum) {

                //check if user_id exists
                if(array_key_exists('user_id',$req_datum)) {

                    $user = User::where('user_id',$req_datum['user_id'])->first();
                    if(!$user) {
                        if(isset($req_datum['email']) || isset($req_datum['user_mobile'])) {
                            $user = new User();

                            foreach ($req_datum as $key => $value) {
                                if (strpos($key, 'customs_field') !== false) {

                                } else {
                                    if(!in_array($key,$address_attrs)) {
                                        if($key == 'gender')
                                            $value = strtolower($value);

                                        $user->$key = $value;
                                    }

                                }

                            }
                            //first save user
                            $user->save();
                            if($user) {
                                $success++;
                                (new ElasticSearchController())->insertUserToES($user->user_id);
                                //save user address
                                $this->saveUserAddress($user->user_id,$req_datum);
                            }
                            else {
                                $failed++;
                            }
                            //loop custom fields
                            foreach ($req_datum as $key => $value) {
                                if (strpos($key, 'customs_field') !== false) {
                                    $this->updateUserCustomField($user->user_id,$key,$value);
                                }
                            }
                        }
                        else {
                            $failed++;
                        }

                    }
                    else {
                        //loop
                        foreach ($req_datum as $key => $value) {
                            if (strpos($key, 'customs_field') !== false) {
                                $this->updateUserCustomField($user->user_id,$key,$value);
                            }
                            else {
                                if($key != 'email' && $key != 'user_mobile') {
                                    if(!in_array($key,$address_attrs)) {
                                        if($key == 'gender')
                                            $value = strtolower($value);
                                        $user->$key = $value;
                                    }
                                }
                            }
                        }
                        Log::channel('custom')->info('user_obj_update', ['user_obj' => $user ]);
                        $user->save();
                        if($user) {
                            $success++;
                            (new ElasticSearchController())->insertUserToES($user->user_id);
                            //save user address
                            $this->saveUserAddress($user->user_id,$req_datum);

                        }
                    }
                }


                else {
                    //check if email col exists in array
                    if($register_unique_col == 'email') {
                        if(isset($req_datum['email'])) {
                            $user = User::where('email',$req_datum['email'])->first();
                            if(!$user) {
                                $user = new User();

                                foreach ($req_datum as $key => $value) {
                                    if (strpos($key, 'customs_field') !== false) {

                                    } else {
                                        if(!in_array($key,$address_attrs)) {
                                            if($key == 'gender')
                                                $value = strtolower($value);

                                            $user->$key = $value;
                                        }

                                    }

                                }
                                //Log::channel('custom')->info('user_obj', ['user_obj' => $user ]);
                                //first save user
                                $user->save();
                                if($user) {
                                    $success++;
                                    (new ElasticSearchController())->insertUserToES($user->user_id);
                                    //save user address
                                    $this->saveUserAddress($user->user_id,$req_datum);
                                }
                                else {
                                    $failed++;
                                }


                                //loop
                                foreach ($req_datum as $key => $value) {
                                    if (strpos($key, 'customs_field') !== false) {
                                        $this->updateUserCustomField($user->user_id,$key,$value);
                                    }
                                }
                            }

                            else {
                                //loop
                                foreach ($req_datum as $key => $value) {
                                    if (strpos($key, 'customs_field') !== false) {
                                        $this->updateUserCustomField($user->user_id,$key,$value);
                                    }
                                    else {
                                        if($key != 'email') {
                                            if(!in_array($key,$address_attrs)) {
                                                if($key == 'gender')
                                                    $value = strtolower($value);
                                                $user->$key = $value;
                                            }
                                        }
                                    }
                                }
                                Log::channel('custom')->info('user_obj_update', ['user_obj' => $user ]);
                                $user->save();
                                if($user) {
                                    $success++;
                                    (new ElasticSearchController())->insertUserToES($user->user_id);
                                    //save user address
                                    $this->saveUserAddress($user->user_id,$req_datum);

                                }
                            }
                        }
                        else
                            $failed++;
                    }

                    //if unique field is mobile
                    else {
                        if(isset($req_datum['user_mobile'])) {
                            $user = User::where('user_mobile',$req_datum['user_mobile'])->first();
                            if(!$user) {
                                $user = new User();

                                foreach ($req_datum as $key => $value) {
                                    if (strpos($key, 'customs_field') !== false) {

                                    }
                                    else {
                                        if(!in_array($key,$address_attrs)) {
                                            if($key == 'gender')
                                                $value = strtolower($value);

                                            $user->$key = $value;
                                        }
                                    }

                                }
                                //first save user
                                $user->save();
                                if($user) {
                                    $success++;
                                    (new ElasticSearchController())->insertUserToES($user->user_id);
                                    //save user address
                                    $this->saveUserAddress($user->user_id,$req_datum);
                                }
                                //loop
                                foreach ($req_datum as $key => $value) {
                                    if (strpos($key, 'customs_field') !== false) {
                                        $this->updateUserCustomField($user->user_id,$key,$value);
                                    }
                                }
                            }

                            else {
                                //loop
                                foreach ($req_datum as $key => $value) {
                                    if (strpos($key, 'customs_field') !== false) {
                                        $this->updateUserCustomField($user->user_id,$key,$value);
                                    }
                                    else {
                                        if($key != 'user_mobile') {
                                            if(!in_array($key,$address_attrs)) {
                                                if($key == 'gender')
                                                    $value = strtolower($value);

                                                $user->$key = $value;
                                            }
                                        }
                                    }
                                }
                                $user->save();
                                if($user) {
                                    $success++;
                                    (new ElasticSearchController())->insertUserToES($user->user_id);
                                    //save user address
                                    $this->saveUserAddress($user->user_id,$req_datum);

                                }
                            }
                        }
                        else
                            $failed++;
                    }
                }
            }
            return \response()->json(['status' => "Updated $success, Rejected $failed"],200);
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('addUpdateUser_error', ['addUpdateUser_error ' => $e->getMessage(),'addUpdateUser_error' => $e->getLine() ]);
            return \response()->json(['status' => "Server Error"],500);
        }
    }


    public function addUpdateUser(Request $request) {
        try {
            $this->csv_mappings = $request->csv_mappings;



            $address_attrs = ['address','address2','street_number','street_name','country','city','state','suburb','postal_code'];

            $user_cols  = Schema::getColumnListing('users'); // users table


            $register_unique_col = $request->match_on;
            if($register_unique_col == '')
                $register_unique_col = 'user_id';



            $req_data = $request->queue_data;

            // Log::channel('custom')->info('$req_data', ['$req_data' => $req_data ]);

            $success = 0;
            $failed = 0;

            foreach ($req_data as $req_datum) {
                //check if email col exists in array

                if(isset($req_datum[$register_unique_col])) {
                    $user = User::where($register_unique_col,$req_datum[$register_unique_col])->first();
                    if(!$user) {
                        $user = new User();

                        foreach ($req_datum as $key => $value) {
                            if (strpos($key, 'customs_field') !== false) {

                            } else {
                                if(!in_array($key,$address_attrs)) {
                                    //check if key exist as user column
                                    if(in_array($key,$user_cols)) {
                                        if($key == 'gender')
                                            if($key == 'gender') {
                                                if($value == 'Mr')
                                                    $value = strtolower('male');
                                                if($value == 'Mrs')
                                                    $value = strtolower('female');
                                                if($value == '' || $value == null)
                                                    $value = strtolower('other');

                                                $value = strtolower($value);
                                            }

                                        if($key == 'groups') {
                                            $value = (!empty($value)) ? json_encode(['Member', $value]) : json_encode(['Member']);
                                        }
                                        $user->$key = $value;
                                    }

                                }

                            }
                            //adding client customer id for new user
                            $user->client_customer_id = (new UserApiController())->checkUniqueCustomerID();

                        }
                        $user->is_active = 1;
                        //Log::channel('custom')->info('user_obj', ['user_obj' => $user ]);
                        //first save user
                        $user->save();
                        if($user) {
                            $success++;
                            (new ElasticSearchController())->insertUserToES($user->user_id);
                            //save user address
                            $this->saveUserAddress($user->user_id,$req_datum);
                        }
                        else {
                            $failed++;
                        }


                        //loop
                        foreach ($req_datum as $key => $value) {
                            if (strpos($key, 'customs_field') !== false) {
                                $this->updateUserCustomField($user->user_id,$key,$value);
                            }
                        }
                    }

                    else {
                        //loop
                        foreach ($req_datum as $key => $value) {
                            Log::channel('custom')->info('$key', ['$key' => $key ]);
                            if (strpos($key, 'customs_field') !== false) {

                                $this->updateUserCustomField($user->user_id,$key,$value);
                            }
                            else {
                                if($key != $register_unique_col) {
                                    if(!in_array($key,$address_attrs)) {
                                        //check if key exist as user column
                                        if(in_array($key,$user_cols)) {
                                            if($key == 'gender') {
                                                if($value == 'Mr')
                                                    $value = strtolower('male');
                                                if($value == 'Mrs')
                                                    $value = strtolower('female');
                                                if($value == '' || $value == null)
                                                    $value = strtolower('other');

                                                $value = strtolower($value);
                                            }


                                            if($key == 'groups') {
                                                $user_groups = ['Member'];
                                                if(!empty($value)) {
                                                    $value = json_encode(['Member', $value]);
                                                }
//                                                if(!empty($user->groups)) {
//
//                                                    $value = json_encode(['Member', $value]);
//
////                                                    $user_groups = json_decode($user->groups);
////                                                    if(is_array($user_groups)) {
////                                                        if(!in_array($value,$user_groups)) {
////                                                            $user_groups[] = $value;
////                                                        }
////                                                    }
//                                                } else {
////                                                    if($value == 'Member')
////                                                        $user_groups = ['Member'];
////                                                    else {
////                                                        $user_groups[] = $value;
////                                                    }
//                                                    $value = json_encode(['Member']);
//                                                }
                                                //$value = json_encode($user_groups);
                                            }
                                            $user->$key = $value;
                                        }
                                    }


                                }
                            }
                        }
                        Log::channel('custom')->info('user_obj_update', ['user_obj' => $user ]);
                        $user->save();
                        if($user) {
                            $success++;
                            (new ElasticSearchController())->insertUserToES($user->user_id);
                            //save user address
                            $this->saveUserAddress($user->user_id,$req_datum);

                        }
                    }
                }
                else
                    $failed++;

            }
            return \response()->json(['status' => "Updated $success, Rejected $failed"],200);
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('addUpdateUser_error', ['addUpdateUser_error ' => $e->getMessage(),'addUpdateUser_error' => $e->getLine() ]);
            return \response()->json(['status' => "Server Error"],500);
        }
    }

    private function updateUserCustomField($user_id,$field_id,$value) {
        $custom_field = UserCustomField::where('field_unique_id',$field_id)->first();
        if($custom_field) {
            $field_value = $this->getCustomFieldValue($value,$custom_field,$user_id);

            if($custom_field->field_type != 'multiselect') {
                UserCustomFieldData::updateOrCreate(
                    ["user_id" => $user_id,"custom_field_id" => $custom_field->id],
                    ["user_id" => $user_id,
                        "custom_field_id" => $custom_field->id,
                        "value" => $field_value,
                        "form_id" => (new Utility())->IsNullOrEmptyString($custom_field->parent_id) ? 0 : $custom_field->parent_id
                        ]
                );
            }
            else {
                UserCustomFieldData::updateOrCreate(
                    ["user_id" => $user_id,"custom_field_id" => $custom_field->id],
                    ["user_id" => $user_id,"custom_field_id" => $custom_field->id,
                    "multiselect_value" => $field_value,
                        "form_id" => (new Utility())->IsNullOrEmptyString($custom_field->parent_id) ? 0 : $custom_field->parent_id
                    ]
                );
            }
        }
    }



    private function getCustomFieldValue($new_value,$custom_field,$user_id) {
       // Log::channel('custom')->info('$this->csv_mappings', ['$this->csv_mappings ' => $this->csv_mappings]);
        Log::channel('custom')->info('getCustomFieldValue', ['getCustomFieldValue_$new_value' => $new_value]);
        Log::channel('custom')->info('getCustomFieldValue', ['getCustomFieldValue_$custom_field' => $custom_field]);
        $field_value = $new_value;
        $field_type = $custom_field->field_type;

        if ($field_type == "datetime") {
            $field_value = strtotime($new_value) * 1000;

        }else if ($field_type == "date") {
            $field_value = date("Y-m-d",strtotime($new_value));

        } else if($field_type == "multiselect") {
            //check if it already exists
           $exist = UserCustomFieldData::where([
               'user_id' => $user_id,
               'custom_field_id' => $custom_field->id,
           ])->first();

           if(!$exist) {
               return json_encode([$field_value]);
           }
           else {
               $exist_value = json_decode($exist->multiselect_value);
               if(is_array($exist_value)) {
                   $csv_mapping = collect($this->csv_mappings);
                   $csv_obj = $csv_mapping->where('map_name',$custom_field->field_unique_id)->first();

                   if(count($csv_obj) > 0) {
                       if($csv_obj['multi_select_value'] == 'remove') {
                           Log::channel('custom')->info('multi_select_value', ['multi_select_value ' => $csv_obj['multi_select_value'] ]);
                           Log::channel('custom')->info('multi_select_value', ['$new_value' => $new_value]);
                           $index = array_search($new_value, $exist_value);
                            unset($exist_value[$index]);
                           Log::channel('custom')->info('multi_select_value', ['$exist_value' => $exist_value]);
                       }
                       else {
                           if(!in_array($new_value,$exist_value)) {
                               $exist_value[] = $new_value;
                           }
                       }
                       return json_encode($exist_value);
                   }
                   else {
                       json_encode([$new_value]);
                   }

               }
               else {
                   return json_encode([$exist_value]);
               }
           }
        }
        else if ($field_type == "boolean") {
            if($new_value == 'y' || $new_value == 'Y' || $new_value == 1 || $new_value == 'true') {
                $field_value =  true;
            }
            else {
                $field_value = false;
            }

        }
        return $field_value;
    }

    private function saveUserAddress($user_id,$req_datum) {

        Log::channel('custom')->info('saveUserAddress', ['saveUserAddress ' => $req_datum, 'user_id' => $user_id ]);

        $user_address = UserAddresses::where('user_id',$user_id)->first();
        if(!$user_address) {
            $user_address = new UserAddresses();
        }
        $user_address->user_id = $user_id;
        foreach ($req_datum as $key => $value) {
            switch ($key):
                case 'address':
                    $user_address->address = $value;
                    break;
                case 'address2':
                    $user_address->address2 = $value;
                    break;
                case 'street_number':
                    $user_address->street_number = $value;
                    break;
                case 'street_name':
                    $user_address->street_name = $value;
                    break;
                case 'country':
                    $user_address->country = $value;
                    break;
                case 'city':
                    $user_address->city = $value;
                    break;
                case 'state':
                    $user_address->state = $value;
                    break;
                case 'suburb':
                    $user_address->suburb = $value;
                    break;
                case 'postal_code':
                    $user_address->postal_code = $value;
                    break;
                default:
                    break;
            endswitch;
        }
        Log::channel('custom')->info('$user_address', ['$user_address ' => $user_address ]);
        $user_address->save();

    }

    public function addQueueID(Request $request) {
        $queue_id = $request->id;
        if( !(new Utility())->IsNullOrEmptyString($queue_id) ) {
            DB::table("queue_ids")->updateOrInsert([
                'queue_id' => $queue_id
            ], ['queue_id' => $queue_id]);
        }
        return \response()->json(['success' => true],200);

    }

    public function getGamesVC(Request $request)
    {
        $games = DB::table('games')->whereNull('deleted_at')->get(['id','title AS text']);
        return response()->json(['results' => $games], 200);
    }

    public function getMissionsVC(Request $request)
    {
        $game_id = $request->game_id;
        $missions = DB::table('missions')->where('game_id',$game_id)->whereNull('deleted_at')->get(['id','title AS text']);
        return response()->json(['results' => $missions], 200);
    }

    public function getAllBrandsVC() {
        $http = new \GuzzleHttp\Client();
        $response = $http->get(config('constant.LINK_URL') . 'unilever/getBrands', [
            'headers' => ['X-Link-Secret-Key' => config('constant.LINK_SECRET')],

        ]);
        $response = json_decode($response->getBody()->getContents(), true);

        $data = $response['body'];

        $newDataArray = [];

        foreach ($data['brands'] as $value) {
            $newDataArray[] = ['id' => $value['name'], 'text' => $value['name']];
        }


        $data =  $this->getUnileverProducts();
//        $html_str = json_encode($html_str);
        $html_str = trim(preg_replace('/\s\s+/', ' ', $data['tree_html']));
        return ['status' => true, 'brands' => $newDataArray, 'product_data' => $html_str,'product_arr' => $data['tree_arr']];
    }

    public function getUnileverProducts()
    {


//        $http = new \GuzzleHttp\Client();
//        $response = $http->get(config('constant.LINK_URL') . 'get_wuhu_categories_and_products', [
//            'headers' => ['secret_key' => config('constant.LINK_SECRET')]
//        ]);
//        $response = json_decode($response->getBody()->getContents(), true);


        $http = new \GuzzleHttp\Client();
        $response = $http->get(config('constant.LINK_URL') . 'get_wuhu_master_data', [
            'headers' => [
                'X-Link-Secret-Key' => config('constant.LINK_SECRET'),
                'X-Link-Version' => 'v2',
                'X-Link-Mapping-Required' => 'no'
            ]
        ]);
        $response = json_decode($response->getBody()->getContents(), true);

       // $response = json_decode(file_get_contents("../test.json"), true);


        $data = $response['body'];


        $newDataArray = [];
        $digits = 12;




        $tree_markup = "<ul class='treeview_ hummingbird-base'>";
        $tree_markup .= $this->makeTree($data);
        $tree_markup .= "</ul>";


//        echo($tree_markup);
//        exit;

        return ['tree_html' => $tree_markup,'tree_arr' => $newDataArray];


       /* foreach ($data as $eachKey => $eachValueOBJ) {


            //first category
            $categoryArray = [];
            foreach ($eachValueOBJ as $eachNewKey => $eachValueOBJ01) {

                $productArray = [];
                $finalDataArray = ['value' => str_pad(rand(0, pow(10, $digits) - 1), $digits, '0', STR_PAD_LEFT), 'label' => $eachNewKey];
                //second category
                if (is_int($eachNewKey)) {

                    //$this->add_myproducts($eachValueOBJ01,$data);
                } else {
                    $pushData = true;
                    foreach ($eachValueOBJ01 as $thirdKey => $thirdValue) {

                        if (is_int($thirdKey)) {
                            $pushData = true;
                            //$productArray[] = ['value' => $thirdValue['alias_id'], 'label' => $thirdValue['alias']];
                            $productArray[] = ['value' => isset($thirdValue['product']['barcode']['$numberLong']) ? $thirdValue['product']['barcode']['$numberLong'] : $thirdValue['alias_id'], 'label' => $thirdValue['alias']];
                        } else {

                            foreach ($thirdValue as $thirdLevelName => $eachProduct) {

                                //$productArray[] = ['value' => $eachProduct['alias_id'], 'label' => $eachProduct['alias']];
                                $productArray[] = ['value' => isset($eachProduct['product']['barcode']['$numberLong']) ? $eachProduct['product']['barcode']['$numberLong'] : $eachProduct['alias_id'], 'label' => $eachProduct['alias']];
                            }
                            $pushData = false;
                            if (count($productArray) >= 1) {
                                $finalDataArray['children'][] = ['value' => str_pad(rand(0, pow(10, $digits) - 1), $digits, '0', STR_PAD_LEFT), 'label' => $thirdKey, 'children' => (count($productArray) > 0) ? $productArray : null];
                            }
                        }
                    }
                }
                if ($pushData and count($productArray) > 0) {
                    $finalDataArray['children'] = $productArray;
                }

                $categoryArray[] = $finalDataArray;
            }
            $newDataArray[] = ['value' => str_pad(rand(0, pow(10, $digits) - 1), $digits, '0', STR_PAD_LEFT), 'label' => $eachKey, 'children' => $categoryArray];
        }*/

        //dd($newDataArray);

        //return $newDataArray;
        $newDataArray  = json_decode (json_encode ($newDataArray), FALSE);

        $tree_markup = "<ul class='treeview_ hummingbird-base'>";


        $arr = [];
        //make data
        foreach ($newDataArray as $level_1) {
            $arr[] = [
                'Id' => $level_1->value,
                'Title' => $level_1->label,
                'ParentId' => null,
            ];
            $label = $level_1->label;

//            $tree_markup .= "<li><i class='fa fa-plus'></i><label><input type='checkbox' id='.$level_1->value.' data-id='$level_1->value' /> $label </label>";

            if(isset($level_1->children) && count($level_1->children) > 0) {
                $tree_markup .= "<li><i class='fa fa-plus'></i><label><input type='checkbox' id='.$level_1->value.' data-id='$level_1->value' /> $label </label>";
                $tree_markup .= "<ul>";

                foreach ($level_1->children as $level_2) {
                    $arr[] = [
                        'Id' => $level_2->value,
                        'Title' => $level_2->label,
                        'ParentId' => $level_1->value,
                    ];

//                    $tree_markup .= "<li><i class='fa fa-plus'></i><label><input type='checkbox' id='$level_2->value' data-id='$level_2->value' /> $level_2->label </label>";

                    if(isset($level_2->children) && count($level_2->children) > 0) {
                        $tree_markup .= "<li><i class='fa fa-plus'></i><label><input type='checkbox' id='$level_2->value' data-id='$level_2->value' /> $level_2->label </label>";
                        $tree_markup .= "<ul>";

                        foreach ($level_2->children as $level_3) {
                            $arr[] = [
                                'Id' => $level_3->value,
                                'Title' => $level_3->label,
                                'ParentId' => $level_2->value,
                            ];
//                            $tree_markup .= "<li><i class='fa fa-plus'></i><label><input type='checkbox' id='$level_3->value' data-id='$level_3->value' /> $level_3->label </label>";

                            if(isset($level_3->children) && count($level_3->children) > 0) {
                                $tree_markup .= "<li><i class='fa fa-plus'></i><label><input type='checkbox' id='$level_3->value' data-id='$level_3->value' /> $level_3->label </label>";
                                $tree_markup .= "<ul>";
                                foreach ($level_3->children as $level_4) {
                                    $arr[] = [
                                        'Id' => $level_4->value,
                                        'Title' => $level_4->label,
                                        'ParentId' => $level_3->value,
                                    ];
                                    $tree_markup .= "
                                        <li><label><input class='hummingbirdNoParent' type='checkbox' id='$level_4->value' data-id='$level_4->value' /> $level_4->label </label></li>";
                                }
                                $tree_markup .= "</ul>";
                            }
                            else {
                                $tree_markup .= "<li><i class='fa fa-plus'></i><label><input class='hummingbirdNoParent' type='checkbox' id='$level_3->value' data-id='$level_3->value' /> $level_3->label </label></li>";
//                                $tree_markup .= "</li>";
                            }
                        }
                        $tree_markup .= "</ul>";
                    }
                    else {
                        $tree_markup .= "<li><i class='fa fa-plus'></i><label><input class='hummingbirdNoParent' type='checkbox' id='$level_2->value' data-id='$level_2->value' /> $level_2->label </label></li>";
//                        $tree_markup .= "</li>";
                    }
                }
                $tree_markup .= "</ul>";
            }
            else {
                $tree_markup .= "<li><i class='fa fa-plus'></i><label><input class='hummingbirdNoParent' type='checkbox' id='.$level_1->value.' data-id='$level_1->value' /> $label </label>";
                //$tree_markup .= "</li>";
            }
        }
        $tree_markup .= "</ul>";
//        echo "<pre>";
//        print_r($tree_markup);
//        exit;


        dd($tree_markup);
        //return $newDataArray;
        //return $arr;
        return ['tree_html' => $tree_markup,'tree_arr' => $newDataArray];
        return $tree_markup;

    }



    public function makeTree($data) {

        $result = "";

        foreach($data as $key => $val) {

            $rand = $this->generateRandomNumber();

            // If product
            if (is_numeric($key) || $key === 0) {
                $result .= "<li>
                            <i class='fa fa-minus'></i>
                            <label><input class='hummingbirdNoParent' type='checkbox' id='$val[gtin]' data-id='$val[gtin]' /> $val[product_name] </label>
                        ";
            } else {
                $result .= "<li>
                            <i class='fa fa-plus'></i>
                            <label><input type='checkbox' id='$rand' data-id='$rand' /> $key </label>
                        ";
            }


            if (is_array($val) && !is_numeric($key)) {

                $result .= "<ul>";
                $result .= $this->makeTree($val);
                $result .= "</ul>";
            }

            $result .= "</li>";

        }


        //print_r( $result) . "<hr>";
       //dd($result);

        //$this->treeHTML .= $result;

        return $result;

    }

    public function generateRandomNumber() {
        return mt_rand(100000000000,9999999999999);
    }

    public function getUpcomingMission() {
        //get upcoming mission


        $upcoming_game = Games::where('start_date','>',date('Y-m-d H:i:s'))->whereNull('deleted_at')->orderBy('start_date','ASC')->first();
        //$upcoming_game = DB::select("SELECT * FROM games WHERE start_date > NOW() AND deleted_at IS NULL ORDER BY start_date LIMIT 1");
        if($upcoming_game) {

            //get latest mission of this game
            $mission = Mission::where('game_id',$upcoming_game->id)->orderBy('created_at','DESC')->first();

            if($mission) {
                $info = json_decode($mission->info,true);

                if(isset($info['survey_id'])) {
                    if($info['survey_id'] == 0)
                        $surveyId = "";
                    else
                        $surveyId = $info['survey_id'];
                }
                else {
                    $surveyId = "";
                }
                $outcomes = [];
                $video = [];
                if(isset($info['video_id']) && $info['video_id'] != 0) {
                    $video_obj = RecipeOffer::where('id',$info['video_id'])->first();

                    if($video_obj) {
                        $video['video_id'] = $video_obj->id;
                        if(isset($video_obj->video_link)) {
                            $video['video_url'] = url('/').'/'.$video_obj->video_link;
                        } else {
                            $video['video_url'] = $video_obj->url ?? "";
                        }
                    }
                    else {
                        $video['video_url'] = "";
                        $video['video_id'] = 0;
                    }


                }
                else {
                    $video['video_url'] = "";
                    $video['video_id'] = 0;
                }
                $video =  (object) $video;

                if (!isset($outcomes['badge_name']) and !isset($outcomes['badge_id'])) {
                    $outcomes['badge_name'] = '';
                    $outcomes['badge_image'] = '';
                    $outcomes['badge_id'] = '';
                    $outcomes['percentage'] = '';
                }


                //my code
                $badge = Badge::where('id',isset($info['badge_id']) ? $info['badge_id'] : 0)->first();
                if($badge) {
                    $outcomes['badge_name'] = $badge->title;
                    $outcomes['badge_id'] = $badge->id;
                    $outcomes['badge_image'] = "";
                    //get state
                    $state = BadgeState::where('badge_id',$badge->id)->first();
                    if($state) {
//                                $outcome['percentage'] = $state->progression;
                        $outcomes['state_name'] = $state->state_name;
                        $perCent = $state->progression;
                        if(isset($state->state_image) and $state->state_image != "") {
                            $outcomes['badge_image'] = isset($state->state_image) ? url('/badges').'/'.$state->state_image : "";
                        } else {
                            $outcomes['badge_image'] = isset($badge->image) ? url('/badges').'/'.$badge->image : "";
                        }


                    }

                }
                else {
                    $outcomes['badge_name'] = '';
                    $outcomes['badge_image'] = '';
                    $outcomes['badge_id'] = '';
                    $outcomes['percentage'] = '';
                }
                $outcomes['points'] = isset($info['points']) ? $info['points'] : 0;


                $completeProfile = isset($info['mission_type']) ? $info['mission_type'] : "";


                //get upcoming mission time in seconds
                $seconds = Carbon::parse(date('Y-m-d H:i:s'))->diffInSeconds(Carbon::parse($upcoming_game->start_date));
                $seconds = $seconds >= 0 ? $seconds : 0;



                $final_data = ['mission_id' => $mission->id,'time_in_seconds' => $seconds, 'start_date' => $upcoming_game->start_date, 'mission_description' =>$mission->description,
                    'mission_type' => $completeProfile,
                    'survey_id' =>$surveyId, 'completed' => false,
                    'mission_name' => $mission->title, 'outcomes' => $outcomes,'video' => $video,
                    'long_description' =>  isset($info['long_desc']) ? $info['long_desc'] : "" ,
                ];

                return $final_data;
            }
            else {
                 return  ['mission_id' => 0,  'time_in_seconds' => 0, 'start_date' => "", 'mission_description' =>"",
                    'mission_type' => "",
                    'survey_id' => 0, 'completed' => false,
                    'mission_name' => "", 'outcomes' => (object)[],'video' => (object)[],
                    'long_description' =>  isset($info['long_desc']) ? $info['long_desc'] : "" ,
                ];
            }
        }
        else {
            return  ['mission_id' => 0, 'time_in_seconds' => 0, 'start_date' => "", 'mission_description' =>"",
                'mission_type' => "",
                'survey_id' => 0, 'completed' => false,
                'mission_name' => "", 'outcomes' => (object)[],'video' => (object)[],
                'long_description' =>  isset($info['long_desc']) ? $info['long_desc'] : "" ,
            ];
        }


    }

    public function gamificationVC() {
        try {
            $user = \request()->user();
           // $user = User::where('user_id',5898)->first();

            //get user games
            //$game_ids = MissionUserEntry::where('user_id',$user->user_id)->pluck('game_id')->toArray();

                $games = Games::with(['missions' => function ($query) {

                    $query->where(function ($q){
                        $q->whereNull('start_date')->orWhere('start_date', '<=', date('Y-m-d H:i:s'));
                    })->where(function ($q) {
                            $q->whereNull('end_date')->orWhere('end_date', '>=', date('Y-m-d H:i:s'));
                        })->where(function ($q){
                            $q->where('mission_channel','Overt');
                    });


                }])->whereNull('deleted_at')->where(function ($q) {

                $q->whereNull('start_date')
                    ->orWhere('start_date', '<=', date('Y-m-d H:i:s'));
            })->where(function ($q) {
                $q->whereNull('end_date')
                    ->orWhere('end_date', '>=', date('Y-m-d H:i:s'));
            })->get();

                //dd(json_encode($games));

            $data = [];


        $userMissions = collect([]);
        $gameData = collect([]);
        $pushData = false;
        $completed = true;
        $countData = 0;
        $perCent = 0;

        $hidden = false;

        $games->each(function ($game) use (&$userMissions, &$pushData, &$completed, &$gameData, &$user, &$countData, &$perCent,&$hidden) {


            $game->missions->each(
                function ($mission) use (&$userMissions, &$pushData, &$completed, $game, &$user, &$gameData, &$countData, &$perCent,&$hidden) {


                    $missionOuntcomeData = json_decode($mission->outcomes);
                    $gameMissions = json_decode($game->missions);

                    $mission->outcomes = json_decode($mission->outcomes);

                    $missionEntry = MissionUserEntry::where(['user_id' => $user->user_id, 'mission_id' => $mission->id, 'game_id' => $mission->game_id])->first();


                    //my code
                    $info = json_decode($mission->info,true);
                    if(isset($info['survey_id'])) {
                        if($info['survey_id'] == 0)
                            $surveyId = "";
                        else
                            $surveyId = $info['survey_id'];
                    }
                    else {
                        $surveyId = "";
                    }
                    $video = [];
                    if(isset($info['video_id']) && $info['video_id'] != 0) {
                        $video_obj = RecipeOffer::where('id',$info['video_id'])->first();

                        if($video_obj) {
                            $video['video_id'] = $video_obj->id;
                            if(isset($video_obj->video_link)) {
                                $video['video_url'] = url('/').'/'.$video_obj->video_link;
                            } else {
                                $video['video_url'] = $video_obj->url ?? "";
                            }
                        }
                        else {
                            $video['video_url'] = "";
                            $video['video_id'] = 0;
                        }


                    }
                    else {
                        $video['video_url'] = "";
                        $video['video_id'] = 0;
                    }



                    $video =  (object) $video;
                   // if (!empty($outcomes)) {
                        $countData = $countData + 1;
                        $pushData = true;
//                        if (!isset($outcomes['points'])) {
//                            $outcomes['points'] = (string)0;
//                        }
//
//                        if ($missionEntry) {
//                            if (isset($outcomes['percentage'])) {
//                                $perCent = $outcomes['percentage'];
//                            }
//                        }
                        if (!isset($outcomes['badge_name']) and !isset($outcomes['badge_id'])) {
                            $outcomes['badge_name'] = '';
                            $outcomes['badge_image'] = '';
                            $outcomes['badge_id'] = '';
                            $outcomes['percentage'] = '';
                        }


                        //my code
                        $badge = Badge::where('id',isset($info['badge_id']) ? $info['badge_id'] : 0)->first();
                        if($badge) {
                            $outcomes['badge_name'] = $badge->title;
                            $outcomes['badge_id'] = $badge->id;
                            $outcomes['badge_image'] = "";
                            //get state
                            $state = BadgeState::where('badge_id',$badge->id)->first();
                            if($state) {
//                                $outcome['percentage'] = $state->progression;
                                $outcomes['state_name'] = $state->state_name;
                                $perCent = $state->progression;
                                if(isset($state->state_image) and $state->state_image != "") {
                                    $outcomes['badge_image'] = isset($state->state_image) ? url('/badges').'/'.$state->state_image : "";
                                } else {
                                    $outcomes['badge_image'] = isset($badge->image) ? url('/badges').'/'.$badge->image : "";
                                }


                            }

                        }
                        else {
                            $outcomes['badge_name'] = '';
                            $outcomes['badge_image'] = '';
                            $outcomes['badge_id'] = '';
                            $outcomes['percentage'] = '';
                        }
                        $outcomes['points'] = isset($info['points']) ? $info['points'] : 0;

                        //mission type
                        $completeProfile = isset($info['mission_type']) ? $info['mission_type'] : "";

                        if ($missionEntry and count($gameMissions) > 1) {
                            $outcomes['percentage'] = $perCent;
                            $completed = true;
                            $userMissions->push(
                                ['mission_id' => $mission->id,'mission_description' =>$mission->description,
                                'mission_type' => $completeProfile,
                                'survey_id' =>$surveyId, 'completed' => $completed,
                                'mission_name' => $mission->title, 'outcomes' => $outcomes,'video' => $video,
                                'long_description' =>  isset($info['long_desc']) ? $info['long_desc'] : "" ,

                            ]
                            );
                        } else if ($missionEntry and count($gameMissions) == 1) {
                            if (isset($outcomes['percentage']))
                                $outcomes['percentage'] = 100;

                            $userMissions->push(['mission_id' => $mission->id,'mission_description' =>$mission->description,
                                'mission_type' => $completeProfile,'survey_id' =>$surveyId, 'completed' => true,
                                'mission_name' => $mission->title, 'outcomes' => $outcomes,'video' => $video,
                                'long_description' =>  isset($info['long_desc']) ? $info['long_desc'] : "" ,

                            ]);
                        } else if (!$missionEntry and count($gameMissions) > 1) {
                            if (isset($outcomes['percentage']))
                                $outcomes['percentage'] = $perCent;

                            $userMissions->push(['mission_id' => $mission->id,'mission_description' =>$mission->description,'mission_type' => $completeProfile,'survey_id' => $surveyId, 'completed' => false,
                                'mission_name' => $mission->title, 'outcomes' => $outcomes,'video' => $video,
                                'long_description' =>  isset($info['long_desc']) ? $info['long_desc'] : "" ,

                            ]);
                        } else if (!$missionEntry and count($gameMissions) == 1) {
                            if (isset($outcomes['percentage']))
                                $outcomes['percentage'] = 0;

                            $userMissions->push(['mission_id' => $mission->id,'mission_description' =>$mission->description,'mission_type' => $completeProfile,'survey_id' => $surveyId, 'completed' => false,
                                'mission_name' => $mission->title,
                                'long_description' =>  isset($info['long_desc']) ? $info['long_desc'] : "" ,
                                'outcomes' => $outcomes,'video' => $video,

                            ]);
                        }

                        $completed = 0;


                });


                if($userMissions->isNotEmpty()) {
                    $gameData->push(['game_id' => $game->id, 'game_name' => $game->title, 'missions' => $userMissions->toArray()]);
                }

                $userMissions = collect([]);
                $countData = 0;


        });


            $upcoming_mission = $this->getUpcomingMission();




        return ['status' => true, 'data' => $gameData->toArray(), 'upcoming_mission' => $upcoming_mission];
        dd("out");


        foreach ($games as $game) {








                //get mission
                $mission = Mission::where('game_id',$game->id)->orderBy('id','desc')->first();
                if($mission) {


                    $game_temp = [];
                    $game_temp['game_id'] = $game->id;
                    $game_temp['game_name'] = $game->title;

                    $mission_obj = [];

                    $info = json_decode($mission->info,true);
                    $mission_obj['mission_id'] = $mission->id;
                    $mission_obj['mission_description'] = $mission->description;
                    $mission_obj['mission_name'] = $mission->title;
                    $mission_obj['mission_type'] = isset($info['mission_type']) ? isset($info['mission_type']) : "";
                    if(isset($info['survey_id'])) {
                        if($info['survey_id'] == 0)
                            $mission_obj['survey_id'] = "";
                        else
                            $mission_obj['survey_id'] = $info['survey_id'];
                    }
                    else {
                        $mission_obj['survey_id'] = "";
                    }

                    //add complete status
                    $user_count = MissionUserEntry::where(['game_id' => $game->id,'user_id' => $user->user_id])->count();
                    $mission_count = Mission::where('game_id',$game->id)->count();
                    if($user_count >= $mission_count) {
                        $mission_obj['completed'] = true;
                    }
                    else {
                        $mission_obj['completed'] = false;
                    }


                    //make outcome obj
                    $outcome = [];
                    //get badge
                    $badge = Badge::where('id',isset($info['badge_id']) ? $info['badge_id'] : 0)->first();
                    if($badge) {
                        $outcome['badge_name'] = $badge->title;
                        $outcome['badge_id'] = $badge->id;
                        $outcome['badge_image'] = isset($badge->image) ? url('/badges').'/'.$badge->image : "";
                        //get state
                        $state = BadgeState::where('badge_id',$badge->id)->first();
                        if($state) {
                            $outcome['percentage'] = $state->progression;
                            $outcome['state_name'] = $state->state_name;
                        }

                    }
                    else {
                        $outcome['badge_name'] = "";
                        $outcome['badge_id'] = "";
                        $outcome['badge_image'] = "";
                    }
                    $outcome['points'] = isset($info['points']) ? $info['points'] : 0;

                    $mission_obj['outcomes'] = $outcome;
                    //make video obj
                    $video = [];
                    if(isset($info['video_id']) && $info['video_id'] != 0) {
                        $video = RecipeOffer::where('id',$info['video_id'])->first();
                        $video['video_id'] = $video->id;
                        if($video) {
                            if(isset($video->video_link)) {
                                $video['video_url'] = url('/uploads').'/'.$video->video_link;
                            } else {
                                $video['video_url'] = $video->url ?? "";
                            }
                        }
                    }
                    $mission_obj['video'] = $video;


                    $game_temp['missions'] = [$mission_obj];

                    $data[] = $game_temp;
                }
                else {
                    //$game_temp['missions'][] = [];
                }


            }
        return ['status' => true, 'data' => $data];
        }
        catch (\Exception $e) {

            Log::channel('custom')->info('gameVC_error', ['gameVC_error ' => $e->getTrace(),'line' => $e->getLine()]);
            return ['status' => false, 'data' => [], 'message' => $e->getMessage()];
        }
    }



    public function saveCSVTemplate(Request $request) {
        try {
            $temp = CSVTemplate::where('name',$request->temp_name)->first();
            if(!$temp) {
                $temp = new CSVTemplate();
                $temp->name = $request->temp_name;
                $temp->template = json_encode($request->mapping_arr);
                $temp->save();
                return ['status' => true, 'message' => 'Template Saved'];
            }
            return ['status' => 400, 'message' => 'Template Saved'];
        }
        catch (\Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }

    public function getCSVTemplates(Request $request) {
        try {
            return ['status' => true, 'templates' => CSVTemplate::all()];
        }
        catch (\Exception $e) {
            return ['status' => true, 'templates' => [], 'message' => $e->getMessage()];
        }
    }

    public function bookingTrigger(Request $request) {
        Log::channel('custom')->info('bookingEvent', ['bookingEvent ' => $request->all()]);
    }
    public function getUserDevices(Request $request) {
        try {
            $user_id = $request->user_id;
            $no_hardware = $request->no_hardware;
            $days = $request->days;
            $date = '';
            $fraud_status = false;
            $message = '';
            if($days > 0) {
                Log::channel('custom')->info('iggffffffffffffffffffff');
                $date = Carbon::parse()->subDays($days)->toDateString();
                Log::channel('custom')->info('$date',['$date' => $date]);
                $devices = (new ElasticSearchController())->getDevices($user_id,$date);
            }
            else {
                Log::channel('custom')->info('yooooooooooooo');
                $devices = (new ElasticSearchController())->getDevices($user_id);
            }
            Log::channel('custom')->info('$devices', ['$devices ' => $devices]);
            foreach ($devices as $device) {
                $query = ['query' => [
                    'bool' => [
                        'must' => [
                            ['match' => ['custom_doc_type' => config('constant.persona_devices')]],
                            ['match' => ['device_name' => $device['_source']['device_name']]],
                        ],
                        "must_not" =>[
                            ['term' => ['persona_id' => $user_id]]
                        ]
                    ]
                ]];
                $count = ElasticsearchUtility::count(ElasticsearchUtility::generateIndexName(request()->company_id, request()->venue_id), $query);
                Log::channel('custom')->info('$count', ['$count ' => $count]);
                if($count >= $no_hardware) {
                    $fraud_status = true;
                    $device_id = $device['_source']['device_name'];
                    $message = "More than $no_hardware profiles exists against this device $device_id" ;
                    break;
                }
            }
            Log::channel('custom')->info('$date', ['$date ' => $date]);

            return response()->json(['message' => $message]);
        }
        catch (\Exception $e) {
            Log::channel('custom')->info('getUserDevices_error', ['getUserDevices_error ' => $e->getMessage()]);
            return response()->json(['message' => $message]);
        }
    }






}
