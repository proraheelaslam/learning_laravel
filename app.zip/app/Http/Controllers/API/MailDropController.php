<?php

namespace App\Http\Controllers\API;

use App\Models\MailDrop;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MailDropController extends Controller
{
    public function getMailDrop(Request $request){
        //..... get single template for editing .....//
        $skip = ($_GET["perPage"]) * $_GET['page'];
        $data = MailDrop::select(["id","name","sku","start_date as date","end_date"])->orderBy("id","DESC")
            ->skip($skip)->take($_GET["perPage"])->get();


        foreach ($data as $key => $value){
            //echo $value->date."=====";
            $value->date = !empty($value->date) ? date("d-m-Y",strtotime($value->date)) : !empty($value->end_date) ? date("d-m-Y",strtotime($value->end_date)) : "";
        }
        return [

            "status"=>true,
            "data"=>$data,
            "totalRecords"=>MailDrop::select(["id"])->count(),
        ];
        //..... end of edit .....//
    }


     public function listMailDrop(){
         if (request()->nameSearch != "") {
             $data['data'] = MailDrop::where('name', 'like', '%' . request()->nameSearch . '%')->skip(request()->offset)->take(request()->limit)->orderBy(request()->order_by, request()->orderData)->get();
             $data['total'] = MailDrop::where('name', 'like', '%' . request()->nameSearch . '%')->count();
         } else {
             $data['data'] = MailDrop::skip(request()->offset)->take(request()->limit)->orderBy(request()->order_by, request()->orderData)->get();
             $data['total'] = MailDrop::count();
         }

         $data['status'] = true;
         return $data;
     }

    public function saveMailDrop(Request $request, FilesController $filesController)
    {

        $venueData = ['name' => $request->name, "sku" => $request->sku, 'descriptions' => $request->descriptions];
        if(request()->start_date != null)
            $venueData['start_date'] = request()->start_date;
        if(request()->end_date != null)
            $venueData['end_date'] = request()->end_date;
        $image = time() * rand() . ".png";

        if ($filesController->uploadBase64Image(request()->image, 'mail_drop/' . $image))
            $venueData['image'] = $image;

        if($venueData['start_date'] == "null")
            $venueData['start_date'] = NULL;
        if($venueData['end_date'] == "null")
            $venueData['end_date'] = NULL;

        if ($request->is_edit == 0) {

            MailDrop::create($venueData);
        } else {
            MailDrop::where(["id" => $request->is_edit])->update($venueData);
        }//..... end if-else() .....//


        return ['status' => true, 'message' => 'Venue saved successfully!'];
    }//..... end of saveVenue() ......//

    public function deleteMailDrop($id)
    {
        MailDrop::where("id",$id)->delete();
        return ["status" => true, "message" => "Record Deleted successfully "];
    }
}
