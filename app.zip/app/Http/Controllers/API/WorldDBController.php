<?php

namespace App\Http\Controllers\API;

use App\Classes\CommonLibrary;
use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Support\Facades\DB;

class WorldDBController extends Controller
{

    public $country_name = '';

    public function __construct()
    {

        $setting = Setting::where('type', 'country_name')->first();
        if ($setting) {
                $this->country_name = $setting->field1;
        } else {
            $this->country_name = 'AU';
        }
    }

    public function getCountries() {
        $countries = DB::table('countries')->get(['sortname','name','phonecode']);

        $country_name = $this->country_name;
        if($this->country_name != "" and $this->country_name != null) {
            foreach ($countries as $value) {
                if ($value->sortname   ===  $this->country_name) {
                    $value->is_default = true;
                } else {
                    $value->is_default = false;
                }
            }


        }
        return ['status' => true, 'data' => $countries, 'message' => ''];
    }

    public function getStates() {
        if(request()->has('country_name')){
            $states = DB::table('geo')->where('country_name',request()->country_name)->where('subdivision_1_name','!=','')->orderBy('subdivision_1_name', 'ASC')->groupBy('subdivision_1_name')->get(['subdivision_1_name as name','id']);
        }else{
            $states = DB::table('states')->where('country_id',request()->country_id)->orderBy('name', 'DESC')->get(['id','name']);
        }

        return ['status' => true, 'data' => $states, 'message' => ''];
    }

    public function getCities() {
        if(request()->has('state_name')){

            $cities = DB::table('geo')->where('subdivision_1_name','like','%'.trim(request()->state_name).'%')->where('city_name','!=','')->orderBy('city_name', 'ASC')->get(['id','city_name as name']);
        }else{
            $cities = DB::table('cities')->where('state_id',request()->state_id)->orderBy('name', 'DESC')->get(['id','name']);
        }

        return ['status' => true, 'data' => $cities, 'message' => ''];
    }


}
