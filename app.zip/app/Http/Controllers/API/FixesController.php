<?php


namespace App\Http\Controllers\API;


use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Models\Voucher;
use App\Models\VoucherUser;
use App\User;
use App\Utility\ElasticsearchUtility;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\StreamedResponse;
use App\Http\Controllers\API\VoucherController;
class FixesController extends Controller
{
    public $UniquerVoucherCode='';
    public $countData = 0;
    public function __construct()
    {
        set_time_limit(0);
        ini_set('memory_limit', '-1');
    }

    /**
     * @return array
     * Function for fixing null voucher_code entered
     */
    public function nullVoucherFixes()
    {
        try {
            $vouchers = VoucherUser::whereNull('voucher_code')->get();
            foreach ($vouchers as $value) {

                $voucher = Voucher::where('id', $value->voucher_id)->first(['pos_ibs']);

                $this->getUniqueVoucherCode($voucher->pos_ibs);// --- Call for getting unique voucher code

                $value->voucher_code = $this->UniquerVoucherCode;
                $value->save();
            }
            return ['status' => true, 'message' => 'Updated Successfully'];
        }catch (\Exception $e){
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }//----- End of nullVoucherFixes() -----//

    /**
     * @param $ibs
     * @return string
     *  Function for checking Voucher Code exists in table
     */
    public function getUniqueVoucherCode($ibs)
    {
        $this->UniquerVoucherCode = $this->generateVoucherCode($ibs);
        $voucherFind = VoucherUser::where('voucher_code',  $this->UniquerVoucherCode)->exists();
        if (!empty($voucherFind)) {
            return $this->getUniqueVoucherCode($ibs ?? 0);
        } else {
            return  $this->UniquerVoucherCode;
        }
    }//------ En of getUniqueVoucherCode() ------//

    /**
     * @param $ibs
     * @param int $sixdigit
     * @return string
     * Function for Generating Random Voucher Code
     */
    public function generateVoucherCode($ibs,$sixdigit=6) {

        $total_characters = '0123456789';
        $randomString = '';
        for ($i = 0; $i < $sixdigit; $i++) {
            $index = rand(0, strlen($total_characters) - 1);
            $randomString .= $total_characters[$index];
        }

        return $ibs . $randomString;
    }//----- End of generateVoucherCode() -----//

    public function changeMemberShipUser()
    {
        $index = config('constant.ES_INDEX_BASENAME');
        $query = [
            "query" => [
                "bool" => [
                    "must" => [
                        [
                            "terms" => [
                                    "groups" => ['Staff'] ?? []
                                ]

                        ]
                    ]
                ]
            ]
        ];
        $response = (new ElasticsearchUtility())->getAllData($query, $index);
        echo  count($response).' Users Founds <br/>';
        $dataUpdate=0;
      if(count($response)>0){
          foreach ($response as $value){
             $user = User::where('user_id',$value['persona_id'])->first();
             if($user) {
                 $fidMember = (!empty($user->groups)) ? $user->groups : json_encode(["Member"]);
                 $user->groups =json_encode(['Member']);
                 $user->save();
                 (new ElasticSearchController())->insertUserToES($user->user_id);
                 sleep(2);
                 (new ElasticSearchController())->updateUserMembership($user, '', json_decode($fidMember,true));


                 $dataUpdate = $dataUpdate + 1;
             }
          }
      }
      echo 'User Updated'. $dataUpdate;
    }

    public function updateMemberShip()
    {
        $file = request()->file('csv');

        $filename = "membership".$file->getClientOriginalExtension();
        $res = $file->move(public_path('/uploads/'), $filename);

        $customerArr = $this->get_file_data($res);
        echo "Total CSV Users =".count($customerArr).'<br/>';
        $countData =0;
         foreach ($customerArr as $value){
             $user = User::where('email',$value['email'])->first();
             if($user){
                 $fidMember = (!empty($user->groups)) ? $user->groups : json_encode(["Member"]);
                 $user->groups =json_encode(['Member','Staff']);
                 $user->save();
                 (new ElasticSearchController())->insertUserToES($user->user_id);
                 sleep(1);
                 (new ElasticSearchController())->updateUserMembership($user, 'Staff', json_decode($fidMember,true));

                 $countData = $countData +1;
             }


         }
        echo "Total User Update".$countData;
    }

    public function get_csv_file($path, $start, $end){

        $data = array();

        $file = fopen($path,"r");
        $i = 0;
        $count = 0;
        $head_array = array();
        $data_array = array();

        while(! feof($file))
        {
            if($i == 0){
                $head_array = fgetcsv($file);
            }else{
                $temp = array();
                $data = fgetcsv($file, 0, ',', '"', '"');

                if($i > $start && $i <= $end) {
                    if ($data != '') {
                        for ($k = 0; $k < count($head_array); $k++) {

                            $temp[$head_array[$k]] = $data[$k];
                        }
                        $data_array[] = $temp;
                    }
                }

            }
            $i++;
            $count++;

        }

        //echo count($data_array);
        //print_r($data_array);

        return $data_array;
    }
    public function get_file_data($p_Filepath="")
    {
        ini_set('allow_url_fopen',1);
        $file = fopen($p_Filepath,"r");

        $i = 0;
        $count=0;
        $head_array = array();
        $data_array = array();
        while(! feof($file))
        {
            if($i == 0){
                $head_array = fgetcsv($file);
            }else{
                $temp = array();
                $data = fgetcsv($file);

                if($data !=''){
                    for($k = 0; $k <count($head_array); $k++){
                        $temp[$head_array[$k]] = $data[$k];
                    }
                    $data_array[] = $temp;
                }

                if($i == 500){
                    $data_array = array();
                    $i = 0;
                }

            }
            $i++;
            $count++;

        }
        return $data_array;
        return ["status"=>true,"message"=>"Total $count records are dumped to database"];
    }

    /**
     *  Update Member Group For AUFC
     *  change member to Non-Member
     */
    public function updateMemberType()
    {
        if(config('constant.ACCESS_KEY') == request()->id) {

            $users = User::where('is_active', 1)->where('groups', 'NOT LIKE', '%"Non-Member"%')->limit(500)->get();

            if (count($users) > 0) {

                foreach ($users as $user) {
                    $groups = [];
                    if ($user->groups and json_decode($user->groups, true) > 0) {
                        $groups = json_decode($user->groups, true);
                        $groups[] = 'Non-Member';

                    } else {
                        $groups[] = 'Non-Member';
                    }
                    $user->update(['groups' => json_encode(array_values(array_unique($groups)))]);

                }
                 (new ElasticsearchUtility())->bulkUserDataInsertNew($users);
                echo '<meta http-equiv = "refresh" content = "1" />';
                exit();
            }else{
                echo 'All Finished';
            }
        }else{
            return ['status' => false, 'message' => 'You dont have access'];
        }

    }//------- End of updateMemberType() -----//

    public function urgentVoucherIssuing()
    {
        $voucher = Voucher::where(['id' => request()->voucher_id])->first();
        if ($voucher->voucher_type == 'group-voucher') {
            $vouchers = collect(json_decode($voucher->voucher_avial_data, true))->pluck('id');
        } else {
            $vouchers = [$voucher->id];
        }

        $take  =1000;
        $skip = 0;

        $settings = Setting::where('type','voucher_issued')->first();
        if($settings){

            $skip= $settings->field1 + 1000;
        }
        Log::channel('custom')->info('urgentVoucherIssuing()', ['take' => $take,'skip' => $skip]);
        $voucherList = Voucher::whereIn('id', $vouchers)->get();
        $random = rand(0, (count($vouchers) - 1));
        $randomVoucher = $voucherList[$random];

        try{

            $users = User::where('is_active',1)->skip($skip)->take($take)->get();
            foreach ($users as $user ) {

                $voucherCode = $this->checkValidCode($randomVoucher->pos_ibs);



                VoucherUser::insert([
                    "user_id" => $user->user_id,
                    "company_id" => $user->company_id,
                    "voucher_start_date" => ($randomVoucher->isNumberOfDays) ? date('Y-m-d H:i', strtotime('-1 days')) : $randomVoucher->start_date,
                    "voucher_end_date" => ($randomVoucher->isNumberOfDays) ? date('Y-m-d H:i', strtotime('+' . $randomVoucher->isNumberOfDays . ' days')) : $randomVoucher->end_date,
                    "no_of_uses" => $randomVoucher->no_of_uses,
                    "uses_remaining" => $randomVoucher->no_of_uses,
                    "created_at" => date('Y-m-d H:i'),
                    "updated_at" => date('Y-m-d H:i'),
                    "voucher_id" => $randomVoucher->id,
                    "voucher_code" => $voucherCode,
                    "group_id" => $randomVoucher->group_id ?? 0,
                ]);


            }

            if($settings){
                Setting::where('type','voucher_issued')->update([
                    'field1'=> $skip
                ]);
            }else{
                Setting::create([
                    'type'=>'voucher_issued',
                    'field1'=> $skip
                ]);
            }

            if($users){
                echo '<meta http-equiv="refresh" content="1">';
                exit();
            }else{
                echo 'All Finished';
                exit();
            }

        }catch (\Exception $e){
            Log::channel('custom')->info('urgentVoucherIssuing()', ['errorMessage' =>  $e->getMessage(),'line' => $e->getLine()]);
        }

    }//----- End of assignVoucher() ------//

    private function checkValidCode($posibs)
    {
        $voucherCode = $this->getIBSCode($posibs ?? 0);
        if (VoucherUser::where('voucher_code', $voucherCode)->exists()) {
            return $this->checkValidCode($posibs);
        } else {
            return $voucherCode;
        }
    }//----End of checkValidCode() -----/

    public function getIBSCode($ibs = 0)
    {
        $settings = Setting::where('type', 'configure_numbers')->first();
        $numberSetting = Setting::where('type', 'voucher_code_length')->first();
        if ($settings->field1 == 1) {
            $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
            $res = "";

            for ($i = 0; $i < 15; $i++)
                $res .= $chars[mt_rand(0, strlen($chars) - 1)];

            $code = str_split($res, 5);

            $first = $code[0] ?? '';
            $second = $code[1] ?? '';
            $third = $code[2] ?? '';
            $string = str_split($third, 2);
            $newString = $string[0] ?? "";
            return ($ibs) ? $ibs . $first . $second . $newString : $first . $second . $third;
        } else {
            $chars = "0123456789";
            $res = "";

            for ($i = 0; $i < (int)$numberSetting->field1; $i++)
                $res .= $chars[mt_rand(0, strlen($chars) - 1)];

            $code = str_split($res, 3);

            $first = $code[0] ?? '';
            $second = $code[1] ?? '';
            return ($ibs) ? $ibs . $first . $second : $first . $second;
        }
    }

    /**
     * @return StreamedResponse
     *  Get User Active Vouchers Report
     */
    public function userActiveVouchers()
    {
        $filename = 'user_vouchers_data' . date('Y-m-d') . '.csv';

            @unlink(public_path('/uploads/') . $filename);

        $response = new StreamedResponse(function () use ($filename) {
            $handle = fopen(public_path('/uploads/') . $filename, 'w+');

            // Add CSV headers
            fputcsv($handle, [
                'Client Customer ID',
                'First Name',
                'Last Name',
                'Email',
                'Voucher Name',
                'Expiry',
            ]);

             User::where('is_active',1)->chunk(100, function ($campaigns) use ($handle) {
                foreach ($campaigns as $value) {
                    $voucher = VoucherUser::where('user_id', $value->user_id)
                        ->whereDate('voucher_start_date', '<=', date('Y-m-d'))
                        ->whereDate('voucher_end_date', '>=', date('Y-m-d'))
                        ->where('uses_remaining', '>', 0)->get();
                    if (count($voucher)>0) {
                        foreach ($voucher as $key => $valueVoucher) {
                            $voucher = Voucher::where('id', $valueVoucher->voucher_id)->first();
                            if ($key == 0) {
                                fputcsv($handle, ['client_customer_id'=> $value->client_customer_id,'first_name' => $value->user_first_name, 'last_name' => $value->user_family_name, 'email' => $value->email, 'voucher_name' => $voucher->name, 'expiry' => $valueVoucher->voucher_end_date]);
                            } else {
                                fputcsv($handle, ['client_customer_id'=> '','first_name' => '', 'last_name' => '', 'email' => '', 'voucher_name' => $voucher->name, 'expiry' => $valueVoucher->voucher_end_date]);
                            }
                        }
                    }
                }

            });

            // Close the output stream
            fclose($handle);
        }, 200, [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename,
        ]);

      print_r(['status' => true, 'message' => 'CSV save as name:-'.$filename.' download url '.url('uploads/'.$filename)]);
        return $response;
    }//----- End of userActiveVouchers() ----//

    /**
     * @return array
     *  Issue Birthday Voucher
     */
    public function issueBirthDayVoucher()
    {
        $count = 0;
        $users = DB::select(DB::raw("SELECT * FROM users WHERE MONTH(dob) >= '01' AND MONTH(dob) <= MONTH(NOW())  AND DAYOFMONTH(NOW()) ='2' AND is_active='1'"));
        $users = collect($users);
        try {
            foreach ($users as $value) {
                $count = $count + 1;
                $userVouchers = Voucher::where('id', 8)->first();

                $voucherData = VoucherUser::where(['user_id'=> $value->user_id,'voucher_id'=>8])->first();
                if($voucherData){
                    continue;
                }
                $month = date('m', strtotime($value->dob));
                $day = date('d', strtotime($value->dob));
                $year = date('Y');
                $date = $year . '-' . $month . '-' . $day;
                if ($userVouchers->isNumberOfDays) {

                    $startDate = date('Y-m-d h:i:s a', strtotime($date));
                    $endDate = date('Y-m-d h:i:s a', strtotime($date . '+' . $userVouchers->isNumberOfDays . ' days'));
                } else {
                    $startDate = date('Y-m-d h:i:s a', strtotime($date));
                    $endDate = date('Y-m-d h:i:s a', strtotime($userVouchers->end_date));
                }

                $dataInsert = [
                    "no_of_uses" => $userVouchers->no_of_uses,
                    "uses_remaining" => $userVouchers->no_of_uses,
                    'group_id' => $userVouchers->group_id ?? 0,
                    'voucher_start_date' => $startDate,
                    'voucher_end_date' => $endDate,
                    'voucher_code' => (new VoucherController())->uniqueVoucherCode($userVouchers->pos_ibs ?? 0),
                    'user_id' => $value->user_id,
                    'voucher_id' => $userVouchers->id,
                    'company_id' => $userVouchers->company_id,
                    'campaign_id' => 177,
                    "created_at" => date('Y-m-d 00:00:00 a', strtotime($date))
                ];;


                VoucherUser::insert($dataInsert);

            }
            return ['status' =>'true','count' => $count];
        }catch (QueryException $e){
            if ($e->errorInfo[1]) {

                return $this->issueBirthDayVoucher();
            } else {
                return ['status' => false, 'message' => $e->getMessage()];
            }
        }
        

    }//----- End of issueBirthDayVoucher() ----//

    public function deleteBirthDayVoucher()
    {
        if(!request()->has('type')) {
            $vouchers = VoucherUser::where('voucher_id', 8)->where('campaign_id', 177)->count();
            VoucherUser::where('voucher_id', 8)->where('campaign_id', 177)->forceDelete();
            return ['status' => true, 'count' => $vouchers];
        }else{
            $vouchers = VoucherUser::where('voucher_id', 8)->where('campaign_id', 177)->whereDate('created_at','>','2021-02-02')->forceDelete();
            return ['status' => true, 'count' => $vouchers];
        }
    }


    public function checkCSV()
    {
        dd($this->get_csv_file(public_path('uploads/petstock_prod_pos_customer_20_nz.csv'), 0, 20));
    }




}