<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\API\ElasticSearchController;
use App\Models\Campaign;
use App\Models\Games;
use App\Models\GameUserEntry;
use App\Models\Groups;
use App\Models\Lt_Transaction;
use App\Models\Mission;
use App\Models\MissionUserEntry;
use App\Models\PunchCard;
use App\Models\Role;
use App\Models\Setting;
use App\Models\StoreConfig;
use App\Models\UserAddresses;
use App\Models\UserCustomField;
use App\Models\UserCustomFieldData;
use App\Models\UserLoyaltyPoints;
use App\Models\UserNotification;
use App\Models\UserPets;
use App\Models\UserReceipts;
use App\Models\UserStamp;
use App\Models\UserStore;
use App\Models\UserVenueRelation;
use App\Models\Voucher;
use App\Models\VoucherLog;
use App\Models\VoucherUser;
use App\User;
use App\Utility\ElasticsearchUtility;
use App\Utility\Gamification;
use App\Utility\VCTrigger;
use Carbon\Carbon;

use GuzzleHttp\Exception\ClientException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use DB;
use Illuminate\Support\Facades\Config;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use mysql_xdevapi\Exception;
use Session;
use File;
use Image;
use function foo\func;
use App\Http\Controllers\API\VenueController;

class UsersController extends Controller
{
    public $autoNumber = 999999;
    public $upc = '';

    public $allow_duplicate = false;
    public $max_scan = 0;

    public function __construct()
    {
        set_time_limit(0);
        ini_set('memory_limit', '-1');

        $setting = Setting::where('type', 'duplicate_scan')->first();
        if ($setting) {
            if ($setting->field1 == 1) {
                $this->allow_duplicate = true;
            } else {
                $this->allow_duplicate = false;
            }
        } else {
            $this->allow_duplicate = false;
        }


        $scan_setting = Setting::where('type', 'max_scans')->first();
        if ($scan_setting) {
            $this->max_scan = $scan_setting->field1;
        } else {
            $this->max_scan = 0;
        }


    }

    public function deleteCustomerPos()
    {
        Log::channel('custom')->info('deleteCustomerPos', ['deleteCustomerPos' => \request()->all(), 'headers' => \request()->headers]);
        if (request()->header('app-key') and (request()->header('app-key') === \config('constant.POS_API_KEY'))) {
            $user = User::where('soldi_id', \request()->user_id)->first();
            if ($user) {
                $requestParam = new \Illuminate\Http\Request();
                $requestParam->setMethod('POST');
                request()->merge([
                    'delete_ids' => [$user->user_id],
                    'from_soldi' => true,
                ]);
                return $this->deleteMember();

            } else {
                return ['status' => false, 'message' => "user with this id not found"];
            }
        } else {
            return ['status' => false, 'message' => "You can't perform this action"];
        }
    }

    public function deleteMember()
    {

        try {
            $delete_ids = [];
            if (\request()->has('delete_ids') and !empty(\request()->delete_ids)) {
                $delete_ids = request()->delete_ids;
            } else {
                $user = \request()->user();
                $delete_ids = [$user->user_id];
            }


            /**
             *  Delete User From Soldi
             */
            $this->deleteCustomerFromSoldi($delete_ids);

            if (\config('constant.BOOKING_ENGINE_URL') and \config('constant.BOOKING_ENGINE_KEY')) {
                $this->deleteCustomerFromBooking();
            }
            User::whereIn('user_id', $delete_ids)->update(['is_active' => 0]);
            User::whereIn('user_id', $delete_ids)->delete();
            if (Schema::hasTable('user_pets')) {
                UserPets::whereIn('user_id', $delete_ids)->delete();
            }
            MissionUserEntry::whereIn('user_id', $delete_ids)->forceDelete();
            UserVenueRelation::whereIn('user_id', $delete_ids)->forceDelete();
            UserStore::whereIn('user_id', $delete_ids)->forceDelete();
            VoucherUser::whereIn('user_id', $delete_ids)->forceDelete();
            VoucherLog::whereIn('user_id', $delete_ids)->forceDelete();
            UserStamp::whereIn('user_id', $delete_ids)->forceDelete();
            UserLoyaltyPoints::whereIn('user_id', $delete_ids)->forceDelete();
            GameUserEntry::whereIn('user_id', $delete_ids)->forceDelete();
            Lt_Transaction::whereIn('user_id', $delete_ids)->forceDelete();
            UserAddresses::whereIn('user_id', $delete_ids)->forceDelete();

            /**
             *  Delete User From ES
             */
            $status = ElasticsearchUtility::deleteByQuery(ElasticsearchUtility::generateIndexName(request()->company_id, request()->venue_id), '', '',
                ['terms' => ['persona_id' => $delete_ids]]
            );
            return ['status' => true, 'message' => (\request()->has('delete_ids')) ? 'Member Deleted' : 'Your account is deleted successfully'];
        } catch (\Exception $e) {
            Log::channel('custom')->info('deleteMember()_error', ['deleteMember()_error' => $e->getMessage()]);
            return ['status' => false, 'message' => 'Member not Deleted'];

        }


    }


    public function deleteUsersCrone()
    {
        $users = User::where('is_active', 0)->get();
        foreach ($users as $user) {

            $user_creation_date = Carbon::parse($user->created_at);

            $diff = $user_creation_date->diffInDays(Carbon::now());
            if ($diff >= 30) {
                ElasticsearchUtility::deleteByQuery(ElasticsearchUtility::generateIndexName($user->company_id, $user->default_venue), 'persona_id', $user->user_id, '');
                $user->delete();
            }
        }
    }

    public function usercreate(Request $request)
    {
        $KNOX_URL = config('constant.Knox_Url');
        $client = new Client();
        $company_id = $request->company_id;
        $parm = array(
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'company' => $company_id,//$company_id,
            'email' => $request->email,
            'contact_number' => "123456" . rand(111, 999),//$request->contact_number,
            'group_id' => '2',
            'password' => 12345678,//$request->password,
            'user_level' => $request->user_level,
            'venue_name' => 'Plutus'
        );

        try {
            $response = $client->request('POST', $KNOX_URL . 'apis/user_with_level', [
                'json' => $parm
            ]);
            $users_res = $response->getBody()->getContents();
            $data = json_decode($users_res);
            $user_id = $data->users;
            if ($request->user_role_id != '') {
                $id = DB::table('role_level_users')->insertGetId(['user_id' => $user_id, 'level_id' => $request->user_level, 'role_id' => $request->user_role_id, "created_at" => date("Y-m-d H:i:s"), "updated_at" => date("Y-m-d H:i:s")]);
            }

            if (isset($data->Status)) {
                $arr['message'] = 'success';
                $arr['user_id'] = $user_id;
                return json_encode($arr);
            } else {
                $arr['message'] = 'already_exist';
                $arr['user_id'] = '0';
                return json_encode($arr);
            }
        } catch (RequestException $e) {
            $arr['message'] = 'falier';
            $arr['user_id'] = '0';
            return json_encode($arr);
        }
    }


    public function getRole(Request $request)
    {
        $company_id = $request->company_id;
        $level_id = $request->level_id;
        $role_level = \Illuminate\Support\Facades\DB::table("role_assigns")->where('level_id', $level_id)->get();
        $roleArray = [];
        $level = '';
        foreach ($role_level as $row) {
            $role_id = $row->role_id;
            $roles = Role::where('id', $role_id)->where('company_id', $company_id)->first();
            if ($roles) {
                $roleArray[] = $roles;
            }
        }
        return $roleArray;
        /*$data['role_arr'] = $roleArray;
        return view('layouts/dashboard_master/users/ajax_roles', $data);*/
    }

    /**
     * @param $id
     * @return array|string
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    private function deleteCustomerFromSoldi($delete_ids)
    {
        if (count($delete_ids) > 0) {
            try {
                //get soldi ids
                $soldi_ids = User::whereIn('user_id', $delete_ids)->whereNotNull('soldi_id')->pluck('soldi_id')->toArray();
               $businessDetail = (new UserApiController())->getVenuesInformation();
                $response = (new Client([
                    'headers' => [
                        'Content-Type' => 'application/x-www-form-urlencoded',
                        'X-API-KEY' => $businessDetail['data']['api_key'],
                        'SECRET' => $businessDetail['data']['secret_key']
                    ]
                ]))->request('DELETE', config('constant.SOLDI_DEFAULT_PATH') . '/customer/delete_bulk', array(
                        'form_params' => array(
                            'customer_id' => implode(',', $soldi_ids),
                        )
                    )
                )->getBody();
                Log::channel('custom')->info('User Delete From Soldi', ['ResponseData' => $response]);
                return $response;
            } catch (\Exception $e) {
                Log::channel('custom')->info('Error Occured', ['ErrorINDELETE' => $e->getMessage()]);
                return ['status' => false];
            }
        } else {
            return ['status' => false];
        }
    }//------- End of deleteCustomerFromSoldi() ------//

    public function emailTrackEvents()
    {
        try {
            //get soldi ids
            Log::channel('custom')->info('emailTrackEvents()', ['emailTrackEvents()' => \request()->all()]);
            $request_data = \request()->all();
            foreach ($request_data as $request_datum) {
                //Log::channel('custom')->info('$request_datum', ['$request_datum' => $request_datum['user_id']]);
                $user = User::whereEmail($request_datum['email'])->first();
                DB::table('notification_events')->insert([
                    'user_id' => ($user) ? $user->user_id : '',
                    'campaign_id' => $request_datum['campaign_id'] ?? '',
                    'company_id' => $request_datum['company_id'] ?? '',
                    'event' => $request_datum['event'],
                    'email' => $request_datum['email'],
                    'event_type' => 'email',
                    'sg_event_id' => $request_datum['sg_event_id'],
                    'sg_message_id' => $request_datum['sg_message_id'],
                    'timestamp' => strtotime(date('Y-m-d'))
                ]);
            }

            return ['status' => true];

            /*return (new Client())->request('POST', config('constant.JAVA_URL') . 'emailTrackingEvents', [
                'headers' => [
                ],
                'json' => request()->all()
            ]);*/

        } catch (\Exception $e) {
            Log::channel('custom')->info('emailTrackEvents()_error', ['emailTrackEvents()_error' => $e->getMessage()]);
            return ['status' => false];
        }

    }

    public function getAllCampaignData()
    {
        $index = config('constant.ES_INDEX_BASENAME');
        $campaigns = Campaign::where(['action_type' => 'reward'])->get();
        foreach ($campaigns as $key => $value) {

            $query = [
                "query" => [
                    "bool" => [
                        "must" => [
                            [
                                "term" => [
                                    "custom_doc_type" => [
                                        "value" => "user_integrated_voucher"
                                    ]
                                ]
                            ],
                            [
                                "term" => [
                                    "campaign_id" => [
                                        "value" => $value['id']
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ];

            $response = (new ElasticsearchUtility())->getAllData($query, $index);

            if (count($response) > 0) {


                $vocuher_avail_data =
                    isset($response['hits']['hits'][0]['_source']['voucher_avial_data']) ?
                        $response['hits']['hits'][0]['_source']['voucher_avial_data']
                        :
                        [];
                $recieveResponse = $this->voucherDataInsert($response, $value, $vocuher_avail_data);

                $campaigns[$key]['action_value'] = json_encode($recieveResponse);
                $campaigns[$key]->save();


            }
        }
        return ['status' => true, 'message' => 'Successfully added'];
    }

    private function voucherDataInsert($response, $value, $vocuher_avail_data)
    {

        $actionValue = $resource = json_decode($value['action_value'], true);


        if ($actionValue[0]['value']['type'] == 'integrated-voucher') {


            $actionValue = $actionValue[0]['value']['other']['content'];
            $startDate = '';
            $endDate = '';
            if (isset($actionValue['isNumberOfDays'])) {
                $startDate = date('Y-m-d H:i:00', strtotime('-1 days'));
                $endDate = date('Y-m-d H:i:00', strtotime('+' . $actionValue['isNumberOfDays'] . ' days'));
            } else {
                $startDate = date('Y-m-d H:i:00', strtotime($actionValue['voucher_start_date']));
                $endDate = date('Y-m-d H:i:00', strtotime($actionValue['voucher_end_date']));
            }

            $data = [
                'business' => json_encode($actionValue['business']),
                'name' => $actionValue['voucher_name'] ?? $actionValue['promotion_text'],
                'promotion_text' => $actionValue['promotion_text'],
                'discount_type' => $actionValue['discount_type'],
                'amount' => $actionValue['discount'],
                'no_of_uses' => $actionValue['no_of_uses'],
                'isNumberOfDays' => $actionValue['isNumberOfDays'] ?? '',
                'category' => 'Normal Voucher',
                'company_id' => $value['company_id'],
                'start_date' => $startDate,
                'end_date' => $endDate,
                'voucher_avial_data' => json_encode($actionValue['voucher_avial_data'] ?? $vocuher_avail_data),
                'image' => $resource[0]['value']['resource'],
                'tree_structure' => json_encode(['selectedKeys' => $actionValue['checkedKeys'] ?? [], 'treeSelected' => $actionValue['treeData'] ?? [],
                    'expended' => $actionValue['expanded'] ?? []
                ]),
            ];
            $groupid = 1;
            if (isset($resource[0]['value']['other']['content']['voucher_name']) and $resource[0]['value']['other']['content']['voucher_name'] == 'Student Voucher') {
                $groupData = Groups::where('group_name', 'Student')->first();
                $groupid = $groupData->group_id;

            } else if (isset($resource[0]['value']['other']['content']['voucher_name']) and $resource[0]['value']['other']['content']['voucher_name'] == 'Staff Voucher') {
                $groupData = Groups::where('group_name', 'Staff')->first();
                $groupid = $groupData->group_id;

            }
            $voucherid = Voucher::create($data);
            $resource[0]['value']['type'] = 'voucher';
            $resource[0]['value']['other']['content'] = ["showDate" => false, "voucher_id" => $voucherid->id];
            $this->insertUserData(0, $response, $voucherid->id, $value['company_id'], $groupid, $voucherid->name);

            unset($resource[0]['value']['other']['content']['selectedData']);
            unset($resource[0]['value']['other']['content']['pos_ibs']);
            unset($resource[0]['value']['other']['content']['basket_level']);
            unset($resource[0]['value']['other']['content']['voucher_name']);
            unset($resource[0]['value']['other']['content']['business']);
            unset($resource[0]['value']['other']['content']['treeData']);
            unset($resource[0]['value']['other']['content']['voucher_avial_data']);
            unset($resource[0]['value']['other']['content']['checkedKeys']);
            unset($resource[0]['value']['other']['content']['expanded']);
            unset($resource[0]['value']['other']['content']['voucher_avail_type']);
            unset($resource[0]['value']['other']['content']['discount_type']);
            unset($resource[0]['value']['other']['content']['discount']);
            unset($resource[0]['value']['other']['content']['discount']);
            unset($resource[0]['value']['other']['content']['type']);
            unset($resource[0]['value']['other']['content']['voucher_start_date']);
            unset($resource[0]['value']['other']['content']['voucher_valid']);
            unset($resource[0]['value']['other']['content']['voucher_end_date']);

            return $resource;
        }
    }

    private function voucherDataInsertGame(array $response, $value)
    {
        $company_id = $value['company_id'];
        $actionValue = json_decode($value['action_value'], true);


        foreach ($actionValue as $key => $value) {

            foreach ($value['missions'] as $missionKey => $missionValue) {
                if ($missionValue['outcomes'][0]['action_value'][0]['value']['type'] == 'integrated-voucher') {
                    $newValue = $actionValue[$key]['missions'][$missionKey]['outcomes'][0]['action_value'][0]['value'];
                    if (isset($newValue['other']['content']['isNumberOfDays'])) {
                        $startDate = date('Y-m-d H:i', strtotime('-1 days'));
                        $endDate = date('Y-m-d H:i', strtotime('+' . $newValue['other']['content']['isNumberOfDays'] . ' days'));
                    } else {

                        $startDate = date('Y-m-d H:i', strtotime($newValue['other']['content']['voucher_start_date']));
                        $endDate = date('Y-m-d H:i', strtotime($newValue['other']['content']['voucher_end_date']));

                    }

                    $groupid = 1;
                    if ($newValue['other']['content']['voucher_name'] == 'Student Voucher') {
                        $groupData = Groups::where('group_name', 'Student')->first();
                        $groupid = $groupData->group_id;

                    } else if ($newValue['other']['content']['voucher_name'] == 'Staff Voucher') {
                        $groupData = Groups::where('group_name', 'Staff')->first();
                        $groupid = $groupData->group_id;

                    }
                    $data = [
                        'business' => json_encode($newValue['other']['content']['business']),
                        'name' => $newValue['other']['content']['voucher_name'],
                        'promotion_text' => $newValue['other']['content']['promotion_text'],
                        'discount_type' => $newValue['other']['content']['discount_type'],
                        'amount' => $newValue['other']['content']['discount'],
                        'no_of_uses' => $newValue['other']['content']['no_of_uses'],
                        'isNumberOfDays' => $newValue['other']['content']['isNumberOfDays'] ?? 0,
                        'basket_level' => ($newValue['other']['content']['basket_level']) ? 1 : 0,
                        'pos_ibs' => $newValue['other']['content']['pos_ibs'],
                        'category' => 'Normal Voucher',
                        'start_date' => $startDate,
                        'end_date' => $endDate,
                        'group_id' => $groupid,
                        'company_id' => $company_id,
                        'voucher_avial_data' => json_encode($newValue['other']['content']['voucher_avial_data']),
                        'image' => $newValue['resource'],
                        'tree_structure' => json_encode(['selectedKeys' => $newValue['other']['content']['checkedKeys'], 'treeSelected' => $newValue['other']['content']['treeData'],
                            'expended' => $newValue['other']['content']['expanded'] ?? []
                        ]),
                    ];

                    $voucherid = Voucher::create($data);
                    $this->insertUserData(0, $response, $voucherid->id, $company_id, $groupid, $newValue['other']['content']['voucher_name']);
                    unset($newValue['other']['content']['selectedData']);
                    unset($newValue['other']['content']['pos_ibs']);
                    unset($newValue['other']['content']['basket_level']);
                    unset($newValue['other']['content']['voucher_name']);
                    unset($newValue['other']['content']['business']);
                    unset($newValue['other']['content']['treeData']);
                    unset($newValue['other']['content']['voucher_avial_data']);
                    unset($newValue['other']['content']['checkedKeys']);
                    unset($newValue['other']['content']['expanded']);
                    unset($newValue['other']['content']['voucher_avail_type']);
                    unset($newValue['other']['content']['discount_type']);
                    unset($newValue['other']['content']['discount']);
                    unset($newValue['other']['content']['discount']);
                    unset($newValue['other']['content']['type']);
                    unset($newValue['other']['content']['voucher_start_date']);
                    unset($newValue['other']['content']['voucher_valid']);
                    unset($newValue['other']['content']['voucher_end_date']);
                    $newValue['other']['content'] = [];


                    $actionValue[$key]['missions'][$missionKey]['outcomes'][0]['action_value'][0]['value']['type'] = 'voucher';
                    $actionValue[$key]['missions'][$missionKey]['outcomes'][0]['action_value'][0]['value']['other']['content'] = ["showDate" => false, "voucher_id" => $voucherid->id];


                    Mission::where('id', $missionValue['id'])->update([
                        'outcomes' => json_encode($actionValue[$key]['missions'][$missionKey]['outcomes'])
                    ]);

                }
            }

        }
        return $actionValue;
    }

    public function importGamificationData()
    {
        $index = config('constant.ES_INDEX_BASENAME');
        $campaigns = Campaign::where(['type' => '4'])->get();
        foreach ($campaigns as $key => $value) {

            $query = [
                "query" => [
                    "bool" => [
                        "must" => [
                            [
                                "term" => [
                                    "custom_doc_type" => [
                                        "value" => "user_integrated_voucher"
                                    ]
                                ]
                            ],
                            [
                                "term" => [
                                    "campaign_id" => [
                                        "value" => $value['id']
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ];

            $response = (new ElasticsearchUtility())->getAllData($query, $index);

            if (count($response) > 0) {

                $recieveResponse = $this->voucherDataInsertGame($response, $value);

                $campaigns[$key]['action_value'] = json_encode($recieveResponse);
                $campaigns[$key]->save();


            }
        }
        return ['status' => true, 'message' => 'Successfully added'];

    }

    public function insertUserData($count = 0, $response, $voucherid, $companyid, $groupid, $voucherName)
    {
        $userException = [];
        $len = count($response);
        $userResponseData = $response;
        try {

            foreach ($userResponseData as $key => $userdata) {
                $voucherCode = (new Gamification())->getIBSCode($userdata['pos_ibs'] ?? 0);
                if ($userdata['voucher_name'] == $voucherName) {
                    Log::channel('custom')->info('user', ['user' => $userdata['user_id'], 'voucher_name' => $userdata['voucher_name']]);
                    $user = VoucherUser::updateOrCreate(['campaign_id' => $userdata['campaign_id'], 'user_id' => $userdata['user_id'], 'voucher_id' => $voucherid], [
                        'campaign_id' => $userdata['campaign_id'],
                        'user_id' => $userdata['user_id'],
                        'company_id' => $companyid,
                        'voucher_code' => $voucherCode,
                        'voucher_start_date' => date('Y-m-d h:i:s', strtotime($userdata['voucher_start_date'])),
                        'voucher_end_date' => date('Y-m-d h:i:s', strtotime($userdata['voucher_end_date'])),
                        'created_at' => date('Y-m-d h:i:s', $userdata['dateadded']),
                        'updated_at' => date('Y-m-d h:i:s', $userdata['dateadded']),
                        'voucher_id' => $voucherid,
                        'uses_remaining' => $userdata['uses_remaining'],
                        'no_of_uses' => $userdata['no_of_uses'],
                        'group_id' => $groupid
                    ]);
                    if ($user) {
                        unset($userResponseData[$key]);
                    }

                }


            }
            return true;
        } catch (\Exception $e) {
            Log::channel('custom')->info('user', ['insertUserData_error' => $e->getMessage(), 'user' => $userdata['user_id'], 'voucher_name' => $userdata['voucher_name']]);
            return $this->insertUserData($count, $userResponseData, $voucherid, $companyid, $groupid, $voucherName);
        }
    }


    public function importPunchCard()
    {
        $punch = PunchCard::get();
        $index = config('constant.ES_INDEX_BASENAME');
        foreach ($punch as $key => $value) {

            $query = [
                "query" => [
                    "bool" => [
                        "must" => [
                            [
                                "term" => [
                                    "custom_doc_type" => [
                                        "value" => "user_integrated_voucher"
                                    ]
                                ]
                            ],
                            [
                                "term" => [
                                    "from_punch_card" => [
                                        "value" => $value['id']
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ];

            $response = (new ElasticsearchUtility())->getAllData($query, $index);
            if (count($response) > 0) {
                $actionValue = $this->insertPunchCardData($response, $value);
                $punch[$key]['voucher_id'] = $actionValue;
                $punch[$key]->save();
            }

        }
        return ['status' => true, 'message' => 'successfully inserted data'];
    }

    private function insertPunchCardData(array $response, $value)
    {

        $treeData = json_decode($value['tree_structure']);
        $punchCardDat = json_decode($value['punch_card_data'], true);


        $business = ["business_id" => $value['business_id'], "business_name" => $value['business_name'],
            "business_image" => json_decode($value['business_images'])
        ];

        $data = [
            'business' => json_encode($business),
            'name' => $value['name'],
            'promotion_text' => $value['description'],
            'discount_type' => $value['discount_type'],
            'amount' => $value['voucher_amount'] ?? 0,
            'no_of_uses' => 1,
            'isNumberOfDays' => 0,
            'basket_level' => $value['basket_level'],
            'pos_ibs' => $value['pos_ibs'],
            'category' => 'Normal Voucher',
            'start_date' => date('Y-m-d h:i:s', strtotime($response[0]['voucher_start_date'])),
            'end_date' => date('Y-m-d h:i:s', strtotime($response[0]['voucher_end_date'])),
            'group_id' => 1,
            'company_id' => $value['company_id'],
            'voucher_avial_data' => json_encode($punchCardDat),
            'image' => $value['image'],
            'tree_structure' => json_encode(['selectedKeys' => $treeData->selectedKeys ?? [],
                'treeSelected' => $treeData->treeSelected ?? [],
                'expended' => $treeData->expended ?? []
            ]),
        ];
        $voucherID = Voucher::create($data);

        $this->insertPunchUserData($count = 0, $response, $voucherID->id, $value['id'], 1, $value['company_id']);
        return $voucherID->id;
    }

    public function insertPunchUserData($count = 0, $response, $voucherid, $punchid, $groupid, $company_id)
    {
        $userException = [];

        try {

            foreach ($response as $key => $userdata) {
                $userException = $userdata;
                $index = $key;
                $count++;

                $user = VoucherUser::create([
                    'campaign_id' => $userdata['campaign_id'],
                    'user_id' => $userdata['user_id'],
                    'company_id' => $company_id,
                    'voucher_code' => $userdata['pos_ibs'] . $this->getRandomSix(),
                    'punch_id' => $punchid,
                    'voucher_start_date' => date('Y-m-d h:i:s', strtotime($userdata['voucher_start_date'])),
                    'voucher_end_date' => date('Y-m-d h:i:s', strtotime($userdata['voucher_end_date'])),
                    'created_at' => date('Y-m-d h:i:s', $userdata['dateadded']),
                    'updated_at' => date('Y-m-d h:i:s', $userdata['dateadded']),
                    'voucher_id' => $voucherid,
                    'uses_remaining' => $userdata['uses_remaining'],
                    'no_of_uses' => 1,
                    'group_id' => $groupid
                ]);
                if ($user)
                    unset($response[$key]);


            }
            return true;
        } catch (\Exception $e) {
            $voucherCode = $userException['pos_ibs'] . $this->getRandomSix();
            $userVoucher = VoucherUser::where('voucher_code', $voucherCode)->first();
            if ($userVoucher) {
                $voucherCode = $userException['pos_ibs'] . $this->getRandomSix();
            } else {

                $user = VoucherUser::create([
                    'punch_id' => $punchid,
                    'user_id' => $userException['user_id'],
                    'company_id' => $company_id,
                    'voucher_code' => $voucherCode,
                    'voucher_start_date' => date('Y-m-d h:i:s', strtotime($userException['voucher_start_date'])),
                    'voucher_end_date' => date('Y-m-d h:i:s', strtotime($userException['voucher_end_date'])),
                    'created_at' => date('Y-m-d h:i:s', $userException['dateadded']),
                    'updated_at' => date('Y-m-d h:i:s', $userException['dateadded']),
                    'voucher_id' => $voucherid,
                    'uses_remaining' => $userException['uses_remaining'],
                    'no_of_uses' => $userException['no_of_uses'],
                    'group_id' => $groupid
                ]);
                if ($user) ;
                {
                    unset($response[$index]);
                }

                $count++;
                return $this->insertPunchUserData($count, $response, $voucherid, $punchid, $groupid, $company_id);
            }
        }
    }

    public function getRandomSix()
    {
        return $this->autoNumber = ($this->autoNumber + 1);
    }

    public function thirdPartyUserIntegration(Request $request)
    {
        try {

            if ($request->header('secret') == config('constant.UDB_AUTH_KEY')) {
                if ($request->has('limit') and $request->limit > 0) {
                    $limit = $request->limit;
                } else {
                    $limit = 100;
                }
                $gigya_custom_field = UserCustomField::where('field_name', 'gigya_integrated')->first();
                if ($gigya_custom_field) {
                    $gigya_user_ids = UserCustomFieldData::where('custom_field_id', $gigya_custom_field->id)
                        ->pluck('user_id');
                    $users = User::whereNotIn('user_id', $gigya_user_ids)->where(['user_type' => 'app', 'is_active' => 1])->take($limit)->get([
                        'user_id',
                        'user_first_name',
                        'user_family_name',
                        'email',
                        'user_mobile',
                        'dob',
                        'address',
                        'city',
                        'postal_code',
                        'user_lat',
                        'user_long',
                        'gender',
                        'created_at',
                    ]);
                    $user_arr = [];
                    foreach ($users as $user) {
                        $gender = $user->gender;
                        if ($gender == 'Other' or $gender == "O")
                            $gender = 'O';
                        else if ($gender == 'Male' or $gender == 'M')
                            $gender = 'M';
                        else if ($gender == 'Female' or $gender == 'F')
                            $gender = 'M';
                        else
                            $gender = 'U';

                        $user_mobile = $user->user_mobile;
                        $user_mobile = ltrim($user_mobile, '0');
                        $temp = [
                            'user_first_name' => empty($user->user_first_name) ? "" : $user->user_first_name,
                            'user_family_name' => empty($user->user_family_name) ? "" : $user->user_family_name,
                            'email' => empty($user->email) ? "" : $user->email,
                            'user_mobile' => (empty($user->user_mobile) or $user_mobile == "") ? "" : '+' . $user_mobile,
                            'dob' => empty($user->dob) ? "" : $user->dob,
                            'address' => empty($user->address) ? "" : $user->address,
                            'city' => empty($user->city) ? "" : $user->city,
                            'postal_code' => empty($user->postal_code) ? "" : $user->postal_code,
                            'user_lat' => empty($user->user_lat) ? 0 : $user->user_lat,
                            'user_long' => empty($user->user_long) ? 0 : $user->user_long,
                            'gender' => $gender,
                            'registration_date' => date("Y-m-d\TH:i:s.000\Z", strtotime($user->created_at)),
                            'sms_opt' => $this->getUserNotificationStatus($user, 'sms'),
                            'email_opt' => $this->getUserNotificationStatus($user, 'email'),
                            'push_opt' => $this->getUserNotificationStatus($user, 'push'),

                        ];
                        $user_arr[] = $temp;

                        if ($request->status_update == 1) {
                            //save custom field data against user
                            $this->insertUserToCustomField($user, $gigya_custom_field->id);
                        }

                    }
                    if ($request->status_update == 1) {
                        //save custom field data against user in ES
                        (new ElasticsearchUtility())->bulkUserDataInsertNew($users);
                    }

                    return ['status' => 200, 'message' => '', 'data' => $user_arr];
                } else {
                    Log::channel('custom')->info('custom field not found', ['custom field not found' => 'custom field not found']);
                    return ['status' => 200, 'message' => '', 'data' => []];
                }
            } else {
                return ['status' => 401, 'message' => 'You are not authorize to perform this request', 'data' => []];
            }
        } catch (\Exception $e) {
            Log::channel('custom')->info('thirdPartyUserIntegration_error', ['thirdPartyUserIntegration_error' => $e->getMessage(), 'line' => $e->getLine()]);
            return ['status' => 500, 'message' => $e->getMessage(), 'data' => []];
        }
    }

    public function insertUserToCustomField($user, $custom_field_id)
    {
        UserCustomFieldData::updateOrCreate(
            ["user_id" => $user->user_id, "custom_field_id" => $custom_field_id],
            ["user_id" => $user->user_id,
                "custom_field_id" => $custom_field_id,
                "value" => 1,
                "multiselect_value" => ""
            ]);
    }

    public function getUserNotificationStatus($user, $channel)
    {
        $user_notifi = UserNotification::where(['user_id' => $user->user_id, 'channel' => $channel])->first();
        if ($user_notifi)
            $status = $user_notifi->subscribed ? TRUE : FALSE;
        else
            $status = TRUE;

        return $status;
    }

    /**
     * @return array
     */
    public function getAllPoints()
    {
        $user = User::select('user_id as id', 'user_first_name', 'user_family_name', 'soldi_id', 'email', 'user_mobile')->whereNotNull('soldi_id')/*->where('soldi_id','!=','0')*/
        ;


        if (request()->has('search') and !empty(\request()->search)) {
            $user->where('user_first_name', 'like', '%' . trim(request()->search) . '%')
                ->orWhere('user_family_name', 'like', '%' . trim(request()->search) . '%')->orWhere('email', 'like', '%' . trim(request()->search) . '%');
        }
        $userCount = $user->count();
        $user = $user->skip(request()->offSet)->take(request()->pageSize)->get();
        foreach ($user as $value) {
            $allUserPoints = $this->getUserPoints($value->id);
            $expiredPioints = $this->getExpiredPoints($value->id);
            $notExpired = $this->getNotExpiredPoints($value->id);
            $totalPoints = 0;
            $creditAmount = 0;
            $debitAmount = 0;
            if ($allUserPoints) {
                $creditAmount = $allUserPoints[0]->points_total ?? 0;
                $debitAmount = $allUserPoints[1]->points_total ?? 0;
                $totalPoints = $creditAmount - $debitAmount;
            }
            if ($notExpired > 0) {
                $totalPoints = $totalPoints + $notExpired;
            }

            $value->points = $totalPoints;
            $value->credit = $creditAmount;
            $value->debit = $debitAmount;
            $value->expiredPoints = $expiredPioints;
            $value->active = false;
            $value->allTransactions = Lt_Transaction::where('user_id', $value->id)->orderBy('created_at', 'DESC')->get();
        }
        return ['status' => true, "data" => $user, 'countData' => $userCount];
    }//----- End of getAllPoints() -----//

    public function getUserPoints($soldi_id)
    {
        return Lt_Transaction::selectRaw('SUM(lt_transations.value_points) AS points_total,type')
            ->where('user_id', $soldi_id)
            ->whereNull('expiry_date')
            ->groupBy('type')
            ->get();
    }

    /**
     * @return array
     */
    public function addUserPoints()
    {
        $user = DB::table('users')->where('user_id', request()->userID)->first();
        $expiry = $this->assignPointWithCheckExpiry();

        $insertData = [
            'soldi_id' => $user->soldi_id,
            'company_id' => Config::get('constant.company_id'),
            'venue_id' => 1223,
            'order_amount' => 0,
            'lt_rule_id' => 1,
            'status' => 1,
            'customer_id' => $user->soldi_id,
            'rule_for' => 'optional',
            'source' => 'manual',
            'type' => (request()->addStamps) ? 'credit' : 'debit',
            'point_id' => 1,
            'value_points' => request()->pointassign,
            'created_at' => time(),
            'updated_at' => time(),
            'wi_code' => 0,
            'user_id' => $user->user_id
        ];
        if (!empty($expiry['expiry']) and request()->addStamps) {
            $insertData['expiry_date'] = $expiry['expiry'];
        }
        DB::table('lt_transations')->insert(
            $insertData
        );

        //call event trigger
        $data = [
            'user_id' => $user->user_id,
            'points' => (int)request()->pointassign,
            'trigger_type' => 'points'
        ];
        $trigger_type = "$.points_trigger";
        (new VCTrigger())->callVCTrigger($data, $trigger_type);

        return ['status' => true, 'message' => 'Points updated successfully'];
    }//----- End of addUserPoints() -----//

    public function recieptCallback()
    {
        try {
            $http = new \GuzzleHttp\Client();
            $data = request()->data;


            //Log::channel('custom')->info('recieptCallback', ['recieptCallback' => \request()->all()]);
            $count = 0;


            if (\request()->has('data')) {

                $userId = explode('-', $data['reference']);
                $user = User::where('user_id', $userId[1])->first();
                if (!$user) {
                    return ['status' => false, 'messsage' => 'User Not exists'];
                }
                $userData = UserReceipts::where('reference_no', $data['reference'])->first();
                if ($userData) {
                    $userData->detail = json_encode($data);
                    $userData->save();
                }

                $brandName = '';
                $pointsEarn = 0;
                $stamp = 0;
                if (!$data['rows']) {
                    return ['status' => false];
                }
                $totalAmount = 0;
                if (isset($data['top']['total'])) {
                    $totalAmount = $data['top']['total'];
                }
                $allBrand = $data['rows'];
                $allBrand = collect($allBrand);
                $onlyBrands = $allBrand->pluck('brand')->toArray();
                $productId = $allBrand->pluck('alias_id')->toArray();

                $onlyUnilever = $allBrand->where('is_unilever', 1)->sum('quantity');
                foreach ($data['rows'] as $value) {
                    if ($value['requires_observation'])
                        $count = $count + 1;

                    $brandCount = $allBrand->where('brand', $value['brand'])->sum('quantity');
                    $productCount = $allBrand->where('alias_id', $value['alias_id'])->sum('quantity');

                    $responseData = (new GamificationController())->rewardOnScanReciept($userId[1], ucfirst($value['brand']), ($value['is_unilever'] == 1) ? true : false, $onlyBrands, $onlyUnilever, $brandCount, $value['alias_id'], $productCount, $data['reference'], $productId, $totalAmount);
                    $getData = (new GamificationController())->completedMissionForUser($userId[1], $totalAmount);

                    if (count($getData) > 0) {
                        foreach ($getData as $value) {
                            if (isset($value['points'])) {
                                $pointsEarn = ($pointsEarn + $value['points']);
                            } elseif (isset($value['stamps'])) {
                                $stamp = ($stamp + $value['stamps']);
                            }
                        }
                    }
                    Log::channel('custom')->info('recieve', ['recieve' => $responseData]);
                    if (count($responseData) > 0) {
                        foreach ($responseData as $value) {
                            if (isset($value['points'])) {
                                $pointsEarn = ($pointsEarn + $value['points']);
                            } elseif (isset($value['stamps'])) {
                                $stamp = ($stamp + $value['stamps']);
                            }
                        }
                    }
                }
                if ($user) {
                    Log::channel('custom')->info('totalearnedPoints', ['totalearnedPoints' => $pointsEarn, 'totalStamp' => $stamp]);
                    // Assign Points
                    /*                    $points = 10;
                                       $this->assignPointsTouser($user->user_id,$points,'debit','Receipt Call Back');*/

                    \request()->merge(['stamp' => $stamp, 'points' => $pointsEarn, 'resolve' => $count]);


                    if ($userData) {
                        $userPoints = ($userData->points) ? $userData->points : 0;

                        $userData->points = ($userPoints + $pointsEarn);
                        $userData->stamp = $stamp;
                        $userData->save();
                    }
                    Log::channel('custom')->info('allRequest', ['allRequest' => request()->all()]);
                    $response = $http->post(config('constant.JAVA_URL') . 'sendTestPushToUser', [
                        'headers' => array(),
                        'json' => [
                            'notification_type' => "push",
                            'petronID' => $userId[1],
                            'message' => 'You have received response of your receipt scan!',
                            'content' => request()->all(),
                        ]
                    ]);
                    $smsResponse = json_decode($response->getBody(), true);
                    //Log::channel('user')->info('recieptCallback', ['recieptCallback()' => \request()->all(), 'Notification' => $smsResponse]);
                    return ['status' => true, 'message' => 'Data recieve Successfully'];
                } else {
                    return ['status' => false, 'message' => 'Refernce id not found'];
                }


            } else {
                return ['status' => false, 'message' => 'Please Provide data'];
            }
        } catch (\Exception $e) {
            Log::channel('custom')->info('recieptCallbackError', ['recieptCallbackError' => $e->getMessage(), 'lineNumber' => $e->getLine(), 'getController' => $e->getFile()]);
            return ['status' => false, 'message' => 'Please Provide data'];
        }
    }

    public function assignPointsTouser($userid, $points, $type, $source, $pointsid, $source_value)
    {
        DB::table('lt_transations')->insert(
            ['company_id' => Config::get('constant.company_id'), 'venue_id' => 1223, 'order_amount' => 0, 'lt_rule_id' => 1, 'status' => 1, 'customer_id' => $userid, 'rule_for' => 'optional', 'source' => $source, 'type' => $type, 'point_id' => $pointsid ?? '', 'value_points' => $points, 'created_at' => time(), 'updated_at' => time(), 'wi_code' => 0, 'user_id' => $userid, 'source_value' => $source_value]
        );
        //call event trigger
        $data = [
            'user_id' => $userid,
            'points' => (int)$points,
            'trigger_type' => 'points'
        ];
        $trigger_type = "$.points_trigger";
        (new VCTrigger())->callVCTrigger($data, $trigger_type);
        return true;
    }

    public function sendTestingPoints()
    {
        $http = new \GuzzleHttp\Client();
        $response = $http->post(config('constant.JAVA_URL') . 'sendTestPushToUser', [
            'headers' => array(),
            'json' => [
                'notification_type' => "point",
                'petronID' => \request()->user_id,
                'message' => 'point',
                'content' => ['receive_points' => 10, 'total_points' => 200],
            ]
        ]);
        $smsResponse = json_decode($response->getBody(), true);
        dd($smsResponse);
    }

    public function addUdbCustomers()
    {
        if (request()->header('secret') == config('constant.UDB_AUTH_KEY')) {
            $userData = request()->data;

            if (count($userData) == 0) {
                return ['status' => false, 'message' => 'Please provide data'];
            }
            $countData = 0;
            foreach ($userData as $data) {
                if (!empty($data['email']) and !empty($data['phone']) and !empty($data['first_name'])) {
                    $user = User::updateOrCreate(['email' => $data['email'], 'user_mobile' => $data['phone']], [
                        'user_first_name' => $data['first_name'],
                        'user_family_name' => $data['last_name'],
                        'user_mobile' => $data['phone'],
                        'email' => $data['email'],
                        'client_customer_id' => $data['accountcode'],
                        'is_active' => 1
                    ]);
                    if ($user) {
                        $userAddress = UserAddresses::where('user_id', $user->user_id)->first();
                        if ($userAddress) {
                            UserAddresses::where('user_id', $user->user_id)->delete();
                        }

                        UserAddresses::create([
                            'address' => $data['address_line1'],
                            'address2' => $data['address_line2'],
                            'suburb' => $data['suburb'],
                            'state' => $data['state'],
                            'country' => $data['country'],
                            'postal_code' => $data['postcode'],
                            'address_type' => 'Residential',
                            'user_id' => $user->user_id,
                            'is_default' => 1,
                        ]);
                        (new ElasticSearchController())->insertUserToES($user->user_id);
                    }
                    $countData = ($countData + 1);
                }
            }
            return ['status' => true, 'message' => 'Customer Data inserted Successfully', 'total_inserted' => $countData, 'not_inserted' => (count($userData) - $countData)];
        } else {
            return ['status' => 401, 'message' => 'You are not authorize to perform this request', 'data' => []];
        }
    }

    public function getUsers(Request $request)
    {

        if (request()->search_from == "es") {
            return $this->esSearch(request()->q);
        }

        $user_ids = [];
        if (request()->q) {
            $search = request()->q;
            if (is_numeric($search)) {
                $user_ids = User::where('client_customer_id', 'like', "%$search%")
                    ->orWhere('user_id', 'like', "%$search%")
                    ->orWhere('user_mobile', 'like', "%$search%")
                    ->pluck('user_id');
            } else {
                $nameSearch = explode(' ', $search);
                if (is_array($nameSearch) && isset($nameSearch[0]) && isset($nameSearch[1]) && count($nameSearch) >= 2) {

                    $user_ids = User::where('user_first_name', 'like', '%' . str_replace('%', '', $nameSearch[0]) . '%')
                        ->where('user_family_name', 'like', '%' . $nameSearch[1] . '%')
                        ->pluck('user_id');

                } else {
                    $user_ids = User::where('user_first_name', 'like', '%' . request()->q . '%')->orWhere('user_family_name', 'like', '%' . request()->q . '%')->orWhere('email', 'like', '%' . request()->q . '%')->pluck('user_id');
                }
            }


        }
        $arr = [];
        $users = User::whereIn('user_id', $user_ids)->take(10)->get();
        foreach ($users as $user) {
            $text = "";
            if ($user->user_first_name)
                $text .= $user->user_first_name . ' ';
            if ($user->user_family_name)
                $text .= $user->user_family_name . ' (';
            if ($user->email)
                $text .= $user->email . ') ';

            $text .= ": $user->user_id";


            $temp = [
                'id' => $user->user_id,
                'text' => $text
            ];
            $arr[] = $temp;
        }

        return response()->json(['results' => $arr], 200);
    }

    public function esSearch($search)
    {
        request()->merge([
            "serchName" => $search,
            "sorting" => "persona_id",
            "sortingOrder" => "asc"
        ]);
        $arr = [];
        $dataRecieve = ElasticsearchUtility::autoSuggestData(request(), \config('constant.ES_INDEX_BASENAME'));
        if (array_key_exists('hits', $dataRecieve)) {
            foreach ($dataRecieve['hits']['hits'] as $user) {
                $user = (object)$user['_source'];
                $text = "";
                if ($user->persona_fname)
                    $text .= $user->persona_fname . ' ';
                if ($user->persona_lname)
                    $text .= $user->persona_lname . ' (';
                if (isset($user->emails['personal_emails']))
                    $text .= $user->emails['personal_emails'] . ') ';

                $text .= ": $user->persona_id";


                $temp = [
                    'id' => $user->persona_id,
                    'text' => $text
                ];
                $arr[] = $temp;
            }

            return response()->json(['results' => $arr], 200);
        }
        return response()->json(['results' => []], 200);

    }

    public function applicationEvents()
    {
        if (\request()->has('event_name') and !empty(\request()->event_name)) {
            $user = \request()->user();
            DB::table('application_events')->insert([
                'user_id' => $user->user_id,
                'event_name' => \request()->event_name,
            ]);
            return ['status' => true, 'message' => 'Event logged successfully'];
        } else {
            return ['status' => false, 'message' => 'Please Provide Event name'];
        }

    }

    public function userEventActivities()
    {
        $allActivities = DB::table('application_events')->where('user_id', \request()->user_id);
        $count = DB::table('application_events')->where('user_id', \request()->user_id)->count();
        if ($count > 0) {
            return ['status' => true, 'data' => $allActivities->orderBy(\request()->sorting, \request()->sortingOrder)->skip(request()->offSet)->take(request()->pageSize)->get(), 'count' => $count];
        } else {
            return ['status' => false, 'data' => $allActivities->orderBy(\request()->sorting, \request()->sortingOrder)->skip(request()->offSet)->take(request()->pageSize)->get(), 'count' => $count];
        }
    }

    public function getUserKillbill()
    {
        $user = User::where('user_id', \request()->user_id)->first();
        return ['status' => true, 'data' => $user];
    }

    public function triggerMissionForSeenVideos()
    {
        try {
            $user = \request()->user();
            $videoId = \request()->video_id;
            $videoStatus = \request()->is_completed;

            $pointsEarn = 0;
            if ($videoStatus) {
                $responseData = (new GamificationController())->checkMissionsForVideos($user->user_id, $videoId);
                (new GamificationController())->completedMissionForUser($user->user_id, 0);
                if (count($responseData) > 0) {
                    foreach ($responseData as $value) {
                        if (isset($value['points'])) {
                            $pointsEarn = ($pointsEarn + $value['points']);
                        }
                    }
                }
            }


            try {
                //update video status in DB
                DB::table('user_video_status')->updateOrInsert(
                    ["user_id" => $user->user_id, "video_id" => $videoId],
                    [
                        'user_id' => $user->user_id,
                        'video_id' => $videoId,
                        'status_type' => $videoStatus ? 'completed' : 'clicked'
                    ]
                );
            } catch (\Exception $e) {
                Log::channel('custom')->info('video_status_error', ['video_status_error' => $e->getMessage()]);
            }

            //call event trigger
            $data = [
                'user_id' => $user->user_id,
                'video_id' => $videoId,
                'video_status' => $videoStatus ? 'completed' : 'clicked',
                'trigger_type' => 'video'
            ];
            $trigger_type = "$.video_trigger";
            (new VCTrigger())->callVCTrigger($data, $trigger_type);

            return ['status' => true, 'message' => 'trigger mission success fully', 'points' => $pointsEarn];
        } catch (\Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }

    }

    public function udbUserBrandPoints()
    {
        $data = request()->data;

        foreach ($data as $value) {
            $user = User::where('client_customer_id', $value['customer_id'])->first();
            if ($user) {
                $brand = DB::table('user_brand_points')->where('brand_name', $value['brand_name'])->first();
                if (!$brand) {
                    DB::table('user_brand_points')->insert([
                        'user_id' => $user->user_id,
                        'brand_name' => $value['brand_name'],
                        'points' => $value['points'],
                        'meta' => json_encode($value['ExpiringAmounts']),
                    ]);
                } else {
                    DB::table('user_brand_points')->where('brand_name', $value['brand_name'])->update([
                        'user_id' => $user->user_id,
                        'brand_name' => $value['brand_name'],
                        'points' => $value['points'],
                        'meta' => json_encode($value['ExpiringAmounts']),
                    ]);
                }
            } else {
                return ['status' => false, 'message' => 'customer id not found'];
            }
        }
        return ['status' => true, 'message' => 'Successfully insert data'];
    }//---- End of -----//

    /**
     *  Function for brand points
     */
    public function brandPoints()
    {
        $user = \request()->user();
        $brandData = DB::table('user_brand_points')->where('user_id', $user->user_id)->get(['brand_name', 'points', 'meta']);
        return ['status' => true, 'data' => $brandData];
    }

    public function convertOrderData()
    {
        $limit = 500;
        $transactions = \Illuminate\Support\Facades\DB::table('member_transactions')
            ->whereNotNull('order_detail')->orWhere('order_detail', '<>', '')
            ->limit($limit)->get();

        if ($transactions->count() == 0) {
            echo "All records transferred";
            exit;
        }

        foreach ($transactions as $transaction) {
            $prd_details = json_decode($transaction->order_detail);
            //Log::channel('custom')->info('json_encode', ['json_encode' => $prd_details]);
            foreach ($prd_details as $prd_detail) {
                try {
                    $result = DB::table('member_transaction_order_detail')->insert([
                        'member_transaction_id' => $transaction->id,
                        'product_detail' => json_encode($prd_detail)
                    ]);
                } catch (\Exception $e) {
                    Log::channel('custom')->info('member_transaction_order_detail_error', ['member_transaction_order_detail_error' => $e->getMessage()]);
                }

            }
            try {
                DB::table('member_transactions')->where('id', $transaction->id)->update(['order_detail' => NULL]);
            } catch (\Exception $e) {
                Log::channel('custom')->info('member_transaction_error', ['member_transaction_error' => $e->getMessage()]);
            }

        }

        echo "$limit Done";
        echo '<meta http-equiv="refresh" content="1">';
        exit;
    }


    public function savePaymentTypes($tender, $tran_id)
    {
        if ($tender != "" and $tender != null) {
            $payment_types = json_decode($tender);
            foreach ($payment_types as $payment_type) {
                if ($payment_type->amount > 0) {
                    //$arr[] = $payment_type->tender_type;
                    try {
                        $result = DB::table('member_transaction_payment_types')->insert([
                            'member_transaction_id' => $tran_id,
                            'tender_type' => $payment_type->tender_type,
                            'amount' => round($payment_type->amount, 2),
                        ]);
                    } catch (\Exception $e) {
                        Log::channel('custom')->info('savePaymentTypes_error', ['savePaymentTypes_error' => $e->getMessage()]);
                    }
                }
            }
        }
    }

    public function saveTransactionNew($ord_items, $tran_id)
    {
        $ord_items = json_decode($ord_items);
        foreach ($ord_items as $prd_detail) {
            try {
                $result = DB::table('member_transaction_order_detail')->insert([
                    'member_transaction_id' => $tran_id,
                    'product_detail' => json_encode($prd_detail)
                ]);
            } catch (\Exception $e) {
                Log::channel('custom')->info('saveTransactionNew_error', ['member_transaction_order_detail_error' => $e->getMessage()]);
            }

        }
    }


    public function getOrderDetail($tran_id = 0)
    {
        if ($tran_id == 0) {
            $trans = DB::table('member_transaction_order_detail')->get();
        } else {
            $trans = DB::table('member_transaction_order_detail')->where('member_transaction_id', $tran_id)->get();
        }
        $arr = [];
        foreach ($trans as $tran) {
            $arr[] = json_decode($tran->product_detail);
        }
        return $arr;

    }

    /**
     * @return array
     *  Delete Data of deleted users
     */
    public function deleteVoucherForTrashedUser()
    {
        $check_deleted_user = User::onlyTrashed()->get();
        $count = 0;
        if ($check_deleted_user->isNotEmpty()) {
            foreach ($check_deleted_user as $user) {
                $count = $count + 1;
                Log::channel('user')->info('register_req', ['Removing already deleted user' => $user]);
                MissionUserEntry::where('user_id', $user->user_id)->forceDelete();
                VoucherUser::where('user_id', $user->user_id)->forceDelete();
                VoucherLog::where('user_id', $user->user_id)->forceDelete();
                UserStamp::where('user_id', $user->user_id)->forceDelete();
                GameUserEntry::where('user_id', $user->user_id)->forceDelete();
                Lt_Transaction::where('user_id', $user->user_id)->forceDelete();
                UserAddresses::where('user_id', $user->user_id)->forceDelete();
                $user->forceDelete();

            }
            return ['status' => true, 'message' => $count . ' Delete Record successfully'];
        } else {
            return ['status' => false, 'message' => 'No Deleted Record Found'];
        }
    }//----- End of deleteVoucherForTrashedUser() ----//

    public function findDuplicateUser()
    {
        $limit = 10;
        $offset = 0;
        if (\request()->has('offset'))
            $offset = \request()->offset;

        $users = DB::select('SELECT users.*
FROM users
INNER JOIN (
  SELECT client_customer_id
  FROM users
  GROUP BY client_customer_id
  HAVING COUNT(client_customer_id) > 1
) dupes ON users.client_customer_id = dupes.client_customer_id
ORDER BY users.client_customer_id LIMIT ' . $offset . ', ' . $limit);
        $count = 0;
        $data = [];
        foreach ($users as $value) {
            $data[] = $value;
        }
        if (count($data) > 0) {
            echo "Total records found: " . count($data) . "<br>";

            foreach (collect($data) as $key => $value) {
                $userData = $this->updateUserInSoldi($value);

                User::where('user_id', $value->user_id)->update([
                    'client_customer_id' => $userData['customer_id']
                ]);
                (new ElasticSearchController())->insertUserToES($value->user_id);
                $count = $count + 1;

            }

            echo '<meta http-equiv = "refresh" content = "1" url = "' . url("/api/find-duplicate?offset=" . ($offset + $limit)) . '" />';
            exit();
        }
        echo "All finished";
        exit;

        //return ['total_user' =>$count];
    }

    public function updateUserInSoldi($value)
    {

        $parm = ['first_name' => $value->user_first_name, 'last_name' => $value->user_family_name,
            'email_address' => $value->email,
            'mobile_number' => $value->user_mobile, 'membership_id' => $this->checkUniqueCustomerID(),
            'land_line' => ''
        ];


        $client1 = new Client([
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => config('constant.SOLDI_API_KEY'),
                'SECRET' => config('constant.SOLDI_SECRET')

            ]
        ]);

        $response = $client1->request('POST', config('constant.SOLDI_DEFAULT_PATH') . '/customer/updateibscustomer', [
            'json' => $parm
        ]);
        $soldi_res = $response->getBody()->getContents();
        $soldi_arr = json_decode($soldi_res);
        Log::channel('user')->info('response on creation soldi', ['soldiResponse' => $soldi_arr, 'inputToSoldi' => $parm]);
        return ['customer_id' => $soldi_arr->data->icustomer_id_uk, 'icustomer_id_uk' => $soldi_arr->data->icustomer_id_ire];

    }

    /**
     * @return int
     * Check Unique Membership ID
     */
    private function checkUniqueCustomerID()
    {
        $memberShipID = mt_rand(1000000, 9999999);
        if (User::where('client_customer_id', $memberShipID)->exists()) {
            return $this->checkUniqueCustomerID();
        } else {
            return $memberShipID;
        }
    }//------ End of checkUniqueCustomerID() -----//

    /**
     * @return array
     *
     * Update membership id
     */
    public function updateMembershipID()
    {
        if (\request()->has('soldi_id') and \request()->has('membership_id')) {
            Log::channel('custom')->info('updateMembershipID', ['request_params' => \request()->all()]);
            $user = User::where('soldi_id', \request()->soldi_id)->first();
            if ($user) {
                $user->client_customer_id = \request()->membership_id;
                $user->save();
                (new ElasticSearchController())->insertUserToES($user->user_id);
                return ['status' => true, 'message' => 'successfully updated'];
            } else {
                return ['status' => false, 'message' => 'User Not exists'];
            }
        } else {
            return ['status' => false, 'message' => 'Please provide membership and soldi id'];
        }
    }//------- End of updateMembershipID() -----//

    /**
     * @return array
     *
     * Add new member as friend for baller
     */
    public function addMemberAsFriend()
    {
        Log::channel('user')->info('addMemberAsFriend', ['request' => \request()->all()]);
        if (request()->has('email') and request()->has('first_name') and request()->has('last_name') and request()->has('phone') and request()->has('friend_id')) {
            $user = User::where(['is_active' => 0, 'email' => request()->email])->first();

            if ($user) {
                return ['status' => false, 'message' => 'User with same email Already exists'];
            }
            $image = '';
            if (request()->hasFile('image')) {
                $image = rand(111, 999) * time() . '.' . request()->file('image')->getClientOriginalExtension();
                $path = base_path() . '/public/users/';
                request()->file('image')->move($path, $image);
                Image::make($path . $image, array(
                    'width' => 200,
                    'height' => 200,
                    'grayscale' => false
                ))->save(base_path() . '/public/users/thumbs/thumb_' . $image);
            }

            $userFriend = User::where('user_id', \request()->friend_id)->first();
            $user = User::create([
                'user_first_name' => request()->first_name,
                'user_family_name' => request()->last_name,
                'email' => request()->email,
                'user_mobile' => request()->phone,
                'user_avatar' => $image,
                'is_active' => 0,
                'password' => Hash::make(rand(123123123, 12312312312)),
                'referal_by' => $userFriend->referral_code ?? $userFriend['referral_code']
            ]);

            if (\request()->has('subscribe') and (request()->subscribe || request()->subscribe === 'true')) {
                (new UserApiController())->saveChannels($user);
            }
            (new ElasticSearchController())->insertUserToES($user->user_id);
            if (!empty($image)) {
                $user->image = url('users/thumbs/thumb_' . $image);
            } else {
                $user->image = url('assets/images/members_icon@2x.png');
            }
            return ['status' => true, 'message' => 'User Added Successfully', 'data' => $user];
        } else {
            return ['status' => false, 'message' => 'Provide All parameters'];
        }
    }//----- End of addMemberAsFriend() ------//

    /**
     * @return array
     * List data for baller friends
     */
    public function getMemberFriends()
    {
        Log::channel('user')->info('getMemberFriends', ['request' => \request()->all()]);
        if (\request()->has('user_id')) {
            $user = User::where('user_id', \request()->user_id)->first();
            if ($user) {
                $allUsers = User::where('referal_by', $user->referral_code)->get();
                foreach ($allUsers as $value) {
                    if (empty($value->user_avatar)) {
                        $value->image = url('assets/images/members_icon@2x.png');
                    } else {
                        $value->image = url('users/thumbs/thumb_' . $value->user_avatar);
                    }
                }

                return ['status' => true, 'data' => $allUsers];
            } else {
                return ['status' => false, 'message' => 'Please provide register active user'];
            }
        } else {
            return ['status' => false, 'message' => 'Please Provide user id'];
        }
    }

    /**
     * @return array
     *
     *  Delete Member From
     */
    public function deleteMemberFriend()
    {
        $status = false;
        $message = '';
        if (\request()->has('user_id') and !empty(\request()->user_id) and \request()->has('friend_id') and !empty(\request()->friend_id)) {
            $userID = User::where('user_id', \request()->user_id)->first();
            $friendid = User::where('user_id', \request()->friend_id)->first();
            if ($userID->referal_by == $friendid->referral_code) {
                $user = User::where('user_id', \request()->user_id)->forceDelete();
                $query = [
                    'bool' => [
                        'must' => [
                            ['match' => ['persona_id' => request()->user_id]],

                        ]
                    ]
                ];
                ElasticsearchUtility::deleteByQuery(config('constant.ES_INDEX_BASENAME'), '', '', $query);
                $status = true;
                $message = 'Friend deleted successfully';
            } else {
                $status = false;
                $message = 'User with this id not exists';
            }

        } else {
            $status = false;
            $message = 'Please provide user_id and friend_id';
        }

        return ['status' => $status, 'message' => $message];

    }

    /**
     * @return array
     */
    public function scanRestaurant()
    {
        $user = request()->user();
        if (request()->has('qr_code')) {
            $checkExisting = UserVenueRelation::where(['user_id' => $user->user_id, 'venue_id' => request()->qr_code])->first();
            if (!$checkExisting) {
                UserVenueRelation::create([
                    'user_id' => $user->user_id,
                    'venue_id' => request()->qr_code
                ]);

                return ['status' => true, 'message' => 'Store is added successfully'];
            } else
                return ['status' => false, 'message' => 'Store Already exist in your list'];

        } else
            return ['status' => false, 'message' => 'Please Provide QR Code'];
    }//------ End of scanRestaurant() -------//

    /**
     * @return array
     */
    public function searchRestaurant()
    {
        $business = (new VenueController())->getSoldiBusinessGawler();
        $data = [];

        foreach ($business['data'] as $value) {
            $data[] = ['business_id' => $value->business_id, 'business_name' => $value->business_name];
        }
        return ['status' => true, 'data' => $data];
    }//------ End of searchRestaurant() ------//


    public function addRestaurant()
    {
        $user = request()->user();
        if (\request()->has('business_id')) {
            $checkExisting = UserVenueRelation::where(['user_id' => $user->user_id, 'venue_id' => \request()->business_id])->first();
            if (!$checkExisting) {
                UserVenueRelation::create([
                    'user_id' => $user->user_id,
                    'venue_id' => request()->business_id
                ]);

                return ['status' => true, 'message' => 'Store is added successfully'];
            } else
                return ['status' => false, 'message' => 'Store Already exist in your list'];

        } else
            return ['status' => false, 'message' => 'Please provide Store id'];
    }

    public function getUserBusiness()
    {
        $user = request()->user();
        if (\request()->has('coordinate')) {

            $business = (new VenueController())->getSoldiBusinessWithCordinates(\request()->coordinate);
            $businessData = collect($business['data']);
            $userVenues = UserVenueRelation::where(['user_id' => $user->user_id])->get();
            $data = [];
            foreach ($userVenues as $value) {
                $newData = $businessData->where('business_id', $value->venue_id)->first();
                if ($newData) {
                    $data[] = $newData;
                }
            }
            return ['status' => true, 'data' => $data];
        } else
            return ['status' => false, 'message' => 'Please Provide Coordinate'];
    }

    /**
     * @return array
     */
    public function updateMemberEmails()
    {
        if (\config('constant.ACCESS_KEY') == \request()->access) {
            $users = User::where('user_id', \request()->user_id)->first();
            if ($users) {
                $users->email = request()->updated_email;
                $users->save();
                (new ElasticSearchController())->insertUserToES($users->user_id);


                return ['status' => true, 'Messages' => 'Membership Updated'];
            } else {
                return ['status' => false, 'Messages' => 'User Not Found'];
            }
        } else
            return ['status' => false, 'message' => 'Provide access key'];
    }

    /**
     * Bulk upload Till Slip
     */
    public function buildUploadTillSlip()
    {
        if (request()->user_id and !empty(request()->user_id) and request()->directory and !empty(request()->directory)) {
            if (is_dir(public_path(request()->directory))) {                 //Checking Directory Exists
                $user = User::where('user_id', request()->user_id)->exists();

                if ($user) {
                    $path = public_path(request()->directory);
                    $data = $this->forwardDataToUdb($path);             // Forward Data to UDB
                    if ($data['status']) {
                        unlink(public_path(request()->directory . '/' . $data['file_name']));
                        echo '<meta http-equiv = "refresh" content = "1" />';
                        exit();
                    } else {
                        if (isset($data['all_finished'])) {
                            echo 'all Finished';
                            exit;
                        }
                        echo $data['message'];
                        exit;
                    }
                } else {
                    echo 'User Not Found';
                    exit();

                }

            } else {
                echo 'No Directory exists';
                exit();
            }

        } else {
            echo 'user_id or directory missing';
            exit();
        }

    }

    /**
     * @param $path
     * @return array
     *
     * Function for post till slip
     */
    private function forwardDataToUdb($path)
    {
        try {
            $files = File::allfiles($path);

            $files = collect($files)->filter(function ($item) {
                return $item->getExtension() == 'jpg' || $item->getExtension() == 'jpeg' || $item->getExtension() == 'gif';
            });
            $files = array_values($files->toArray());
            if (count($files) == 0) {
                return ['status' => false, 'all_finished' => true];
            }
            $percent = 1;
            $images = imagecreatefromjpeg($files[0]->getRealPath());
            $images = imagescale($images, 500);
            ob_start();
            imagejpeg($images);

            $contents = ob_get_contents();
            ob_end_clean();
            $baseImage = base64_encode($contents);
            $fileName = $files[0]->getFilename();

            $extension = $files[0]->getExtension();
            $slip_name = uniqid() . '.' . $extension;
            $slip_mime_type = mime_content_type($files[0]->getRealPath());
            $base64Image = $baseImage;
            $imagestest[] = [
                'filename' => $slip_name,
                'mimetype' => $slip_mime_type,
                'content' => $base64Image
            ];
            $userReciepts = UserReceipts::create([
                'user_id' => request()->user_id,
                'image' => $fileName,

            ]);
            $referenceId = "ref-" . request()->user_id . '-' . $userReciepts->id;
            $data_to_send = [
                'reference' => $referenceId,
                'client_name' => 'unilever',
                'images' => $imagestest

            ];
            Log::channel('user')->info('$data_to_send', ['$data_to_send' => $data_to_send]);
            $client = new Client([
                'headers' => ['Content-Type' => 'application/json', 'secret_key' => config('constant.LINK_SECRET')]
            ]);
            $result = $client->post(config('constant.LINK_URL') . '/submit_slip', [
                'json' => $data_to_send
            ]);
            $result = json_decode($result->getBody()->getContents());
            Log::channel('user')->error('$result', ['$result' => $result]);
            if ($result->status) {
                UserReceipts::where('id', $userReciepts->id)->update([
                    'reference_no' => "ref-" . request()->user_id . '-' . $userReciepts->id,
                    'submissionid' => $result->body->submission_id
                ]);

                return ['status' => true, 'message' => 'Slip uploaded', 'data' => $result->body->submission_id, 'file_name' => $fileName];
            } else {
                return ['status' => false, 'message' => $result->body, 'data' => 0];
            }

        } catch (ClientException $e) {
            Log::channel('user')->error('ClientException', ['ClientException' => $e->getMessage()]);
            return ['status' => false, 'message' => $e->getMessage(), 'data' => 0];
        } catch (\Exception $e) {
            Log::channel('user')->error('exception_submit_slip', ['exception_submit_slip' => $e->getMessage()]);
            return ['status' => false, 'message' => $e->getMessage(), 'data' => 0];
        }
    }//----End of forwardDataToUdb() ----//

    function image_resize($file_name, $width, $height, $crop = FALSE)
    {
        list($wid, $ht) = getimagesize($file_name);
        $r = $wid / $ht;
        if ($crop) {
            if ($wid > $ht) {
                $wid = ceil($wid - ($width * abs($r - $width / $height)));
            } else {
                $ht = ceil($ht - ($ht * abs($r - $wid / $ht)));
            }
            $new_width = $width;
            $new_height = $height;
        } else {
            if ($width / $height > $r) {
                $new_width = $height * $r;
                $new_height = $height;
            } else {
                $new_height = $width / $r;
                $new_width = $width;
            }
        }
        $source = imagecreatefromjpeg($file_name);
        $dst = imagecreatetruecolor($new_width, $new_height);
        imagecopyresized($dst, $source, 0, 0, 0, 0, $new_width, $new_height, $wid, $ht);
        return $dst;
    }

    /**
     * @return array
     * Function for insert update user groups
     */
    public function addMailingListUsers()
    {
        $create = $update = false;
        if (\request()->has('email') and !empty(request()->email)) {
            $user = User::where('email', \request()->email)->first();
            if ($user) {
                $user->user_first_name = request()->first_name;
                $user->user_family_name = request()->last_name;
                $user->groups = json_encode(['Member', 'MailingList']);
                $user->save();
                if (\request()->has('covid') and \request()->covid) {
                    DB::table('covid19')->where('user_id', $user->user_id)->update([
                        'number_of_guests' => \request()->number_of_guest ?? 0,
                        'updated_at' => Carbon::now(),
                    ]);
                }
                $update = true;
            } else {
                $user = User::create([
                    'user_first_name' => \request()->first_name ?? '',
                    'user_family_name' => \request()->last_name ?? '',
                    'email' => \request()->email ?? '',
                    'is_active' => 0,
                    'groups' => json_encode(['Member', 'MailingList']),
                    'created_at' => Carbon::now(),
                ]);
                $create = true;

                if (\request()->has('covid') and \request()->covid) {
                    DB::table('covid19')->insert([
                        'number_of_guests' => \request()->number_of_guest ?? 0,
                        'updated_at' => Carbon::now(),
                        'user_id' => $user->user_id
                    ]);
                }

            }
            (new ElasticSearchController())->insertUserToES($user->user_id);
            return ['status' => true, 'message' => ($create) ? 'User created successfully' : 'User updated successfully'];
        } else {
            return ['status' => false, 'message' => "Email is required"];
        }
    }

    /**
     * @return array
     * Function to retrieve Data Against Receipt id
     */
    public function getReceiptData()
    {
        try {
            $receipt_id = request()->receipt_id;
            if (empty($receipt_id)) {
                return ['status' => false, 'message' => 'Provide receipt id'];
            }

            // Check receipt exists
            $receipts = UserReceipts::where('id', $receipt_id)->first();

            if (!$receipts) {
                return ['status' => false, 'message' => 'No record exists against receipt id'];
            }
            $receiptData = json_decode($receipts->detail, true);
            //Check Logo For Retailer
            $logo = '';
            //mobeen code
            if (isset($receiptData['merchantName']) && isset($receiptData['merchantName']['value'])) {
                $merchant_name = trim(strtolower($receiptData['merchantName']['value']));
                $store = StoreConfig::where('name', $merchant_name)->first();
                $logo = ($store) ? url($store->image) : '';
            }
//            if (isset($receiptData['retailerId'])) {
//                $store = StoreConfig::where('external_id', $receiptData['retailerId'])->first();
//                $logo = ($store) ? url($store->image) : '';
//            }
            // Main data Array
            $data = [
                "total" => $receiptData['total']['value'] ?? 0,
                "sub_total" => $receiptData['subtotal']['value'] ?? 0,
                "retailer" => $receiptData['merchantName']['value'] ?? '',
                "loyalty" => ['points' => $receipts->points, 'stamps' => $receipts->stamp],
                "retailer_logo" => $logo,
                "retailer_address" => $receiptData['storeAddress']['value'] ?? '',
                "receipt_id" => $receiptData['blinkReceiptId'] ?? '',
                "scan_date" => Carbon::parse($receipts->created_at)->format('m/d/Y'),
                "receipt_date" => $receiptData['receiptDate']['value'] ?? '',
                "receipt_time" => $receiptData['receiptTime']['value'] ?? '',
                "store_number" => $receiptData['storePhone']['value'] ?? '',
                "vat" => "", "discount" => "", "payment_type" => $receiptData['paymentMethods'][0]['method']['value'] ?? '', "products" => []
            ];
            $productsData = [];
            //Check if products Data exists
            if (isset($receiptData['products']) and count($receiptData['products']) > 0) {
                foreach ($receiptData['products'] as $products) {

                    // Data is created for products
                    $productsData[] = [
                        "sku" => $products['upc'] ?? '', "category" => $products['category'] ?? '', "brand" => $products['brand'] ?? '',
                        "amount" => (isset($products['totalPrice']) and is_array($products['totalPrice'])) ? $products['totalPrice']['value'] : (isset($products['totalPrice']) ? $products['totalPrice'] : 0), "barcode" => null, "quantity" => $products['quantity']['value'] ?? 0,
                        "name" => $products['productName'] ?? '', "unit_price" => $products['unitPrice']['value'] ?? 0, "total_price" => (is_array($products['totalPrice'])) ? $products['totalPrice']['value'] : $products['totalPrice'],
                        "discount_price" => $products['discountAmount'] ?? 0, "description" => $products['productDescription']['value'] ?? '',
                        "is_unilever" => $products['is_unilever'] ?? false, "requires_observation" => $products['isVoided'] ?? false,
                        "loyalty" => ["points" => isset($products['points']) ? $products['points'] : 0, "stamps" => isset($products['stamps']) ? $products['stamps'] : 0]
                    ];
                }

                $data['products'] = $productsData;

                return ['status' => true, 'data' => $data];

            } else {

                return ['status' => true, 'data' => $data];
            }
        } catch (\Exception $e) {
            //dd($e->getMessage());
            Log::channel('custom')->info('getReceiptData_error', ['getReceiptData_error' => $e->getMessage()]);
            return ['status' => false, 'message' => 'Something went wrong.'];
        }

    }//---- End of getReceiptData() -----//

    public function getScanReceipt()
    {
        set_time_limit(0);
        try {
            $rec_data = $data = json_decode(\request()->slip_data, true);
            $images = json_decode(\request()->receipt_images, true);


            Log::channel('custom')->info('recieptCallback', ['recieptCallback' => \request()->all()]);
            $products = [];

            if (!isset($data['products'])) {
                return ['status' => false, 'message' => 'This slip is invalid. Please check out FAQs'];
            }
            foreach ($data['products'] as $productValue) {
                $products[] = $productValue['productDescription']['value'];
            }


            Log::channel('custom')->info('duplicate', ['duplicate' => $this->allow_duplicate]);
            //duplicate check
            if (!$this->allow_duplicate) {
                if (array_key_exists('isDuplicate', $data)) {
                    if ($data['isDuplicate'] == true || $data['isDuplicate'] == 'true') {
                        return ['status' => false, 'message' => 'This receipt is already scanned!', 'is_duplicate' => true];
                    }
                }
            }


            $user = \request()->user();
            //  $user = User::where('user_id',5777)->first();


            Log::channel('custom')->info('max_scan', ['max_scan' => $this->max_scan]);


            $data['soldi_id'] = $user->soldi_id ?? 0;
            // Saving receipt data for users
            $userReciepts = UserReceipts::create([
                'user_id' => $user->user_id,
                'detail' => json_encode($data),
                'created_at' => Carbon::now(),
            ]);

            $referenceId = "ref-" . $user->user_id . '-' . $userReciepts->id;
            $userReciepts->reference_no = $referenceId;
            $userReciepts->save();

            if ($userReciepts) {
                Log::channel('custom')->info('append receipt id', ['append receipt id' => true]);
                \request()->request->add(['receipt_id' => $userReciepts->id]);
            }

            $data['reference_no'] = $referenceId;
            // Receipt Data to Udb
            $client = new Client([
                'headers' => ['Content-Type' => 'application/json', 'X-Link-Secret-Key' => config('constant.LINK_SECRET')]
            ]);
            $result = $client->post(config('constant.LINK_URL') . 'receiptItems', [
                'json' => $data
            ]);
            $result = json_decode($result->getBody()->getContents());

            //Log::channel('custom')->info('recieptCallback', ['UDB Response' => $result]);

            $pointsEarn = 0;
            $stamp = 0;
            $total = isset($data['total']['value']) ? round($data['total']['value']) : 0;

            $receiptDate = (isset($data['receiptDate']) && is_array($data['receiptDate'])) ? $data['receiptDate']['value'] : (isset($data['receiptDate']) and is_string($data['receiptDate']) ? $data['receiptDate'] : '');
            $recieveMaximum = $this->checkMaximumReceiptCount($receiptDate,$user->user_id);

            Log::channel('custom')->info('maximumScanResult', ['recieve' => $recieveMaximum,'date'=>$receiptDate]);
            $receiptDate = (!empty($receiptDate)) ? $this->getDays($receiptDate) : '';

            $upc = '';
            $pushValues = [];
            $brandsValues = [];
            foreach ($data['products'] as $value) {
                if ($value) {
                    $productCount = 0;
                    if (isset($recieveMaximum['status']) and !$recieveMaximum['status']) {
                        continue;
                    }
                    if (isset($value['upc']) || isset($value['possibleProducts'])) {

                            if (isset($value['possibleProducts'])) {
                                foreach ($value['possibleProducts'] as $value1) {
                                    if (!in_array($value1['upc'], $pushValues)) {

                                        $this->assginReceiptPunchCard($value1['upc'], $referenceId, $total, $user->user_id, $receiptDate);
                                        $pushValues[] = $value1['upc'];
                                    }


                                }

                            } else if (isset($value['upc'])) {
                                if (!in_array($value['upc'], $pushValues)) {

                                    $this->assginReceiptPunchCard($value['upc'], $referenceId, $total, $user->user_id, $receiptDate);
                                    $pushValues[] = $value['upc'];
                                }


                            }

                    }
                    if (isset($value['brand'])) {
                        $Brandquantity = 1;
                            if (isset($value['quantity']) and $value['quantity']['value'] > 0) {
                                $Brandquantity = $value['quantity']['value'];
                            }
                            $totalSum = 0;
                            if (isset($value['unitPrice'])) {
                                $totalSum = $value['unitPrice']['value'];
                            }
                            $this->assginReceiptBrandPunchCard($value['brand'], $referenceId, $totalSum, $user->user_id, $Brandquantity, $receiptDate);

                    }

                    $productCount = collect($data['products'])->where('productDescription.value', $value['productDescription']['value'])->count();
                    $responseData = (new GamificationController())->rewardOnScanReciept($user->user_id, [], isset($value['is_unilever']) ? true : false, [], 0, 0, $products, $productCount, '', [], $total);
                    $getData = (new GamificationController())->completedMissionForUser($user->user_id, $total);

                    if (count($getData) > 0) {
                        foreach ($getData as $value) {
                            if (isset($value['points'])) {
                                $pointsEarn = ($pointsEarn + $value['points']);
                            } elseif (isset($value['stamps'])) {
                                $stamp = ($stamp + $value['stamps']);
                            }
                        }
                    }
                    Log::channel('custom')->info('recieve', ['recieve' => $responseData]);
                    if (count($responseData) > 0) {
                        foreach ($responseData as $value) {
                            if (isset($value['points'])) {
                                $pointsEarn = ($pointsEarn + $value['points']);
                            } elseif (isset($value['stamps'])) {
                                $stamp = ($stamp + $value['stamps']);
                            }
                        }
                    }
                }
            }

            if ($user) {
                Log::channel('custom')->info('totalearnedPoints', ['totalearnedPoints' => $pointsEarn, 'totalStamp' => $stamp]);

//                $this->assignPointsTouser($user->user_id, $pointsEarn, 'debit', 'Receipt Call Back', '', 'Receipt Call Back');


                //call event trigger
                $trigger_data = [
                    'user_id' => $user->user_id,
                    'reference_no' => $userReciepts->reference_no,
                    'scan_data' => $rec_data,
                    'receipt_id' => $userReciepts->id,
                    'trigger_type' => 'receipt'
                ];
                $trigger_type = "$.receipt_trigger";

                (new VCTrigger())->callVCTrigger($trigger_data, $trigger_type);

                //max scans check 
                if ($this->max_scan > 0) {
                    //$today_count = UserReceipts::whereDate('created_at','=',date("Y-m-d"))->where('user_id',$user->user_id)->count();
                    $user_id = $user->user_id;
                    $incoming_receipt_data = $rec_data['receiptDate']['value'] ?? '';
                    if (!empty($incoming_receipt_data)) {
                        $res = DB::select("SELECT COUNT(id) AS rec_count FROM user_receipts WHERE user_id = '$user_id' AND JSON_UNQUOTE(JSON_EXTRACT(detail,'$.receiptDate.value')) = '$incoming_receipt_data'");
                        $rec_count = $res[0]->rec_count;

                        Log::channel('custom')->info('$rec_count', ['$rec_count' => $rec_count]);
                        if ($rec_count > $this->max_scan) {
                            return ['status' => false, 'message' => 'You have crossed limit of maximum scans per day, you will not receive reward of this receipt', 'max_scan' => true, 'receipt_id' => $userReciepts->id];
                        }
                    }
                }

                return ['status' => true, 'message' => 'Slip submitted successfully', 'receipt_id' => $userReciepts->id];
            }
        } catch (\Exception $e) {
            Log::channel('custom')->info('scan_error', ['scan_error' => $e->getMessage(), 'trace' => $e->getTrace()]);
            return ['status' => false, 'message' => $e->getMessage(), 'receipt_id' => 0];

        }


    }

    public function assignPointWithCheckExpiry()
    {
        $setting = Setting::where('type', 'point_expiry_settings')->first();
        $expiry = '';
        if ($setting) {
            switch ($setting->field1) {
                case 'no_expiry';
                    $expiry = '';
                    break;
                case "specific_time":
                    $expiry = $this->calculateExpiry($setting);
                    break;
                case "expiry_period":
                    $expiry = $this->calculateEpiryPeriod($setting);
                    break;
                default:
                    $expiry = '';
            }
        }
        return ['status' => true, 'expiry' => $expiry];
    }

    private function calculateExpiry($setting)
    {
        $day = json_decode($setting->field2);
        $day = $day->value;
        $month = json_decode($setting->field3);
        $month = $month->value;
        $year = date('Y');
        return $year . '-' . $month . '-' . $day;

    }

    private function calculateEpiryPeriod($setting)
    {
        $increment = $setting->field2;
        $incrementBy = json_decode($setting->field3);
        $incrementBy = $incrementBy->value;
        return date('Y-m-d', strtotime('+' . $increment . ' ' . $incrementBy));
    }

    public function getExpiredPoints($id)
    {
        $date = date('Y-m-d');
        $data = Lt_Transaction::selectRaw('SUM(lt_transations.value_points) AS points_total,type')
            ->where('user_id', $id)
            ->whereNotNull('expiry_date')
            ->whereDate('expiry_date', '<', $date)
            ->groupBy('type')
            ->get();

        $totalPoints = 0;

        if (count($data) > 0) {
            $creditAmount = $data[0]->points_total ?? 0;
            $debitAmount = $data[1]->points_total ?? 0;
            $totalPoints = $creditAmount - $debitAmount;

        } else {
            $totalPoints = 0;
        }
        return $totalPoints;
    }

    public function getNotExpiredPoints($id)
    {
        $date = date('Y-m-d');
        $data = Lt_Transaction::selectRaw('SUM(lt_transations.value_points) AS points_total,type')
            ->where('user_id', $id)
            ->whereNotNull('expiry_date')
            ->whereDate('expiry_date', '>', $date)
            ->groupBy('type')
            ->get();

        $totalPoints = 0;

        if (count($data) > 0) {
            $creditAmount = $data[0]->points_total ?? 0;
            $debitAmount = $data[1]->points_total ?? 0;
            $totalPoints = $creditAmount - $debitAmount;

        }

        return $totalPoints;
    }

    public function getAllMembers()
    {
        $users = User::where('is_active', 1)->get();
        return ['status' => true, 'data' => $users];
    }

    /**
     * @return array
     * @throws \Matthewbdaly\SMS\Exceptions\DriverNotConfiguredException
     * Verify User for Booking and send verification code
     */
    public function verifyMember()
    {
        if (\request()->has('email') and !empty(\request()->email)) {
            $user = User::where('email', \request()->email)->first();
            if ($user) {
                $pin = rand(1111, 9999);
                $user->update(['activation_token' => $pin]);
                $message = 'Hi ' . $user->user_first_name . ', your verification code is ' . $pin . ' for PETstock Grooming. Please enter this PIN to continue your booking.';
                (new UserApiController())->sendSms($user->user_mobile, $message, 'default');
                (new UserApiController())->send_email($user->email, $user->user_first_name, 'verfication Email', $user->user_family_name, $pin, 'code_verification', $region_type = 'uk');

                return ['status' => true, 'data' => $user, 'code' => $pin];
            } else {
                return ['status' => false, 'message' => 'User not found'];
            }
        } else {
            return ['status' => false, 'message' => 'Please provide email'];
        }
    }//----- End of verifyMember() -----//

    /**
     * @return array
     *  Verify Pin code against user for booking engine
     */
    public function verifyPinCode()
    {
        if (\request()->has('email') and !empty(\request()->email) and \request()->has('code') and !empty(\request()->code)) {
            $user = User::where(['email' => \request()->email, 'activation_token' => \request()->code])->first();
            if ($user) {
                $user->activation_token = '';
                $user->save();
                return ['status' => true, 'message' => 'User successfully activated', 'data' => User::where('user_id', $user->user_id)->first()];
            } else {
                return ['status' => false, 'message' => 'User not exists'];
            }

        } else {
            return ['status' => false, 'message' => 'Please enter all required data'];
        }
    }//----- End of verifyPinCode() -----//

    /**
     * @return array
     *  Member Search For juvae project
     */
    public function searchMember()
    {

        if (\request()->has('search') and !empty(\request()->search)) {
            $nameSearch = explode(' ', request()->search);
            if (isset($nameSearch[0]) and !isset($nameSearch[1]) and !\request()->has('user_type')) {
                $user = User::where('user_first_name', 'like', '%' . trim($nameSearch[0]) . '%')->where('default_venue', \request()->venue_id)->orWhere('email', 'like', '%' . trim($nameSearch[0]) . '%')->get();
            }
            if (isset($nameSearch[0]) and isset($nameSearch[1]) and !\request()->has('user_type')) {
                $user = User::where('user_first_name', 'like', '%' . trim($nameSearch[0]) . '%')->where('default_venue', \request()->venue_id)->Where('user_family_name', 'like', '%' . trim($nameSearch[1]) . '%')->get();
            }
            if (isset($nameSearch[0]) and !isset($nameSearch[1]) and \request()->has('user_type') and !empty(\request()->user_type)) {
                $user = User::where('user_first_name', 'like', '%' . trim($nameSearch[0]) . '%')->where('default_venue', \request()->venue_id)->orWhere('email', 'like', '%' . trim($nameSearch[0]) . '%')->whereJsonContains('groups', \request()->user_type)->get();
            }

            if (isset($nameSearch[0]) and !isset($nameSearch[1]) and \request()->has('user_type') and !empty(\request()->user_type) and \request()->has('limit') and !empty(\request()->limit)) {
                $user = User::where('user_first_name', 'like', '%' . trim($nameSearch[0]) . '%')->where('default_venue', \request()->venue_id)->orWhere('email', 'like', '%' . trim($nameSearch[0]) . '%')->whereJsonContains('groups', \request()->user_type)->take(request()->limit)->get();
            }
            if (isset($nameSearch[0]) and isset($nameSearch[1]) and \request()->has('user_type') and !empty(\request()->user_type)) {
                $user = User::where('user_first_name', 'like', '%' . trim($nameSearch[0]) . '%')->where('default_venue', \request()->venue_id)->Where('user_family_name', 'like', '%' . trim($nameSearch[1]) . '%')->whereJsonContains('groups', \request()->user_type)->get();
            }

            if (isset($nameSearch[0]) and isset($nameSearch[1]) and \request()->has('user_type') and !empty(\request()->user_type) and \request()->has('limit') and !empty(\request()->limit)) {
                $user = User::where('user_first_name', 'like', '%' . trim($nameSearch[0]) . '%')->where('default_venue', \request()->venue_id)->Where('user_family_name', 'like', '%' . trim($nameSearch[1]) . '%')->whereJsonContains('groups', \request()->user_type)->take(request()->limit)->get();
            }
            if ($user) {
                return ['status' => true, 'data' => $user];
            } else {
                return ['status' => false, 'message' => 'User Not exists'];
            }
        } elseif (\request()->has('limit') and !empty(\request()->limit)) {
            if (\request()->has('user_type') and !empty(\request()->user_type)) {
                $user = User::where('is_active', 1)->where('default_venue', \request()->venue_id)->whereJsonContains('groups', \request()->user_type)->take(request()->limit)->get();
            } else {
                $user = User::where('is_active', 1)->where('default_venue', \request()->venue_id)->take(request()->limit)->get();
            }

            return ['status' => true, 'data' => $user];
        } else {
            if (\request()->has('user_type') and !empty(\request()->user_type)) {
                $user = User::where('default_venue', \request()->venue_id)->whereJsonContains('groups', \request()->user_type)->get();
            }

            return ['status' => true, 'data' => $user];
        }
    }

    /**
     * @return mixed
     * Get Brand Data
     */
    public function getBrandData()
    {
        $client = new Client([
            'headers' => ['Content-Type' => 'application/json', 'X-Link-Secret-Key' => config('constant.LINK_SECRET')]
        ]);
        $result = $client->get(config('constant.LINK_URL') . 'unilever/getBrands');
        $data = json_decode($result->getBody()->getContents());
        return ['status' => true, 'data' => $data->body];
    }

    public function testPunchCard()
    {
        if (isset(request()->receipt))
            $this->assginReceiptPunchCard(\request()->receipt);
    }

    private function assginReceiptPunchCard($upc, $referenceId, $total, $user_id, $receiptDate)
    {

        Log::channel('custom')->info('assginReceiptPunchCard', ['upc' => $upc, 'date' => $receiptDate]);
        $punchCard = PunchCard::where('redemption_type', 'category_product')->where('punch_card_data', 'like', "%" . $upc . "%")->get();
        if (count($punchCard) > 0) {

            foreach ($punchCard as $value) {
                Log::channel('custom')->info('assginReceiptPunchCard', ['day_check' => $value['day_on']]);
                if (!is_null($value['day_on'])) {
                    if ($receiptDate ==='') {
                        return true;
                    }

                    if ($receiptDate !=='' and ($value['day_on'] < $receiptDate)) {
                        continue;
                    }
                    $requestParam = new \Illuminate\Http\Request();
                    $requestParam->setMethod('POST');


                    $user_id = $user_id;
                    $through = "From Scan Receipt Against upc:$upc and total is : $total Reference  # $referenceId";
                    request()->merge(["company_id" => config('constant.COMPANY_ID'),
                        "venue_id" => "295255", "stampid" => $value->id, "userID" => $user_id, "mrcht_id" => "0",
                        "stampassign" => 1, 'addStamps' => false, 'notify' => false, 'assign_through' => $through]);
                    //call
                    $response = (new ElasticSearchController())->stampCardAssign();
                }
                return true;

            }
        }
        return true;
    }

    private function assginReceiptBrandPunchCard($brand, $referenceId, $total, $user_id, $quantity, $receiptDate)
    {
        Log::channel('custom')->info('assginReceiptBrandPunchCard', ['brand' => $brand, 'total' => $total, 'quantity' => $quantity, 'receiptDate' => $receiptDate]);
        $punchCard = PunchCard::where('brand_name', 'like', "%" . $brand . "%")->get();
        if (count($punchCard) > 0) {

            foreach ($punchCard as $value) {

                if (!is_null($value['day_on'])) {
                    if ($receiptDate ==='') {
                        return true;
                    }

                    Log::channel('custom')->info('assginReceiptBrandPunchCard', ['day_check' => $value['day_on']]);
                    if ($receiptDate !=='' and ($value['day_on'] < $receiptDate)) {
                        continue;
                    }

                    if ($total >= $value->transaction_threshold) {
                        Log::channel('custom')->info('assginReceiptPunchCard', ['assginReceiptPunchCard' => $value->id]);
                        $requestParam = new \Illuminate\Http\Request();
                        $requestParam->setMethod('POST');


                        $user_id = $user_id;
                        $through = "From Scan Receipt Against Brand:$brand and total is: $total Reference  # $referenceId";
                        request()->merge(["company_id" => config('constant.COMPANY_ID'),
                            "venue_id" => "295255", "stampid" => $value->id, "userID" => $user_id, "mrcht_id" => "0",
                            "stampassign" => $quantity, 'addStamps' => false, 'notify' => false, 'assign_through' => $through]);
                        //call
                        $response = (new ElasticSearchController())->stampCardAssign();
                    }


                }

            }
        }
        return true;
    }

    private function deleteCustomerFromBooking()
    {
        $booking_id = User::whereIn('user_id', request()->delete_ids)->whereNotNull('booking_engine_id')->pluck('booking_engine_id')->toArray();
        $response = (new Client([
            'headers' => [
                'Content-Type' => 'application/x-www-form-urlencoded',
                'SECRET-KEY' => config('constant.BOOKING_ENGINE_KEY'),
            ]
        ]))->request('POST', config('constant.BOOKING_ENGINE_URL') . 'api/delete-customer', array(
                'form_params' => [
                    'be_user_id' => implode(',', $booking_id),
                ]
            )
        )->getBody();
        Log::channel('custom')->info('User Delete From booking Engine', ['deleteCustomerFromBooking' => $response, 'data' => [
            'be_user_id' => implode(',', $booking_id),
        ]]);
        return $response;
    }

    private function getDays(string $receiptDate)
    {
        $sec = strtotime($receiptDate);
        //converts seconds into a specific format
        $newdate = date("Y-m-d", $sec);
        return Carbon::parse($newdate)->diffInDays();
    }


    public function testDates()
    {
        dd(json_encode('{"isDuplicate":true,"duplicateBlinkReceiptIds":["7811328B-2A01-4353-B88F-A17C6CEA7C82","6edf6d8e-5653-45cc-9781-590a72a81384","BA022E50-1316-4E63-B3FE-9B1B487EAD62","5375DA49-D7B9-4515-8FA9-DFD9D1684B41","5F1E1735-9E85-4F9C-8657-9CD628593657","B2B6BB5A-9988-4804-A3D7-32EC61C0CEF6"],"ereceiptAuthenticated":false,"subtotal":{"confidence":100,"value":366.4100036621094},"storePhone":{"confidence":98.92835998535156,"value":"031 573 9540"},"ocrConfidence":95.19308471679688,"total":{"confidence":98.98589324951172,"value":366.4100036621094},"receiptDate":{"confidence":98.08619689941406,"value":"06\/23\/2020"},"serverLookupsCompleted":true,"loyaltyProgram":false,"isFraudulent":false,"subtotalMatches":false,"productsPendingLookup":0,"taxId":{"confidence":98.94141387939453,"value":"4420106777"},"retailerId":10539,"foundBottomEdge":false,"products":[{"lineNumber":1003,"isVoided":false,"productNumber":{"confidence":100,"value":""},"productDescription":{"confidence":99,"value":"BDYLTN ABSRB 400"},"userAdded":false,"totalPrice":{"confidence":99,"value":44.9900016784668},"unitPrice":{"confidence":99,"value":44.9900016784668},"userModified":false,"quantity":{"value":1,"confidence":100},"isSensitive":false},{"isVoided":false,"lineNumber":1004,"userAdded":false,"productDescription":{"value":"CHECKOUT BAG CH","confidence":99},"productNumber":{"value":"","confidence":100},"additionalLines":[{"type":{"value":"Quantity","confidence":100},"lineNumber":1005,"text":{"confidence":100,"value":"2 @ 0.75 1.50"}}],"totalPrice":{"value":1.5,"confidence":99},"unitPrice":{"value":0.75,"confidence":99},"userModified":false,"quantity":{"value":2,"confidence":100},"isSensitive":false},{"lineNumber":1006,"isVoided":false,"productNumber":{"value":"","confidence":100},"productDescription":{"value":"DAY CRM J&J 50ML","confidence":98.95394897460938},"userAdded":false,"totalPrice":{"value":69.98999786376953,"confidence":99},"unitPrice":{"value":69.98999786376953,"confidence":99},"userModified":false,"quantity":{"value":1,"confidence":100},"isSensitive":false},{"lineNumber":1007,"isVoided":false,"productNumber":{"value":"","confidence":100},"productDescription":{"value":"JOKO TBAG 100S","confidence":99},"userAdded":false,"totalPrice":{"value":38.9900016784668,"confidence":99},"unitPrice":{"value":38.9900016784668,"confidence":99},"userModified":false,"quantity":{"value":1,"confidence":100},"isSensitive":false},{"lineNumber":1008,"isVoided":false,"productNumber":{"value":"","confidence":100},"productDescription":{"value":"KNORR BRWON 50G","confidence":99},"userAdded":false,"totalPrice":{"value":4.990000247955322,"confidence":99},"unitPrice":{"value":4.990000247955322,"confidence":99},"userModified":false,"quantity":{"value":1,"confidence":100},"isSensitive":false},{"lineNumber":1009,"isVoided":false,"productNumber":{"value":"","confidence":100},"productDescription":{"value":"LFBUOY TOTL 175G","confidence":99},"userAdded":false,"totalPrice":{"value":13.989999771118164,"confidence":99},"unitPrice":{"value":13.989999771118164,"confidence":99},"userModified":false,"quantity":{"value":1,"confidence":100},"isSensitive":false},{"lineNumber":1010,"isVoided":false,"productNumber":{"value":"","confidence":100},"productDescription":{"value":"NIVEA D\/CRM 50ML","confidence":98.88672637939453},"userAdded":false,"totalPrice":{"value":99.98999786376953,"confidence":99},"unitPrice":{"value":99.98999786376953,"confidence":99},"userModified":false,"quantity":{"value":1,"confidence":100},"isSensitive":false},{"lineNumber":1011,"isVoided":false,"productNumber":{"value":"","confidence":100},"productDescription":{"value":"RAJAH MED 100G","confidence":98.90946197509766},"userAdded":false,"totalPrice":{"value":23.989999771118164,"confidence":99},"unitPrice":{"value":23.989999771118164,"confidence":99},"userModified":false,"quantity":{"value":1,"confidence":100},"isSensitive":false},{"lineNumber":1012,"isVoided":false,"productNumber":{"value":"","confidence":100},"productDescription":{"value":"SNLGHT REG 750ML","confidence":98.95640563964844},"userAdded":false,"totalPrice":{"value":29.989999771118164,"confidence":99},"unitPrice":{"value":29.989999771118164,"confidence":99},"userModified":false,"quantity":{"value":1,"confidence":100},"isSensitive":false},{"lineNumber":1013,"isVoided":false,"productNumber":{"value":"","confidence":100},"productDescription":{"value":"SURF FLEXI 2KG","confidence":99},"userAdded":false,"totalPrice":{"value":37.9900016784668,"confidence":98.827392578125},"unitPrice":{"value":37.9900016784668,"confidence":98.827392578125},"userModified":false,"quantity":{"value":1,"confidence":100},"isSensitive":false}],"blinkReceiptId":"07081ABE-7559-42FF-BE12-F6C5F55D4887","merchantSources":[1,5],"merchantName":{"value":"Checkers","confidence":90},"foundTopEdge":true,"receiptTime":{"value":"11:45","confidence":98.08619689941406},"receipt_images":["\/var\/mobile\/Containers\/Data\/Application\/38466617-5672-4778-ACB9-A209AAFBA581\/Documents\/BlinkReceipt\/br_img_1614858753.jpg"],"soldi_id":225}'));
        $date = $this->getDays('06/23/2020');
        dd($date, (260 >= $date));

    }

    public function searchMemberDetail()
    {
        $postalCode = \request()->postal_code;
        $addresses=collect([]);
        if (\request()->has('postal_code')) {
            $addresses = UserAddresses::where('postal_code', \request()->postal_code)->get();
            foreach ($addresses as $key => $value) {
                $user = User::where('user_id', $value->user_id)->first();
                if ($user)
                    $addresses[$key]['users'] =$user;
            }

        }
        if (\request()->has('suburb')) {
            $addresses = UserAddresses::where('suburb','like','%'.request()->suburb.'%')->get();
            foreach ($addresses as $key => $value) {
                $user = User::where('user_id', $value->user_id)->first();
                if ($user)
                    $addresses[$key]['users'] =$user;
            }

        }
        return ['status' => true, 'data' => $addresses];
    }

    public function checkMaximumReceiptCount($receiptData,$user_id)
    {
        $data = ['status' => true];
        if ($this->max_scan > 0) {
            if ($receiptData !== '') {
                $res = DB::select("SELECT COUNT(id) AS rec_count FROM user_receipts WHERE user_id = '$user_id' AND JSON_UNQUOTE(JSON_EXTRACT(detail,'$.receiptDate.value')) = '$receiptData'");
                $rec_count = $res[0]->rec_count;
                if ($rec_count > $this->max_scan) {
                    $data['status'] = false;
                }
            }
        }
        return $data;
    }

}
