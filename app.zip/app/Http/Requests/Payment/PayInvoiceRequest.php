<?php

namespace App\Http\Requests\Payment;

use Illuminate\Foundation\Http\FormRequest;

class PayInvoiceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'invoice'=>'required',
            'authenticatedData.outcome'=>'required|string',
            'authenticatedData.transactionReference'=>'required|string',
            'authenticatedData.authentication.version'=>'required|string',
            'authenticatedData.authentication.authenticationValue'=>'required|string',
            'authenticatedData.authentication.eci'=>'required|string',
            'authenticatedData.authentication.transactionId'=>'required|string',
        ];
    }
}
