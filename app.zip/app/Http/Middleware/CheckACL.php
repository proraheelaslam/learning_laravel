<?php

namespace App\Http\Middleware;

use Closure;
use App\Helpers\ACLHelper;
use Illuminate\Contracts\Container\BindingResolutionException;
use Symfony\Component\HttpFoundation\Exception\SuspiciousOperationException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class CheckACL
{
    /**
     * 
     * @var ACLHelper
     */
    private $aclHelper;

    /**
     * Construct
     *
     * @param ACLHelper $aclHelper
     */
    public function __construct(ACLHelper $aclHelper)
    {
        $this->aclHelper = $aclHelper;
    }

    /**
     * 
     * @param mixed $request 
     * @param Closure $next 
     * @param string $aclList 
     * @param string $aclMode 
     * @return mixed 
     * @throws BindingResolutionException 
     * @throws SuspiciousOperationException 
     * @throws HttpException 
     * @throws NotFoundHttpException 
     */
    public function handle($request, Closure $next, $aclList = '', $aclMode = ACLHelper::ACL_MODE_WHITELIST)
    {
        // Apply default aclMode if the supplied aclMode is invalid
        if (!in_array($aclMode, ACLHelper::ACL_MODES)) {
            $aclMode = ACLHelper::ACL_MODE_WHITELIST;
        }

        // Explode ACL list from middleware into array
        $aclList = $aclList ? explode('|', $aclList) : [];
        $result = $this->aclHelper->checkACL($request->ip(), $aclList, $aclMode);
        if (!$result) {
            abort(403, 'Access is forbidden via ACL.');
        }

        return $next($request);
    }
}
