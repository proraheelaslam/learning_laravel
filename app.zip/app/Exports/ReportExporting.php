<?php


namespace App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
class ReportExporting implements FromCollection, ShouldAutoSize, WithHeadings
{
    private $voucherReport;

    public function __construct($voucher)
    {
        $this->voucherReport = collect($voucher);
    }

    /**
     * @return Collection
     */
    public function collection()
    {
        return $this->voucherReport;
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'Transaction Date',
            'Transaction ID',
            'Client ID',
            'Name',
            'Email',
            'Transaction Amount',
            'Discount',
            'Voucher Amount',
            'Voucher Discount Type',
        ];
    }
}