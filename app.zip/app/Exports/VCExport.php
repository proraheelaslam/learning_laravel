<?php
/**
 * Created by PhpStorm.
 * User: sadiq
 * Date: 5/31/2018
 * Time: 3:10 PM
 */

namespace App\Exports;

use App\User;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Events\AfterSheet;


class VCExport implements FromCollection, ShouldAutoSize,WithHeadings,WithEvents
{
    private $csvCollection;
    private $headings;

    public function __construct($members,$headings)
    {

        //$this->csvCollection = User::all();
        $this->csvCollection = collect($members);
        $this->headings = $headings;


    }
    /**
     * @return Collection
     */
    public function collection()
    {
        return $this->csvCollection;
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return $this->headings;
    }
    /**
     * @return array
     */
    public function registerEvents(): array
    {
        return [
            AfterSheet::class    => function(AfterSheet $event) {
                $cellRange = 'A1:W1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(12);
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setBold(true);
            },
        ];
    }

}