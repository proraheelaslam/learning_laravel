<?php

namespace App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;


class UserVoucherReports implements FromCollection, ShouldAutoSize, WithHeadings
{
    private $userCollection;

    public function __construct($users)
    {
        $this->userCollection = collect($users);
    }

    /**
     * @return Collection
     */
    public function collection()
    {
        return $this->userCollection;
    }

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'First Name',
            'Last Name',
            'Email',
            'Voucher Name',
            'Expiry',
        ];
    }
}
