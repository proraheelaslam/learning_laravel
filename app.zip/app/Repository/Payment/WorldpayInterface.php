<?php


namespace App\Repository\Payment;


interface WorldpayInterface
{
    /**
     * Make invoice
     * @param string $country
     * @param array $request
     * @return mixed
     */
    public function makeInvoice(string $country,array $request);

    /**
     * add new payment method
     * @param string $country
     * @param array $request
     * @return mixed
     */
    public function addPaymentMethod(string $country,array $request);

    /**
     * get list all payment method of access worldpay
     * todo: will be change to integrate others payment plugin
     * @param string $country
     * @return mixed
     */
    public function getListPayment(string $country);

    /**
     * Continuous to payment process after challenge
     * @param array $request
     * @return mixed
     */
    public function paymentAuthorized(array $request);

    /**
     * use to initial payment session with payment gate
     * @return mixed
     */
    public function initialDeviceSession();
}