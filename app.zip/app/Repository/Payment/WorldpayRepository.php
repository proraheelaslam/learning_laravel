<?php


namespace App\Repository\Payment;

use App\Exceptions\PaymentConfigException;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class WorldpayRepository implements WorldpayInterface
{
    private $headers = [];
    private $body = [];
    private $query = [];
    private $api;
    private $killBillId = null;

    public function __construct()
    {
        $this->api = new Client([
            'base_uri' => config('payment.killbill.url')
        ]);
    }

    /**
     * @description initial session for payment
     * @return \Illuminate\Http\JsonResponse
     */
    public function initialDeviceSession()
    {
        return $this->responseJson([
            'initialData' => $this->initial3DS()
        ]);
    }

    private function responseJson($data, int $status = 200, string $message = null)
    {
        $response['data'] = $data;
        $response['status'] = $status;
        if (isset($message) && !empty($message)) {
            $response['message'] = $message;
        }
        return response()->json($response);
    }

    private function initial3DS()
    {
        $pluginName = 'accessworldpay';
        $this->setBody([
            'deviceDataCollectionJWT'
        ]);
        $result = $this->makeRequest('POST', '/1.0/kb/paymentGateways/notification/' . $pluginName);
        return json_decode($result->data['responseBody']);
    }

    /**
     * @description set request body
     * @param array $body
     */
    public function setBody(array $body): void
    {
        $this->body = $body;
    }

    /**
     * @description make request
     * @param string $method
     * @param string $path
     * @param string $country
     * @return false|object
     * @throws PaymentConfigException
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function makeRequest(string $method, string $path, string $country = 'uk')
    {
        if (!config('payment.killbill.url')) {
            throw new PaymentConfigException('SYSERR: config kill bill url not found', 500);
        }

        $this->setHeaders($country);

        $requestOption = array();
        $requestOption['auth'] = ($country == 'uk') ? [config('constant.KILL_BILL_USER_NAME'), config('constant.KILL_BILL_PASSWORD')] : [config('constant.KILL_BILL_IRE_USER_NAME'), config('constant.KILL_BILL_IRE_PASSWORD')];
        if (!empty($this->headers)) {
            $requestOption['headers'] = $this->headers;
        }
        if (!empty($this->body)) {
            $requestOption['body'] = json_encode($this->body);
        }
        if (!empty($this->query)) {
            $requestOption['query'] = $this->query;
        }
        /**
         * uncomment when need to debug request
         */
//        $requestOption['debug']=true;
        $response = $this->api->request($method, $path, $requestOption);

        if ($response->getStatusCode() >= 200 && $response->getStatusCode() < 300) {
            $body = $response->getBody()->getContents();
            $this->resetRequest();
            if ($this->isJson($body)) {
                return (object)[
                    'headers' => $response->getHeaders(),
                    'status' => $response->getStatusCode(),
                    'data' => json_decode($body, true)
                ];
            }
            return (object)[
                'headers' => $response->getHeaders(),
                'status' => $response->getStatusCode(),
                'data' => $body
            ];
        }
        return false;
    }

    /**
     * set header for calling kill bill api
     * @TODO: need optimize
     * @param $country
     */

    private function setHeaders($country)
    {
        $appName = str_replace('engage-', '', config('constant.APP_NAME'));
        $this->headers = [
            'Content-Type' => 'application/json',
            'x-killbill-apikey' => ($country != 'ire') ? config('constant.KILL_BILL_APIKEY') : config('constant.KILL_BILL_IRE_APIKEY'),
            'x-killbill-apisecret' => ($country != 'ire') ? config('constant.KILL_BILL_SECRET') : config('constant.KILL_BILL_IRE_SECRET'),
            "x-killbill-createdby" => $appName
        ];
    }

    private function resetRequest()
    {
        $this->setBody([]);
        $this->setQuery([]);
    }

    /**
     * @description set request url query
     * @param array $query
     */
    public function setQuery(array $query): void
    {
        $this->query = $query;
    }

    private function isJson($string)
    {
        return is_string($string) && is_array(json_decode($string, true));
    }

    public function addPaymentMethod(string $country, array $request)
    {
        $this->setKillBillId($country);
        $this->setBody([
            "pluginName" => 'accessworldpay',
            'pluginInfo' => [
                "externalPaymentMethodId" => "external",
                "isDefaultPaymentMethod" => 'true',
                "properties" => [
                    [
                        "key" => "sessionHref",
                        "value" => $request['sessionHref'],
                        "isUpdatable" => true
                    ],
                    [
                        "key" => "cardHolderName",
                        "value" => $request['cardHolderName'],
                        "isUpdatable" => true
                    ]
                ]
            ]
        ]);
        $this->setQuery([
            'isDefault' => 'true',
            'payAllUnpaidInvoices' => 'false'
        ]);
        $this->makeRequest('POST', "/1.0/kb/accounts/{$this->killBillId}/paymentMethods");

        try {
            $result = $this->makeRequest('POST', "/1.0/kb/accounts/{$this->killBillId}/paymentMethods");
        } catch (PaymentConfigException $e) {
            return false;
        }
        if ($result && $result->status == 201) {
            return $this->responseJson([], 201, 'Add card success');
        }
    }

    /**
     *
     */
    private function setKillBillId($country = 'uk')
    {
        $currentUser = Auth::user();
        if (empty($currentUser->kill_bill_id)) {
            //killbill uk acount
            $kill_bill_id = $this->createKillBillAccount('uk', $currentUser);
            if ($kill_bill_id) {
                $this->disableAutoPayment($kill_bill_id);
                $currentUser->kill_bill_id = $kill_bill_id;
                $currentUser->save();
            }
        }
        if (empty($currentUser->kilbill_ire_id)) {
            //killbill ire account
            $kilbill_ire_id = $this->createKillBillAccount('ire', $currentUser);
            if ($kilbill_ire_id) {
                $this->disableAutoPayment($kilbill_ire_id);
                $currentUser->kilbill_ire_id = $kilbill_ire_id;
                $currentUser->save();
            }
        }

        $this->killBillId = $country != 'ire' ? $currentUser->kill_bill_id : $currentUser->kilbill_ire_id;
    }

    private function createKillBillAccount(string $country, $user)
    {
        /**
         * @todo: parse data from auth user
         */
        $this->setBody(
            [
                "name" => "john eric",
                "firstNameLength" => 9,
                "email" => "john_eric@plutuscommerce.net",
                "phone" => "(02) 435 6561",
                "currency" => "GBP",
                "billCycleDayLocal" => 1,
                "timeZone" => "UTC",
                "referenceTime" => "2019-05-21T08:47:06.931Z",
                "address2" => "2 Cherry Cottage The Green Milton Keynes",
                "postalCode" => "MK11 2PN"
            ]
        );
        try {
            $result = $this->makeRequest('POST', '/1.0/kb/accounts');
        } catch (PaymentConfigException $e) {
            return false;
        }
        if ($result && $result->status == 201) {
            $location = $result->headers['Location'];
            $locationArray = explode('/', $location[0]);
            return array_pop($locationArray);
        }
        return false;
    }

    /* ================================================================================
     * Below this line will be moved to other location and optimized code when possible
     * ================================================================================
     * */

    private function disableAutoPayment($killBillId)
    {
        $this->setBody([
            "00000000-0000-0000-0000-000000000001"
        ]);
        $this->makeRequest('POST', "/1.0/kb/accounts/{$$killBillId}/tags");
    }

    public function makeInvoice(string $country, array $request)
    {
        $this->setKillBillId();

        $this->setQuery([
            'autoCommit' => 'true'
        ]);
        $this->setBody([
            [
                'itemType' => 'EXTERNAL_CHARGE',
                'description' => $request['description'],
                'amount' => $request['amount']
            ]
        ]);

        $result = $this->makeRequest('POST', '/1.0/kb/invoices/charges/' . $this->killBillId);

        if (count($result->data) == 1) {
            /**
             * @note href":"https://try.access.worldpay.com/tokens/MTIzNDU2Nzg5MDEyMzQ1Ng", missing token @@ got that shit
             * step 1: authorize 3ds
             * @todo if authorized -> pay
             * @todo else response to client to authorized ->pay
             * @todo mark paid invoice
             */
            $authorizeData = $this->paymentAuthorize($result->data[0], $request);
            if ($authorizeData->isAuthorized) {
                $paymentData = [
                    'paymentMethodId' => $request['paymentMethodId'],
                    'invoice' => $result->data[0],
                    'authenticatedData' => $authorizeData->authorizeData
                ];
                return $this->payCreatedInvoice($paymentData);
            } else {
                $responseData = [
                    'isRequireChallenge' => 'true',
                    'paymentMethodId' => $request['paymentMethodId'],
                    'invoice' => $result->data[0],
                    'challengeData' => $authorizeData->authorizeData
                ];
                return $this->responseJson($responseData);
            }
        } else {
            /**
             * @todo: this step may have many invoice to chare so may make a discuss with PK team
             */
        }
    }

    /**
     * @description authorize payment method before charge to make sure 3ds will be implemented
     * @param $invoice
     * @param $request
     * @return object|string
     * @throws PaymentConfigException
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    private function paymentAuthorize($invoice, $request)
    {
        $initial = $this->initial3DS();
        $this->setBody([
            "operation" => "customers3dsAuthentication",
            "transactionReference" => $initial->transactionReference,
            "href" => $request['href'],
            "amount" => $invoice['amount'],
            "currency" => $invoice['currency'],
            "collectionReference" => $request['collectionReference'],
            "returnUrl" => $request['returnUrl'] //will change to env
        ]);
        $response = $this->makeRequest('POST', '/1.0/kb/paymentGateways/notification/accessworldpay');
        switch ($response->data['status']):
            case 'challenged':
                return (object)[
                    'isAuthorized' => false,
                    'authorizeData' => json_decode($response->data['responseBody'])
                ];
            case 'authenticated' || 'bypassed':
                return (object)[
                    'isAuthorized' => true,
                    'authorizeData' => json_decode($response->data['responseBody'])
                ];
            default:
                /**
                 * may be throw exception from there
                 */
                return 'failed';
        endswitch;
    }

    private function payCreatedInvoice($request)
    {
        $invoice = $request['invoice'];
        $authenticatedData = $request['authenticatedData'];
        /**
         * start pay
         */
        $this->setBody([
            'accountId' => $this->killBillId,
            'paymentMethodId' => $request['paymentMethodId'],
            'targetInvoiceId' => $invoice['invoiceId'],
            'purchasedAmount' => $invoice['amount'],
            'paymentId' => $authenticatedData['authentication']['transactionId']
        ]);

        $response = $this->makeRequest('POST', "/1.0/kb/invoices/{$invoice['invoiceId']}/payments");
        Log::info('[Payment]Finish Payment Process Response',[
            'data'=>$response
        ]);
        /*
         * todo: check response and fix that code
         */
        return true;
    }

    public function paymentAuthorized(array $request)
    {
        $verifiedData = $this->paymentVerify($request);
        if ($verifiedData) {
            $request['authenticatedData'] = $verifiedData;
        }
        if ($request['authenticatedData']['outcome'] != 'authenticated' && $request['authenticatedData']['transactionReference'] == 'unique-transactionReference') {
            return $this->responseJson([], 406, 'Payment failed');
        }
        if($this->payCreatedInvoice($request)){
            return $this->responseJson([],200,'Payment success!');
        }
        return $this->responseJson([],406,'Payment failed!');
    }

    private function paymentVerify($request)
    {
        $this->setBody([
            'operation' => 'challengeVerification',
            'transactionReference' => $request['transactionReference'],
            'challengeReference' => $request['challengeReference'],
        ]);
        $result = $this->makeRequest('POST', '/1.0/kb/paymentGateways/notification/accessworldpay');
        if ($result->status >= 200 and $result->status < 300) {
            return $result->data;
        }
        return false;
    }

    public function getListPayment(string $country)
    {
        $this->setKillBillId($country);
        $this->query = [
            'withPluginInfo' => 'true'
        ];

        $response = $this->makeRequest('GET', "/1.0/kb/accounts/{$this->killBillId}/paymentMethods");

        if ($response->status == 200) {
            if (count($response->data) > 0) {
                $paymentList = collect($response->data);
                $paymentList = $paymentList->map(function ($item, $key) {
                    $current = $item;
                    if (is_array($current['pluginInfo']) && count($current['pluginInfo']) >= 1) {
                        foreach ($current['pluginInfo']['properties'] as $key => $property) {
                            if ($this->isJson($property['value'])) {
                                $decodedProperty = json_decode($property['value'], true);
                                $current['pluginInfo']['properties'][$key]['value'] = $decodedProperty;
                            }
                        }
                    }
                    return $current;
                })->filter(function ($item, $key) {
                    return $item['pluginName'] == 'accessworldpay';
                })->all();
                return $this->responseJson($paymentList, $response->status);
            }
            return $this->responseJson($response->data, $response->status, "Haven't added card before!");
        }
        return abort(404, 'not found user');

    }
}