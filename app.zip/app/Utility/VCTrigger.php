<?php


namespace App\Utility;

use App\Http\Controllers\API\VisualCampaignController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class VCTrigger
{
    private $VC_URL;

    public function __construct()
    {
        $this->VC_URL  = config('constant.VC_URL');

    }//..... end of __construct() .....//

    public function callVCTrigger($data = [],$trigger_type = "") {
        if(isset($this->VC_URL) and $this->VC_URL != "") {
            try {
                $trigger_name = "Event Trigger";
                //$trigger_type = "$.survey_trigger";
                Log::channel('custom')->info('trigger_type', ['trigger_type' => $trigger_type]);
                $components = DB::select("SELECT * FROM vc_triggers WHERE NAME = '$trigger_name' AND JSON_UNQUOTE(JSON_EXTRACT(trigger_type,'$trigger_type')) = 'configured'");


                //$components = \Illuminate\Support\Facades\DB::table('vc_triggers')->where('name','Event Trigger')->get();
                foreach ($components as $component) {
                    $path = "trigger/event/".$component->id;
                    (new VisualCampaignController())->triggerVS($data,$path);
                }
            }
            catch (\Exception $e) {
                Log::channel('custom')->info('trigger_error', ['message' => $e->getMessage(),'line' => $e->getLine()]);
            }
        }
    }




}//..... end of VCTrigger class