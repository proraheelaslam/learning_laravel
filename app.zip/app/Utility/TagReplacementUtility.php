<?php
/**
 * Created by PhpStorm.
 * User: sadiq
 * Date: 2/27/19
 * Time: 9:59 AM
 */

namespace App\Utility;


use App\Models\EmailTemplate;
use App\Models\SurveyFront;
use App\Models\SurveyQuestionAnswers;
use App\Models\SurveyQueue;
use App\models\User;
use App\Models\Venue;
use App\Models\Voucher;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class TagReplacementUtility
{
    private $demographicData = [];
    private $refferedUser = [];

    private $userData = [];
    private $VenueId;
    private $UserID;
    private $selected_venue;
    private $custom_fields;
    private $custom_fields_values;
    private $template_tags;
    private $survey = null;
    private $voucherData = null;





    public function generateTagText($message,$venue_id,$user_id,$template_id=0,$survey_id=0,$survey_answers = [],$voucher_id = 0,$json_csv = [],$queue_data = [],$unique = 'email')
    {

        $this->VenueId = $venue_id;
        $this->UserID = $user_id;
        $fields = DB::table("user_custom_field")->where('venue_id', request()->venue_id)->get();

        $this->survey = SurveyFront::where('id',$survey_id)->first();

        $this->voucherData = Voucher::where('id',$voucher_id)->first();

        if ($fields)
            $this->customFields = $fields;


        $this->userData = DB::table("users")->where(["user_id"=>$user_id])->get();


        $this->refferedUser = DB::table("users")->where(["referal_by" => $this->userData[0]->referal_by ?? 0])->get();

        $selected_venue =$this->selected_venue= Venue::where('id',$this->VenueId)->get()->toArray();
        $this->custom_fields = $this->customFields;


        $this->custom_fields_values = DB::table("user_custom_field_data")->where(["user_id"=>$user_id])->get();

        $template = EmailTemplate::whereId($template_id)->first();

        if(!empty($template)){
            $this->template_tags = (!empty($template->tag_values)) ? json_decode($template->tag_values,true) : [];
        }




        $str = $message;




        try {
            $re = '/\|(.*?)\|/';

            preg_match_all($re, $str, $matches, PREG_SET_ORDER, 0);
            $indexName = Config::get('constant.ES_INDEX_BASENAME');
            if (is_array($matches) && count($matches) > 0) {
                foreach ($matches as $key => $rs) {
                    if (is_array($rs) && isset($rs[0])) {
                        // to Check if Tag is POS OR Barrel with POS:POSID
                        $chk = explode(":", $rs[0]);

                        $field_name = str_replace("|" , "",$rs[0] );


                        $is_template_tag = $this->template_tags[$field_name] ?? false;
                        if($is_template_tag){
                            $str = str_replace($chk[0], $is_template_tag ?? "", $str);
                            continue;
                        }





                        //check for meta tags
                        if(strpos($chk[0], 'meta_') !== false) {

                            //check if it is csv data
                            if(count($queue_data) > 0) {
                                $queue_data_coll = collect($queue_data);
                                $field_name = str_replace("|" , "",$chk[0]);
                                $found = $queue_data_coll->where($unique,$this->userData[0]->$unique)->first();
                                if($found) {
//                                    Log::channel('custom')->info('sendEmailVS_req', ['$found' => gettype($found)]);
//                                    Log::channel('custom')->info('sendEmailVS_req', ['foundfield_name' => $found->meta_test]);
//                                    Log::channel('custom')->info('sendEmailVS_req', ['$field_name' => $field_name]);
                                    //Log::channel('custom')->info('sendEmailVS_req', ['foundfield_name' => $found[$field_name]]);

                                    $str = str_replace($chk[0], $found[$field_name] ?? "", $str);
                                }
                            }
                            else {
                                $survey_queue = SurveyQueue::where(['survey_id' => $survey_id,'user_id' => $user_id])->first();
                                if($survey_queue) {
                                    if(isset($survey_queue->meta)) {
                                        //remove "|"
                                        $field_name = str_replace("|" , "",$chk[0]);
                                        $meta = json_decode($survey_queue->meta,true);
                                        if(isset($meta[$field_name])) {
                                            $str = str_replace($chk[0], $meta[$field_name] ?? "", $str);
                                        }
                                    }
                                }
                            }


                            continue;
                        }



                        $getESType = $this->getESTypeByTagName($chk[0]);

                        $getFieldDetail = $this->getFieldNameByTag(str_replace('|', "", $chk[0]));



                        if (empty($getFieldDetail)) continue;

                        if (empty($getFieldDetail)) continue;



                        if($getESType == 'survey') {
                            
                            $field = $getFieldDetail["field"];

                            if($field == 'name') {
                                if($this->survey) {
                                    $survey_name = $this->survey->title;
                                    $str = str_replace($chk[0], $survey_name, $str);
                                }

                            }
                            if($field == 'url') {
                                $user_id = $this->userData[0]->user_id;
                                $survey_id = $this->survey ? $this->survey->id : 0;
                                if($user_id > 0 and $survey_id > 0) {
                                    $query_string = "$user_id&$survey_id";
                                    $encrype = Crypt::encrypt($query_string);

                                    $survey_url = url('/get-survey')."?token=$encrype";

                                    Log::channel('custom')->info('$survey_url', ['$survey_url' => $survey_url]);

                                    //shorten the url
                                    $endpoint = config('constant.URL_SHORTNER_LINK');
                                    $key = config('constant.URL_SHORTNER_KEY');
                                    if(isset($endpoint) and isset($key)) {
                                        try {
                                            $res = (new Client())->request('GET', $endpoint . "?key=". $key."&short=". $survey_url)->getBody()->getContents();
                                            $res = json_decode($res);
                                            Log::channel('custom')->info('cutly_res', ['cutly_res' => $res]);
                                            if($res->url->shortLink) {
                                                $str = str_replace($chk[0], $res->url->shortLink, $str);
                                            }
                                            
                                        } catch (ClientException $e) {
                                            $responseData = json_decode($e->getResponse()->getBody(),true);
                                            Log::channel('custom')->info('cuttly_error', ['cuttly_error' => $responseData]);
                                            $str = str_replace($chk[0], $survey_url, $str);
                                        }
                                    }
                                    else {
                                        $str = str_replace($chk[0], $survey_url, $str);
                                    }
                                }


                            }
                            if($field == 'SurveyReminderUnsubscribeUrl') {
                                $user_id = $this->userData[0]->user_id;
                                if($user_id > 0) {
                                    $query_string = "$user_id";
                                    $encrype = Crypt::encrypt($query_string);

                                    $survey_url = url('/unsubscribe-reminder')."?user_id=$encrype";
                                    //shorten the url
                                    $endpoint = config('constant.URL_SHORTNER_LINK');
                                    $key = config('constant.URL_SHORTNER_KEY');
                                    if(isset($endpoint) and isset($key)) {
                                        try {
                                            $res = (new Client())->request('GET', $endpoint . "?key=". $key."&short=". $survey_url)->getBody()->getContents();
                                            $res = json_decode($res);
                                            if($res->url->shortLink) {
                                                $str = str_replace($chk[0], $res->url->shortLink, $str);
                                            }

                                        } catch (ClientException $e) {
                                            $responseData = json_decode($e->getResponse()->getBody(),true);
                                            Log::channel('custom')->info('cuttly_error', ['cuttly_error' => $responseData]);
                                            $str = str_replace($chk[0], $survey_url, $str);
                                        }
                                    }
                                    else {
                                        $str = str_replace($chk[0], $survey_url, $str);
                                    }
                                }
                            }
                            if($field == 'SurveyAnswers') {
                                if(count($survey_answers) > 0) {

                                    //check if contact me question exists
                                    $json_data = json_decode($this->survey->json);


                                    $contact_ans = $this->getCommentQuestion($json_data,$survey_answers);
                                    Log::channel('custom')->info('$contact_ans', ['$contact_ans' => $contact_ans]);




                                    $html = "<div class='collapse_answers'><button>Show Survey</button></div><div class='answers_container'>";
//                                    if($contact_ans == "Yes") {
//                                        $html = "<div class='collapse_answers'><button>Show Survey</button></div><div class='answers_container'>";
//                                    }
//                                    else {
//                                        $html = "<div class='alert alert-danger custom_alert_' role='alert'> This user doesn't want to be contacted</div><div class='collapse_answers'><button>Show Survey</button></div><div class='answers_container'>";
//                                    }

                                    if($contact_ans == "No") {

                                        $html = "<div class='alert alert-danger custom_alert_' role='alert'> This customer doesn't want to be contacted</div><div class='collapse_answers'><button>Show Survey</button></div><div class='answers_container'>";
                                   
                                    }

                                    foreach ($survey_answers as $survey_answer) {
                                        $question = $survey_answer['question'];

                                        //replace question tags
                                        $survey_queue = SurveyQueue::where(['user_id' => $user_id,'survey_id' => $survey_id])->first();
                                        if($survey_queue) {
                                            $json_csv = isset($survey_queue->csv_data) ? json_decode($survey_queue->csv_data,true): [];
                                            $new_question = (new TagReplacementUtility())->generateTagText($question,0,$user_id,0,$survey_id,[],0,$json_csv);
                                            $question = $new_question;
                                        }


                                        $ques_answer = "Question : "."$question"."<br>";
                                        $ans_str = "";
                                        //check for array
                                        if(is_array($survey_answer['answer'])) {
                                            foreach ($survey_answer['answer'] as $key => $value) {
                                                if(is_numeric($key)) {
                                                    $ans_str = implode(", ",$survey_answer['answer']);
                                                    break;
                                                }
                                                else {
                                                    //it is multi array
                                                    $ans_str .= $key.": ".$value."<br>";
                                                }
                                            }
                                        }
                                        else {
                                            $ans_str = $survey_answer['answer'];
                                        }

                                        $ques_answer .= "Answer: "."<strong>$ans_str</strong>"."<br><br>";
                                        $html .= $ques_answer;
                                    }

                                    $html .= "</div>";
                                    $str = str_replace($chk[0], $html, $str);
                                }
                            }




                            if($field == 'Product') {
                                if(isset($json_csv['Product'])) {
                                    $str = str_replace($chk[0], $json_csv['Product'], $str);
                                }
                            }
                            if($field == 'StoreName') {
                                if(isset($json_csv['StoreName'])) {
                                    $str = str_replace($chk[0], $json_csv['StoreName'], $str);
                                }
                            }
                            if($field == 'TransactionNumber') {
                                if(isset($json_csv['TransactionNumber'])) {
                                    $str = str_replace($chk[0], $json_csv['TransactionNumber'], $str);
                                }
                            }

                        }

                        if ($getESType == 'venue') {

                            //get user store name
//                            $this->userData[0]->s
                            if ($selected_venue) {
                                $str = str_replace($chk[0], $selected_venue[0][$getFieldDetail["field"]] ?? "", $str);

                            }

                            continue;
                        }

                        if($getESType == "custom_fields"){
                            $field_type = $this->getFieldType($getFieldDetail["field"]);
                            $field_id = $this->getFieldId($getFieldDetail["field"]);




                            $replace_value = "";
                            if($field_type == "boolean"){
                                $replace_value = ($this->getUserCustomFieldValue($this->UserID,$field_id) == true) ? "true" : "false";
                            }else if($field_type == "date"){

                                $replace_value = $this->getUserCustomFieldValue($this->UserID,$field_id);


                                //$replace_value = $this->custom_fields[$getFieldDetail["field"]];
                                $replace_value = date("d M Y",strtotime($replace_value));
                            }
                            else if($field_type == "datetime"){
                                $replace_value = $this->getUserCustomFieldValue($this->UserID,$field_id);

                                //$replace_value = $this->custom_fields[$getFieldDetail["field"]];
                                $seconds = $replace_value / 1000;

                                $replace_value = date("d M Y H:i:s",($seconds));

                            }
                            else if($field_type == "dropdown"){
                                $value_data = $this->getUserCustomFieldValue($this->UserID,$field_id);
                                if(!empty($value_data)){
                                    $value_data = json_decode($value_data,true);
                                }

                                //$value_data = ($this->custom_fields[$getFieldDetail["field"]]);

                                foreach ($value_data as $key33 => $value33 ){

                                    $replace_value = $replace_value .$value33.", ";
                                }


                            }else{
                                $replace_value = $this->getUserCustomFieldValue($this->UserID,$field_id);
                            }

                            if(!empty($replace_value))
                                $str = str_replace($chk[0], $replace_value ?? "", $str);
                        }



                        $this->getESDataByQuery($indexName, $getESType);


                        $getData = $this->getReplaceTagValue($getFieldDetail,$getESType);


                        if ($getData) {
                            $str = str_replace($chk[0], $getData, $str);
                        }else{
                            $str = str_replace($chk[0], "", $str);
                        }

                    }
                }
                return $str;
            } else {
                return $str;
            }
        } catch (\Exception $e){
            Log::channel('custom')->info('generateTag_error', ['generateTag_error' => $e->getMessage(),'line' => $e->getLine()]);
            return $str;
        }
    }

    function getESTypeByTagName($tag)
    {
        Log::channel('custom')->info('$tag', ['$tag' => $tag]);
        if ($tag == '|NameTitle|' || $tag == '|FirstName|' || $tag == '|MiddleInitial|' || $tag == '|OtherName|' ||
            $tag == '|MembershipId|' || $tag == '|ExpiryDatetime|' || $tag == '|Id|' || $tag == '|MembershipTypeId|'
            || $tag == '|Status|' || $tag == '|RatingGradeId|' || $tag == '|HomeTelephone|'
            || $tag == '|Mobile|' || $tag == '|Country|' || $tag == '|PostalCode|' || $tag == '|Locality|'
            || $tag == '|PostalAddress1|' || $tag == '|ResPostalCode|' || $tag == '|ResLocality|'
            || $tag == '|ResStateProvince|' || $tag == '|LastName|'
            || $tag == '|ResAddress1|' || $tag == '|WorkTelephone|' || $tag == '|CreationDatetime|' || $tag == '|Email|' || $tag == '|ContactOnEmail|' || $tag == '|ContactOnMobile|' || $tag == '|ContactOnMail|' ||$tag =='|Facebook|' || $tag =='|Twitter|' || $tag =='|Instagram|'
            || $tag == '|RefreeName|' || $tag == '|ReferredUser|' || $tag == '|ReferralCode|'|| $tag == '|ActivationCode|'|| $tag == '|date|'|| $tag == '|month|'|| $tag == '|year|'|| $tag == '|VenueNameDesign|'
            || $tag =='|VenueAddressDesign|' || $tag =='|VenuePhoneNumber|'|| $tag =='|discount|'|| $tag =='|DiscountPrice|'|| $tag =='|Discount|'

        ) {
            return 'demographic';
        } else if ($tag == '|Balance|') {
            return 'account_balance';
        }else if ($tag == '|ReferralCode|') {
            return 'referral_code';
        }else if ($tag == '|ActivationCode|') {
            return 'activation_code'; // routing query
        }else if ($tag == '|RefreeName|' || $tag == '|ReferredUser|') {
            return 'persona_fname'; // routing query
        } else if ($tag == '|POS|') {
            return 'pos_transaction_item'; // routing query
        } else if ($tag == '|PointTypeId|') {
            return 'point_type_summary'; // routing query
        } else if ($tag == '|BarrelDraw|') {
            return 'barrel_draw'; // routing query
        } else if ($tag == '|TicketCount|') {
            return 'barreldraw_ticket_summary'; // routing query
        } else if ($tag == '|MycashExpiry|' || $tag == '|MycashBalance|') {
            return 'cash_balance'; // routing query
        } else if ($tag == '|LastGamePlay|') {
            return 'member_egm_transaction'; // routing query
        } else if ($tag == '|LastPOSEntry|') {
            return 'pos_sale'; // routing query
        } else if ($tag == '|LastKioskEntry|') {
            return 'kiosk_transaction'; // routing query
        } else if ($tag == '|LastVisit|') {
            return 'visitation'; // routing query
        } else if($tag == '|SurveyName|' || $tag == '|SurveyUrl|' || $tag == '|SurveyReminderUnsubscribeUrl|' || $tag == '|SurveyAnswers|'
            || $tag == '|Product|' || $tag == '|StoreName|' || $tag == '|TransactionNumber|' || $tag == '|SurveyLogo|') {
            return 'survey';
        }
        else if($tag == '|VoucherDescription|') {
            return 'voucher';
        }
        else if($tag == '|MembershipNumber|' || $tag == '|MembershipType|') {
            return 'user';
        }
        else if($tag == '|PointBalance|' || $tag == '|AvailablePoints|' || $tag ==  '|StampsBalance|') {
            return 'loyalty';
        }
        else if($tag == '|REFERLINK|' || $tag == '|REFERRED_NAME|') {

            return 'referred';
        }
        /*else if(Str::is('|custom_*', $tag)){
            foreach ($this->custom_fields as $key => $value){
                if ($tag == "|custom_$key|") {

                    return $key; // routing query

                }
            }
        }*/

        if(Str::is('|custom_*', $tag)){
            return "custom_fields";
        }

        return 'venue';
    }//...... end of function getESTypeByTagName() .....//



    public function getCommentQuestion($json_data,$survey_answers) {
        $question = "";
        if(isset($json_data)) {
            if(isset($json_data->pages)) {
                foreach ($json_data->pages as $page) {
                    foreach($page->elements as $data) {
                        //if this question has comment then return question name
                        if(isset($data->commentText)) {
                            if($data->commentText == 'ContactMe') {
                                $question = $data->title;

                            }
                        }
                    }
                }
            }
        }
        $answer = "";
        if($question != "") {
            //get get question answer from user answers
            foreach ($survey_answers as $survey_answer) {
                if($survey_answer['question'] == $question) {
                    $answer = $survey_answer['answer'];
                    break;
                }
            }
        }
        return $answer;
    }

    //......  get filed name by tag ......//
    function getFieldNameByTag($key)
    {

        $array = [
            'NameTitle'             => ['field' => 'name_title', 'fieldType' => 'string'],
            'FirstName'             => ['field' => 'persona_fname', 'fieldType' => 'string'],
            'LastName'              => ['field' => 'persona_lname', 'fieldType' => 'string'],
            'RefreeName'              => ['field' => 'persona_fname', 'fieldType' => 'string'],
            'ReferredUser'          => ['field' => 'persona_fname', 'fieldType' => 'string'],
            'ReferralCode'          => ['field' => 'referral_code', 'fieldType' => 'string'],
            'ActivationCode'          => ['field' => 'activation_code', 'fieldType' => 'string'],
            'MiddleInitial'         => ['field' => 'middle_initial', 'fieldType' => 'string'],
            'OtherName'             => ['field' => 'other_name', 'fieldType' => 'string'],

            'Balance'               => ['field' => 'balance', 'fieldType' => 'integer'],
            'MembershipId'          => ['field' => 'membership_id', 'fieldType' => 'integer'],
            'year'          => ['field' => 'year', 'fieldType' => 'integer'],
            'month'          => ['field' => 'month', 'fieldType' => 'integer'],
            'date'          => ['field' => 'date', 'fieldType' => 'integer'],
            'ExpiryDatetime'        => ['field' => 'expiry_datetime', 'fieldType' => 'date'],
            'Id'                    => ['field' => '_routing', 'fieldType' => 'integer'],
            'MembershipTypeId'      => ['field' => 'membership_type_id', 'fieldType' => 'integer'],
            'Status'                => ['field' => 'status', 'fieldType' => 'string'],
            'RatingGradeId'         => ['field' => 'rating_grade_id', 'fieldType' => 'integer'],
            'PointTypeId'           => ['field' => 'point_type_id', 'fieldType' => 'integer'],
            'TicketCount'           => ['field' => 'ticket_count', 'fieldType' => 'integer'],

            'Email'                 => ['field' => 'persona_email', 'fieldType' => 'string'],
            'HomeTelephone'         => ['field' => 'phone_numbers', 'fieldType' => 'integer'],
            'Mobile'                => ['field' => 'phone_numbers', 'fieldType' => 'integer'],
            'ContactOnEmail'        => ['field' => 'email_subscribed_flag', 'fieldType' => 'string'],
            'ContactOnMobile'       => ['field' => 'sms_subscribed_flag', 'fieldType' => 'string'],
            'ContactOnMail'         => ['field' => 'mail_subscribed_flag', 'fieldType' => 'string'],
            'Country'               => ['field' => 'residential_address.country', 'fieldType' => 'string'],
            'PostalCode'            => ['field' => 'postal_address.postal_code', 'fieldType' => 'integer'],
            'Locality'              => ['field' => 'residential_address.suburb', 'fieldType' => 'string'],
            'PostalAddress1'        => ['field' => 'postal_address.address_1', 'fieldType' => 'string'],
            'ResPostalCode'         => ['field' => 'residential_address.postal_code', 'fieldType' => 'string'],
            'ResLocality'           => ['field' => 'residential_address.suburb', 'fieldType' => 'string'],
            'ResStateProvince'      => ['field' => 'residential_address.state', 'fieldType' => 'string'],
            'ResAddress1'           => ['field' => 'residential_address.address_1', 'fieldType' => 'string'],
            'WorkTelephone'         => ['field' => 'phone_numbers.work_phone', 'fieldType' => 'integer'],

            'VenueAddress'          => ['field' => 'address', 'fieldType' => 'string'],
            'VenueName'             => ['field' => 'venue_name', 'fieldType' => 'string'],
            'VenuePhoneNo'          => ['field' => 'telephone', 'fieldType' => 'integer'],
            'VenuePhoneNumber'      => ['field' => 'telephone', 'fieldType' => 'integer'],

            'LastVisit'             => ['field' => 'date_added', 'fieldType' => 'date'],
            'LastPOSEntry'          => ['field' => 'sale_datetime', 'fieldType' => 'date'],
            'LastKioskEntry'        => ['field' => 'entry_datetime', 'fieldType' => 'date'],
            'LastGamePlay'          => ['field' => 'transaction_datetime', 'fieldType' => 'date'],
            'CreationDatetime'      => ['field' => 'creation_datetime', 'fieldType' => 'date'],

            'MycashExpiry'          => ['field' => 'latest_transaction_date_time', 'fieldType' => 'string'],
            'MycashBalance'         => ['field' => 'balance', 'fieldType' => 'integer'],

            'POS'                   => ['field' => 'item_description', 'fieldType' => 'string'],
            'BarrelDraw'            => ['field' => 'description', 'fieldType' => 'string'],


            'VenueNameDesign'       => ['field' => 'venue_name', 'fieldType' => 'string'],
            'VenueAddressDesign'    => ['field' => 'address', 'fieldType' => 'string'],
            'discount'              => ['field' => 'discount', 'fieldType' => 'string'],
            'DiscountPrice'         => ['field' => 'DiscountPrice', 'fieldType' => 'string'],
            'Discount'              => ['field' => 'Discount', 'fieldType' => 'string'],

            'facebook'              => ['field' => 'facebook_id', 'fieldType' => 'string'],
            'twitter'               => ['field' => 'twitter_id', 'fieldType' => 'string'],
            'instagram'             => ['field' => 'instagram_id', 'fieldType' => 'string'],
            'SurveyName'             => ['field' => 'name', 'fieldType' => 'string'],
            'SurveyUrl'             => ['field' => 'url', 'fieldType' => 'string'],
            'SurveyReminderUnsubscribeUrl'  => ['field' => 'SurveyReminderUnsubscribeUrl', 'fieldType' => 'string'],
            'SurveyAnswers'  => ['field' => 'SurveyAnswers', 'fieldType' => 'string'],
            'SurveyLogo'  => ['field' => 'SurveyLogo', 'fieldType' => 'string'],
            'Product'  => ['field' => 'Product', 'fieldType' => 'string'],
            'StoreName'  => ['field' => 'StoreName', 'fieldType' => 'string'],
            'TransactionNumber'  => ['field' => 'TransactionNumber', 'fieldType' => 'string'],
            'PointBalance'  => ['field' => 'PointBalance', 'fieldType' => 'string'],
            'AvailablePoints'  => ['field' => 'AvailablePoints', 'fieldType' => 'string'],
            'StampsBalance'  => ['field' => 'StampsBalance', 'fieldType' => 'string'],

            'VoucherDescription'  => ['field' => 'promotion_text', 'fieldType' => 'string'],
            'MembershipNumber'  => ['field' => 'client_customer_id', 'fieldType' => 'string'],
            'MembershipType'  => ['field' => 'groups', 'fieldType' => 'string'],
            'REFERLINK' => ['field' => 'REFERLINK', 'fieldType' => 'string'],
            'REFERRED_NAME' => ['field' => 'REFERRED_NAME', 'fieldType' => 'string'],
        ];

        foreach ($this->custom_fields as $key2 => $value2){
            $array["custom_".$value2->field_name] = ['field' => $value2->field_name, 'fieldType' => 'string'];
        }




        return (array_key_exists($key, $array)) ? $array[$key] : '';
    }//...... End of function getFieldNameByTag()  ......//

    //...... get user information from elastic search ......//
    function getEsDataByQuery($indexName,$getESType){

        if(empty($this->demographicData)){
            $q = [
                "query"=> [
                    "bool"=>[
                        "must"=>[
                            [
                                "term"=>[
                                    "persona_id"=> [
                                        "value"=> $this->UserID
                                    ]
                                ]
                            ],
                            [
                                "term"=>[
                                    "custom_doc_type"=> "demographic"
                                ]
                            ]

                        ]
                    ]
                ]
            ];
            $this->demographicData = ElasticsearchUtility::getSource($indexName,$q);


        }

        return $this->demographicData;
    }//.....  end of function getEsDataByQuery()  ......//

    //..... set different type of user data global to Optimize performance  .....//
    private function getReplaceTagValue($getFieldDetail,$getESType){

        Log::channel('custom')->info('tag_detail', ['$getFieldDetail' => $getFieldDetail,'$getESType' => $getESType]);

        $field = $getFieldDetail["field"];

        if($getESType == "demographic"){
            return  $this->getDemoGraphicData($field);
        }
        else if($getESType == "voucher") {
            return $this->getVoucherData($field);
        }
        else if($getESType == 'user') {
            return $this->getUserData($field);
        }
        else if($getESType == 'loyalty') {
            return $this->getLoyaltyData($field);
        }
        else if($getESType == 'survey') {
            return $this->getSurveyData($field);
        }
        else if($getESType == 'referred') {
            return $this->getReferData($field);
        }
        else {
            return "";
        }

    }//......  end of function getReplaceTagValue()  ......//


    private function getReferData($field) {
        $req_data = request()->all();
        if(isset($req_data['referred_data'])) {
            $refer_data = $req_data['referred_data'];
            Log::channel('custom')->info('here', ['$refer_data' => $refer_data]);
            switch ($field) {
                case "REFERLINK":
                    if(isset($refer_data['refer_link'])) {
                        return $refer_data['refer_link'];
                    }
                    return  false;
                case "REFERRED_NAME":
                    if(isset($refer_data['referred_name'])) {
                        return $refer_data['referred_name'];
                    }
                    return false;
                default:
                    return false;
            }
        }
    }

    private function getUserData($field) {
        switch ($field) {
            case "client_customer_id":
                return isset($this->userData[0]) ? $this->userData[0]->client_customer_id : false;
            case "groups":
                if(isset($this->userData[0])) {
                    if($this->userData[0]->groups != null and $this->userData[0]->groups != "") {
                        $groups = json_decode($this->userData[0]->groups);
                        return count($groups) > 1 ? $groups[1] : $groups[0];
                    }
                }
                return false;
            default:
                return false;
        }
    }
    private function getLoyaltyData($field) {
        switch ($field) {
            case "PointBalance":
                //add points in req object
                if(\request()->points) {
                    $user_points =  \request()->points;
                } else {
                    $user_points =  DB::table('lt_transations')->where('user_id',$this->userData[0]->user_id)->orderByDesc('lt_transation_id')->first();
                    $user_points = $user_points ? (int) $user_points->value_points : 0;
                }
               return (int) $user_points;
            case "AvailablePoints":
                $user_points =  DB::table('lt_transations')->where('user_id',$this->userData[0]->user_id)->sum('value_points');
                return $user_points;

            case "StampsBalance":
                $user_stamps = (request()->stamps) ? request()->stamps : '';
                return (int)$user_stamps;

            default:
                return false;
        }
    }
    private function getSurveyData($field) {
        switch ($field) {
            case "SurveyLogo":
                if($this->survey) {
                    $json_arr = json_decode($this->survey->json,true);
                    if(isset($json_arr['logo'])) {
                        if((is_file(public_path($json_arr['logo']))) && (file_exists(public_path($json_arr['logo'])))){
                            $log_url = url('/').'/'.$json_arr['logo'];
                            //return '<img src='.$log_url.' />';
                            return $log_url;
                        }
                    }
                }
                return false;
            default:
                return false;
        }
    }
    private function getVoucherData($field) {
        switch ($field){
            case "promotion_text":
                return isset($this->voucherData) ? $this->voucherData->promotion_text : false;
            default:
                return false;
        }
    }


    //.... return  user demographic data by field name to replace it in message string  .....//
    private function getDemoGraphicData($field){
        //Log::channel('custom')->info('getDemoGraphicData', ['getDemoGraphicData' => $this->demographicData[0]]);
        Log::channel('custom')->info('$field', ['$field' => $field]);
        Log::channel('custom')->info('$this->userData[0]', ['$this->userData[0]' => $this->userData[0]]);
        switch ($field){
            case "phone_numbers":
                return $this->demographicData[0]['devices']['mobile'] ?? false;
            case "persona_fname":
                if(isset($this->userData[0])) {
                    return $this->userData[0]->user_first_name;
                }
                else {
                    return 'Customer';
                }

            case "persona_lname":
                if(isset($this->userData[0])) {
                    return $this->userData[0]->user_family_name;
                }
                else {
                    return 'Customer';
                }


//                if(isset($this->demographicData[0])) {
//                    if($this->demographicData[0]['persona_fname']) {
//                        return $this->demographicData[0]['persona_fname'];
//                    }
//                    else {
//                        return 'Customer';
//                    }
//                }
//                else {
//                    return 'Customer';
//                }

                //return $this->demographicData[0]['persona_fname'] == "" ? 'Customer' : $this->demographicData[0]['persona_fname'];
            case "telephone":
                return isset($this->selected_venue[0]) ? $this->selected_venue[0]['telephone'] : "";
            case "refferedUser":
                return $this->refferedUser[0]->user_first_name ?? "";
            case "activation_code":
                //return rand(1111,9999);
                return $this->userData[0]->activation_token;
            case "date":
                return "";
                //return date('d');
            case "month":
                return "";
                //return date('M');
            case "year":
                return "";
                //return date('Y');
            case "venue_name":
                return isset($this->selected_venue[0]) ? $this->selected_venue[0]['venue_name'] : "";
            case "address":
                return isset($this->selected_venue[0]) ? $this->selected_venue[0]['address'] : "";
            case "discount":
                return "";
                //return rand(1,100);
            case "DiscountPrice":
                return "";
                //return rand(1,100);
            case "Discount":
                return rand(1,100);
            case "Discount":
                return rand(1,100);
            default:
                //return $this->demographicData[0][$field] ?? false;
                return "";
        }
    }//..... end of function getDemoGraphicData  .....//


    public function getFieldType($key)
    {
        $field = $this->customFields->where("field_name",$key)->first();

        if(isset($field->field_type))
            return $field->field_type;
        else
            return "not_found";
    }

    public function getFieldId($key)
    {
        $field = $this->customFields->where("field_name",$key)->first();

        if(isset($field->field_type))
            return $field->id;
        else
            return "not_found";
    }

    public function getUserCustomFieldValue($user_id,$field_id){

        $value = $this->custom_fields_values
            ->where("user_id",$user_id)
            ->where("custom_field_id",$field_id)->first();


        return !empty($value) ? $value->value : "";
    }

}
