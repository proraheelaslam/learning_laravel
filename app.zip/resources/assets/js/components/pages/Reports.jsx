import React, {Component} from 'react';
import VoucherReport from "./sub-pages/Reports/VoucherReport";
import StampcardReport from "./sub-pages/Reports/StampcardReport";

import RedeemptionReport from "./sub-pages/Reports/RedeemptionReport";
import CampaignReporting from "./sub-pages/Reports/CampaignReporting";
import SmsReporting from "./sub-pages/Reports/SmsReporting";
import UnsubscriptionReport from "./sub-pages/Reports/UnsubscriptionReport";
import SaturationReport from "./sub-pages/Reports/SaturationReport";
import CoreApiReport from "./sub-pages/Reports/CoreApiReport";
import DemographicReport from "./sub-pages/Reports/DemographicReport";
import RewardReport from "./sub-pages/Reports/RewardReport";
import CRMReport from "./sub-pages/Reports/CRMReport";
import EmailReporting from "./sub-pages/Reports/EmailReporting";

class Reports extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currentTab: 'redeemption', showTab: true,
            campaign_id: (this.props.match.params.id) ? this.props.match.params.id : 0,
            data: [],
            redeemption: true,
            email_report: true,
            sms_report: true,
            unsub_report: true,
            saturation_report: true,
            corereport: true,
            demographicreport: true,
            rewardreport: true,
            crmreport: true,

        };

        this.setActiveTab = this.setActiveTab.bind(this);
    }//..... end of constructor() ....//
    componentDidCatch = (error, info) => {

    };//...... end of componentDidCatch() .....//
    componentDidMount = () => {

        if ((this.props.location.pathname.indexOf("/subscription") >= 0)) {
            this.setState((prevState) => ({showTab: !prevState.showTab, currentTab: 'unsubscribe'}));
        }
    }

    loadComponentData = () => {

        show_loader()
        axios.get(BaseUrl + '/api/get-report-configuration').then(res => {

            this.setState(() => ({data: res.data.data}), () => {
                this.changeStatus()
            });

        }).catch((err) => {
            show_loader(true);

        });
    }
    changeStatus = () => {
        let dataArray = this.state.data;
        let index = dataArray.findIndex(x => x.name === 'Report');
        let jsonData = dataArray[index].data;
        let obj = jsonData.find(o => o.show === true);
        if(obj != undefined){
            let currentTab =obj.field_name;

            this.setState(()=>({
                currentTab
            }))
        }
        this.setState(() => ({
            redeemption: this.findViewIn('redeemption', 'Report'),
            email_report: this.findViewIn('email-report', 'Report'),
            sms_report: this.findViewIn('sms-report', 'Report'),
            unsub_report: this.findViewIn('unsubscribe', 'Report'),
            saturation_report: this.findViewIn('saturation', 'Report'),
            corereport: this.findViewIn('corereport', 'Report'),
            demographicreport: this.findViewIn('demographicreport', 'Report'),
            rewardreport: this.findViewIn('rewardreport', 'Report'),
            crmreport: this.findViewIn('crmreport', 'Report'),
        }))
    }
    findViewIn = (field_name, type) => {
        let dataArray = this.state.data;
        let index = dataArray.findIndex(x => x.name === type);
        let jsonData = dataArray[index].data;
        let jsonInde = jsonData.findIndex(t => t.field_name === field_name);
        return jsonData[jsonInde].show;
    }
    componentWillMount() {
        this.loadComponentData();


    }

    render() {
        return (
            <div>
                <div className="compaignstabsBttns clearfix">
                    {
                        (this.state.redeemption) && (
                            <a style={{cursor: 'pointer'}} onClick={(e) => {
                                this.setActiveTab('redeemption')
                            }} className={this.state.currentTab == 'redeemption' ? 'compaignsActive' : ''}>Redemption
                                Report</a>
                        )
                    }

                    {
                        (this.state.email_report) && (
                            <a style={{cursor: 'pointer'}} onClick={(e) => {
                                this.setActiveTab('email-report')
                            }} className={this.state.currentTab == 'email-report' ? 'compaignsActive' : ''}>Email
                                Report</a>
                        )
                    }
                    {
                        (this.state.sms_report) && (
                            <a style={{cursor: 'pointer'}} onClick={(e) => {
                                this.setActiveTab('sms-report')
                            }} className={this.state.currentTab == 'sms-report' ? 'compaignsActive' : ''}>Sms Report</a>
                        )
                    }
                    {
                        (this.state.unsub_report) && (
                            <a style={{cursor: 'pointer'}} onClick={(e) => {
                                this.setActiveTab('unsubscribe')
                            }} className={this.state.currentTab == 'unsubscribe' ? 'compaignsActive' : ''}>Unsubscribe
                                Report</a>
                        )
                    }
                    {
                        (this.state.saturation_report) && (
                            <a style={{cursor: 'pointer'}} onClick={(e) => {
                                this.setActiveTab('saturation')
                            }} className={this.state.currentTab == 'saturation' ? 'compaignsActive' : ''}>Saturation
                                Report</a>
                        )}
                    {
                        (this.state.corereport) && (
                            <a style={{cursor: 'pointer'}} onClick={(e) => {
                                this.setActiveTab('corereport')
                            }} className={this.state.currentTab == 'corereport' ? 'compaignsActive' : ''}>CORE
                                Report</a>
                        )
                    }
                    {
                        (this.state.demographicreport) && (
                            <a style={{cursor: 'pointer'}} onClick={(e) => {
                                this.setActiveTab('demographicreport')
                            }} className={this.state.currentTab == 'demographicreport' ? 'compaignsActive' : ''}>Demographic
                                report</a>
                        )
                    }
                    {
                        (this.state.rewardreport) && (
                            <a style={{cursor: 'pointer'}} onClick={(e) => {
                                this.setActiveTab('rewardreport')
                            }} className={this.state.currentTab == 'rewardreport' ? 'compaignsActive' : ''}>Rewards
                                Report</a>
                        )
                    }
                    {
                        (this.state.crmreport) && (
                            <a style={{cursor: 'pointer'}} onClick={(e) => {
                                this.setActiveTab('crmreport')
                            }} className={this.state.currentTab == 'crmreport' ? 'compaignsActive' : ''}>CRM Report</a>
                        )
                    }
                </div>

                <div className="contentDetail">
                    <div className="autoContent">
                        <div className="contentinner">

                            {
                                this.loadActiveComponent()
                            }

                        </div>
                    </div>
                </div>
            </div>
        );
    }//..... end of render() .....//

    setActiveTab(tab) {

        this.setState({currentTab: tab});

    }//..... end of setActiveTab() .....//
    navigateToCampaignBuilder = (e, slug) => {
        if (e)
            e.preventDefault();

        this.setState({currentTab: 'unsubscribe'});
        this.props.history.push(slug);
    };//..... end of navigateToCampaignBuilder() .....//
    loadActiveComponent = () => {
        switch (this.state.currentTab) {
            case "redeemption":
                return <RedeemptionReport showReport={this.state.redeemption}/>;
            case "email-report" :
                return <EmailReporting />;
            case "sms-report" :
                return <SmsReporting navigate={this.navigateToCampaignBuilder}/>;
            case "unsubscribe" :
                return <UnsubscriptionReport campaign_id={this.props.match.params.id}/>;
            case "saturation":
                return <SaturationReport/>;
            case "corereport":
                return <CoreApiReport/>;
            case 'demographicreport':
                return <DemographicReport/>;
            case 'rewardreport':
                return <RewardReport/>;
            case 'crmreport':
                return <CRMReport/>;
            default :
                return "";
        }
    };
}//..... end of members() .....//

export default Reports;
