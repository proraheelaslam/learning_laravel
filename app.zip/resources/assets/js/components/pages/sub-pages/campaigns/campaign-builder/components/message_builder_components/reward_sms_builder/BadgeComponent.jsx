import React, {Component} from 'react';
import {Scrollbars} from 'react-custom-scrollbars';
import {NotificationManager} from 'react-notifications';
import {connect} from "react-redux";
import {
    addMessageBuilderValue,
    setVoucherData,
} from "../../../../../../../redux/actions/CampaignBuilderActions";

import {find} from "lodash";
import {
    selectMessageBuilderObject,
    selectVoucherEndDate,
    selectVoucherStartDate
} from "../../../../../../../redux/selectors/Selectors";

import ToggleSwitch from "@trendmicro/react-toggle-switch";
import '@trendmicro/react-toggle-switch/dist/react-toggle-switch.css';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
class BadgeComponent extends Component {
    customDropDownBSpanRef = null;
    customDropDownBSONEpanRef = null;
    customDropDownShowBRef = null;
    customDropDownONEShowBRef = null;
    state={
        badge_state:[]
    }

    setMessageValue = (key, value) => {
        let other = {...this.props.messageBuilder.other};
        other.content[key] = value;
        this.props.dispatch(addMessageBuilderValue({
            [this.props.currentChannel]: {
                ...this.props.messageBuilder,
                other: {...other}
            }
        }));
    };//..... end of setMessageValue() .....//


    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//
    componentDidMount() {
        if(this.props.gameMissionTypeToCreate == 'game-mission') {
            this.setMessageValue('mission_data', true);
            if ((this.props.messageBuilder.other.content.hasOwnProperty('badge_id') && this.props.messageBuilder.other.content.badge_id)) {
                let datafind = this.props.badgeListData.find( (item) => item.id ===  this.props.messageBuilder.other.content.badge_id)
                this.setState(()=>({
                    badge_state:datafind.states
                }),()=>{
                });
            }
        }
    }

    setBadge = (badge,type) => {
        this.customDropDownShowBRef.style.display = 'none';
        this.customDropDownBSpanRef.classList.remove('changeAero');
        this.setState(()=>({
            badge_state:badge.states
        }),()=>{
        });
        this.setMessageValue('badge_id', badge.id);
    };//..... end of setVoucher() .....//

    setBadgeState = (badge,type) => {
        this.customDropDownONEShowBRef.style.display = 'none';
        this.customDropDownBSONEpanRef.classList.remove('changeAero');

        this.setMessageValue('state_id', badge.id);
    };//..... end of setVoucher() .....//



    handleDropDownBSpanClick = (e) => {
        e.target.classList.toggle('changeAero');
        this.customDropDownShowBRef.style.display =  this.customDropDownShowBRef.style.display === 'none' ? 'block' : 'none';
    };//..... end of handleDropDownBSpanClick() .....//

    handleDropDownONEBSpanClick = (e) => {
        e.target.classList.toggle('changeAero');
        this.customDropDownONEShowBRef.style.display =  this.customDropDownONEShowBRef.style.display === 'none' ? 'block' : 'none';
    };//..... end of handleDropDownBSpanClick() .....//
    getStateData = () =>{
        let find=  this.props.badgeListData.find( (item) => item.id ===  this.props.messageBuilder.other.content.badge_id)

        if(typeof  find !='undefined'){

            return find.title;
        }else{
            return 'Select Badge'
        }
    }

    getStateName = () =>{
        let  find ='undefined';
        if(this.state.badge_state.length>0) {
             find = this.state.badge_state.find((item) => item.id === this.props.messageBuilder.other.content.state_id)
        }
        if(typeof  find !='undefined'){

            return find.state_name;
        }else{
            return 'Select Badge State'
        }
    }

    render() {


        return (
            <div className="messageBuilder_outer ">
                <div className="messageBuilder_heading">
                    <h3>Badges</h3>
                    <p></p>
                </div>
                <div className="pushNotification_section clearfix">
                    <div>
                        <div className="segment_heading segmentaxn_heading">
                            <h3>Select Badge</h3>
                        </div>
                        <div className="smsDetail_inner primary_voucher_setting">

                            <div className="dropSegmentation_section">
                                <div className="dropSegmentation_heading clearfix">
                                    <h3>Badge</h3>
                                </div>
                                <div className="stateSegmentation primary_voucher_setting">
                                    <div className="venueIdentification_section">
                                        <div className="venueIdentification_form">
                                            <div className='customDropDown'>
                                                <span  ref={ref => this.customDropDownBSpanRef = ref} onClick={this.handleDropDownBSpanClick}> {this.props.messageBuilder.other.content.badge_id ? (this.getStateData()) : 'Select Badge'}</span>
                                                <ul className="customDropDown_show customPlaceHolder" ref={ref => this.customDropDownShowBRef = ref} style={{marginBottom: '30px',marginTop: '-10px', maxHeight:'207px', display:'none',zIndex: '3'}} >
                                                    <Scrollbars autoHeight renderTrackHorizontal={() => <div></div>} renderThumbHorizontal={() => <div></div>}>
                                                        {

                                                            this.props.badgeListData.map((badge) => {
                                                                return <li key={badge.id} onClick={(e)=> {this.setBadge(badge,"")}} className={ badge.id === this.props.messageBuilder.other.content.badge_id ? 'selectedItem' : ''}>{badge.title}</li>;
                                                            })
                                                        }
                                                    </Scrollbars>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {
                                (this.props.gameMissionTypeToCreate =='game-mission' && this.props.messageBuilder.other.content.badge_id) && (
                                    <div className="dropSegmentation_section">
                                        <div className="dropSegmentation_heading clearfix">
                                            <h3>Badge State</h3>
                                        </div>
                                        <div className="stateSegmentation primary_voucher_setting">
                                            <div className="venueIdentification_section">
                                                <div className="venueIdentification_form">
                                                    <div className='customDropDown'>
                                                        <span  ref={ref => this.customDropDownBSONEpanRef = ref} onClick={this.handleDropDownONEBSpanClick}> {this.props.messageBuilder.other.content.state_id ? (this.getStateName()) : 'Select Badge State'}</span>
                                                        <ul className="customDropDown_show customPlaceHolder" ref={ref => this.customDropDownONEShowBRef = ref} style={{marginBottom: '30px',marginTop: '-10px', maxHeight:'207px', display:'none',zIndex: '3'}} >
                                                            <Scrollbars autoHeight renderTrackHorizontal={() => <div></div>} renderThumbHorizontal={() => <div></div>}>
                                                                {

                                                                    this.state.badge_state.map((state) => {
                                                                        return <li key={state.id} onClick={(e)=> {this.setBadgeState(state,"")}} className={ state.id === this.props.messageBuilder.other.content.state_id ? 'selectedItem' : ''}>{state.state_name}</li>;
                                                                    })
                                                                }
                                                            </Scrollbars>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )
                            }

                        </div>
                    </div>
                </div>
            </div>

        );
    }//..... end of render() .....//
}//..... end of VoucherBuilderComponent.

const mapStateToProps = (state) => {
    return {
        ...state.campaignBuilder,
        messageBuilder  : selectMessageBuilderObject(state.campaignBuilder.messageBuilder, state.campaignBuilder.currentChannel),
        voucher:state.voucherBuilder,
        startDate       : selectVoucherStartDate(state.campaignBuilder.messageBuilder, state.campaignBuilder.currentChannel),
        endDate         : selectVoucherEndDate(state.campaignBuilder.messageBuilder, state.campaignBuilder.currentChannel),
    };
};
export default connect(mapStateToProps)(BadgeComponent);