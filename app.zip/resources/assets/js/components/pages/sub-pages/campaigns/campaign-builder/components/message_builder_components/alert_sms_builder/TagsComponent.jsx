import React, {Component} from 'react';
import {Draggable} from 'react-drag-and-drop'
import PropTypes from 'prop-types';
import {addMessageBuilderValue} from "../../../../../../../redux/actions/CampaignBuilderActions";

class TagsComponent extends Component {
    constructor(props) {
        super(props);
    }//..... end of constructor() .....//
    state = {
        customFields: [],
        tagsInputs: []
    }
    setMessage = (data) => {
        let message = this.props.messageBuilder.message;
        message += "|" + data + "|";

        if (this.props.currentChannel === 'sms') {
            if (message.length > 144)
                return false;
        }

        this.props.dispatch(addMessageBuilderValue({
            [this.props.currentChannel]: {
                ...this.props.messageBuilder,
                message
            }
        }));
    };//..... end of setMessage() .....//
    componentDidMount() {

        this.getMemberCustomFields();
        this.getAllTags();



    }//..... end of componentDidMount() .....//

    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//

    getMemberCustomFields = () => {
        let memberCustomFields = JSON.parse(localStorage.getItem('memberCustomFields'));
        this.setState(() => ({customFields: memberCustomFields}));
    }
    getAllTags = () => {
        show_loader()
        axios.get(BaseUrl + '/api/get-tag-setting').then(res => {

            this.setState(() => ({tagsInputs:res.data.data}),()=>{

                var data =this.state.tagsInputs;
                for (var i=0; i<data.length;i++){
                    var count = 0;

                    let lengthData = data[i].tags.length;
                    for (var x of  data[i].tags) {
                        if (!x.status) {
                            count++;
                        }
                    }
                    if(lengthData == count){
                        data[i].showTitle = false;
                    }else{
                        data[i].showTitle = true;
                    }
                }
                this.setState(() => ({tagsInputs:data}),() => {
                    $(".clickAccordian").click(function () {
                        $(".segments_accordian ul li a").removeClass("active");
                        $(this).addClass("active");
                        $(".clickAccordian_show").stop().slideUp(500);
                        $(this).parent(".segments_accordian ul li").find(".clickAccordian_show").stop().slideDown();
                    });
                });

                setTimeout(function () {


                },5000);


            });

            show_loader(true);

        }).catch((err) => {
            show_loader(true);

        });
    }
    render() {
        return (
            <div className="tagsAccordian_column">
                <div className="segmentsSection_left">
                    <div className="segment_heading">
                        <h3>TAGS</h3>
                    </div>
                    <div className="segmentsAccordianList">
                        <div className="segments_accordian">
                            <div className="acordianSeprator">&nbsp;</div>
                            <ul>

                                {this.state.tagsInputs.map((value, key) => {
                                    if(value.showTitle){
                                        return (<li key={key}>

                                            <a className="accordianIcons  clickAccordian"
                                               style={{cursor: 'pointer'}}>
                                                <b>1</b>
                                                <small>{value.tagTitle}</small>
                                            </a>
                                            <div className="showAccordian_data clickAccordian_show">
                                                <div className="dragAccordianData">
                                                    {
                                                        value.tags.map((tagValue, tagKey) => {
                                                            if (tagValue.status) {
                                                                return (
                                                                    <Draggable key={(tagKey + '_' + tagValue.tagName)}
                                                                               type="tags"
                                                                               data={tagValue.tagName}
                                                                               onDoubleClick={(e) => {
                                                                                   this.setMessage(tagValue.tagName)
                                                                               }}><strong
                                                                        className="capitalize">{tagValue.subTitle}</strong></Draggable>

                                                                )
                                                            }


                                                        })

                                                    }
                                                </div>
                                            </div>

                                        </li>)

                                    }})}

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        );
    }//..... end of render() .....//
}//..... end of TagsComponent.

TagsComponent.propTypes = {};

export default TagsComponent;