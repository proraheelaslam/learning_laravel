import React, {Component} from 'react';
import {Scrollbars} from "react-custom-scrollbars";
import ToggleSwitch from "@trendmicro/react-toggle-switch";
import Select from "react-select";
import MultiSelectReact from "multi-select-react";
import CheckboxTree from "react-checkbox-tree";

class ApplicationEvents extends Component {
    customDropDownSpanRef = null;
    customDropDownShowRef = null;
    state = {
        activities:[],
        is_selected:false,
        is_all:0,
        is_first:false,
        total_quantity:0,
        treeNode:[],
        checked:[],
        expanded:[],
    };

    setCriteriaValue = (value) => {
        this.props.setCriteriaValue('app_events', 'value', value);
    };//..... end of setCriteriaValue() .....//

    componentDidMount = () => {
        this.getAllBrands();
        if (this.props.criteria.value){
            this.setState({activities:this.props.criteria.value.activities});
        }

    };//..... end of componentDidMount() .....//


    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//

    handleDropDownSpanClick = (e) => {
        e.target.classList.toggle('changeAero');
        this.customDropDownShowRef.style.display =  (this.customDropDownShowRef.style.display === 'none') ? 'block' : 'none';
    };//..... end of handleDropDownSpanClick() .....//

    getAllBrands = ()=>{
        show_loader();
        axios.get(`${BaseUrl}/api/get-all-activities`).then(res => {
            this.setState(()=>({activities: res.data.data}));
            show_loader(true);
        }).catch((err) => {
            show_loader(true);
        });
    }
    setValueSelected = (selectedOption) => {
        let preVal = this.props.criteria.value;
        preVal.activities = selectedOption;

        this.setCriteriaValue(preVal);
    };//..... end of setValueSelected() .....//


    render() {
        return (
            <div className="dropSegmentation_section">
                <div className="dropSegmentation_heading clearfix">
                    <h3>Application Events</h3>
                    <div className="segmntClose" onClick={(e)=> {this.props.removeCriteria('app_events')}}>
                        <a  style={{cursor:'pointer'}}>&nbsp;</a>
                    </div>
                </div>


                <div className="stateSegmentation" style={{padding:'0px 16px 15px'}}>
                    <div className="compaignDescription_outer clearfix">
                        <div className="memberNumberOuter clearfix">
                            <div className="memberNumber_placeholder" style={{width: '100%', float: 'none'}}>
                                <div className="placeHolderOuter clearfix">

                                    <div></div>
                                </div>
                            </div>
                        </div>
                        <div className="memberNumberOuter clearfix">
                            <div className="memberNumber_placeholder" style={{width: '100%', float: 'none'}}>
                                <div className="placeHolderOuter clearfix">

                                    <Select
                                        value={this.props.criteria.value.activities}
                                        onChange={this.setValueSelected}
                                        options={this.state.activities}
                                        isMulti={true}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        );
    }//..... end of render() .....//

}//..... end of MembershipNumber.

export default ApplicationEvents;