import React, {Component} from 'react';

class WalkthrougCompleted extends Component {
    state = {
        walkthrough_completed : '',

    };

    setCriteriaValue = (value) => {
        this.props.setCriteriaValue('walkthrough_completed', 'value', value);
    };//..... end of setCriteriaValue() .....//

    componentDidMount = () => {
        if (this.props.criteria.value){
            this.setState({walkthrough_completed:true});
        }

    };//..... end of componentDidMount() .....//



    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//

    render() {
        return (
            <div className="dropSegmentation_section">
                <div className="dropSegmentation_heading clearfix">
                    <h3>Walk-through  Completed</h3>
                    <div className="segmntClose" onClick={(e)=> {this.props.removeCriteria('walkthrough_completed')}}>
                        <a  style={{cursor:'pointer'}}>&nbsp;</a>
                    </div>
                </div>
                <div className="stateSegmentation">
                    <div className="compaignDescription_outer clearfix">
                        <label>This Mission will be triggered when Walk-through screens will be completed</label>
                    </div>
                </div>


            </div>
        );
    }//..... end of render() .....//

}//..... end of MembershipNumber.

export default WalkthrougCompleted;