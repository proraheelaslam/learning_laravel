import React, {Component} from 'react';

class CompleteProfile extends Component {
    state = {
        percentage : '',

    };

    setCriteriaValue = (value) => {
        this.props.setCriteriaValue('completed_profile', 'value', value);
    };//..... end of setCriteriaValue() .....//

    componentDidMount = () => {
        if (this.props.criteria.value){
            this.setState({percentage:this.props.criteria.value.percentage});
        }

    };//..... end of componentDidMount() .....//

    handleFromIputs = (e) => {

        this.setState({
            percentage:  e.target.value,
        });

        let preVal = this.props.criteria.value;
         preVal.percentage = e.target.value;
        this.setCriteriaValue(preVal);
    };


    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//

    render() {
        return (
            <div className="dropSegmentation_section">
                <div className="dropSegmentation_heading clearfix">
                    <h3>Complete Profile</h3>
                    <div className="segmntClose" onClick={(e)=> {this.props.removeCriteria('completed_profile')}}>
                        <a  style={{cursor:'pointer'}}>&nbsp;</a>
                    </div>
                </div>
                <div className="stateSegmentation">
                    <div className="compaignDescription_outer clearfix">
                        <label>Complete Profile 100%</label>

                    </div>
                </div>


            </div>
        );
    }//..... end of render() .....//

}//..... end of MembershipNumber.

export default CompleteProfile;