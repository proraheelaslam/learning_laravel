import React, {Component} from 'react';
import {connect} from "react-redux";
import MailDropBuilder from "../MailDropBuilder";

import {selectMessageBuilderObject} from "../../../../../../../redux/selectors/Selectors";
import {setMailDropType} from "../../../../../../../redux/actions/CampaignBuilderActions";

class AlertMailDrop extends Component {

    setEmailType = (type) => {
        this.props.dispatch(setMailDropType(type))
    };//..... end of setEmailType() .....//

    componentDidMount() {
        if (this.props.messageBuilder.type === '')
            this.setEmailType('mail_drop');
    }//.... end of componentDidMount() .....//

    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//

    render() {
        return (
            <React.Fragment>
                <div className="chooseMessageType">
                    <label>Choose your Message type for users.</label>
                    <div className="chooseMessageType_icons">
                        <div className="segmentsOptions clearfix">
                            <ul>
                                <li>
                                    <div className="segmentsOptions_detail">
                                        <span
                                            className={this.props.messageBuilder.type === 'mail_drop' ? 'choseSegmnt' : ''}>
                                            <b className="useTemplate" onClick={(e) => {
                                                this.setEmailType('mail_drop');
                                            }}>&nbsp;</b>
                                        </span>
                                        <h3>Use a Mail Drop</h3>
                                    </div>
                                </li>




                                {/*<li>
                                    <div className="segmentsOptions_detail">
                                        <span className={ this.props.messageBuilder.type === 'new_template' ? 'choseSegmnt' : ''}>
                                            <b className="creatDesign" onClick={(e) => {this.setEmailType('new_template');}}>&nbsp;</b>
                                        </span>
                                        <h3>Create a design</h3>
                                    </div>
                                </li>*/}
                            </ul>
                        </div>
                    </div>
                </div>

                {this.getComponent()}
            </React.Fragment>
        );
    }//..... end of render() .....//

    getComponent = () => {

        switch (this.props.messageBuilder.type) {

            case 'mail_drop':
                return <MailDropBuilder/>;
            default:
                return <MailDropBuilder/>;
        }//.... end of switch() .....//
    };//..... end of getComponent() .....//
}//..... end of AlertMailDrop.

const mapStateToProps = (state) => {
    return {
        messageBuilder: selectMessageBuilderObject(state.campaignBuilder.messageBuilder, state.campaignBuilder.currentChannel),
        currentChannel: state.campaignBuilder.currentChannel,
        triggerType: state.campaignBuilder.trigger_type,
    };
};
export default connect(mapStateToProps)(AlertMailDrop);