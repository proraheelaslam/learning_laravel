import React, {Component} from 'react';

class CompletedMissions extends Component {
    state = {
        mission_complete : '',

    };

    setCriteriaValue = (value) => {
        this.props.setCriteriaValue('complete_missions', 'value', value);
    };//..... end of setCriteriaValue() .....//

    componentDidMount = () => {
        if (this.props.criteria.value){
            this.setState({mission_complete:this.props.criteria.value.mission_complete});
        }

    };//..... end of componentDidMount() .....//

    handleFromIputs = (e) => {

        this.setState({
            mission_complete:  e.target.value,
        });

        let preVal = this.props.criteria.value;
         preVal.mission_complete = e.target.value;
        this.setCriteriaValue(preVal);
    };


    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//

    render() {
        return (
            <div className="dropSegmentation_section">
                <div className="dropSegmentation_heading clearfix">
                    <h3>Complete Missions</h3>
                    <div className="segmntClose" onClick={(e)=> {this.props.removeCriteria('complete_missions')}}>
                        <a  style={{cursor:'pointer'}}>&nbsp;</a>
                    </div>
                </div>
                <div className="stateSegmentation">
                    <div className="compaignDescription_outer clearfix">
                        <label>Complete Mission</label>
                        <div className="memberNumberOuter clearfix">
                            <div className="" style={{width:'58%'}}>
                                <div className="numberFields clearfix">
                                    <input  type="text" placeholder="Complete Mission" style={{width:100+'%'}} value={this.state.percentage} onChange={(e) => {this.handleFromIputs(e)}}/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        );
    }//..... end of render() .....//

}//..... end of MembershipNumber.

export default CompletedMissions;