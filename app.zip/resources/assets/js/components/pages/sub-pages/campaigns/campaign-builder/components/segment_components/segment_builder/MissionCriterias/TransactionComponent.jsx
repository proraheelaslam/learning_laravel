import React, {Component} from 'react';
import {Scrollbars} from "react-custom-scrollbars";
import ToggleSwitch from "@trendmicro/react-toggle-switch";
import Select from "react-select";
import MultiSelectReact from "multi-select-react";
import CheckboxTree from "react-checkbox-tree";
import {NotificationManager} from "react-notifications";
import {setVoucherBusiness} from "../../../../../../../../redux/actions/VoucherAction";

class TransactionComponent extends Component {
    customDropDownBSpanRef = null;
    customDropDownShowBRef = null;
    state = {
        businessData:[],
    };

    setCriteriaValue = (value) => {
        this.props.setCriteriaValue('transaction_scan', 'value', value);
    };//..... end of setCriteriaValue() .....//

    componentDidMount = () => {
        this.loadBusinessList();
        if (this.props.criteria.value){
            this.setState({});
        }

    };//..... end of componentDidMount() .....//

    loadBusinessList = () => {
        axios.get(`${BaseUrl}/api/business-list/${CompanyID}`).
        then((response) => {
            let data = response.data.data.map(item =>{
                item.label = item.business_name;
                item.id = item.business_id;
                item.value =false;

                return item;
            })

           this.setState(()=>({
               businessData:data
           }));
        }).catch((err) => {
        });
    };//..... end of loadBusinessList() .....//

    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//

    handleDropDownBSpanClick = (e) => {
        e.target.classList.toggle('changeAero');
        this.customDropDownShowBRef.style.display = this.customDropDownShowBRef.style.display === 'none' ? 'block' : 'none';
    };//..... end of handleDropDownBSpanClick() .....//

    setBusiness = (business, type) => {
        this.customDropDownShowBRef.style.display = 'none';
        this.customDropDownBSpanRef.classList.remove('changeAero');

        let preVal = this.props.criteria.value;
        preVal.business_id = business.business_id;
        preVal.business_name = business.business_name;
        this.setCriteriaValue(preVal)
        if (type == "All") {
            return false;
        }

        this.getBusinessCategoriesList(business, true);
    };//..... end of setBusiness() .....//


    getBusinessCategoriesList = (business,check) => {

        show_loader();
        axios.post(BaseUrl + '/api/get-business-category', {business_id: business.business_id, api_key: business.api_key, secret: business.secret_key,company_id:CompanyID})
            .then((response) => {
                if (response.data.status) {

                    var data = response.data.data.map(items => {
                        return {
                            value: items.cate_id + "_" + this.randomString(10, "A"),
                            isParent: true,
                            label: items.cate_name,
                            isCategory: true,
                            voucher_plu_ids: items.voucher_plu_idd,
                            availType:'category',
                            children: items.cate_items.map(productItems => {
                                return {
                                    value: productItems.prd_id,
                                    label: productItems.prd_name,
                                    voucher_plu_ids: productItems.voucher_plu_idd,
                                    availType:'product',

                                }
                            })

                        }
                    });
                    this.setState(()=>({
                        treeNode:data
                    }))
                } else {
                    //NotificationManager.warning("Could not get categories list.", 'No Data');
                }//..... end if-else() .....//
                show_loader(true);
            }).catch((err)=> {
            show_loader(true);
            NotificationManager.error("Error occurred while fetching business's category.", 'Error'+err);
        });
    };//..... end of removeFile() ......//
    onCheck =(checked,treeNode) =>{
        this.setState({ checked })
        let preVal = this.props.criteria.value;

        let datArray = preVal.products;
        if (treeNode.isParent) {

            treeNode.children.forEach(val => {
                var keyValue = val.value;
                var found=false;
                found = datArray.some(function (el) {
                    return el.id == keyValue;
                });
                if (!found) {

                    datArray.push({
                        id: keyValue,
                       plu_ids: val.voucher_plu_ids,
                    });
                } else {
                    datArray = datArray.filter(function (obj) {
                        return obj.id != keyValue;
                    });
                    if(treeNode.checked) {
                        datArray.push({
                            id: keyValue,
                            plu_ids: val.voucher_plu_ids,
                        });
                    }

                }
            })
        } else {

            var keyValue = treeNode.value;
            var found = datArray.some(function (el) {
                return el.id == keyValue;
            });

            if (!found) {

                treeNode.parent.children.forEach(item=> {
                    var foundValue = item.value;
                    if(foundValue == keyValue) {
                        datArray.push({
                            id: keyValue,
                            plu_ids: item.voucher_plu_ids,
                        });
                    }
                });


            } else {
                datArray = datArray.filter(function (obj) {
                    return obj.id !=  keyValue;
                });

            }

        }

        preVal.products = datArray;
        this.setCriteriaValue(preVal);

    }
    onExpand=(expanded) => {
        this.setState({ expanded })

    }

    randomString = (len, an) => {
        an = an && an.toLowerCase();
        var str = "", i = 0, min = an == "a" ? 10 : 0, max = an == "n" ? 10 : 62;
        for (; i++ < len;) {
            var r = Math.random() * (max - min) + min << 0;
            str += String.fromCharCode(r += r > 9 ? r < 36 ? 55 : 61 : 48);
        }
        return str;
    }
    render() {
        return (
            <div className="dropSegmentation_section">
                <div className="dropSegmentation_heading clearfix">
                    <h3>Transaction</h3>
                    <div className="segmntClose" onClick={(e)=> {this.props.removeCriteria('transaction_scan')}}>
                        <a  style={{cursor:'pointer'}}>&nbsp;</a>
                    </div>
                </div>
                <div className="dropSegmentation_section_custom"  style={{marginLeft:'13px',marginTop:'10px'}}>
                    <div className="dropSegmentation_heading clearfix">
                        <h3>Business</h3>
                    </div>
                    <div className="stateSegmentation primary_voucher_setting">
                        <div className="venueIdentification_section">
                            <div className="venueIdentification_form">
                                <div className='customDropDown'>
                                        <span ref={ref => this.customDropDownBSpanRef = ref}
                                              onClick={this.handleDropDownBSpanClick}> {(this.props.criteria.value.business_name !='')? this.props.criteria.value.business_name: 'Select Business'}</span>
                                    <ul className="customDropDown_show customPlaceHolder"
                                        ref={ref => this.customDropDownShowBRef = ref} style={{
                                        marginBottom: '30px',
                                        marginTop: '-10px',
                                        maxHeight: '207px',
                                        display: 'none',
                                        zIndex: '3'
                                    }}>
                                        <Scrollbars autoHeight renderTrackHorizontal={() => <div></div>}
                                                    renderThumbHorizontal={() => <div></div>}>
                                            {

                                                this.state.businessData.map((business) => {
                                                    return <li key={business.business_id} onClick={(e) => {
                                                        this.setBusiness(business, "")
                                                    }}
                                                               className={this.state.businessData && business.business_id === this.props.criteria.value.business_id ? 'selectedItem' : ''}>{business.business_name}</li>;
                                                })
                                            }
                                        </Scrollbars>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="dropSegmentation_section_custom" id="tree_view_data" style={{marginLeft:'13px'}}>
                    <div className="dropSegmentation_heading clearfix">
                        <h3>Product list</h3>
                    </div>
                    <div className="stateSegmentation primary_voucher_setting">
                        <div className="venueIdentification_section">
                            <div className='venueIdentification_form'>
                                <CheckboxTree
                                    nodes={this.state.treeNode?this.state.treeNode:[]}
                                    checked={this.state.checked?this.state.checked:[]}
                                    expanded={this.state.expanded?this.state.expanded:[]}
                                    onCheck={this.onCheck}
                                    onExpand={this.onExpand}
                                />
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        );
    }//..... end of render() .....//

}//..... end of MembershipNumber.

export default TransactionComponent;