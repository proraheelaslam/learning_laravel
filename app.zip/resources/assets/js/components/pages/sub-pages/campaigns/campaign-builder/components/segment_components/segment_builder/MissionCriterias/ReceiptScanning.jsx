import React, {Component} from 'react';
import {Scrollbars} from "react-custom-scrollbars";
import ToggleSwitch from "@trendmicro/react-toggle-switch";
import Select from "react-select";
import MultiSelectReact from "multi-select-react";
import CheckboxTree from "react-checkbox-tree";

class ReceiptScanning extends Component {
    customDropDownSpanRef = null;
    customDropDownShowRef = null;
    state = {
        brands:[],
        is_selected:false,
        is_all:0,
        is_first:false,
        total_quantity:0,
        is_all_product:0,
        treeNode:[],
        checked:[],
        expanded:[],
    };

    setCriteriaValue = (value) => {
        this.props.setCriteriaValue('receipt_scanning', 'value', value);
    };//..... end of setCriteriaValue() .....//

    componentDidMount = () => {
        this.getAllBrands();
        if (this.props.criteria.value){
            this.setState({is_all_product:this.props.criteria.value.is_all_product,is_selected:this.props.criteria.value.is_unilever,is_all:this.props.criteria.value.is_all,is_first:this.props.criteria.value.is_first,total_quantity:this.props.criteria.value.total_quantity});
        }

    };//..... end of componentDidMount() .....//

    handleInterval = (e,type) => {

        let value
        if(type == 'is_selected') {
             value = this.state.is_selected;
        }else if(type =='is_first'){
            value = this.state.is_first;
        }else if(type =='is_all_product') {
            value = this.state.is_all_product;
        }else{
            value =this.state.is_all;
        }
        if(value){
            value = (value ==1)?0:false;
        }else{
            value = (value ==0)?1:true;
        }
        let preVal = this.props.criteria.value;
        if(type == 'is_selected') {
            this.setState({
                is_selected: value,
            });

            preVal.is_unilever = value;
        }else if(type =='is_first'){
            this.setState({
                is_first: value,
            });

            preVal.is_first = value;
        }else if(type =='is_all_product') {

            this.setState({
                is_all_product: value,
            });

            preVal.is_all_product = value;

        }else{
            this.setState({
                is_all: value,
            });

            preVal.is_all = value;
        }

        this.setCriteriaValue(preVal);
    };

    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//

    handleDropDownSpanClick = (e) => {
        e.target.classList.toggle('changeAero');
        this.customDropDownShowRef.style.display =  (this.customDropDownShowRef.style.display === 'none') ? 'block' : 'none';
    };//..... end of handleDropDownSpanClick() .....//

    getAllBrands = ()=>{
        show_loader();
        axios.post(`${BaseUrl}/api/get-all-brands`,{
            company_id:CompanyID
        }).then(res => {
            this.setState(()=>({brands: res.data.data,treeNode:res.data.product_data}));
            show_loader(true);
        }).catch((err) => {
            show_loader(true);
        });
    }
    setValueSelected = (selectedOption) => {
        let preVal = this.props.criteria.value;
        preVal.brandName = selectedOption;

        this.setCriteriaValue(preVal);
    };//..... end of setValueSelected() .....//

    handleFromIputs = (e) => {

        this.setState({
            total_quantity:  e.target.value,
        });

        let preVal = this.props.criteria.value;
        preVal.total_quantity = e.target.value;
        this.setCriteriaValue(preVal);
    };
    onCheck =(checked,treeNode) =>{
        this.setState({ checked })
        console.log(checked);
        let preVal = this.props.criteria.value;
        preVal.products = checked.label;
        this.setCriteriaValue(preVal);

    }
    onExpand=(expanded) => {
        this.setState({ expanded })

    }
    render() {
        return (
            <div className="dropSegmentation_section">
                <div className="dropSegmentation_heading clearfix">
                    <h3>Receipt Scanning</h3>
                    <div className="segmntClose" onClick={(e)=> {this.props.removeCriteria('receipt_scanning')}}>
                        <a  style={{cursor:'pointer'}}>&nbsp;</a>
                    </div>
                </div>
                <div className="stateSegmentation">
                    <div className="compaignDescription_outer clearfix">
                        <label>Is Unilever</label>
                        <div className="memberNumberOuter clearfix">
                            <ToggleSwitch

                                checked={this.state.is_selected}
                                onChange={(e) => {
                                    this.handleInterval(e,'is_selected')
                                }}
                            />
                            <span style={{fontWeight:'bold'}}> {this.state.is_selected ? "Yes" : "No"}</span>
                        </div>
                    </div>
                </div>

                <div className="stateSegmentation" style={{padding:'0px 16px 15px'}}>
                    <div className="compaignDescription_outer clearfix">
                        <label>Brands</label>
                        <div className="memberNumberOuter clearfix">
                            <div className="memberNumber_placeholder" style={{width: '100%', float: 'none'}}>
                                <div className="placeHolderOuter clearfix">

                                    <div> </div>
                                </div>
                            </div>
                        </div>
                        <div className="memberNumberOuter clearfix">
                            <div className="memberNumber_placeholder" style={{width: '79%', float: 'none'}}>
                                <div className="placeHolderOuter clearfix">

                                    <Select
                                        value={this.props.criteria.value.brandName}
                                        onChange={this.setValueSelected}
                                        options={this.state.brands}
                                        isMulti={true}
                                    />
                                </div>
                            </div>
                            <span className="cL_rowList_number"
                                  style={{fontSize: '13px', fontWeight: 'bold',marginTop:'-52px', float: 'right'}}><input
                                type="checkbox" defaultChecked={this.state.is_all}  onClick={(e) => {
                                this.handleInterval(e,'is_all')
                            }} /><span > Match all</span></span>
                        </div>
                    </div>
                </div>

                <div className="dropSegmentation_section_custom" id="tree_view_data" style={{marginLeft:'13px'}}>
                    <div className="dropSegmentation_heading clearfix">
                        <h3>Product list</h3><span className="cL_rowList_number"
                                                   style={{fontSize: '13px', fontWeight: 'bold',marginTop:'12px',marginRight:'20px', float: 'right'}}><input
                        type="checkbox" defaultChecked={this.state.is_all_product}  onClick={(e) => {
                        this.handleInterval(e,'is_all_product')
                    }} /><span > Match all</span></span>
                    </div>
                    <div className="stateSegmentation primary_voucher_setting">
                        <div className="venueIdentification_section">
                            <div className='venueIdentification_form'>
                                <CheckboxTree
                                    nodes={this.state.treeNode?this.state.treeNode:[]}
                                    checked={this.state.checked?this.state.checked:[]}
                                    expanded={this.state.expanded?this.state.expanded:[]}
                                    onCheck={this.onCheck}
                                    onExpand={this.onExpand}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="stateSegmentation" style={{padding:'0px 16px 15px'}}>
                    <div className="compaignDescription_outer clearfix">
                        <label>First Receipt Scan</label>
                        <div className="memberNumberOuter clearfix">
                            <ToggleSwitch

                                checked={this.state.is_first}
                                onChange={(e) => {
                                    this.handleInterval(e,'is_first')
                                }}
                            />
                            <span style={{fontWeight:'bold'}}> {this.state.is_first ? "Yes" : "No"}</span>
                        </div>
                    </div>
                </div>
                <div className="stateSegmentation" style={{paddingTop:"0px"}}>
                    <div className="compaignDescription_outer clearfix">
                        <label>Total Quantity</label>
                        <div className="memberNumberOuter clearfix">


                            <div className="memberNumbe" style={{width: "50%",float:"left"}}>
                                <div className="numberFields clearfix">
                                    <input  type="number" placeholder="Total Quantity" style={{width:100+'%'}} value={this.state.total_quantity} onChange={(e) => {this.handleFromIputs(e)}}/>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>

            </div>
        );
    }//..... end of render() .....//

}//..... end of MembershipNumber.

export default ReceiptScanning;