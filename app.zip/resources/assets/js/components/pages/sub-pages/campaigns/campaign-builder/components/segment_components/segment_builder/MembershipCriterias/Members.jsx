import React, {Component} from 'react';
import { Scrollbars } from 'react-custom-scrollbars';
import Autocomplete from "react-autocomplete";

class Members extends Component {
    customDropDownSpanRef = null;
    customDropDownShowRef = null;

    constructor (props) {
        super(props);
        this.state = {
            from: '',
            to: '',
            searchValue: [],
            value: "",
            email_test_recipents: [],
        };
    }

    memberNumber = ['More Than', 'Less Than', 'Equal To', 'Not Equal To', 'Between'];



    setValueSelected = (value) => {
        let preVal = this.props.criteria.value;
        preVal.memberNumber = value;
        this.setCriteriaValue(preVal);

        this.customDropDownShowRef.style.display = 'none';
        this.customDropDownSpanRef.classList.remove('changeAero');
    };//..... end of setValueSelected() .....//

    setCriteriaValue = (value) => {
        this.props.setCriteriaValue('members', 'value', value);
    };//..... end of setCriteriaValue() .....//

    componentDidMount = () => {
        this.setState({email_test_recipents:this.props.criteria.value});
    };//..... end of componentDidMount() .....//

    handleFromMemberIputs = (e) => {

            this.setState({
                from:  parseInt(e.target.value)
            });

            let preVal = this.props.criteria.value;
            preVal.from = parseInt(e.target.value);
            this.setCriteriaValue(preVal);
    };

    handleToMemberIputs = (e, i) => {
        this.setState({
                to:  parseInt(e.target.value)
            });

            let preVal = this.props.criteria.value;
            preVal.to = parseInt(e.target.value);
            this.setCriteriaValue(preVal);

    };//..... end of handleToIputs() ......//

    handleDropDownSpanClick = (e) => {
        e.target.classList.toggle('changeAero');
        this.customDropDownShowRef.style.display =  (this.customDropDownShowRef.style.display === 'none') ? 'block' : 'none';
    };//..... end of handleDropDownSpanClick() .....//

    onChangeSearch = (e) => {
        let value = e.target.value;
        this.setState(() => ({value}));
        show_loader();
        axios.post(BaseUrl + '/api/getMembershipType', {
            value: value,
            searchBy: 'app'
        }).then(res => {
            this.setState(() => ({searchValue: res.data.data}));
            show_loader(true);

        }).catch((err) => {
            show_loader(true);

        });
    };
    onSelectSearch = (e, stateKey,value2) => {
        let value = this.state[stateKey];
        value.push(e);
        var unique = value.filter((v, i, a) => a.indexOf(v) === i);
        this.setState(() => ({[value2]: "", searchValue:[], [stateKey]: unique}), () => {
            this.setCriteriaValue(this.state[stateKey]);
        });

    };

    removeRecipent = (removeValue, stateKey,value2) => {
        let value = this.state[stateKey];
        let v = value.filter((v, k) => {
            return v != removeValue;
        });
        this.setState(() => ({[value2]: "", [stateKey]: v}), () => {
            console.log(this.state[stateKey]);
            this.setCriteriaValue(this.state[stateKey]);
        });
    }


    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//

    render() {
        return (
            <div className="dropSegmentation_section">
                <div className="dropSegmentation_heading clearfix">
                    <h3>Select Members</h3>
                    <div className="segmntClose" onClick={(e)=> {this.props.removeCriteria('members')}}>
                        <a  style={{cursor:'pointer'}}>&nbsp;</a>
                    </div>
                </div>
                <div className="stateSegmentation">
                    <div className="compaignDescription_outer clearfix showTags">
                        <div className=" numberFields_1 numberFields">
                            <Autocomplete
                                getItemValue={(item) => item.label}
                                items={this.state.searchValue}
                                renderItem={(item, isHighlighted) =>
                                    <div style={{ background: isHighlighted ? 'lightgray' : 'white' }}>
                                        {item.label}
                                    </div>
                                }
                                value={this.state.value}
                                onChange={(e)=>{this.onChangeSearch(e)}}
                                onSelect={(e)=>{this.onSelectSearch(e,"email_test_recipents","value")}}
                            />
                        </div>
                        {this.state.email_test_recipents.map((value,key)=>{
                            return (
                                <a key={key} style={{marginTop:"5px"}} href="javascript:void(0)">{value}<i onClick={(e)=>{this.removeRecipent(value,"email_test_recipents","value")}}>&nbsp;</i></a>
                            )
                        })}

                    </div>
                </div>
            </div>
        );
    }//..... end of render() .....//

}//..... end of MembershipNumber.

export default Members;