import React, {Component} from 'react';
import ReactPaginate from 'react-paginate';
import {NotificationManager} from 'react-notifications';
import {connect} from "react-redux";


import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import {
    addMessageBuilderValue,
    setSelectedEmailTemplate,
    setSelectedMailDrop
} from "../../../../../../redux/actions/CampaignBuilderActions";
import {selectMessageBuilderObject} from "../../../../../../redux/selectors/Selectors";
import UserRole from "../../../../venue/UserRole";

class MailDropBuilder extends Component {
    constructor(props) {
        super(props);

        this.state = {
            data        : [],
            selectedPage: 0,
            totalRecords: 0,
            perPageCount: 12,
            EmailType   : 1,
            html        :"",
            preview_template_id        :0,
        };
    }//..... end of constructor() .....//

    handlePaginationClick = (data) => {
        this.setState((prevState) => ({selectedPage: data.selected}), () => {this.getTemplateList()});
    };//..... end of handlePaginationClick() .....//

    componentDidMount() {
        this.getTemplateList();
        setTimeout(()=>{
            let userData = JSON.parse(localStorage.getItem('userData'));
            let user_email = userData.email;
            this.setMessageValue("user_email",user_email);
        },800);
    }//..... end of componentDidMount() .....//

    selectTemplate = (e,template) => {

        this.setMessageValue("mailDrop",template);

    };//..... end of selectTemplate() .....//

    getTemplateList() {
        show_loader();
            axios.get(`${BaseUrl}/api/get-mail-drop?page=${this.state.selectedPage}&perPage=${this.state.perPageCount}`)
                .then((response) => {
                    show_loader(true);
                    if(response.data.status == true){
                        this.setState(() => ({
                            data: response.data.data,
                            totalRecords: response.data.totalRecords
                        }));
                    }

                }).catch(err => {
                show_loader(true);
                NotificationManager.error("Error occurred while getting Templates List.", 'Error');
            });
    }//..... end of getTemplateList() ......//

    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//

    viewTemplate = (id) => {

        axios.get(`${BaseUrl}/api/get-template/${id}`)
            .then((response) => {

                if(response.data.status == true){
                    this.setState(()=>({html:response.data.html,preview_template_id:id}),()=>{
                        this.openPopup();
                    });
                }

            }).catch(err => {

            NotificationManager.error("Error occurred while getting Templates List.", 'Error');
        });
    };

    openPopup = () => {
        this.NewsCatPopup.style.display = "block";
    };

    closePopup = () => {
        this.NewsCatPopup.style.display = "none";
        this.setState(()=>({html:""}));
    };

    setMessageValue = (key, value) => {
        let other = {...this.props.messageBuilder.other};
        other.content[key] = value;
        this.props.dispatch(addMessageBuilderValue({
            [this.props.currentChannel]: {
                ...this.props.messageBuilder,
                other: {...other}
            }
        }));
    };//..... end of setMessageValue() .....//

    render() {
        return (
            <div className="messageBuilder_outer tempLibrary myClass">
                <div className="messageBuilder_heading">
                    <h3>Mail Drop Templates</h3>

                    {/*   <select onChange={(e)=>{this.getTemplate(e.target.value)}} style={{border:"1px solid lightgray",width:"200px",marginLeft:"974px",float:"left",marginTop:"10px",height:"27px"}}>
                        <option value="1">Decendra</option>
                        <option value="2">Engage</option>
                    </select>*/}
                </div>




                <div className="templateLibrary_listing">
                    <ul>
                        {
                            this.state.data.map((record) => (
                                <li key={record.id} onClick={(e)=>{ this.selectTemplate(e,record)}}>
                                    <div className={((this.props.messageBuilder.other.content.hasOwnProperty("mailDrop")) && this.props.messageBuilder.other.content.mailDrop.id === record.id) ? 'listHighlight templateLibrary_column': 'templateLibrary_column'}>
                                        <a  style={{cursor:'pointer'}}>
                                            {/*<img src={record.image} alt={record.name} />*/}
                                        </a>
                                        <div className="templateLibrary_text">
                                            <small>Date Created: {record.date}</small>
                                            <h4>Name: {record.name}</h4>
                                            <h4>SKU: {record.sku}</h4>
                                        </div>
                                    </div>
                                </li>
                            ))
                        }
                    </ul>
                </div>
                <Pagination handlePaginationClick={this.handlePaginationClick} totalRecords={this.state.totalRecords} perPage={this.state.perPageCount}/>

                <div className= "popups_outer addNewsCategoryPopup" ref={(ref)=>{this.NewsCatPopup = ref}} style={{display: 'none'}}>

                    <div className="popups_inner">
                        <div className="overley_popup" data-attr="addNewUser_popup" onClick={()=>this.closePopup()}></div>
                        <div className="popupDiv3">
                            <div className="popupDiv_detail">
                                <div className="popup_heading clearfix">
                                    <h3>Email Preview</h3>
                                    <a href="javascript:void(0)" data-attr="addNewUser_popup" className="popupClose close_popup" onClick={()=>this.closePopup()}>&nbsp;</a>
                                </div>

                                <div className="beacon_popupDeatail3">
                                    <div className="beacon_popup_form">
                                        <div className="venueIdentification_form" style={{height:"calc(100vh - 100px)"}}>
                                            <ul style={{height:"100%"}}>
                                                <li style={{height:"100%"}} >
                                                    <iframe src={BaseUrl+"/list-email-view/"+this.state.preview_template_id+"?venue_id="+VenueID} frameBorder="0"
                                                            style={{overflow:"hidden",height:"",width:"100%"}}
                                                            width="100%"></iframe>

                                                </li>

                                            </ul>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        );
    }//..... end of render() .....//
}//..... end of MailDropBuilder.

function Pagination(props) {
    const totalRecords = parseInt(props.totalRecords) / parseInt(props.perPage);
    return (
        <div className="campLstng_paginaton_out">
            <div className="campLstng_paginaton_inn">
                <ReactPaginate previousLabel={""}
                               nextLabel={""}
                               nextLinkClassName={'campPagi_next'}
                               breakLabel={<a href="">...</a>}
                               breakClassName={"break-me"}
                               pageCount={totalRecords}
                               marginPagesDisplayed={2}
                               pageRangeDisplayed={5}
                               previousLinkClassName={'campPagi_prev'}
                               onPageChange={props.handlePaginationClick}
                               activeClassName={"active"}/>
            </div>
        </div>
    );
}//..... end of Pagination() ......//

const mapStateToProps = (state) => {
    return {
        messageBuilder  : selectMessageBuilderObject(state.campaignBuilder.messageBuilder, state.campaignBuilder.currentChannel),
        currentChannel  : state.campaignBuilder.currentChannel
    };
};
export default connect(mapStateToProps)(MailDropBuilder);