import React, {Component} from 'react';
import { Scrollbars } from 'react-custom-scrollbars';
import {NotificationManager} from "react-notifications";
import {find, trim} from 'lodash';

import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import moment from "moment";
import 'react-image-crop/dist/ReactCrop.css';

import MultiSelectReact from "multi-select-react";
import MultiSelectCustom from "./MultiSelectCustom";
import {validateRecipeOfferData} from "../../utils/Validations";
import {resetDropDownsData, setRedemptionFrequency} from "../../redux/actions/PunchCardActions";


class AppData extends Component {
    customDropDownRedSpanRef = null;
    heading_types = [
        {
            "field":"about",
            "label": "About"
        },
        {
            "field":"council_services",
            "label": "Council & Services"
        }

    ];
    constructor(props) {
        super(props);
        this.state = {
            headings: [],
            response_data: [],
            response_status: false,
            final_arr: [],
            new_heading: false,
            heading_data: {
                name: '',
                type: ''
            }
        }
        this.final_arr = [];
        this.changed_arr = [];
    }

    componentDidMount() {
      this.loadData();
    };//..... end of componentDidMount() .....//



    makeFinalArray = (data) => {

        if(this.final_arr.length == 0) {

            this.final_arr.push(data);
            this.changed_arr.push(data);
        }
        else {
            this.changed_arr = this.final_arr;
            this.final_arr.map((value,key) => {
                let find = this.final_arr.find(o => o.id === data.id);
                if(find) {
                    this.changed_arr[key] = value;
                }
                else {
                    this.changed_arr.push(data);
                }
            });
        }

        //this.final_arr = this.changed_arr;
        console.log(this.changed_arr);

    };

    loadData = () => {
        show_loader();
        axios.post(BaseUrl + '/api/get-headings-data').then((response) => {
            show_loader(true);
            if (response.data.status) {
                this.setState({response_data: response.data.data,response_status: true});
            } else {
                NotificationManager.error(response.data.message, 'Error');
            }//..... end if-else() .....//

            show_loader(true);
        }).catch((err)=> {
            show_loader(true);
            console.log(err);
            NotificationManager.error("Error occurred while fetching headings data, please try later.", 'Error');
        });
    };

    saveData = () => {
        var validation_error = false;
        if(this.final_arr.length == 0) {
            NotificationManager.warning("Please Select mapping", 'Missing Fields');
            return false;
        }
        else {
            this.final_arr.map(function (arr) {
                if(arr.url.length == 0 && arr.check_url == true) {
                    validation_error = true;
                    return false;
                }
            });
            if(validation_error) {
                NotificationManager.warning("Please Select URL", 'Missing Fields');
                return false;
            }
        }
        //new heading validation
        if(this.state.new_heading) {
            if(this.state.heading_data.name.length == 0 || this.state.heading_data.type == 0) {
                NotificationManager.warning("Select heading type and name", 'Missing Fields');
                return false;
            }
        }

        show_loader();
        axios.post(BaseUrl + '/api/save-map-data', {map_data:this.final_arr,heading_data:this.state.heading_data}).then((response) => {
            show_loader(true);
            if (response.data.status) {
                NotificationManager.success(response.data.message, 'Success');
                this.removeHeading();
                this.loadData();
            } else {
                NotificationManager.error(response.data.message, 'Error');
            }//..... end if-else() .....//
        }).catch((err)=> {
            show_loader(true);
            NotificationManager.error("Error occurred while mapping data", 'Error');
        });
    };
    //..... end of saveData() .....//

    addHeading = () => {
        this.setState({new_heading : !this.state.new_heading});
    };
    removeHeading = () => {
        this.setState( (prevState) => ({new_heading:false, heading_data: {...prevState.heading_data,type: "",name:""}}) );
    };

    saveNewHeading = () => {
        if(this.state.heading_data.name.length == 0 || this.state.heading_data.type == 0) {
            NotificationManager.warning("Select heading type and name", 'Missing Fields');
            return false;
        }
        show_loader();
        axios.post(BaseUrl + '/api/save-new-heading', {heading_data:this.state.heading_data}).then((response) => {
            show_loader(true);
            if (response.data.status) {
                NotificationManager.success(response.data.message, 'Success');
            } else {
                NotificationManager.error(response.data.message, 'Error');
            }//..... end if-else() .....//
        }).catch((err)=> {
            show_loader(true);
            NotificationManager.error("Error occurred while saving data", 'Error');
        });
    };
    handleDropDownRedSpanClick = (e) => {
        e.target.classList.toggle('changeAero');
        this.customDropDownShowRedRef.style.display = this.customDropDownShowRedRef.style.display === 'none' ? 'block' : 'none';
    };//..... end of handleDropDownRedSpanClick() .....//

    setHeadingType = (headingType) => {
        this.customDropDownShowRedRef.style.display = 'none';
        this.customDropDownRedSpanRef.classList.remove('changeAero');
        this.setState( (prevState) => ({heading_data: {...prevState.heading_data,type: headingType}}) );

    };//..... end of setRedemptionType() .....//



    render() {
        const selectedOptionsStyles = {
            color: "#3c763d",
            backgroundColor: "#dff0d8",
        };
        const optionsListStyles = {
            backgroundColor: "#fcf8e3",
            color: "#8a6d3b",
        };
        return (
            <div className="newVualt_container">
                <div className="newVualt_container_detail">

                    <div className="newVualt_detail_outer">
                        <div className="newVualt_detail">
                            <div className="newVualt_heading_with_buttons clearfix">
                                <div className="newVualt_heading">
                                    <h3>Parse Data Mapping</h3>
                                </div>
                            </div>

                            <div className="categoryInfo_container clearfix ">
                                {
                                    this.state.response_status &&
                                        this.state.response_data.map((data) => {
                                            return <MultiSelectCustom key={data.id} map_data={data} onSelectData={this.makeFinalArray}/>
                                        })
                                }


                                {
                                    this.state.new_heading &&
                                    <div style={{marginTop:"10px"}}>
                                        <input
                                            style={{"width":"50%","verticalAlign":"middle","borderRadius":"6px",
                                                "border":"solid 1px #d2d6dd","padding": "8px 15px"}}
                                            type="text" name="heading_name"
                                            value={this.state.new_heading_name}
                                            placeholder="Enter Heading Name"
                                            onChange={(e) => {
                                                let name = e.target.value;
                                                this.setState( (prevState) => ({heading_data: {...prevState.heading_data,name}}) );
                                            }}
                                        />
                                        <div className="dropSegmentation_section" style={{width:"49%",margin:"0px",float:"right",height:"89px"}}>
                                            <div className="dropSegmentation_heading clearfix">
                                                <h3>Select Type</h3>
                                            </div>
                                            <div className="stateSegmentation add_heading">
                                                <div className="venueIdentification_section">
                                                    <div className="customDropDown">
                                                    <span ref={ref => this.customDropDownRedSpanRef = ref}
                                                          onClick={this.handleDropDownRedSpanClick}> {this.state.heading_data.type ? (find(this.heading_types, {field: this.state.heading_data.type})).label : 'Select type'}</span>
                                                        <ul className="customDropDown_show customPlaceHolder"
                                                            ref={ref => this.customDropDownShowRedRef = ref} style={{
                                                            marginBottom: '30px',
                                                            marginTop: '-10px',
                                                            maxHeight: '207px',
                                                            display: 'none'
                                                        }}>
                                                            <Scrollbars autoHeight renderTrackHorizontal={() => <div></div>}
                                                                        renderThumbHorizontal={() => <div></div>}>
                                                                {
                                                                    this.heading_types.map((headingType) => {
                                                                        return <li key={headingType.field} onClick={(e) => {
                                                                            this.setHeadingType(headingType.field)
                                                                        }}
                                                                                   className={this.state.heading_data && headingType.field === this.state.heading_data.type ? 'selectedItem' : ''}>{headingType.label}</li>;
                                                                    })
                                                                }
                                                            </Scrollbars>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                }

                                {
                                    this.state.new_heading ?

                                        <div className="remove_heading">
                                            <a onClick={this.removeHeading}  href="javascript:void(0)"><strong><i>&nbsp;</i>Cancel</strong></a>
                                        </div>


                                        :
                                        <div className="remove_heading">
                                            <a href="javascript:void(0)" className="remove_heading" onClick={this.addHeading}>Add</a>
                                        </div>

                                }


                            </div>


                        </div>
                    </div>

                    <br/>
                    <div className="continueCancel  listShops" style={{marginTop: "10px"}}>
                        <a href="javascript:void(0)" className="" onClick={this.saveData}>Save</a>
                    </div>
                </div>
            </div>
        );
    }//..... end of render() .....//
}//..... end of AddPunchCard.

export default AppData;
