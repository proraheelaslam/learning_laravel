import React, {Component} from 'react';
import VoucherReport from "./sub-pages/Reports/VoucherReport";
import StampcardReport from "./sub-pages/Reports/StampcardReport";
import CampaignReporting from "./sub-pages/Reports/CampaignReporting";


import PointReport from "./sub-pages/Reports/PointReport";

import Badge from "./sub-pages/Reports/Badges/Badge";



class ManageComponent extends Component {
    constructor(props) {
        super(props);
        console.log('props',this.props);
        let voucher_id = 0;
        if(this.props.match)
            if(this.props.match.params)
                if(this.props.match.params.id)
                    voucher_id = this.props.match.params.id;

        this.state = {refreshComponent:true,currentTab:'voucher',showTab:true,voucher_id:voucher_id,showPoints:false,showPunch:true};

        this.setActiveTab = this.setActiveTab.bind(this);
    }//..... end of constructor() ....//
    componentDidCatch = (error, info) => {
        show_loader(true);
    };//...... end of componentDidCatch() .....//
    componentDidMount = () => {
          this.getConfiguration();
          if(this.props.location && this.props.location.pathname) {
              if((this.props.location.pathname.indexOf("/voucher") >= 0)){
                  this.setState((prevState)=>({showTab:!prevState.showTab}));
              }
          }

    }

    getConfiguration = () =>{
        let url = BaseUrl + '/api/get-configuration';

        axios.post(url, {
        }).then(res => {

            if (res.data.status) {

                this.setState(()=>({
                    showPoints:  (res.data.points ==1)?true:false,
                    showPunch :  (res.data.punch_card ==1)?true:false,
                }));
                show_loader(true);
            } else {

                show_loader(true);
                this.setState({showListError: true});
            }
        }).catch((err) => {

            show_loader(true);
            this.setState({showListError: true});
        });
    }

    render() {
        return (
            <div>
                <div className="compaignstabsBttns clearfix">
                    <a  style={{cursor:'pointer'}}  onClick={(e)=>{ this.setActiveTab('voucher') }} className={this.state.currentTab == 'voucher' ? 'compaignsActive' : ''}>Voucher</a>
                    {
                        (this.state.showTab && this.state.showPunch) && (
                            <a  style={{cursor:'pointer'}}  onClick={(e)=>{ this.setActiveTab('stampcard') }} className={this.state.currentTab == 'stampcard' ? 'compaignsActive' : ''}>Stampcard</a>
                        )

                    }


                    {
                        (this.state.showPoints) && (
                            <a  style={{cursor:'pointer'}}  onClick={(e)=>{ this.setActiveTab('points') }} className={this.state.currentTab == 'points' ? 'compaignsActive' : ''}>Points</a>
                        )
                    }

                </div>

                <div className="contentDetail">
                    <div className="autoContent">
                        <div className="contentinner">

                            {
                                this.loadActiveComponent()
                            }

                        </div>
                    </div>
                </div>
            </div>
        );
    }//..... end of render() .....//

    setActiveTab(tab) {
        this.setState({currentTab: tab,refreshComponent: !this.state.refreshComponent});
    }//..... end of setActiveTab() .....//

    navigateToCampaignBuilder = (e, slug) => {
        if (e)
            e.preventDefault();
        this.setState({current_page: slug});
        this.props.history.push(slug);
    };//..... end of navigateToCampaignBuilder() .....//
    loadActiveComponent = () => {

        switch (this.state.currentTab){
            case "voucher" :
                return <VoucherReport navigate={this.navigateToCampaignBuilder} voucher_id={this.state.voucher_id}/>;
            case "stampcard" :
                return <StampcardReport />;

            case "points":
                return <PointReport />;
            default :
                return "";
        }
    };
}//..... end of members() .....//

export default ManageComponent;
